sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/BusyIndicator",
    "com/jabil/costrollmaintenance/util/jszip",
    "com/jabil/costrollmaintenance/util/xlsx",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller, BusyIndicator, jszip, xlsx, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("com.jabil.costrollmaintenance.controller.MainView", {
        onInit: function () {
            this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            this.oModel = this.getOwnerComponent().getModel();
            this.ov4Model = this.getOwnerComponent().getModel("v4Model");
        },

        // Action on List Item press to get the pressed list Item ID
        onListItemPress: function (oEvent) {
            var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();
            this.getSplitAppObj().toDetail(this.createId(sToPageId));
            this.getSplitAppObj().hideMaster();
        },

        // Action on List Item press to Load the pressed list Item
        getSplitAppObj: function () {
            var result = this.byId("SplitAppMaintenance");
            if (!result) {
                Log.info("SplitApp object can't be found");
            }
            return result;
        },

        onApprovalMatrixMasterDataUpload: function (oEvent) {
            this.showBusyIndicator();
            this.parseMasterDataAttachmentUpload(oEvent.getParameter("files")[0]).then(function () {
                this.hideBusyIndicator();
            }.bind(this));
        },

        parseMasterDataAttachmentUpload: function (oFile) {
            return new Promise(async function (resolve, reject) {
                var reader = new FileReader();
                reader.onload = async function (e) {
                    var data = e.currentTarget.result;
                    var excelsheet = xlsx.read(data, {
                        type: "binary"
                    });
                    var aMasterData = [];
                    var aExcelLineItems = [];
                    var aPromises = [];
                    for (var i = 0; i < excelsheet.SheetNames.length; i++) {
                        if (excelsheet.SheetNames[i].includes("SAPUI5 Export")) {
                            aExcelLineItems = await xlsx.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[i]]); // this is the required data in Object format
                        }
                    }
                    var oPayload = {};
                    var bValidTemplate = Boolean(aExcelLineItems.length > 0 && aExcelLineItems[0]["Company Code"] && aExcelLineItems[0]["Plant Code"]
                        && aExcelLineItems[0]["Profit Center"] && aExcelLineItems[0]["Material Type"]);
                    if (bValidTemplate) {
                        aExcelLineItems.forEach(function (oItem) {
                            oPayload = {
                                "companyCode": oItem["Company Code"].toString(),
                                "plantCode": oItem["Plant Code"].toString(),
                                "profitCenter": oItem["Profit Center"].toString(),
                                "materialType": oItem["Material Type"].toString(),
                            };
                            aPromises.push(this.performMassCreate(oPayload, "/MasterData"));
                        }.bind(this));
                        Promise.all(aPromises).then(function () {
                            MessageBox.success(this.i18n.getText("massUploadSuccessMasterData"));
                            this.byId("smartFilterBarMasterDataAppr").search();
                            resolve();
                        }.bind(this), function (sError) {
                            MessageBox.error(sError);
                            this.hideBusyIndicator();
                            reject();
                        }.bind(this));
                    } else {
                        MessageBox.information(this.i18n.getText("validationFailedExcel"));
                        this.hideBusyIndicator();
                    }
                }.bind(this);
                reader.readAsArrayBuffer(oFile);
            }.bind(this));
        },

        performMassCreate: function (oItem, sPath) {
            return new Promise(async function (resolve, reject) {
                var oList = this.ov4Model.bindList(sPath);
                var oContext = oList.create(oItem, true);
                oList.attachCreateCompleted(await function (oEvent) {
                    if (oEvent.getParameters().success) {
                        resolve();
                    } else {
                        reject(this.i18n.getText(this.i18n.getText("operationFailedMsg")));
                    }
                }.bind(this));
            }.bind(this));
        },

        onVariantAttachmentUpload: function (oEvent) {
            this.showBusyIndicator();
            this.parseVariantAttachmentUpload(oEvent.getParameter("files")[0]).then(function () {
                this.hideBusyIndicator();
            }.bind(this));
        },

        parseVariantAttachmentUpload: function (oFile) {
            return new Promise(async function (resolve, reject) {
                var reader = new FileReader();
                reader.onload = async function (e) {
                    var data = e.currentTarget.result;
                    var excelsheet = xlsx.read(data, {
                        type: "binary"
                    });
                    var aMasterData = [];
                    var aExcelLineItems = [];
                    var aPromises = [];
                    for (var i = 0; i < excelsheet.SheetNames.length; i++) {
                        if (excelsheet.SheetNames[i].includes("SAPUI5 Export")) {
                            aExcelLineItems = await xlsx.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[i]]); // this is the required data in Object format
                        }
                    }
                    var oPayload = {};
                    var bValidTemplate = Boolean(aExcelLineItems.length > 0 && aExcelLineItems[0]["Company Code"] && aExcelLineItems[0]["Plant Code"]
                        && aExcelLineItems[0]["Costing Type"] && aExcelLineItems[0]["Cost Variant"])
                    if (bValidTemplate) {
                        aExcelLineItems.forEach(function (oItem) {
                            oPayload = {
                                "companyCode": oItem["Company Code"].toString(),
                                "plantCode": oItem["Plant Code"].toString(),
                                "costingType": oItem["Costing Type"].toString(),
                                "costVariant": oItem["Cost Variant"].toString(),
                            };
                            aPromises.push(this.performMassCreate(oPayload, "/HeaderValues"));
                        }.bind(this));
                        Promise.all(aPromises).then(function () {
                            MessageBox.success(this.i18n.getText("massUploadSuccessVariant"));
                            this.byId("SmartFilterVarForCreate").search();
                            resolve();
                        }.bind(this), function (sError) {
                            MessageBox.error(sError);
                            this.hideBusyIndicator();
                            reject();
                        }.bind(this));
                    } else {
                        MessageBox.information(this.i18n.getText("validationFailedExcel"));
                        this.hideBusyIndicator();
                    }
                }.bind(this);
                reader.readAsArrayBuffer(oFile);
            }.bind(this));
        },

        onDeleteMasterData: function (oEvent) {
            var aIndices = this.byId("UITabMasterData").getSelectedIndices();
            if (!aIndices.length) {
                MessageToast.show(this.i18n.getText("noItemSelected"));
                return;
            }

            MessageBox.confirm(this.i18n.getText("DeleteConfirm"), {
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                emphasizedAction: MessageBox.Action.OK,
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        this.handleDelete(aIndices, "/MasterData", "UITabMasterData");
                    }
                }.bind(this)
            });
        },

        onDeleteVariant: function (oEvent) {
            var aIndices = this.byId("UITabVariantData").getSelectedIndices();
            if (!aIndices.length) {
                MessageToast.show(this.i18n.getText("noItemSelected"));
                return;
            }

            MessageBox.confirm(this.i18n.getText("DeleteConfirm"), {
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                emphasizedAction: MessageBox.Action.OK,
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        this.handleDelete(aIndices, "/HeaderValues", "UITabVariantData");
                    }
                }.bind(this)
            });
        },

        handleDelete: function (aIndices, sEntity, sTabId) {
            var aPromises = []; var oItem; var sKey;
            aIndices.forEach((iIndex) => {
                oItem = this.oModel.getProperty(this.byId(sTabId).getContextByIndex(iIndex).getPath());
                sKey = this.getKey(oItem, sEntity);
                aPromises.push(this.performDelete(sKey));
            });
            Promise.all(aPromises).then(function () {
                this.oModel.refresh();
                MessageToast.show(this.i18n.getText("deleteItemMsg"));
                this.hideBusyIndicator();
            }.bind(this), function (sError) {
                MessageBox.error(this.i18n.getText("deleteoperationFailed"));
                this.hideBusyIndicator();
            }.bind(this));
        },

        getKey: function (oItem, sEntity) {
            var sKey;
            if (sEntity === "/MasterData") {
                sKey = this.oModel.createKey(sEntity, {
                    companyCode: oItem.companyCode,
                    plantCode: oItem.plantCode,
                    profitCenter: oItem.profitCenter,
                    materialType: oItem.materialType
                });
            } else {
                sKey = this.oModel.createKey(sEntity, {
                    companyCode: oItem.companyCode,
                    plantCode: oItem.plantCode,
                    costingType: oItem.costingType,
                    costVariant: oItem.costVariant
                });
            }
            return sKey;
        },

        performDelete: function (sKey) {
            return new Promise(async function (resolve, reject) {
                this.oModel.remove(sKey, {
                    success: function (odata) {
                        resolve();
                    }.bind(this),
                    error: function (oError) {
                        reject(oError)
                    }.bind(this)
                });
            }.bind(this));
        },

        hideBusyIndicator: function () {
            BusyIndicator.hide();
        },

        // Shows busy indicator
        showBusyIndicator: function () {
            BusyIndicator.show();
        }
    });
});