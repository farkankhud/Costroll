sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageToast",
        "sap/m/MessageBox",
        "sap/ui/core/BusyIndicator",
        "sap/ui/core/Fragment",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator"
    ],
    function (BaseController, JSONModel, MessageToast, MessageBox, BusyIndicator, Fragment, Filter, FilterOperator) {
        "use strict";

        return BaseController.extend("com.jabil.costrollmanageroute.controller.ManageRoute", {
            onInit: async function () {
                this.oRouter = this.getOwnerComponent().getRouter();
                this.oModel = this.getOwnerComponent().getModel("v4Model");
                this.oCostRollModel = this.getOwnerComponent().getModel("costRollModel");
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                this.oRouter.getRoute("RouteApp").attachPatternMatched(this.onManageRoutePatternMatched, this);
                this._MessageManager = sap.ui.getCore().getMessageManager();
                this._MessageManager.registerObject(this.getView(), true);
                this.getOwnerComponent().setModel(this._MessageManager.getMessageModel(), "message");
                // Model to bind properties to handle view
                this.getView().setModel(this.getViewModelObject(), "ViewModel");
                this.getView().getModel("ViewModel").setSizeLimit(150000);
                this.setRouteCreateModel();
                this.showBusyIndicator();
                this.readValueHelpData(false);

                if (this.getOwnerComponent().getComponentData() && this.getOwnerComponent().getComponentData().startupParameters && this.getOwnerComponent().getComponentData().startupParameters.routeID) {
                    this.sRouteID = this.getOwnerComponent().getComponentData().startupParameters && this.getOwnerComponent().getComponentData().startupParameters.routeID;
                }
            },

            onSmartFilterBarInitialised: function () {
                if (this.sRouteID) {
                    this.byId("ManageRoutesSmartFilter").setFilterData({
                        "routeID": {
                            "items": [{
                                "key": this.sRouteID,
                                "text": ""
                            }]
                        }
                    });
                    this.byId("ManageRoutesSmartFilter").fireSearch();
                }
            },

            readValueHelpData: function (bDraftRefresh) {
                return new Promise(async function (resolve, reject) {
                    this.showBusyIndicator();
                    var aPromises = [];
                    var oValueHelpModel = new JSONModel({
                        "CompanyCodes": [],
                        "Plant": [],
                        "AllData": [],
                        "ArrayCompanyCode": [],
                        "ArrayPlantCode": []
                    });
                    this.setValueHelpModel(oValueHelpModel);
                    aPromises.push(this.readMasterDataVH(bDraftRefresh));
                    aPromises.push(this.readEmails());
                    Promise.all(aPromises).then(function () {
                        resolve();
                    }, function (sError) {
                        reject(sError);
                    });
                }.bind(this));
            },

            readMasterDataVH: function (bDraftRefresh) {
                return new Promise(async function (resolve, reject) {
                    var oOperation = this.oCostRollModel.bindContext("/getUserRoles(...)");
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        var aCompanyCode = [], aPlant = [], aDraft = [], aRouteID = [];
                        var aArrayCompanyCode = [], aArrayPlantCode = [];
                        if (!bDraftRefresh) {
                            oOperationContext.getObject().AllData.forEach((oItem) => {
                                aArrayCompanyCode.push(oItem.COMPANYCODE);
                                aArrayPlantCode.push(oItem.PLANTCODE);
                            });
                            aArrayCompanyCode = [...new Set(aArrayCompanyCode)];
                            aArrayPlantCode = [...new Set(aArrayPlantCode)];
                            aArrayCompanyCode.forEach(function (sCompanyCode) {
                                aCompanyCode.push({
                                    "COMPANYCODE": sCompanyCode
                                });
                            });
                            aArrayPlantCode.forEach(function (sPlant) {
                                aPlant.push({
                                    "PLANTCODE": sPlant
                                });
                            });
                            // oOperationContext.getObject().Draft.forEach((sDraft) => {
                            //     aDraft.push({
                            //         "draft": sDraft
                            //     });
                            // });
                            // oOperationContext.getObject().RouteID.forEach((sRouteID) => {
                            //     aRouteID.push({
                            //         "routeID": sRouteID
                            //     });
                            // });
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/CompanyCodes", aCompanyCode);
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/Plant", aPlant);
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/AllData", oOperationContext.getObject().AllData);
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayCompanyCode", aArrayCompanyCode);
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", aArrayPlantCode);
                            this.filterPlantBasedOnComp("");
                        }
                        this.hideBusyIndicator();
                        resolve();
                    }.bind(this)).catch(function () {
                        this.setValueHelpModel();
                        this.hideBusyIndicator();
                        reject();
                    }.bind(this));
                }.bind(this))
            },

            readEmails: function () {
                return new Promise(async function (resolve, reject) {
                    var oOperation = this.oModel.bindContext("/getEmails(...)");
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        var aEmailId = [];
                        var aArrayEmailId = [];
                        oOperationContext.getObject().value[0].EmailIDs.forEach((oItem) => {
                            aArrayEmailId.push(oItem.USER);
                            aEmailId.push({
                                "EmailID": oItem.USER,
                                "Role": oItem.ROLENAME
                            });
                        });
                        this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/EmailID", aEmailId);
                        this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayEmailID", aArrayEmailId);
                        this.hideBusyIndicator();
                        resolve();
                    }.bind(this)).catch(function () {
                        this.setValueHelpModel();
                        this.hideBusyIndicator();
                        reject();
                    }.bind(this));
                }.bind(this))
            },

            setValueHelpModel: function (oValueHelpModel) {
                if (oValueHelpModel) {
                    this.getOwnerComponent().setModel(oValueHelpModel, "ValueHelpModel");
                } else {
                    this.getOwnerComponent().setModel(this.getValueHelpModelObject(), "ValueHelpModel");

                }

                this.getOwnerComponent().getModel("ValueHelpModel").setSizeLimit(150000);
            },
            getValueHelpModelObject: function () {
                var oValueHelpModel = new JSONModel({
                    "CompanyCodes": [],
                    "Plant": [],
                    "EmailID": [],
                    "AllData": [],
                    "ArrayCompanyCode": [],
                    "ArrayPlantCode": [],
                    "ArrayEmailID": []
                });
                return oValueHelpModel;
            },

            onManageRoutePatternMatched: function () {
                if (this.byId("ManageRoutesSmartFilter")) {
                    this.byId("ManageRoutesSmartFilter").fireSearch();
                }
            },

            getViewModelObject: function () {
                var oViewModel = new JSONModel({
                    "RowMode": "Interactive",
                    "PlantCodeValueState": "None",
                    "CompanyCodeValueState": "None"
                });
                return oViewModel;
            },

            setRouteCreateModel: function () {
                this.getView().setModel(this.getRouteCreateModelObject(), "RouteCreate");
                this.getView().getModel("RouteCreate").setSizeLimit(150000);
            },

            getRouteCreateModelObject: function () {
                var oRouteCreate = new JSONModel({
                    "routeName": "",
                    "appGP1": "",
                    "companyCode": "",
                    "plantCode": ""
                });
                return oRouteCreate;
            },

            onRouteClick: function (oEvent) {
                var oRoute = Object.assign({}, this.getOwnerComponent().getModel().getProperty(oEvent.getSource().getBindingContext().getPath()));
                this.setApproversInComponentModel(oRoute);
                this.oRouter.navTo("AddApprover", {
                    "?routeID": { "RouteID": oRoute.routeID }
                });
            },

            setApproversInComponentModel: function (oRoute) {

                var oApproverGroups = {
                    "routeID": oRoute.routeID,
                    "routeName": oRoute.routeName,
                    "Groups": [],
                    "SelectedGroup": ""
                };
                oApproverGroups.Groups = this.prepareGroupsForRoute(oRoute);
                oApproverGroups.SelectedGroup = oApproverGroups.Groups[0];
                this.getOwnerComponent().getModel("ComponentModel").setProperty("/", oApproverGroups);
            },

            prepareGroupsForRoute: function (oRoute) {
                var aGroups = [];

                aGroups.push({
                    "Key": 1,
                    "Name": this.i18n.getText("apprGroup1"),
                    "EmailIds": oRoute.appGP1 ? this.prepareEmailArray(oRoute.appGP1.split(",")) : []
                });
                aGroups.push({
                    "Key": 2,
                    "Name": this.i18n.getText("apprGroup2"),
                    "EmailIds": oRoute.appGP2 ? this.prepareEmailArray(oRoute.appGP2.split(",")) : []
                });
                return aGroups;
            },

            prepareEmailArray: function (aEmailIds) {
                var aGroups = [];
                aEmailIds.forEach((sEmail) => {
                    aGroups.push({
                        "EmailId": sEmail
                    });
                });
                return aGroups;
            },

            onClear: function () {
                this.resetViewModel();
                this.resetRouteCreateModel();
            },

            resetViewModel: function () {
                this.getView().setModel(this.getViewModelObject(), "ViewModel");
                this.getView().getModel("ViewModel").setSizeLimit(150000);

            },

            resetRouteCreateModel: function () {
                this.getView().setModel(this.getRouteCreateModelObject(), "RouteCreate");
                this.getView().getModel("RouteCreate").setSizeLimit(150000);
            },

            onSubmit: async function () {
                if (this.validateCreateRoute()) {
                    this.showBusyIndicator();
                    await this.performCreateRoute().then(function (sRouteName) {
                        this.hideBusyIndicator();
                        MessageToast.show(this.i18n.getText("routeCreateSuccessMsg", [sRouteName]));
                        this.resetRouteCreateModel();
                        this.byId("ManageRoutesSmartFilter").fireSearch();
                    }.bind(this))
                        .catch(function (sError) {
                            this.displayErrorMessage(sError);
                            this.hideBusyIndicator();
                        }.bind(this))
                }
            },

            displayErrorMessage: function () {
                if (typeof (sError) === "object") {
                    MessageBox.error(sError.toString());
                } else if (typeof (sError) === "string") {
                    MessageBox.error(sError);
                } else {
                    MessageBox.error(this.i18n.getText("operationFailedMsg"));
                }
            },

            validateCreateRoute: function () {
                var aValidationMessages = [], sValidatonMessage = "";
                if (!this.getView().getModel("RouteCreate").getProperty("/routeName")) {
                    aValidationMessages.push(this.i18n.getText("reqRouteNameMsg"));
                }
                if (!this.getView().getModel("RouteCreate").getProperty("/companyCode")) {
                    aValidationMessages.push(this.i18n.getText("reqCompanyCode"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/CompanyCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("compCodeInValidMsg"));
                }
                if (!this.getView().getModel("RouteCreate").getProperty("/plantCode")) {
                    aValidationMessages.push(this.i18n.getText("reqPlantCode"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/PlantCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("plantCodeInValidMsg"));
                }
                sValidatonMessage = aValidationMessages.join("\n\n");
                if (aValidationMessages.length > 0) {
                    MessageBox.information(this.i18n.getText("reqFieldsMissingMsg") + "\n\n" + sValidatonMessage);
                    return false;
                }
                return true;
            },

            performCreateRoute: function () {
                return new Promise(function (resolve, reject) {
                    var oList = this.oModel.bindList("/ManageRoutes");
                    var oPayload = this.prepareCreateRoutePayload();
                    var oContext = oList.create(oPayload, true);
                    oList.attachCreateCompleted(function (oEvent) {
                        if (oEvent.getParameters().success) {
                            var oResponseObject = oEvent.getParameters().context.getObject();
                            resolve(oResponseObject.routeName);
                        } else {
                            reject();
                        }
                    }.bind(this));
                }.bind(this));
            },

            prepareCreateRoutePayload: function () {
                var oPayload = JSON.parse(JSON.stringify(this.getView().getModel("RouteCreate").getProperty("/")));
                return oPayload;
            },

            onDelete: async function () {
                var aIndices = this.byId("ManageRoutesTable").getDependents()[0].getSelectedIndices();
                if (aIndices.length === 0) {
                    MessageToast.show(this.i18n.getText("noItemsSelectedDelete"));
                    return;
                }
                MessageBox.confirm(this.i18n.getText("DeleteConfirm"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: async function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            this.showBusyIndicator();
                            await this.handleDeleteRoute().then(function () {
                                MessageToast.show(this.i18n.getText("routeDeletedMsg"));
                                // this.byId("ManageRoutesSmartFilter").fireSearch();
                                this.byId("ManageRoutesSmartTable").rebindTable();
                                this.hideBusyIndicator();
                            }.bind(this))
                                .catch(function (oError) {
                                    this.displayErrorMessage(oError);
                                    this.hideBusyIndicator();
                                }.bind(this));
                        } else {
                            this.hideBusyIndicator();
                        }
                    }.bind(this)
                });

            },

            handleDeleteRoute: function () {
                return new Promise(async function (resolve, reject) {
                    var aIndices = this.byId("ManageRoutesTable").getDependents()[0].getSelectedIndices();
                    var aPromises = [];
                    var oContextBinding;
                    var oRoute;
                    aIndices.forEach((iIndex) => {
                        oRoute = this.getOwnerComponent().getModel().getProperty(this.byId("ManageRoutesTable").getContextByIndex(iIndex).getPath());
                        oContextBinding = this.oModel.bindContext("/ManageRoutes('" + oRoute.routeID + "')");
                        aPromises.push(this.performDeleteRoute(oContextBinding));
                    });
                    Promise.all(aPromises).then(function () {
                        resolve();
                    }, function (sError) {
                        reject(sError);
                    });
                }.bind(this));
            },

            performDeleteRoute: function (oContextBinding) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(async function () {
                        oContextBinding.getBoundContext().delete();
                        resolve();
                    }.bind(this), function () {
                        reject();
                    });
                }.bind(this));
            },

            hideBusyIndicator: function () {
                BusyIndicator.hide();
            },

            // Shows busy indicator
            showBusyIndicator: function () {
                BusyIndicator.show();
            },

            onCompanyCodeValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._companyCodeValueHelpDialog) {
                    this._companyCodeValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollmanageroute.fragment.CompanyCodeValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._companyCodeValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("COMPANYCODE", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onValueHelpCompanyCodeSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("COMPANYCODE", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpCompanyCodeClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);
                this.getView().getModel("RouteCreate").setProperty("/plantCode", "");

                if (!oSelectedItem) {
                    this.filterPlantBasedOnComp("");
                    return;
                }

                // this.getView().getModel("RouteCreate").setProperty("/companyCode", oSelectedItem.getTitle());
                this.getView().getModel("RouteCreate").setProperty("/companyCode", this.getView().getModel("ValueHelpModel").getProperty(oEvent.getParameter("selectedContexts")[0].getPath()).COMPANYCODE);
                this.filterPlantBasedOnComp(oSelectedItem.getTitle());
                // this.getView().getModel("ViewModel").setProperty("/CompanyCodeValueState", "None");
            },

            filterPlantBasedOnComp: function (sCompanyCode) {
                var aAllData = this.getOwnerComponent().getModel("ValueHelpModel").getProperty("/AllData");
                var aItems = aAllData.filter((oItem) => {
                    return oItem.COMPANYCODE === sCompanyCode
                });
                var aArrayPlantCode = [], aPlant = [];
                aItems.forEach((oItem) => {
                    aArrayPlantCode.push(oItem.PLANTCODE);
                });
                aArrayPlantCode = [...new Set(aArrayPlantCode)];
                aArrayPlantCode.forEach(function (sPlant) {
                    aPlant.push({
                        "PLANTCODE": sPlant
                    });
                });
                this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/Plant", aPlant);
                this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", aArrayPlantCode);
            },

            onCompanyCodeChange: function (oEvent) {
                this.getView().getModel("RouteCreate").setProperty("/plantCode", "");
                if (!oEvent.getParameters().value) {
                    this.filterPlantBasedOnComp("");
                    return;
                }
                if (this.getOwnerComponent().getModel("ValueHelpModel").getProperty("/ArrayCompanyCode").indexOf(oEvent.getParameters().value) === -1) {
                    this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/Plant", []);
                    this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", []);
                    oEvent.getSource().setValueState("Error");
                } else {
                    this.filterPlantBasedOnComp(oEvent.getParameters().value);
                }
            },

            // onEmailIDValueHelpRequest: function (oEvent) {
            //     var sInputValue = oEvent.getSource().getValue(),
            //         oView = this.getView();

            //     if (!this._EmailIDValueHelpDialog) {
            //         this._EmailIDValueHelpDialog = Fragment.load({
            //             id: oView.getId(),
            //             name: "com.jabil.costrollmanageroute.fragment.EmailValueHelp",
            //             controller: this
            //         }).then(function (oDialog) {
            //             oView.addDependent(oDialog);
            //             return oDialog;
            //         });
            //     }
            //     this._EmailIDValueHelpDialog.then(function (oDialog) {
            //         // Create a filter for the binding
            //         oDialog.getBinding("items").filter([new Filter("EmailID", FilterOperator.Contains, sInputValue)]);
            //         // Open ValueHelpDialog filtered by the input's value
            //         oDialog.open(sInputValue);
            //     });
            // },

            // onValueHelpEmailIDSearch: function (oEvent) {
            //     var sValue = oEvent.getParameter("value");
            //     var oFilter = new Filter("EmailID", FilterOperator.Contains, sValue);

            //     oEvent.getSource().getBinding("items").filter([oFilter]);
            // },

            // onValueHelpEmailIDClose: function (oEvent) {
            //     var oSelectedItem = oEvent.getParameter("selectedItem");
            //     oEvent.getSource().getBinding("items").filter([]);

            //     if (!oSelectedItem) {
            //         return;
            //     }

            //     this.getView().getModel("RouteCreate").setProperty("/appGP1", oSelectedItem.getTitle());
            //     // this.getView().getModel("ViewModel").setProperty("/CompanyCodeValueState", "None");
            // },

            // onEmailIDChange: function (oEvent) {
            //     // oEvent.getSource().setValueState("None");
            //     if (!oEvent.getParameters().value) {
            //         return;
            //     }
            //     if (this.getOwnerComponent().getModel("ValueHelpModel").getProperty("/ArrayEmailID").indexOf(oEvent.getParameters().value) === -1) {
            //         // oEvent.getSource().setValueState("Error");
            //     }
            // },

            onPlantCodeChange: function (oEvent) {
                // oEvent.getSource().setValueState("None");
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getOwnerComponent().getModel("ValueHelpModel").getProperty("/ArrayPlantCode").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            },

            onPlantValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._plantValueHelpDialog) {
                    this._plantValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollmanageroute.fragment.PlantCodeValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._plantValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("PLANTCODE", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onValueHelpPlantSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("PLANTCODE", FilterOperator.Contains, sValue);
                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpPlantClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);
                if (!oSelectedItem) {
                    return;
                }
                // this.getView().getModel("RouteCreate").setProperty("/plantCode", oSelectedItem.getTitle());
                this.getView().getModel("RouteCreate").setProperty("/plantCode", this.getView().getModel("ValueHelpModel").getProperty(oEvent.getParameter("selectedContexts")[0].getPath()).PLANTCODE);
                // this.getView().getModel("ViewModel").setProperty("/PlantCodeValueState", "None");
            }


        });
    }
);
