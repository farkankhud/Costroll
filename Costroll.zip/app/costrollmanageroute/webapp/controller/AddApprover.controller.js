sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox",
        "sap/ui/core/BusyIndicator",
        "sap/m/MessageToast",
        "sap/ui/core/Fragment",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator"
    ],
    function (BaseController, JSONModel, MessageBox, BusyIndicator, MessageToast, Fragment, Filter, FilterOperator) {
        "use strict";

        return BaseController.extend("com.jabil.costrollmanageroute.controller.AddApprover", {
            onInit: function () {
                this.oRouter = this.getOwnerComponent().getRouter();
                this.oModel = this.getOwnerComponent().getModel("v4Model");
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                this.oRouter.getRoute("AddApprover").attachPatternMatched(this.onAddApproverRouteMatched, this);
            },

            getViewModelObject: function () {

                var oViewModel = new JSONModel({
                    "InputEmailId": "",
                    "RouteDetails": JSON.parse(JSON.stringify(this.getView().getModel("ComponentModel").getProperty("/"))),
                    "EmailID": [],
                    "ArrayEmailID": [],
                    "EmailIDValueState": "None"
                });
                return oViewModel;
            },

            onAddApproverRouteMatched: function (oEvent) {
                // If component model not present then do a read call to get Route details
                this.getView().setModel(this.getViewModelObject(), "ViewModel");
                this.getView().getModel("ViewModel").setSizeLimit(150000);
                var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
                if (this.byId("GroupList").getItems().length > 0) {
                    this.byId("GroupList").removeSelections();
                    this.byId("GroupList").getItems()[0].setSelected(true);
                }
                if (oCompModel.getProperty("/Groups").length === 0) {
                    // var oParameter = oEvent.getParameter("arguments");
                    this.readData(false, oEvent.getParameter("arguments")["?routeID"].RouteID);
                } else {
                    this.initiateFilterEmails();
                }
                

            },

            readData: function (bDraftRefresh, sRouteID) {
                return new Promise(async function (resolve, reject) {
                    this.showBusyIndicator();
                    var aPromises = [];
                    var oValueHelpModel = new JSONModel({
                        "CompanyCodes": [],
                        "Plant": [],
                        "AllData": [],
                        "ArrayCompanyCode": [],
                        "ArrayPlantCode": [],
                        "EmailID": [],
                        "ArrayEmailID": []
                    });
                    this.setValueHelpModel(oValueHelpModel);
                    aPromises.push(this.readEmails());
                    aPromises.push(this.readRouteDetails(sRouteID));
                    Promise.all(aPromises).then(function () {
                        this.hideBusyIndicator();
                        this.getView().getModel("ViewModel").setProperty("/RouteDetails", JSON.parse(JSON.stringify(this.getView().getModel("ComponentModel").getProperty("/"))));
                        this.initiateFilterEmails();
                        resolve();
                    }.bind(this), function (sError) {
                        this.hideBusyIndicator();
                        this.getView().getModel("ViewModel").setProperty("/RouteDetails", {});
                        reject(sError);
                    }.bind(this));
                }.bind(this));
            },

            initiateFilterEmails: function () {
                var sRole, sSecondRole;
                if (this.getOwnerComponent().getModel("ComponentModel").getProperty("/SelectedGroup").Key === 1) {
                    sRole = "Purchasing Lead Approver";
                    sSecondRole = "Business Unit Approver";
                    this.filterEmailsBasedOnRoles(sRole, sSecondRole);
                } else if (this.getOwnerComponent().getModel("ComponentModel").getProperty("/SelectedGroup").Key === 2) {
                    sRole = "Finance";
                    this.filterEmailsBasedOnRoles(sRole);
                }
                
            },

            filterEmailsBasedOnRoles: function (sRole, sSecondRole) {
                var aArrayEmailId = [], aEmailId = [];
                this.getOwnerComponent().getModel("ValueHelpModel").getProperty("/EmailID").forEach((oItem) => {
                    if (sSecondRole) {
                        if (oItem.Role === sRole || oItem.Role === sSecondRole) {
                            aArrayEmailId.push(oItem.EmailID);
                            aEmailId.push({
                                "EmailID": oItem.EmailID,
                                "Role": oItem.Role
                            });
                        }
                    } else {
                        if (oItem.Role === sRole) {
                            aArrayEmailId.push(oItem.EmailID);
                            aEmailId.push({
                                "EmailID": oItem.EmailID,
                                "Role": oItem.Role
                            });
                        }
                    }
                    
                });
                // this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/EmailID", aEmailId);
                // this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayEmailID", aArrayEmailId);
                this.getView().getModel("ViewModel").setProperty("/EmailID", aEmailId);
                this.getView().getModel("ViewModel").setProperty("/ArrayEmailID", aArrayEmailId);

            },

            readMasterDataVH: function (bDraftRefresh) {
                return new Promise(async function (resolve, reject) {
                    var oOperation = this.oCostRollModel.bindContext("/getUserRoles(...)");
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        var aCompanyCode = [], aPlant = [], aDraft = [], aRouteID = [];
                        var aArrayCompanyCode = [], aArrayPlantCode = [];
                        if (!bDraftRefresh) {
                            oOperationContext.getObject().AllData.forEach((oItem) => {
                                aArrayCompanyCode.push(oItem.COMPANYCODE);
                                aArrayPlantCode.push(oItem.PLANTCODE);
                            });
                            aArrayCompanyCode = [...new Set(aArrayCompanyCode)];
                            aArrayPlantCode = [...new Set(aArrayPlantCode)];
                            aArrayCompanyCode.forEach(function (sCompanyCode) {
                                aCompanyCode.push({
                                    "COMPANYCODE": sCompanyCode
                                });
                            });
                            aArrayPlantCode.forEach(function (sPlant) {
                                aPlant.push({
                                    "PLANTCODE": sPlant
                                });
                            });
                            oOperationContext.getObject().Draft.forEach((sDraft) => {
                                aDraft.push({
                                    "draft": sDraft
                                });
                            });
                            oOperationContext.getObject().RouteID.forEach((sRouteID) => {
                                aRouteID.push({
                                    "routeID": sRouteID
                                });
                            });
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/CompanyCodes", aCompanyCode);
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/Plant", aPlant);
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/AllData", oOperationContext.getObject().AllData);
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayCompanyCode", aArrayCompanyCode);
                            this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", aArrayPlantCode);
                        }
                        this.hideBusyIndicator();
                        resolve();
                    }.bind(this)).catch(function () {
                        this.setValueHelpModel();
                        this.hideBusyIndicator();
                        reject();
                    }.bind(this));
                }.bind(this))
            },

            readEmails: function () {
                return new Promise(async function (resolve, reject) {
                    var oOperation = this.oModel.bindContext("/getEmails(...)");
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        var aEmailId = [];
                        var aArrayEmailId = [];
                        oOperationContext.getObject().value[0].EmailIDs.forEach((oItem) => {
                            aArrayEmailId.push(oItem.USER);
                            aEmailId.push({
                                "EmailID": oItem.USER,
                                "Role": oItem.ROLENAME
                            });
                        });
                        this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/EmailID", aEmailId);
                        this.getOwnerComponent().getModel("ValueHelpModel").setProperty("/ArrayEmailID", aArrayEmailId);
                        this.hideBusyIndicator();
                        resolve();
                    }.bind(this)).catch(function () {
                        this.setValueHelpModel();
                        this.hideBusyIndicator();
                        reject();
                    }.bind(this));
                }.bind(this))
            },

            setValueHelpModel: function (oValueHelpModel) {
                if (oValueHelpModel) {
                    this.getOwnerComponent().setModel(oValueHelpModel, "ValueHelpModel");
                } else {
                    this.getOwnerComponent().setModel(this.getValueHelpModelObject(), "ValueHelpModel");

                }
                this.getOwnerComponent().getModel("ValueHelpModel").setSizeLimit(150000);
            },
            getValueHelpModelObject: function () {
                var oValueHelpModel = new JSONModel({
                    "CompanyCodes": [],
                    "Plant": [],
                    "EmailID": [],
                    "AllData": [],
                    "ArrayCompanyCode": [],
                    "ArrayPlantCode": [],
                    "ArrayEmailID": []
                });
                return oValueHelpModel;
            },

            readRouteDetails: async function (sRouteID) {
                await this.performReadRouteDetails(sRouteID).then(async function (oRoute) {
                    var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                    if (oRoute) {
                        oCompModel.setProperty("/routeID", oRoute.routeID);
                        this.setApproversInComponentModel(oRoute);
                    } else {
                        this.resetAddApproverScreen();
                    }
                }.bind(this));
            },

            resetAddApproverScreen: function () {
                MessageToast.show(this.i18n.getText("routeError"));
                this.getOwnerComponent().getModel("ComponentModel").setProperty("/", {});
                this.byId("AddGroupBtn").setEnabled(false);
                this.byId("AddBtn").setEnabled(false);
                this.byId("SaveBtn").setEnabled(false);
                this.byId("ClearBtn").setEnabled(false);
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
            },

            setApproversInComponentModel: function (oRoute) {
                var oApproverGroups = {
                    "routeID": oRoute.routeID,
                    "routeName": oRoute.routeName,
                    "Groups": [],
                    "SelectedGroup": ""
                };
                oApproverGroups.Groups = this.prepareGroupsForRoute(oRoute);
                oApproverGroups.SelectedGroup = oApproverGroups.Groups[0];
                this.getOwnerComponent().getModel("ComponentModel").setProperty("/", oApproverGroups);
            },

            prepareGroupsForRoute: function (oRoute) {
                var aGroups = [];

                aGroups.push({
                    "Key": 1,
                    "Name": this.i18n.getText("apprGroup1"),
                    "EmailIds": oRoute.appGP1 ? this.prepareEmailArray(oRoute.appGP1.split(",")) : []
                });
                aGroups.push({
                    "Key": 2,
                    "Name": this.i18n.getText("apprGroup2"),
                    "EmailIds": oRoute.appGP2 ? this.prepareEmailArray(oRoute.appGP2.split(",")) : []
                });
                return aGroups;
            },

            prepareEmailArray: function (aEmailIds) {
                var aGroups = [];
                aEmailIds.forEach((sEmail) => {
                    aGroups.push({
                        "EmailId": sEmail
                    });
                });
                return aGroups;
            },

            performReadRouteDetails: function (sRouteID) {
                return new Promise(async function (resolve, reject) {
                    var oContextBinding = this.oModel.bindContext("/ManageRoutes('" + sRouteID + "')");
                    oContextBinding.requestObject().then(function () {
                        resolve(oContextBinding.getBoundContext().getObject());
                    }.bind(this))
                        .catch(function (oError) {
                            this.resetAddApproverScreen();
                            reject(oError);
                        }.bind(this));
                }.bind(this));
            },

            onAddNewGroup: function () {
                var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                var sGroupName = "";

                if (oCompModel.getProperty("/Groups").length + 1 === 1) {
                    sGroupName = this.i18n.getText("apprGroup1");
                } else if (oCompModel.getProperty("/Groups").length + 1 === 2) {
                    sGroupName = this.i18n.getText("apprGroup2");
                }
                oCompModel.getProperty("/Groups").push({
                    "Key": oCompModel.getProperty("/Groups").length + 1,
                    "Name": sGroupName,
                    "EmailIds": []
                });
                oCompModel.refresh(true);
                this.byId("GroupList").removeSelections();
                this.byId("GroupList").getItems()[oCompModel.getProperty("/Groups").length - 1].setSelected(true);
                this.getView().getModel("ViewModel").setProperty("/InputEmailId", "");
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
                oCompModel.setProperty("/SelectedGroup", oCompModel.getProperty("/Groups")[oCompModel.getProperty("/Groups").length - 1]);

            },

            onDeleteGroup: function (oEvent) {
                var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                var iIndex = parseInt(oEvent.getSource().getBindingContext("ComponentModel").getPath().charAt(oEvent.getSource().getBindingContext("ComponentModel").getPath().lastIndexOf("/") + 1));
                var iChangedIndex = (iIndex === 0 || iIndex === 1) ? 0 : iIndex - 1;
                oCompModel.getProperty("/Groups").splice(iIndex, 1);
                this.sequenceGroupNames();
                this.getView().getModel("ViewModel").setProperty("/InputEmailId", "");
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
                oCompModel.setProperty("/SelectedGroup", oCompModel.getProperty("/Groups/" + iChangedIndex));
                this.byId("GroupList").getItems()[iChangedIndex].setSelected(true);
                oCompModel.refresh(true);
            },

            sequenceGroupNames: function () {
                var aGroups = this.getView().getModel("ComponentModel").getProperty("/Groups");
                aGroups.forEach((oGroup, iIndex) => {
                    if (iIndex === 0) {
                        oGroup.Name = this.i18n.getText("apprGroup1");
                    } else if (iIndex === 1) {
                        oGroup.Name = this.i18n.getText("apprGroup2");
                    } else if (iIndex === 2) {
                        oGroup.Name = this.i18n.getText("apprGroup3");
                    }
                });
                this.getView().getModel("ComponentModel").refresh(true);
            },

            onGroupPress: function (oEvent) {
                var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                oCompModel.setProperty("/SelectedGroup", oCompModel.getProperty(oEvent.getParameters().listItem.getBindingContext("ComponentModel").getPath()));
                this.getView().getModel("ViewModel").setProperty("/InputEmailId", "");
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
                this.initiateFilterEmails();
            },

            onEmailIdAdd: function (oEvent) {

                var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                var bInvalidFlag = Boolean(this.getView().getModel("ViewModel").getProperty("/EmailIDValueState") === "Error"
                    || this.getView().getModel("ViewModel").getProperty("/ArrayEmailID").indexOf(this.getView().getModel("ViewModel").getProperty("/InputEmailId")) === -1);
                if (bInvalidFlag) {
                    MessageToast.show(this.i18n.getText("emailIdEnteredInvalidMsg"));
                    return;
                }
                if (this.getView().getModel("ViewModel").getProperty("/InputEmailId")) {
                    oCompModel.getProperty("/SelectedGroup/EmailIds").push({
                        "EmailId": this.getView().getModel("ViewModel").getProperty("/InputEmailId")
                    });
                } else {
                    MessageToast.show(this.i18n.getText("noEmailIdToAdd"));
                }
                oCompModel.setProperty("/Groups/" + parseInt(oCompModel.getProperty("/SelectedGroup/Key") - 1), oCompModel.getProperty("/SelectedGroup"));
                oCompModel.refresh(true);
                this.getView().getModel("ViewModel").setProperty("/InputEmailId", "");
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
            },

            onEmailIdDelete: function (oEvent) {
                var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                oCompModel.getProperty("/SelectedGroup/EmailIds").splice(parseInt(oEvent.getParameters().listItem.getBindingContext("ComponentModel").getPath().charAt(oEvent.getParameters().listItem.getBindingContext("ComponentModel").getPath().lastIndexOf("/") + 1)), 1);
                oCompModel.setProperty("/Groups/" + parseInt(oCompModel.getProperty("/SelectedGroup/Key") - 1), oCompModel.getProperty("/SelectedGroup"));
                oCompModel.refresh(true);
            },

            onSave: async function () {
                if (this.validateUpdateRoute()) {
                    this.showBusyIndicator();
                    await this.updateRouteDetails().then(function (sRouteName) {
                        this.getView().getModel("ViewModel").setProperty("/InputEmailId", "");
                        this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
                        this.getView().getModel("ViewModel").setProperty("/RouteDetails",
                            JSON.parse(JSON.stringify(this.getView().getModel("ComponentModel").getProperty("/")))
                        );
                        MessageBox.success(this.i18n.getText("routeUpdateSuccessMsg", [sRouteName]));
                        this.hideBusyIndicator();
                    }.bind(this));
                }
            },

            onClear: function () {
                this.getView().getModel("ComponentModel").setProperty("/",
                    JSON.parse(JSON.stringify(this.getView().getModel("ViewModel").getProperty("/RouteDetails")))
                );
                this.getView().getModel("ViewModel").setProperty("/InputEmailId", "");
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
                MessageToast.show(this.i18n.getText("UnsavedChangesClear"));
            },

            updateRouteDetails: function () {
                return new Promise(async function (resolve, reject) {
                    var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                    var oUpdate = oCompModel.getProperty("/");
                    var oContextBinding = this.oModel.bindContext("/ManageRoutes('" + oCompModel.getProperty("/routeID") + "')");
                    oContextBinding.requestObject().then(function () {
                        oContextBinding.getBoundContext().setProperty("routeName", oUpdate.routeName);
                        for (let iIndex = 0; iIndex < 3; iIndex++) {
                            if (oUpdate.Groups[iIndex] && oUpdate.Groups[iIndex].EmailIds.length > 0) {
                                oContextBinding.getBoundContext().setProperty("appGP" + parseInt(iIndex + 1), this.prepareEmailIdAsString(oUpdate.Groups[iIndex].EmailIds));
                            } else {
                                oContextBinding.getBoundContext().setProperty("appGP" + parseInt(iIndex + 1), "");
                            }
                        }
                        resolve(oUpdate.routeName);
                    }.bind(this));
                }.bind(this));
            },

            prepareEmailIdAsString: function (aEmailIds) {
                var aEmailIdToReturn = [];
                aEmailIds.forEach((oEmail) => {
                    aEmailIdToReturn.push(oEmail.EmailId);
                });
                return aEmailIdToReturn.join(",");
            },

            validateUpdateRoute: function () {
                var oCompModel = this.getOwnerComponent().getModel("ComponentModel");
                var aValidationMessages = [], sValidatonMessage = "";
                if (!oCompModel.getProperty("/routeName")) {
                    aValidationMessages.push(this.i18n.getText("reqRouteNameMsg"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/EmailIDValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("emailIdEnteredInvalidMsg"));
                }
                if (aValidationMessages.length > 0) {
                    MessageBox.information(this.i18n.getText("reqFieldsMissingMsg") + "\n\n" + aValidationMessages.join("\n\n"));
                    return false;
                }
                return true;
            },

            validateApprGroups: function (aGroups) {
                var aMessages = [];
                aGroups.forEach((oGroup, iIndex) => {
                    if (oGroup.EmailIds.length === 0) {
                        aMessages.push(this.i18n.getText("emailIdEmpyMsg", [iIndex + 1]));
                    }
                });
                return aMessages;
            },

            onEmailIDValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();


                if (!this._EmailIDValueHelpDialog) {
                    this._EmailIDValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollmanageroute.fragment.EmailValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._EmailIDValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    // oDialog.getBinding("items").filter([]);
                    // if (this.getOwnerComponent().getModel("ComponentModel").getProperty("/SelectedGroup").Key === 1) {
                    //     oDialog.getBinding("items").filter([new Filter("Role", FilterOperator.EQ, "Business Unit Approver"),
                    //     new Filter("Role", FilterOperator.EQ, "Purchasing Lead Approver")
                    //     ]);
                    // } else if (this.getOwnerComponent().getModel("ComponentModel").getProperty("/SelectedGroup").Key === 2) {
                    //     oDialog.getBinding("items").filter([new Filter("Role", FilterOperator.EQ, "Finance")]);
                    // }

                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                }.bind(this));
            },

            onValueHelpEmailIDSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("EmailID", FilterOperator.Contains, sValue);
                // if (this.getOwnerComponent().getModel("ComponentModel").getProperty("/SelectedGroup").Key === 1) {
                //     oEvent.getSource().getBinding("items").filter([new Filter("Role", FilterOperator.EQ, "Business Unit Approver"),
                //     new Filter("Role", FilterOperator.EQ, "Purchasing Lead Approver"), oFilter
                //     ]);
                // } else if (this.getOwnerComponent().getModel("ComponentModel").getProperty("/SelectedGroup").Key === 2) {
                //     oEvent.getSource().getBinding("items").filter([new Filter("Role", FilterOperator.EQ, "Finance"), oFilter]);
                // }
                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpEmailIDClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);
                if (!oSelectedItem) {
                    return;
                }

                this.getView().getModel("ViewModel").setProperty("/InputEmailId", oSelectedItem.getTitle());
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");

            },

            onEmailIDChange: function (oEvent) {
                this.getView().getModel("ViewModel").setProperty("/EmailIDValueState", "None");
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ViewModel").getProperty("/ArrayEmailID").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            },

            hideBusyIndicator: function () {
                BusyIndicator.hide();
            },

            // Shows busy indicator
            showBusyIndicator: function () {
                BusyIndicator.show();
            }
        });
    }
);
