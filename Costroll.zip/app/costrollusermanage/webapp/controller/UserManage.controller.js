sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/Device",
    "sap/base/Log",
    'sap/ui/model/odata/v2/ODataModel',
    'sap/ui/model/json/JSONModel',
    'sap/m/Label',
    "sap/ui/core/Fragment",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/comp/smartvariants/PersonalizableInfo',
    'sap/m/MessageToast',
    "sap/m/MessageBox",
    "sap/ushell/Container",
    "sap/ui/core/BusyIndicator",
    "sap/ui/export/Spreadsheet",
    "com/jabil/costrollusermanage/model/jszip",
    "com/jabil/costrollusermanage/model/xlsx"

],
    function (Controller, Device, Log, ODataModel, JSONModel, Label, Fragment, Filter, FilterOperator, PersonalizableInfo, MessageToast, MessageBox, Container, BusyIndicator, Spreadsheet, jszip, xlsx) {
        "use strict";

        return Controller.extend("com.jabil.costrollusermanage.controller.UserManage", {
            onInit: function () {
                this.bInitial = true;
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                this.oModel = this.getOwnerComponent().getModel();
                this.ov4Model = this.getOwnerComponent().getModel("v4Model");
            },

            onAddNewUserManagement: function () {
                // sap.ui.core.BusyIndicator.show();
                var graphModel = new JSONModel({
                    'Results': {}
                });
                this.getView().setModel(graphModel, "GraphUser");

                if (!this.oAddUser) {
                    this.oAddUser = this.loadFragment({
                        name: "com.jabil.costrollusermanage.fragment.AddNewUser"
                    });
                }
                this.oAddUser.then(function (oAddUserDialog) {
                    this.oAddUserDialog = oAddUserDialog;
                    this.oAddUserDialog.open();
                }.bind(this));
            },

            onBeforeOpenAddDialog: function () {
                var that = this;
                this.getOwnerComponent().getModel().callFunction("/getAllData", {
                    method: "POST",
                    urlParameters: {},
                    success: function (oData) {
                        var AllValues = {};
                        AllValues = oData.getAllData;
                        // var lRegion = allowedAssignments.REGION.length;
                        // var lPlant = allowedAssignments.PLANT.length;
                        var allCompany = AllValues.COMPANYCODE;
                        var aCompany = [];
                        for (var i in allCompany)
                            aCompany.push([allCompany[i].COMPANYCODE]);
                        var allPlants = AllValues.PLANT;
                        var aPlants = [];
                        for (var i in allPlants)
                            aPlants.push([allPlants[i].PLANTCODE]);

                        var oModelRoles = new JSONModel();
                        oModelRoles.setData(AllValues);
                        that.byId("AddNewUserDialog").setModel(oModelRoles);
                        sap.ui.core.BusyIndicator.hide();
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        that.displayErrorMessages(oError);
                    }.bind(this)
                });
            },

            onCompanyChange: function (oEvent) {
                if (this.byId("InCoCd").getSelectedKeys()[0]) {
                    this.byId("InPlCd").setProperty("editable", true);
                    var selectedItems = oEvent.getSource().getSelectedItems();
                    var aFilters = selectedItems.map((item) => { return new Filter('COMPANYCODE', FilterOperator.EQ, item.getKey()) });
                    this.byId('InPlCd').getBinding("items").filter(aFilters);
                }
                else {
                    this.byId("InPlCd").setSelectedItems([]);
                    this.byId("InPlCd").setProperty("editable", false);
                }
            },

            displayErrorMessages: function (oError) {
                if (oError.responseText && JSON.parse(oError.responseText).error
                    && JSON.parse(oError.responseText).error.message && JSON.parse(oError.responseText).error.message.value) {
                    MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                } else {
                    MessageBox.error(this.i18n.getText("operationFailedMsg"));
                }
            },

            // Calling Value help from Graph API
            onValueHelpChangeLogRequestedUser: function (oEvent) {
                this.parentUserId = oEvent.getSource().getId();
                var graphModel = new JSONModel({
                    'Results': {}
                });
                this.getView().setModel(graphModel, "GraphUser");
                if (!this._oValueHelpDialog) {
                    this._oValueHelpDialog = this.loadFragment({
                        name: "com.jabil.costrollusermanage.fragment.UserDialog"
                    });
                }
                this._oValueHelpDialog.then(function (oValueDialog) {
                    this.oValueDialog = oValueDialog;
                    this.oValueDialog.open();
                }.bind(this));
            },
            // After selece from Graph API result
            handleConfirmUser: function (oEvent) {
                var aContexts = oEvent.getParameter("selectedContexts");
                var userMail = oEvent.getParameter("selectedItem").mProperties.key;
                // var userName = oEvent.getParameter("selectedItem").mProperties.text;
                if (aContexts && aContexts.length > 0) {
                    this.getView().byId("InUser").setValue(aContexts[0].getObject().mail);
                    // this.getView().byId("InUserName2").setValue(aContexts[0].getObject().displayName);
                    this.getView().byId("InUser").setProperty("editable", false)
                    // this.getView().byId("InUserName2").setProperty("editable", false)
                }
                else if (userMail) {
                    this.getView().byId("InUser").setValue(userMail);
                    // this.getView().byId("InUserName2").setValue(userName);
                    this.getView().byId("InUser").setProperty("editable", false)
                    // this.getView().byId("InUserName2").setProperty("editable", false)
                }
            },

            // Search in Graph API 
            handleSearchUser: function (oEvent) {
                var that = this;
                const user = oEvent.getParameter("value");
                var oFilterP = [];
                oFilterP.push(new Filter({
                    path: "displayName",
                    operator: FilterOperator.EQ,
                    value1: user
                }));
                if (oFilterP[0].oValue1 === "") { }
                else {
                    this.getView().getModel().read("/User", {
                        urlParameters: {},
                        async: true,
                        filters: oFilterP,
                        success: function (oData, oResponse) {
                            that.getView().getModel("GraphUser").setData(oData.results);
                            that.oValueDialog.setBusy(false);

                        }.bind(this),
                        error: function (oError) {
                            that.oValueDialog.setBusy(false);
                            new sap.m.MessageToast.show(that.i18n.getText("errorUser"));
                        }
                    });
                }
            },

            // After selece from Graph API result
            // handleConfirmUser: function (oEvent) {
            //     var aContexts = oEvent.getParameter("selectedContexts");
            //     var userMail = oEvent.getParameter("selectedItem").mProperties.key;
            //     var userName = oEvent.getParameter("selectedItem").mProperties.text;
            //     if (aContexts && aContexts.length > 0) {
            //         this.getView().byId("InUser").setValue(aContexts[0].getObject().mail);
            //         // this.getView().byId("InUserName2").setValue(aContexts[0].getObject().displayName);
            //         this.getView().byId("InUser").setProperty("editable", false)
            //         // this.getView().byId("InUserName2").setProperty("editable", false)
            //     }
            //     else if (userMail) {
            //         this.getView().byId("InUser").setValue(userMail);
            //         // this.getView().byId("InUserName2").setValue(userName);
            //         this.getView().byId("InUser").setProperty("editable", false)
            //         // this.getView().byId("InUserName2").setProperty("editable", false)
            //     }
            // },

            createNewUser: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabUserManagement").getModel();
                var user = this.getView().byId("InUser").getValue();
                var roleName = this.getView().byId("InRoleName").getValue();
                var companyCode = this.getView().byId("InCoCd").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                var plantCode = this.getView().byId("InPlCd").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");

                var oItem = {
                    "user": user,
                    "roleName": roleName,
                    "companyCode": companyCode,
                    "plantCode": plantCode
                };
                oModel.create("/UserManagement", oItem, {
                    success: function (odata) {
                        that.closeDialogNewUser();
                        that.getView().byId("UITabUserManagement").getModel().refresh();
                        MessageToast.show(that.i18n.getText("saved"));
                    },
                    error: function (oError) {
                        that.closeDialogNewUser();
                        that.getView().byId("UITabUserManagement").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                })
            },

            closeDialogNewUser: function () {
                var aBlank = [];
                this.oAddUserDialog.close();
                this.byId("InUser").setValue("");
                this.byId("InUser").setProperty("editable", true);
                this.byId("InRoleName").setValue("");
                this.byId("InCoCd").setSelectedKeys(aBlank);
                this.byId("InPlCd").setSelectedKeys(aBlank);
            },


            onEditUser: function (oEvent) {
                var oPath = oEvent.getSource().getBindingContext().getPath();
                this.oPath = oPath;
                if (!this.oEditUser) {
                    this.oEditUser = this.loadFragment({
                        name: "com.jabil.costrollusermanage.fragment.EditUser"
                    });
                }
                this.oEditUser.then(function (oEditUserDialog) {
                    if (!this.bInitial) {
                        this.onRowSelect();
                    }
                    this.oEditUserDialog = oEditUserDialog;
                    this.oEditUserDialog.bindElement({ path: oPath });
                    this.oEditUserDialog.open();
                }.bind(this));
            },


            // After loading the edit row dialog, to load the selected values 
            onBeforeOpenEditDialog: function () {
                if (this.bInitial) {
                    this.onRowSelect();
                }
                this.bInitial = false;
            },

            onRowSelect: function () {
                var that = this;
                this.getOwnerComponent().getModel().callFunction("/getAllData", {
                    method: "POST",
                    urlParameters: {},
                    success: function (oData) {
                        var AllValues = {};
                        AllValues = oData.getAllData;

                        var oModelRoles = new JSONModel();
                        oModelRoles.setData(AllValues);
                        that.byId("EditUserForm2").setModel(oModelRoles);
                    }.bind(this),
                    error: function (oError) {
                        that.displayErrorMessages(oError);
                    }.bind(this)
                });
            },
            // To fill the values of selected line into Edit Row Dialog
            onAfterOpenEditDialog: function () {
                this.byId("EditUser").setValue(this.getView().getModel().getProperty(this.oPath).user);
                this.byId("EditRoleName").setValue(this.getView().getModel().getProperty(this.oPath).roleName);
                var aCompanys = [];
                var aCompanys = this.getView().getModel().getProperty(this.oPath).companyCode.split(',');
                this.byId("EditCoCd").setSelectedKeys(aCompanys);
                var aPlants = [];
                var aPlants = this.getView().getModel().getProperty(this.oPath).plantCode.split(',');
                this.byId("EditPlCd").setSelectedKeys(aPlants);
                // this.byId("EditCoCd").setValue(this.getView().getModel().getProperty(this.oPath).companyCode);
                // this.byId("EditPlCd").setValue(this.getView().getModel().getProperty(this.oPath).plantCode);
            },

            onCompanyChangeEdit: function (oEvent) {
                if (this.byId("EditCoCd").getSelectedKeys()[0]) {
                    this.byId("EditPlCd").setProperty("editable", true);
                    var selectedItems = oEvent.getSource().getSelectedItems();
                    var aFilters = selectedItems.map((item) => { return new Filter('COMPANYCODE', FilterOperator.EQ, item.getKey()) });
                    this.byId('EditPlCd').getBinding("items").filter(aFilters);
                }
                else {
                    this.byId("EditPlCd").setSelectedItems([]);
                    this.byId("EditPlCd").setProperty("editable", false);
                }
            },

            updateUser: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabUserManagement").getModel();
                // var oPath = oEvent.getSource().getBindingContext().getPath();
                var editedRole = this.getView().byId("EditRoleName").getValue();
                var editedCoCd = this.getView().byId("EditCoCd").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                var editedPlCd = this.getView().byId("EditPlCd").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                var oItem = {
                    "roleName": editedRole,
                    "companyCode": editedCoCd,
                    "plantCode": editedPlCd
                };
                oModel.update(this.oPath, oItem, {
                    success: function (odata) {
                        that.getView().byId("UITabUserManagement").getModel().refresh();
                        that.closeDialogEditUser();
                        MessageToast.show(that.i18n.getText("Updated"));
                    },
                    error: function (oError) {
                        that.closeDialogEditUser();
                        that.getView().byId("UITabUserManagement").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }
                )
            },

            closeDialogEditUser: function () {
                var aBlank = [];
                this.byId("EditUser").setValue("");
                this.byId("EditRoleName").setValue("");
                this.byId("EditCoCd").setSelectedKeys(aBlank);
                this.byId("EditPlCd").setSelectedKeys(aBlank);
                this.byId("EditPlCd").setProperty("editable", false);
                this.oEditUserDialog.close();
            },

            onDeleteUser: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var aSelectedIndices = this.getView().byId("UITabUserManagement").getSelectedIndices();
                if (!aSelectedIndices.length) {
                    MessageToast.show(that.i18n.getText("No User Selected"));
                    return;
                }
                // var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("DeleteConfirm"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            aSelectedIndices.forEach(function (i) {
                                var oPath = "/" + oModel.getBindings()[0].aKeys[i]
                                oModel.remove(oPath);
                            });
                            MessageToast.show(that.i18n.getText("deleted"));
                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },

            onUploadUsers: function (oEvent) {
                var that = this;
                // this.showBusyIndicator();
                this.getView().setBusy(true);
                this.parseAttachmentUpload(oEvent.getParameter("files")[0]).then(function () {
                    // this.hideBusyIndicator();                                       
                }.bind(this));
            },

            // Reading of excel when uploaded to browser
            parseAttachmentUpload: async function (oFile) {
                var that = this;
                return new Promise(async function (resolve, reject) {
                    var reader = new FileReader();
                    reader.onload = async function (e) {
                        var data = e.currentTarget.result;
                        var excelsheet = xlsx.read(data, {
                            type: "binary"
                        });
                        var aMasterData = [];
                        var aExcelLineItems = [];
                        var aPromises = [];
                        for (var i = 0; i < excelsheet.SheetNames.length; i++) {
                            if (excelsheet.SheetNames[i].includes("SAPUI5 Export")) {
                                aExcelLineItems = await xlsx.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[i]]); // this is the required data in Object format
                            }
                        }
                        var oPayload = {};
                        if (aExcelLineItems.length > 0) {
                            aExcelLineItems.forEach(function (oItem) {
                                oPayload = {
                                    "user": oItem["User"],
                                    "roleName": oItem["Role Name"],
                                    "companyCode": oItem["Company Code"],
                                    "plantCode": oItem["Plant Code"],
                                };
                                aPromises.push(this.performMassCreate(oPayload, "/UserManagement"));
                            }.bind(this));
                            Promise.all(aPromises).then(function () {
                                MessageBox.success(this.i18n.getText("massUploadSuccessUserData"));
                                // this.byId("smartFilterBarUserManagement").search();
                                resolve();
                                this.getView().setBusy(false);
                                this.getView().byId("UITabUserManagement").getModel().refresh();
                            }.bind(this), function (sError) {
                                MessageBox.error(sError);
                                reject();
                                this.getView().setBusy(false);
                            }.bind(this));
                        } else {
                            MessageBox.information(this.i18n.getText("validationFailedExcel"));
                            this.getView().setBusy(false);
                        }
                        // this.hideBusyIndicator();
                        // sap.ui.core.BusyIndicator.hide();
                    }.bind(this);
                    reader.readAsArrayBuffer(oFile);
                }.bind(this));
            },

            performMassCreate: function (oItem, sPath) {
                return new Promise(async function (resolve, reject) {
                    var oList = this.ov4Model.bindList(sPath);
                    var oContext = oList.create(oItem, true);
                    oList.attachCreateCompleted(await function (oEvent) {
                        if (oEvent.getParameters().success) {
                            resolve();
                        } else {
                            reject("Something Wrong in the File, please correct and reupload.");
                        }
                    }.bind(this));
                }.bind(this));
            },


            // Shows busy indicator
            showBusyIndicator: function () {
                BusyIndicator.show();
            },
            // Hides busy indicator
            hideBusyIndicator: function () {
                sap.ui.core.BusyIndicator.hide();
                this.getView().byId("UITabUserManagement").getModel().refresh();
            }
        });
    });
