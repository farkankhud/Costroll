sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/BusyIndicator",
    "sap/ui/core/Fragment"
],
    function (Controller, JSONModel, MessageToast, MessageBox, BusyIndicator, Fragment) {
        "use strict";

        return Controller.extend("com.jabil.costrolldashboard.controller.CostRollDashboard", {
            onInit: function () {
                this.oModel = this.getOwnerComponent().getModel();
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                var oViewModel = new JSONModel({
                    "CurrentLogDetails": [],
                    "RowMode": "Interactive",
                    "Admin": true,
                    "WithdrawComments": "",
                    "WithdrawCommentsValueState": "None",
                    "ForwardEmail": "",
                    "ForwardEmailValueState": "None",
                    "Comments": "",
                    "CommentsValueState": "None"
                });

                this.sTicketID = "";
                this.getView().setModel(oViewModel, "ViewModel");
                this.getView().getModel("ViewModel").setSizeLimit(150000);
                if (this.getOwnerComponent().getComponentData() && this.getOwnerComponent().getComponentData().startupParameters && this.getOwnerComponent().getComponentData().startupParameters.TicketID) {
                    this.sTicketID = this.getOwnerComponent().getComponentData().startupParameters.TicketID[0];
                }
                this.showBusyIndicator();
                this.callAdminRoleCheck();

            },

            onSmartFilterBarInitialised: function (oEvent) {
                if (this.sTicketID) {
                    this.byId("CostRollDashboardSmartFilterId").setFilterData({
                        "Ticket_ID": {
                            "items": [{
                                "key": this.sTicketID,
                                "text": ""
                            }]
                        }
                    });
                    this.sTicketID = "";
                    this.byId("CostRollDashboardSmartFilterId").fireSearch();
                }
            },

            callAdminRoleCheck: function () {
                this.oModel.callFunction("/checkAdmin", {
                    method: "POST",
                    success: function (oData) {
                        this.getView().getModel("ViewModel").setProperty("/Admin", oData.checkAdmin.Admin);
                        this.getView().getModel("ViewModel").setProperty("/CurrentUser", oData.checkAdmin.UserID);
                        this.hideBusyIndicator();
                    }.bind(this),
                    error: function (oError) {
                        this.getView().getModel("ViewModel").setProperty("/Admin", false);
                        this.getView().getModel("ViewModel").setProperty("/CurrentUser", "");
                        this.hideBusyIndicator();
                    }.bind(this)
                });
            },

            onBeforeRebind: function (oEvent) {
                let oBindingParam = oEvent.getParameter("bindingParams");
                oBindingParam.parameters["expand"] = "LineItems,Attachments($expand=FileID),CRWFHistory";
                var aCompCode = [];
                var aCompanyCodes = this.getOwnerComponent().getModel("componentModel").getProperty("/CompanyCodes");
                aCompanyCodes.forEach((oCompCode) => {
                    aCompCode.push(new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, oCompCode));
                });
                if (aCompanyCodes.length > 0) {
                    var oFilter = new sap.ui.model.Filter(aCompCode, false);
                    oBindingParam.filters.push(oFilter);
                }
            },

            onTicketIDClick: function (oEvent) {
                var sTicketID = this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath() + "/Ticket_ID");
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "CostRollRequestApp",
                        action: "Create"
                    },
                    params: { "TicketID": sTicketID }
                })) || "";
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: hash
                    }
                });
            },

            onForward: function () {
                var aIndices = this.byId("CostRollDashboardTableId").getDependents()[0].getSelectedIndices();
                if (aIndices.length === 0) {
                    MessageToast.show(this.i18n.getText("noItemsSelectedForward"));
                    return;
                }
                if (!this.byId("ForwardDialog")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.costrolldashboard.fragment.ForwardApproval",
                        controller: this
                    }).then(function (oDialog) {
                        this.getView().addDependent(oDialog);
                        this.byId("EmailForward").setValue();
                        this.getView().getModel("ViewModel").setProperty("/ForwardEmailValueState", "None");
                        oDialog.open();
                    }.bind(this));
                } else {
                    this.byId("EmailForward").setValue();
                    this.getView().getModel("ViewModel").setProperty("/ForwardEmailValueState", "None");
                    this.byId("ForwardDialog").open();
                }
            },

            onPerformForward: function () {
                var oSmartFilter = this.byId("CostRollDashboardSmartFilterId");
                var aIndices = this.byId("CostRollDashboardTableId").getDependents()[0].getSelectedIndices();
                var aID = [];
                var aWFID = [];
                aIndices.forEach(function (oIndex) {
                    aID.push(this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(oIndex).getPath()).ID);
                    // aWFID.push(this.oModel.getProperty("/" + this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(oIndex).getPath()).CRWFHistory.__list[0]).WorkflowID);
                    if (this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(oIndex).getPath()).CRWFHistory.__list.length > 0) {
                        aWFID.push(this.oModel.getProperty("/" + this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(oIndex).getPath()).CRWFHistory.__list[0]).WorkflowID);
                    } else {
                        aWFID.push("");
                    }
                }.bind(this));
                if (!this.getView().getModel("ViewModel").getProperty("/ForwardEmail")) {
                    this.getView().getModel("ViewModel").setProperty("/ForwardEmailValueState", "Error");
                    return;
                }
                // oSource.getBindingContext().getModel().getProperty("/" + oSource.getBindingContext().getModel().getProperty(sPath).CRWFHistory.__list[0]).WorkflowID
                this.showBusyIndicator();
                this.oModel.callFunction("/fowrardTicket", {
                    method: "POST",
                    urlParameters: {
                        ID: aID.join(";"),
                        WFID: aWFID.join(";"),
                        Email: this.getView().getModel("ViewModel").getProperty("/ForwardEmail"),
                        Remark: this.getView().getModel("ViewModel").getProperty("/Comments")
                    },
                    success: function (oData) {
                        this.hideBusyIndicator();
                        this.resetFieldsForwardWithdraw();
                        this.byId("ForwardDialog").close();
                        this.displayResponseMessage(oData.fowrardTicket);
                        oSmartFilter.fireSearch();
                    }.bind(this),
                    error: function (oError) {
                        this.byId("ForwardDialog").close();
                        this.resetFieldsForwardWithdraw();
                        this.displayErrorMessages(oError);
                        this.hideBusyIndicator();
                    }.bind(this)
                });
            },

            resetFieldsForwardWithdraw: function () {
                this.getView().getModel("ViewModel").setProperty("/Comments", "");
                this.getView().getModel("ViewModel").setProperty("/ForwardEmail", "");
                this.getView().getModel("ViewModel").setProperty("/WithdrawComments", "");
            },

            displayResponseMessage: function (oResponse) {
                if (oResponse.Msgty === "E") {
                    MessageBox.error(oResponse.Message);
                } else {
                    MessageBox.success(oResponse.Message);
                }
            },

            displayErrorMessages: function (oError) {
                if (oError.responseText && JSON.parse(oError.responseText).error
                    && JSON.parse(oError.responseText).error.message && JSON.parse(oError.responseText).error.message.value) {
                    MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                } else {
                    MessageBox.error(this.i18n.getText("operationFailedMsg"));
                }
            },

            onForwardEmailChange: function () {
                this.getView().getModel("ViewModel").setProperty("/ForwardEmailValueState", "None");
            },

            onCommentsChange: function () {
                this.getView().getModel("ViewModel").setProperty("/CommentsValueState", "None");
            },

            onCancel: function () {
                this.resetFieldsForwardWithdraw();
                this.byId("ForwardDialog").close();
            },

            onWithdraw: function () {
                var aIndices = this.byId("CostRollDashboardTableId").getDependents()[0].getSelectedIndices();
                if (aIndices.length === 0) {
                    MessageToast.show(this.i18n.getText("noItemsSelectedWithdraw"));
                    return;
                }

                if (!this.byId("WithdrawCommentsDialog")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.costrolldashboard.fragment.WithdrawComments",
                        controller: this
                    }).then(function (oDialog) {
                        this.getView().addDependent(oDialog);
                        this.byId("WithdrawComments").setValue();
                        this.getView().getModel("ViewModel").setProperty("/WithdrawCommentsValueState", "None");
                        oDialog.open();
                    }.bind(this));
                } else {
                    this.byId("WithdrawComments").setValue();
                    this.getView().getModel("ViewModel").setProperty("/WithdrawCommentsValueState", "None");
                    this.byId("WithdrawCommentsDialog").open();
                }
            },

            onPerformWithdraw: function () {
                var oSmartFilter = this.byId("CostRollDashboardSmartFilterId");
                var aIndices = this.byId("CostRollDashboardTableId").getDependents()[0].getSelectedIndices();
                var aID = []; var aWFID = [];
                if (!this.getView().getModel("ViewModel").getProperty("/WithdrawComments")) {
                    this.getView().getModel("ViewModel").setProperty("/WithdrawCommentsValueState", "Error");
                    return;
                }

                var bFlag = false;
                for (var i = 0; i < aIndices.length; i++) {
                    if (!this.getView().getModel("ViewModel").getProperty("/Admin") && this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(aIndices[i]).getPath()).Requestor
                        !== this.getView().getModel("ViewModel").getProperty("/CurrentUser")) {
                        bFlag = true;
                        break;
                    }
                    aID.push(this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(aIndices[i]).getPath()).ID);
                    if (this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(aIndices[i]).getPath()).CRWFHistory.__list.length > 0) {
                        aWFID.push(this.oModel.getProperty("/" + this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(aIndices[i]).getPath()).CRWFHistory.__list[0]).WorkflowID);
                    } else {
                        aWFID.push("");
                    }
                }

                if (bFlag) {
                    MessageBox.information(this.i18n.getText("withdrawCurrentUser", [this.getView().getModel("ViewModel").getProperty("/CurrentUser")]));
                    this.byId("WithdrawCommentsDialog").close();
                    return;
                }

                // aIndices.forEach(function (oIndex) {

                //     if (!this.getView().getModel("ViewModel").getProperty("/Admin") && this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(oIndex).getPath()).Requestor
                //         !== this.getView().getModel("ViewModel").getProperty("/CurrentUser")) {
                //         MessageBox.information(this.i18n.getText("withdrawCurrentUser", [this.getView().getModel("ViewModel").getProperty("/CurrentUser")]));
                //         return false;
                //     }
                //     aID.push(this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(oIndex).getPath()).ID);
                //     if (this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(oIndex).getPath()).CRWFHistory.__list.length > 0) {
                //         aWFID.push(this.oModel.getProperty("/" + this.oModel.getProperty(this.byId("CostRollDashboardTableId").getContextByIndex(oIndex).getPath()).CRWFHistory.__list[0]).WorkflowID);
                //     } else {
                //         aWFID.push("");
                //     }
                // }.bind(this));
                this.showBusyIndicator();
                this.oModel.callFunction("/withdrawTicket", {
                    method: "POST",
                    urlParameters: {
                        ID: aID.join(";"),
                        WFID: aWFID.join(";"),
                        Comment: this.getView().getModel("ViewModel").getProperty("/WithdrawComments")
                    },
                    success: function (oData) {
                        this.hideBusyIndicator();
                        this.resetFieldsForwardWithdraw();
                        this.displayResponseMessage(oData.withdrawTicket);
                        this.byId("WithdrawCommentsDialog").close();
                        oSmartFilter.fireSearch();
                    }.bind(this),
                    error: function (oError) {
                        this.displayErrorMessages(oError);
                        this.resetFieldsForwardWithdraw();
                        this.byId("WithdrawCommentsDialog").close();
                        this.hideBusyIndicator();
                    }.bind(this)
                });
            },

            onWithdrawCommentsChange: function () {
                this.getView().getModel("ViewModel").setProperty("/WithdrawCommentsValueState", "None");
            },

            onCancelWithdraw: function () {
                this.resetFieldsForwardWithdraw();
                this.byId("WithdrawCommentsDialog").close();
            },

            onLineItemsPress: function (oEvent) {
                var sPath = oEvent.getSource().getBindingContext().getPath();
                if (!this.byId("ItemsDialog")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.costrolldashboard.fragment.ItemsDialog",
                        controller: this
                    }).then(function (oDialog) {
                        this.getView().addDependent(oDialog);
                        this.setItemsInViewModel(sPath);
                        oDialog.open();
                    }.bind(this));
                } else {
                    this.setItemsInViewModel(sPath);
                    this.byId("ItemsDialog").open();
                }
            },

            setItemsInViewModel: function (sPath) {
                var aItems = [];
                this.oModel.getProperty(sPath).LineItems.__list.forEach((sKey) => {
                    aItems.push(this.oModel.getProperty("/" + sKey));
                });
                this.getView().getModel("ViewModel").setProperty("/Items", aItems);
            },

            onCloseItemsDialog: function () {
                this.byId("ItemsDialog").close();
            },

            // Hides busy indicator
            hideBusyIndicator: function () {
                BusyIndicator.hide();
            },

            // Shows busy indicator
            showBusyIndicator: function () {
                BusyIndicator.show();
            },

            // Displays approver log details in the Dialog
            onViewLogDetails: function (oEvent) {
                if (!this.setLogDetailsModel(oEvent)) {
                    return;
                }
                if (!this.byId("LogDetailsDialog")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.costrolldashboard.fragment.LogDetails",
                        controller: this
                    }).then(function (oDialog) {
                        this.getView().addDependent(oDialog);
                        oDialog.open();
                    }.bind(this));
                } else {
                    this.byId("LogDetailsDialog").open();
                }
            },

            // Sets CurrentLogDetails model for the selected CWA
            setLogDetailsModel: function (oEvent) {
                if (!this.getView().getModel("ViewModel").getProperty("/Admin") && this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath()).Requestor
                    !== this.getView().getModel("ViewModel").getProperty("/CurrentUser")) {
                    MessageBox.information(this.i18n.getText("logDetailsCurrentUser", [this.getView().getModel("ViewModel").getProperty("/CurrentUser")]));
                    return false;
                }
                if (this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath()).CRWFHistory.__list.length > 0) {
                    var aLogDetails = [];
                    this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath()).CRWFHistory.__list.forEach(function (sPath) {
                        aLogDetails.push(this.oModel.getProperty("/" + sPath));
                    }.bind(this));
                    this.getView().getModel("ViewModel").setProperty("/CurrentLogDetails", aLogDetails);
                    return true;
                } else {
                    MessageBox.error(this.i18n.getText("noLogHistoryDetails"));
                    return false;
                }
            },

            // Closes the log details dialog
            onCloseLogDetails: function () {
                this.getView().getModel("ViewModel").setProperty("/CurrentLogDetails", []);
                this.byId("LogDetailsDialog").close();
            }
        });
    });
