/**
 * eslint-disable @sap/ui5-jsdocs/no-jsdoc
 */

sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/jabil/costrolldashboard/model/models"
],
    function (UIComponent, Device, models) {
        "use strict";

        return UIComponent.extend("com.jabil.costrolldashboard.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);

                //sets component model
                this.setModel(models.createComponentModel(), "componentModel");

                //call function import to fetch company codes
                this.fetchUserCompanyCodes();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");
            },

            fetchUserCompanyCodes: function () {
                this.getModel().callFunction("/getUserCoCd", {
                    method: "GET",
                    success: function (oData) {
                        var aCompCode = [];
                        if (oData.getUserCoCd && oData.getUserCoCd !== "*") {
                            aCompCode = oData.getUserCoCd.split(",");
                        }
                        this.getModel("componentModel").setProperty("/CompanyCodes", aCompCode);
                        // enable routing
                        this.getRouter().initialize();
                    }.bind(this),
                    error: function (oError) {
                        this.getModel("componentModel").setProperty("/CompanyCodes", []);
                        // enable routing
                        this.getRouter().initialize();
                    }.bind(this)
                });
            }
        });
    }
);