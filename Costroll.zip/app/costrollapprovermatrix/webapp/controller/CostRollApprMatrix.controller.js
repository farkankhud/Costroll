sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/BusyIndicator",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment",
    "sap/m/Token"
],
    function (Controller, JSONModel, BusyIndicator, MessageToast, MessageBox, Filter, FilterOperator, Fragment, Token) {
        "use strict";

        return Controller.extend("com.jabil.costrollapprovermatrix.controller.CostRollApprMatrix", {

            onInit: async function () {
                this.showBusyIndicator();
                this.bInitial = true;
                this.oModel = this.getOwnerComponent().getModel();
                this.ov4Model = this.getOwnerComponent().getModel("v4Model");
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                this.getView().setModel(this.getViewModelObject(), "ViewModel");
                this.getView().getModel("ViewModel").setSizeLimit(150000);
                this.setApprovalMatrixModel();
                await this.readValueHelpData(false).then(function () {
                    this.readRoutes()
                }.bind(this)).
                    then(function () {
                        this.hideBusyIndicator();
                    }.bind(this)).
                    catch(function () {
                        MessageToast.show(this.i18n.getText("operationFailedMsg"));
                        this.hideBusyIndicator();
                    }.bind(this));
            },

            readRoutes: function () {
                return new Promise(async function (resolve, reject) {
                    var oList = this.ov4Model.bindList("/ManageRoutes");
                    await oList.requestContexts(0, 150000).then(function (aContexts) {
                        var aArrayRoutes = [], aRoutes = [];
                        aContexts.forEach((oItem) => {
                            aArrayRoutes.push(oItem.getObject().routeID);
                        });
                        aArrayRoutes = [...new Set(aArrayRoutes)];
                        aArrayRoutes.forEach(function (sRouteID) {
                            aRoutes.push({
                                "routeID": sRouteID
                            });
                        });
                        this.getView().getModel("ValueHelpModel").setProperty("/RouteIDs", aRoutes);
                        this.getView().getModel("ValueHelpModel").setProperty("/ArrayRouteID", aArrayRoutes);
                    }.bind(this));
                }.bind(this));
            },

            readValueHelpData: function () {
                return new Promise(async function (resolve, reject) {
                    var oList = this.ov4Model.bindList("/MasterData");
                    await oList.requestContexts(0, 150000).then(function (aContexts) {
                        var aCompanyCode = [], aPlant = [], aDraft = [], aRouteID = [], aProfitCenter = [], aMaterialType = [];
                        var aArrayCompanyCode = [], aArrayPlantCode = [], aArrayProfitCenter = [], aArrayMaterialType = [];
                        aContexts.forEach((oItem) => {
                            aArrayCompanyCode.push(oItem.getObject().companyCode);
                            aArrayPlantCode.push(oItem.getObject().plantCode);
                            aArrayProfitCenter.push(oItem.getObject().profitCenter);
                            aArrayMaterialType.push(oItem.getObject().materialType);
                        });
                        aArrayCompanyCode = [...new Set(aArrayCompanyCode)];
                        aArrayPlantCode = [...new Set(aArrayPlantCode)];
                        aArrayProfitCenter = [...new Set(aArrayProfitCenter)];
                        aArrayMaterialType = [...new Set(aArrayMaterialType)];

                        aArrayCompanyCode.forEach(function (sCompanyCode) {
                            aCompanyCode.push({
                                "companyCode": sCompanyCode
                            });
                        });
                        aArrayPlantCode.forEach(function (sPlant) {
                            aPlant.push({
                                "plantCode": sPlant
                            });
                        });
                        aArrayProfitCenter.forEach(function (sProfitCenter) {
                            aProfitCenter.push({
                                "profitCenter": sProfitCenter
                            });
                        });
                        aArrayMaterialType.forEach(function (sMaterialType) {
                            aMaterialType.push({
                                "materialType": sMaterialType
                            });
                        });

                        var oValueHelpModel = new JSONModel({
                            "CompanyCodes": aCompanyCode,
                            "Plant": aPlant,
                            "ProfitCenter": aProfitCenter,
                            "MaterialType": aMaterialType,
                            "AllData": aContexts,
                            "ArrayCompanyCode": aArrayCompanyCode,
                            "ArrayPlantCode": aArrayPlantCode,
                            "ArrayProfitCenter": aArrayProfitCenter,
                            "ArrayMaterialType": aArrayMaterialType
                        });
                        this.setValueHelpModel(oValueHelpModel);
                        resolve();
                    }.bind(this))
                        .catch(function (oError) {
                            reject(oError);
                        });
                }.bind(this));
            },

            setValueHelpModel: function (oValueHelpModel) {
                if (oValueHelpModel) {
                    this.getView().setModel(oValueHelpModel, "ValueHelpModel");
                } else {
                    this.getView().setModel(this.getValueHelpModelObject(), "ValueHelpModel");
                }
                this.getView().getModel("ValueHelpModel").setSizeLimit(150000);

            },

            getValueHelpModelObject: function () {
                var oValueHelpModel = new JSONModel({
                    "CompanyCodes": [],
                    "Plants": [],
                    "Draft": [],
                    "RouteIDs": [],
                    "ArrayCompanyCode": [],
                    "ArrayPlantCode": [],
                    "ArrayDraft": [],
                    "ArrayRouteID": [],
                });
                return oValueHelpModel;
            },

            getViewModelObject: function () {
                var oViewModel = new JSONModel({
                    "CompanyCodeValueState": "None",
                    "PlantCodeValueState": "None",
                    "Add": true
                });
                return oViewModel;
            },

            setApprovalMatrixModel: function () {
                this.getView().setModel(this.getApprovalMatrixModelObject(), "ApprovalMatrix");
                this.getView().getModel("ApprovalMatrix").setSizeLimit(150000);
            },

            getApprovalMatrixModelObject: function () {
                var oApprovalMatrix = new JSONModel({
                    "companyCode": "",
                    "plantCode": "",
                    "profitCenter": "",
                    "materialType": "",
                    "routeID": ""
                });
                return oApprovalMatrix;
            },

            onAddRowApproverMatrix: function () {
                this.getView().setModel(this.getApprovalMatrixModelObject(), "ApprovalMatrix");
                this.getView().getModel("ApprovalMatrix").setSizeLimit(150000);
                if (!this.oAddNewItem) {
                    this.oAddNewItem = this.loadFragment({
                        name: "com.jabil.costrollapprovermatrix.fragment.AddNewItem"
                    });
                }

                this.oAddNewItem.then(function (oAddNewItemDialog) {
                    this.getView().getModel("ViewModel").setProperty("/Add", true);
                    this.byId("AddNewUserDialog").setTitle(this.i18n.getText("AddNewItemTitle", ["Add New"]));
                    this.resetMultiInputs();
                    this.oAddNewItemDialog = oAddNewItemDialog;
                    this.oAddNewItemDialog.open();
                }.bind(this));
            },

            resetMultiInputs: function () {
                this.byId("MaterialTypeMultiInput").destroyTokens();
                this.byId("MaterialTypeMultiInput").setValue();
            },

            onCloseNewItemDialog: function () {
                this.oAddNewItemDialog.close();
            },

            onSave: function () {
                if (this.getView().getModel("ViewModel").getProperty("/Add")) {
                    this.performCreate();
                } else {
                    this.updateUser();
                }
            },

            performCreate: function () {
                var oPayload = this.getView().getModel("ApprovalMatrix").getProperty("/");
                this.showBusyIndicator();
                if (!this.validateAddNewItem()) {
                    this.hideBusyIndicator();
                    return;
                }
                this.oModel.create("/ApproverMatrix", oPayload, {
                    success: function (odata) {
                        this.closeDialogNewUser();
                        this.oModel.refresh();
                        MessageToast.show(this.i18n.getText("itemCreated"));
                        this.hideBusyIndicator();
                    }.bind(this),
                    error: function (oError) {
                        this.closeDialogNewUser();
                        this.oModel.refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                        this.hideBusyIndicator();
                    }.bind(this)
                })
            },

            validateEditItem: function () {
                var aValidationMessages = [], sValidatonMessage = "";
                if (this.getView().getModel("ViewModel").getProperty("/RouteIDValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("routeIdInvalidMsg"));
                } else {
                    if (!this.getView().getModel("ApprovalMatrix").getProperty("/routeID")) {
                        aValidationMessages.push(this.i18n.getText("routeIdReqMsg"));
                    }
                }

                sValidatonMessage = aValidationMessages.join("\n\n");
                if (aValidationMessages.length > 0) {
                    MessageBox.information(this.i18n.getText("reqFieldsMissingMsg") + "\n\n" + sValidatonMessage);
                    return false;
                }
                return true;
            },

            validateAddNewItem: function () {
                var aValidationMessages = [], sValidatonMessage = "";
                if (this.getView().getModel("ViewModel").getProperty("/CompanyCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("compCodeInvalidMsg"));
                } else {
                    if (!this.getView().getModel("ApprovalMatrix").getProperty("/companyCode")) {
                        aValidationMessages.push(this.i18n.getText("compCodeReqMsg"));
                    }
                }

                if (this.getView().getModel("ViewModel").getProperty("/PlantCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("plantInvalidMsg"));
                } else {
                    if (!this.getView().getModel("ApprovalMatrix").getProperty("/plantCode")) {
                        aValidationMessages.push(this.i18n.getText("plantReqMsg"));
                    }
                }

                if (this.getView().getModel("ViewModel").getProperty("/ProfitCenterValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("profitCenterInvalidMsg"));
                } else {
                    if (!this.getView().getModel("ApprovalMatrix").getProperty("/profitCenter")) {
                        aValidationMessages.push(this.i18n.getText("profitCenterReqMsg"));
                    }
                }

                if (this.getView().getModel("ViewModel").getProperty("/MaterialTypeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("materialTypeInvalidMsg"));
                } else {
                    if (!this.getView().getModel("ApprovalMatrix").getProperty("/materialType")) {
                        aValidationMessages.push(this.i18n.getText("materialTypeReqMsg"));
                    }
                }

                if (this.getView().getModel("ViewModel").getProperty("/RouteIDValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("routeIdInvalidMsg"));
                } else {
                    if (!this.getView().getModel("ApprovalMatrix").getProperty("/routeID")) {
                        aValidationMessages.push(this.i18n.getText("routeIdReqMsg"));
                    }
                }

                sValidatonMessage = aValidationMessages.join("\n\n");
                if (aValidationMessages.length > 0) {
                    MessageBox.information(this.i18n.getText("reqFieldsMissingMsg") + "\n\n" + sValidatonMessage);
                    return false;
                }
                return true;
            },

            closeDialogNewUser: function () {
                this.oAddNewItemDialog.close();
                this.setApprovalMatrixModel();
            },

            onEditItem: function (oEvent) {
                var oPath = oEvent.getSource().getBindingContext().getPath();
                var oItem = this.oModel.getProperty(oPath);
                this.getView().getModel("ApprovalMatrix").setProperty("/", oItem);
                if (!this.oAddNewItem) {
                    this.oAddNewItem = this.loadFragment({
                        name: "com.jabil.costrollapprovermatrix.fragment.AddNewItem"
                    });
                }
                this.oAddNewItem.then(function (oAddNewItemDialog) {
                    this.getView().getModel("ViewModel").setProperty("/Add", false);
                    this.byId("AddNewUserDialog").setTitle(this.i18n.getText("AddNewItemTitle", ["Edit"]));
                    this.resetMultiInputs();
                    this.setTokensInMultiInputs(oItem);
                    this.oAddNewItemDialog = oAddNewItemDialog;
                    this.oAddNewItemDialog.open();
                }.bind(this));
            },

            setTokensInMultiInputs: function (oItem) {
                var oToken;
                oItem.materialType.split(",").forEach(function (oItem) {
                    oToken = new Token({
                        text: oItem
                    });
                    this.byId("MaterialTypeMultiInput").addToken(oToken);
                }.bind(this));
            },


            updateUser: function () {
                if (!this.validateEditItem()) {
                    this.hideBusyIndicator();
                    return;
                }
                var oPayload = this.getView().getModel("ApprovalMatrix").getProperty("/");
                var sKey = this.oModel.createKey("/ApproverMatrix", {
                    companyCode: oPayload.companyCode,
                    plantCode: oPayload.plantCode,
                    profitCenter: oPayload.profitCenter,
                    materialType: oPayload.materialType
                });
                this.showBusyIndicator();
                this.oModel.update(sKey, oPayload, {
                    success: function (odata) {
                        this.oModel.refresh();
                        this.closeDialogEditItem();
                        MessageToast.show(this.i18n.getText("updateItemMsg"));
                        this.hideBusyIndicator();
                    }.bind(this),
                    error: function (oError) {
                        this.closeDialogEditItem();
                        this.oModel.refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                        this.hideBusyIndicator();
                    }.bind(this),
                }
                )
            },

            closeDialogEditItem: function () {
                this.oAddNewItemDialog.close();
                this.setApprovalMatrixModel();
            },

            hideBusyIndicator: function () {
                BusyIndicator.hide();
            },

            // Shows busy indicator
            showBusyIndicator: function () {
                BusyIndicator.show();
            },

            onDeleteItems: function (oEvent) {
                var aIndices = this.byId("UITabApproverMatrix").getSelectedIndices();
                if (!aIndices.length) {
                    MessageToast.show(this.i18n.getText("noItemSelected"));
                    return;
                }

                MessageBox.confirm(this.i18n.getText("DeleteConfirm"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            this.handleDelete(aIndices);
                        }
                    }.bind(this)
                });
            },

            handleDelete: function (aIndices) {
                var aPromises = []; var oItem; var sKey;
                aIndices.forEach((iIndex) => {
                    oItem = this.oModel.getProperty(this.byId("UITabApproverMatrix").getContextByIndex(iIndex).getPath());
                    sKey = this.oModel.createKey("/ApproverMatrix", {
                        companyCode: oItem.companyCode,
                        plantCode: oItem.plantCode,
                        profitCenter: oItem.profitCenter,
                        materialType: oItem.materialType
                    });
                    aPromises.push(this.performDelete(sKey));
                });
                Promise.all(aPromises).then(function () {
                    this.oModel.refresh();
                    MessageToast.show(this.i18n.getText("deleteItemMsg"));
                    this.hideBusyIndicator();
                }.bind(this), function (sError) {
                    MessageBox.error(this.i18n.getText("operationFailed"));
                    this.hideBusyIndicator();
                }.bind(this));
            },

            performDelete: function (sKey) {
                return new Promise(async function (resolve, reject) {
                    this.oModel.remove(sKey, {
                        success: function (odata) {
                            resolve();
                        }.bind(this),
                        error: function (oError) {
                            reject(oError)
                        }.bind(this)
                    });
                }.bind(this));
            },

            onRouteClick: function (oEvent) {
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ManageRoute",
                        action: "manage"
                    },
                    params: { "routeID": this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath()).routeID }
                })) || "";
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: hash
                    }
                });
            },

            onProfitCenterValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._profitCenterValueHelpDialog) {
                    this._profitCenterValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollapprovermatrix.fragment.ProfitCenterValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._profitCenterValueHelpDialog.then(function (oDialog) {
                    oDialog.getBinding("items").filter([new Filter("profitCenter", FilterOperator.Contains, sInputValue)]);
                    oDialog.open(sInputValue);
                }.bind(this));
            },

            onValueHelpProfitCenterSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("profitCenter", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpProfitCenterClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);

                if (!oSelectedItem) {
                    return;
                }

                // this.getView().getModel("ApprovalMatrix").setProperty("/profitCenter", oSelectedItem.getTitle());
                this.getView().getModel("ApprovalMatrix").setProperty("/profitCenter", this.getView().getModel("ValueHelpModel").getProperty(oEvent.getParameter("selectedContexts")[0].getPath()).profitCenter);
                this.getView().getModel("ViewModel").setProperty("/ProfitCenterValueState", "None");

                // var aSelectedItems = oEvent.getParameter("selectedItems"),
                //     oMultiInput = this.byId("ProfitCenterMultiInput");
                // var aValue = new Set([]), aTokens = [], oToken;
                // if (aSelectedItems && aSelectedItems.length > 0) {
                //     aSelectedItems.forEach(function (oItem) {
                //         oToken = new Token({
                //             text: oItem.getTitle()
                //         });
                //         oMultiInput.addToken(oToken);
                //         aTokens.push(oToken);
                //         aValue.add(oItem.getTitle());
                //     });
                //     oMultiInput.setValue();
                //     oMultiInput.setTokens(oMultiInput.getTokens().concat(aTokens));
                //     this.getView().getModel("ApprovalMatrix").setProperty("/profitCenter", 
                //         this.getView().getModel("ApprovalMatrix").getProperty("/profitCenter").split(",").concat([...aValue]).join(",")
                //     );
                //     this.getView().getModel("ViewModel").setProperty("/ProfitCenterValueState", "None");
                // }

            },

            onProfitCenterChange: function (oEvent) {
                // oEvent.getSource().setValue();
                // oEvent.getSource().setTokens(oEvent.getSource().getTokens());

                oEvent.getSource().setValueState("None");
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayProfitCenter").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            },

            onProfitCenterTokenUpdate: function (oEvent) {
                var aTokens = oEvent.getSource().getTokens();
                var aValue = new Set([]);
                if (aTokens && aTokens.length > 0) {
                    aTokens.forEach(function (oItem) {
                        aValue.add(oItem.getText());
                    });
                    this.getView().getModel("ApprovalMatrix").setProperty("/profitCenter",
                        this.getView().getModel("ApprovalMatrix").getProperty("/profitCenter").split(",").concat([...aValue]).join(",")
                    );
                } else {
                    this.getView().getModel("ApprovalMatrix").setProperty("/profitCenter", "");
                }
                this.getView().getModel("ViewModel").setProperty("/ProfitCenterValueState", "None");
            },

            onMaterialTypeValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._materialTypeValueHelpDialog) {
                    this._materialTypeValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollapprovermatrix.fragment.MaterialTypeValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._materialTypeValueHelpDialog.then(function (oDialog) {
                    oDialog.getBinding("items").filter([new Filter("materialType", FilterOperator.Contains, sInputValue)]);
                    oDialog.open(sInputValue);
                }.bind(this));
            },

            onValueHelpMaterialTypeSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("materialType", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpMaterialTypeClose: function (oEvent) {
                // var oSelectedItem = oEvent.getParameter("selectedItem");
                // oEvent.getSource().getBinding("items").filter([]);

                // if (!oSelectedItem) {
                //     return;
                // }

                // this.getView().getModel("ApprovalMatrix").setProperty("/materialType", oSelectedItem.getTitle());
                // this.getView().getModel("ViewModel").setProperty("/MaterialTypeValueState", "None");

                var aSelectedItems = oEvent.getParameter("selectedItems"),
                    oMultiInput = this.byId("MaterialTypeMultiInput");
                var aValue = new Set([]), aTokens = [], oToken;
                if (aSelectedItems && aSelectedItems.length > 0) {
                    aSelectedItems.forEach(function (oItem) {
                        oToken = new Token({
                            text: oItem.getTitle()
                        });
                        oMultiInput.addToken(oToken);
                        aTokens.push(oToken);
                        aValue.add(oItem.getTitle());
                    });
                    oMultiInput.setValue();
                    oMultiInput.setTokens(oMultiInput.getTokens().concat(aTokens));
                    this.getView().getModel("ApprovalMatrix").setProperty("/materialType", [...aValue].join(","));
                    this.getView().getModel("ViewModel").setProperty("/MaterialTypeValueState", "None");
                }
            },

            onMaterialTypeChange: function (oEvent) {
                // oEvent.getSource().setValue();
                // oEvent.getSource().setTokens(oEvent.getSource().getTokens());

                oEvent.getSource().setValueState("None");
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayMaterialType").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            },

            onMaterialTypeTokenUpdate: function (oEvent) {
                var aTokens = oEvent.getSource().getTokens();
                var aValue = new Set([]);
                if (aTokens && aTokens.length > 0) {
                    aTokens.forEach(function (oItem) {
                        aValue.add(oItem.getText());
                    });
                    this.getView().getModel("ApprovalMatrix").setProperty("/materialType", [...aValue].join(","));
                } else {
                    this.getView().getModel("ApprovalMatrix").setProperty("/materialType", "");
                }
                this.getView().getModel("ViewModel").setProperty("/MaterialTypeValueState", "None");
            },

            onCompanyCodeValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._companyCodeValueHelpDialog) {
                    this._companyCodeValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollapprovermatrix.fragment.CompanyCodeValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._companyCodeValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("companyCode", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                }.bind(this));
            },

            onValueHelpCompanyCodeSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("companyCode", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpCompanyCodeClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);

                // this.getView().getModel("ApprovalMatrix").setProperty("/companyCode", "");
                this.getView().getModel("ApprovalMatrix").setProperty("/plantCode", "");
                this.getView().getModel("ApprovalMatrix").setProperty("/profitCenter", "");
                this.getView().getModel("ApprovalMatrix").setProperty("/materialType", "");
                this.resetMultiInputs();
                this.filterPlantBasedOnComp(oSelectedItem.getTitle());

                if (!oSelectedItem) {
                    return;
                }

                // this.getView().getModel("ApprovalMatrix").setProperty("/companyCode", oSelectedItem.getTitle());
                this.getView().getModel("ApprovalMatrix").setProperty("/companyCode", this.getView().getModel("ValueHelpModel").getProperty(oEvent.getParameter("selectedContexts")[0].getPath()).companyCode);

                this.getView().getModel("ViewModel").setProperty("/CompanyCodeValueState", "None");
            },

            filterPlantBasedOnComp: function (sCompanyCode) {
                var aAllData = this.getView().getModel("ValueHelpModel").getProperty("/AllData");
                var aItems = aAllData.filter((oItem) => {
                    return oItem.getObject().companyCode === sCompanyCode
                });
                var aArrayPlantCode = [], aPlant = [], aArrayProfitCenter = [], aProfitCenter = [],
                    aArrayMaterialType = [], aMaterialType = [];
                aItems.forEach((oItem) => {
                    aArrayPlantCode.push(oItem.getObject().plantCode);
                    aArrayProfitCenter.push(oItem.getObject().profitCenter);
                    aArrayMaterialType.push(oItem.getObject().materialType);
                });
                aArrayPlantCode = [...new Set(aArrayPlantCode)];
                aArrayPlantCode.forEach(function (sPlant) {
                    aPlant.push({
                        "plantCode": sPlant
                    });
                });
                aArrayProfitCenter = [...new Set(aArrayProfitCenter)];
                aArrayProfitCenter.forEach(function (sProfitCenter) {
                    aProfitCenter.push({
                        "profitCenter": sProfitCenter
                    });
                });
                aArrayMaterialType = [...new Set(aArrayMaterialType)];
                aArrayMaterialType.forEach(function (sMaterialType) {
                    aMaterialType.push({
                        "materialType": sMaterialType
                    });
                });
                this.getView().getModel("ValueHelpModel").setProperty("/Plant", aPlant);
                this.getView().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", aArrayPlantCode);

                this.getView().getModel("ValueHelpModel").setProperty("/ProfitCenter", aProfitCenter);
                this.getView().getModel("ValueHelpModel").setProperty("/ArrayProfitCenter", aArrayProfitCenter);

                this.getView().getModel("ValueHelpModel").setProperty("/MaterialType", aMaterialType);
                this.getView().getModel("ValueHelpModel").setProperty("/ArrayMaterialType", aArrayMaterialType);
            },

            onCompanyCodeChange: function (oEvent) {
                oEvent.getSource().setValueState("None");

                
                this.getView().getModel("ApprovalMatrix").setProperty("/plantCode", "");
                this.getView().getModel("ApprovalMatrix").setProperty("/profitCenter", "");
                this.getView().getModel("ApprovalMatrix").setProperty("/materialType", "");
                this.resetMultiInputs();
                this.filterPlantBasedOnComp(oEvent.getParameters().value);

                if (!oEvent.getParameters().value) {
                    this.getView().getModel("ApprovalMatrix").setProperty("/companyCode", "");
                    // this.getView().getModel("ApprovalMatrix").setProperty("/plantCode", "");
                    // this.getView().getModel("ApprovalMatrix").setProperty("/profitCenter", "");
                    // this.getView().getModel("ApprovalMatrix").setProperty("/materialType", "");
                    // this.resetMultiInputs();
                    // this.filterPlantBasedOnComp(oEvent.getParameters().value);
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayCompanyCode").indexOf(oEvent.getParameters().value) === -1) {
                    // this.getView().getModel("ValueHelpModel").setProperty("/Plant", []);
                    // this.getView().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", []);
                    oEvent.getSource().setValueState("Error");
                    this.getView().getModel("ApprovalMatrix").setProperty("/companyCode", "");
                    this.getView().getModel("ApprovalMatrix").setProperty("/plantCode", "");
                    this.getView().getModel("ApprovalMatrix").setProperty("/materialType", "");
                    this.filterPlantBasedOnComp(oEvent.getParameters().value);
                } else {
                    this.filterPlantBasedOnComp(oEvent.getParameters().value);
                }
            },

            onPlantCodeChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayPlantCode").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            },

            onPlantValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._plantValueHelpDialog) {
                    this._plantValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollapprovermatrix.fragment.PlantCodeValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._plantValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("plantCode", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onValueHelpPlantSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("plantCode", FilterOperator.Contains, sValue);
                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpPlantClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);
                if (!oSelectedItem) {
                    return;
                }
                // this.getView().getModel("ApprovalMatrix").setProperty("/plantCode", oSelectedItem.getTitle());
                this.getView().getModel("ApprovalMatrix").setProperty("/plantCode", this.getView().getModel("ValueHelpModel").getProperty(oEvent.getParameter("selectedContexts")[0].getPath()).plantCode);
                this.getView().getModel("ViewModel").setProperty("/PlantCodeValueState", "None");
            },

            onRouteIDValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._routeIDValueHelpDialog) {
                    this._routeIDValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollapprovermatrix.fragment.RouteIdValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._routeIDValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("routeID", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onValueHelpRouteIDSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("routeID", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpRouteIDClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);

                if (!oSelectedItem) {
                    return;
                }

                // this.getView().getModel("ApprovalMatrix").setProperty("/routeID", oSelectedItem.getTitle());
                this.getView().getModel("ApprovalMatrix").setProperty("/routeID", this.getView().getModel("ValueHelpModel").getProperty(oEvent.getParameter("selectedContexts")[0].getPath()).routeID);
                this.getView().getModel("ViewModel").setProperty("/RouteIDValueState", "None");
            },

            onRouteIDChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayRouteID").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            }
        });
    });

