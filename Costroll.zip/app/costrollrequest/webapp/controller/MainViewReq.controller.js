sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/ui/core/BusyIndicator",
    "com/jabil/costrollrequest/util/jszip",
    "com/jabil/costrollrequest/util/xlsx",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet"
],
    function (Controller, Fragment, JSONModel, MessageBox, BusyIndicator, jszip, xlsx, MessageToast, Filter, FilterOperator, exportLibrary, Spreadsheet) {
        "use strict";

        return Controller.extend("com.jabil.costrollrequest.controller.MainViewReq", {
            onInit: async function () {
                this.showBusyIndicator();
                this.oModel = this.getOwnerComponent().getModel("v4Model");
                this.oRouteModel = this.getOwnerComponent().getModel("approvalMatrix");
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                this._MessageManager = sap.ui.getCore().getMessageManager();
                this._MessageManager.registerObject(this.getView(), true);
                this.getOwnerComponent().setModel(this._MessageManager.getMessageModel(), "message");
                // Model to bind properties to handle view
                this.getView().setModel(this.getViewModelObject(), "ViewModel");
                this.getView().getModel("ViewModel").setSizeLimit(150000);
                this.setCostRollModel();

                await this.readValueHelpData(false).then(function () {
                    if (this.getOwnerComponent().getComponentData() && this.getOwnerComponent().getComponentData().startupParameters && this.getOwnerComponent().getComponentData().startupParameters.TicketID) {
                        this.sTicketID = this.getOwnerComponent().getComponentData().startupParameters.TicketID[0];
                        // this.sDraftName = this.getOwnerComponent().getComponentData().startupParameters.DraftName[0];
                    }
                    if (this.sTicketID) {
                        this.getView().getModel("ViewModel").setProperty("/TicketId", this.sTicketID);
                        this.onGoPress();
                    }
                    this.hideBusyIndicator();
                }.bind(this)).catch(function () {
                    this.hideBusyIndicator();
                }.bind(this));
            },

            getViewModelObject: function () {
                this.aFileIdAttachment = [];
                var oViewModel = new JSONModel({
                    "ReadViaGo": false,
                    "SubmitPressed": false,
                    "Display": false,
                    "UpdateCostRoll": false,
                    "TypeName": "",
                    "TicketId": "",
                    "DraftName": "",
                    "DraftNameValueState": "None",
                    "Attachments": [],
                    "UploadAttachments": [],
                    "RequestTypeValueState": "None",
                    "CompanyCodeValueState": "None",
                    "DraftValueState": "None",
                    "RouteIDValueState": "None",
                    "PlantCodeValueState": "None",
                    "CostingType": "",
                    "CostingTypes": [{
                        "TypeName": "Standard Cost"
                    }, {
                        "TypeName": "Quoted Cost (PP2)"
                    }],
                    "CostingTypeValueState": "None",
                    "CostingVariants": [],
                    "VariantStd": [{
                        "VariantName": "ZAC2"
                    }, {
                        "VariantName": "ZCA3"
                    }],
                    "VariantPP2": [{
                        "VariantName": "ZP2S"
                    }, {
                        "VariantName": "ZP3S"
                    }],
                    "CostingVariantValueState": "None",
                    "DeletionType": "",
                    "DeletionTypes": [{
                        "TypeName": "Future Std Cost Estimates"
                    }, {
                        "TypeName": "Current Std Cost Estimates"
                    }],
                    "DeletionTypeValueState": "None",
                    "RequestTypes": [{
                        "TypeName": "Cost Roll",
                        "TypeKey": "1"
                    }, {
                        "TypeName": "Cost Roll Deletion",
                        "TypeKey": "2"
                    }],
                    "Documents": [],
                    "DeletedItems": [],
                    "DeletedAttachments": [],
                    "RowMode": "Interactive",
                    "FetchPartDetailsFailed": false,
                    "WarningMessage": "",
                    "Requestor": false
                });
                return oViewModel;
            },

            resetViewModel: function () {
                this.aFileIdAttachment = [];
                this.getView().setModel(this.getViewModelObject(), "ViewModel");
                this.getView().getModel("ViewModel").setSizeLimit(150000);
            },

            setCostRollModel: function () {
                this.getView().setModel(this.getCostRollModelObject(), "CostRollModel");
                this.getView().getModel("CostRollModel").setSizeLimit(150000);
            },

            getCostRollModelObject: function () {
                var oCostRollModel = new JSONModel({
                    "ID": "",
                    "ticketID": "",
                    "draftName": "",
                    "companyCode": "",
                    "plantCode": "",
                    "requestType": "",
                    "subReqType": "",
                    "variant": "",
                    "remark": "",
                    "revImpact": 0.0,
                    "workcell": "",
                    "reason": "",
                    "sequence": "",
                    "crLineItems": [],
                    "crAttachments": []
                });
                return oCostRollModel;
            },

            resetCostRollModel: function () {
                this.getView().setModel(this.getCostRollModelObject(), "CostRollModel");
                this.getView().getModel("CostRollModel").setSizeLimit(150000);

            },

            readValueHelpData: function (bDraftRefresh) {
                return new Promise(async function (resolve, reject) {
                    this.showBusyIndicator();
                    var aPromises = [];
                    var oValueHelpModel = new JSONModel({
                        "CompanyCodes": [],
                        "Plant": [],
                        "Draft": [],
                        "RouteIDs": [],
                        "AllData": [],
                        "ArrayCompanyCode": [],
                        "ArrayPlantCode": [],
                        "ArrayDraft": [],
                        "ArrayRouteID": [],
                        "RouteData": []
                    });
                    this.setValueHelpModel(oValueHelpModel);
                    aPromises.push(this.readMasterDataVH(bDraftRefresh));
                    aPromises.push(this.readRouteData());
                    Promise.all(aPromises).then(function () {
                        resolve();
                    }, function (sError) {
                        reject(sError);
                    });
                }.bind(this));
            },

            readMasterDataVH: function (bDraftRefresh) {
                return new Promise(async function (resolve, reject) {
                    var oOperation = this.oModel.bindContext("/getUserRoles(...)");
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        var aCompanyCode = [], aPlant = [], aDraft = [], aRouteID = [];
                        var aArrayCompanyCode = [], aArrayPlantCode = [];
                        // if (!bDraftRefresh) {
                        oOperationContext.getObject().AllData.forEach((oItem) => {
                            aArrayCompanyCode.push(oItem.COMPANYCODE);
                            aArrayPlantCode.push(oItem.PLANTCODE);
                        });
                        aArrayCompanyCode = [...new Set(aArrayCompanyCode)];
                        aArrayPlantCode = [...new Set(aArrayPlantCode)];
                        aArrayCompanyCode.forEach(function (sCompanyCode) {
                            aCompanyCode.push({
                                "COMPANYCODE": sCompanyCode
                            });
                        });
                        aArrayPlantCode.forEach(function (sPlant) {
                            aPlant.push({
                                "PLANTCODE": sPlant
                            });
                        });
                        oOperationContext.getObject().Draft.forEach((sDraft) => {
                            aDraft.push({
                                "draft": sDraft
                            });
                        });
                        this.getView().getModel("ValueHelpModel").setProperty("/CompanyCodes", aCompanyCode);
                        this.getView().getModel("ValueHelpModel").setProperty("/Plant", aPlant);
                        this.getView().getModel("ValueHelpModel").setProperty("/Draft", aDraft);
                        // this.getView().getModel("ValueHelpModel").setProperty("/RouteIDs", aRouteID);
                        this.getView().getModel("ValueHelpModel").setProperty("/AllData", oOperationContext.getObject().AllData);
                        this.getView().getModel("ValueHelpModel").setProperty("/ArrayCompanyCode", aArrayCompanyCode);
                        this.getView().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", aArrayPlantCode);
                        this.getView().getModel("ValueHelpModel").setProperty("/ArrayDraft", oOperationContext.getObject().Draft);
                        // } else {
                        //     oOperationContext.getObject().Draft.forEach((sDraft) => {
                        //         aDraft.push({
                        //             "draft": sDraft
                        //         });
                        //     });
                        //     this.getView().getModel("ValueHelpModel").setProperty("/Draft", aDraft);
                        //     this.getView().getModel("ValueHelpModel").setProperty("/ArrayDraft", oOperationContext.getObject().Draft);
                        // }
                        if (oOperationContext.getObject().RoleName === "Requestor") {
                            this.getView().getModel("ViewModel").setProperty("/Requestor", true);
                        } else {
                            this.getView().getModel("ViewModel").setProperty("/Requestor", false);
                        }
                        
                        this.hideBusyIndicator();
                        resolve();
                    }.bind(this)).catch(function () {
                        this.setValueHelpModel();
                        this.hideBusyIndicator();
                        reject();
                    }.bind(this));
                }.bind(this))
            },

            readRouteData: function () {
                return new Promise(async function (resolve, reject) {
                    var oList = this.oModel.bindList("/AppRouteData");
                    var aRoute = [];
                    // READ request
                    await oList.requestContexts(0, 150000).then(function (aContexts) {
                        aContexts.forEach(function (oContext) {
                            aRoute.push(oContext.getObject());
                        });
                        this.getView().getModel("ValueHelpModel").setProperty("/RouteData", aRoute);
                        resolve();
                    }.bind(this))
                        .catch(function (oError) {
                            this.getView().getModel("ValueHelpModel").setProperty("/RouteData", []);
                            reject(oError);
                        });
                }.bind(this));
            },

            setValueHelpModel: function (oValueHelpModel) {
                if (oValueHelpModel) {
                    this.getView().setModel(oValueHelpModel, "ValueHelpModel");
                } else {
                    this.getView().setModel(this.getValueHelpModelObject(), "ValueHelpModel");
                }
                this.getView().getModel("ValueHelpModel").setSizeLimit(150000);
            },
            getValueHelpModelObject: function () {
                var oValueHelpModel = new JSONModel({
                    "CompanyCodes": [],
                    "Plants": [],
                    "Draft": [],
                    "RouteIDs": [],
                    "ArrayCompanyCode": [],
                    "ArrayPlantCode": [],
                    "ArrayDraft": [],
                    "ArrayRouteID": [],
                });
                return oValueHelpModel;
            },

            onGoPress: function () {
                var oCostRoll = this.getView().getModel("CostRollModel");
                this.getView().getModel("ViewModel").setProperty("/DraftValueState", "None");
                if (!this.getView().getModel("ViewModel").getProperty("/DraftName") && !this.getView().getModel("ViewModel").getProperty("/TicketId")) {
                    MessageBox.information(this.i18n.getText("infoGoButtonPress"));
                    return;
                }

                if (this.getView().getModel("ViewModel").getProperty("/DraftName") && this.getView().getModel("ViewModel").getProperty("/TicketId")) {
                    MessageBox.information(this.i18n.getText("infoGoButtonPress"));
                    return;
                }

                if (oCostRoll.getProperty("/companyCode") || oCostRoll.getProperty("/plantCode")
                    || oCostRoll.getProperty("/requestType") || oCostRoll.getProperty("/Sequence")
                    || oCostRoll.getProperty("/subReqType") || oCostRoll.getProperty("/remark")
                    || oCostRoll.getProperty("/revImpact") || oCostRoll.getProperty("/workcell")
                    || oCostRoll.getProperty("/reason")) {
                    MessageBox.confirm(this.i18n.getText("overwriteConfirmation"), {
                        actions: [sap.m.MessageBox.Action.OK,
                        sap.m.MessageBox.Action.CANCEL],
                        onClose: function (sAction) {
                            if (sAction === sap.m.MessageBox.Action.OK) {
                                this.readCostRollDetails();
                            }
                        }.bind(this)
                    });
                } else {
                    if (!this.checkInvalidDraftValue()) {
                        this.readCostRollDetails();
                    }
                }
            },

            checkInvalidDraftValue: function () {
                if (this.getView().getModel("ViewModel").getProperty("/DraftName") && this.getView().getModel("ViewModel").getProperty("/DraftValueState") === "Error") {
                    MessageBox.error(this.i18n.getText("invalidDraft"));
                    return true;
                }
                return false;
            },

            setDisplayFields: function () {
                if (this.getView().getModel("ViewModel").getProperty("/TicketId")) {
                    this.getView().getModel("ViewModel").setProperty("/Display", true);
                } else {
                    this.getView().getModel("ViewModel").setProperty("/Display", false);
                }
            },

            readCostRollDetails: async function () {
                var aFilters = [],
                    aTicketId = [],
                    aDraftName = [];
                if (this.getView().getModel("ViewModel").getProperty("/TicketId")) {
                    aTicketId.push(new sap.ui.model.Filter("ticketID", sap.ui.model.FilterOperator.EQ, this.getView().getModel("ViewModel").getProperty("/TicketId")));
                    aFilters.push(new sap.ui.model.Filter(aTicketId, false));
                }
                if (this.getView().getModel("ViewModel").getProperty("/DraftName")) {
                    aDraftName.push(new sap.ui.model.Filter("draftName", sap.ui.model.FilterOperator.EQ, this.getView().getModel("ViewModel").getProperty("/DraftName")));
                    aFilters.push(new sap.ui.model.Filter(aDraftName, false));
                }
                this.showBusyIndicator();
                await this.readCostDetails(aFilters).then(async function (aContexts) {
                    this.setDisplayFields();
                    if (aContexts.length > 0) {
                        this.getView().getModel("CostRollModel").setProperty("/", aContexts[0].getObject());
                        this.getView().getModel("ViewModel").setProperty("/ReadViaGo", true);
                        if (this.getView().getModel("CostRollModel").getProperty("/companyCode")) {
                            this.filterPlantBasedOnComp(this.getView().getModel("CostRollModel").getProperty("/companyCode"));
                        }
                        if (this.getView().getModel("CostRollModel").getProperty("/requestType") === "Cost Roll") {
                            this.getView().getModel("ViewModel").setProperty("/TypeName", "1");
                            this.getView().getModel("ViewModel").setProperty("/CostingType", this.getView().getModel("CostRollModel").getProperty("/subReqType"));
                            this.getView().getModel("ViewModel").setProperty("/CostingVariant", this.getView().getModel("CostRollModel").getProperty("/variant"));
                            // if (this.getView().getModel("CostRollModel").getProperty("/subReqType") === "Standard Cost") {
                            //     this.getView().getModel("ViewModel").setProperty("/CostingVariants", this.getView().getModel("ViewModel").getProperty("/VariantStd"));
                            // } else {
                            //     this.getView().getModel("ViewModel").setProperty("/CostingVariants", this.getView().getModel("ViewModel").getProperty("/VariantPP2"));
                            // }
                            this.setCostingVariantData();
                        } else {
                            this.getView().getModel("ViewModel").setProperty("/TypeName", "2");
                            this.getView().getModel("ViewModel").setProperty("/DeletionType", this.getView().getModel("CostRollModel").getProperty("/subReqType"));
                        }
                        var aAttachments = [];
                        aContexts[0].getObject().crAttachments.forEach(function (oAttachment) {
                            this.aFileIdAttachment.push(oAttachment.ID);
                            aAttachments.push({
                                "ID": oAttachment.ID,
                                "DocumentName": oAttachment.FileID.DocumentName,
                                "DocumentType": oAttachment.FileID.DocumentType,
                                "DmsDocumentId": oAttachment.FileID.DmsDocumentId,
                            });
                        }.bind(this));
                        this.getView().getModel("ViewModel").setProperty("/UploadAttachments", aAttachments);
                        this.loadCostDetailsFragment(true);
                    } else {
                        this.performReset();
                        MessageBox.error(this.i18n.getText("noEntryFound"));
                    }

                    this.hideBusyIndicator();
                }.bind(this)).catch(function (oError) {
                    this.resetCostRollModel();
                    this.hideBusyIndicator();
                }.bind(this));
            },

            setCostingVariantData: function () {
                var aAllData = this.getView().getModel("ValueHelpModel").getProperty("/AllData");
                var sCompanyCode = this.getView().getModel("CostRollModel").getProperty("/companyCode");
                var sPlantCode = this.getView().getModel("CostRollModel").getProperty("/plantCode");
                var aVariant = [], aArrayVariant = [];
                var aItems = aAllData.filter((oItem) => {
                    return oItem.COMPANYCODE === sCompanyCode
                        && oItem.PLANTCODE === sPlantCode && oItem.COSTINGTYPE === this.getView().getModel("CostRollModel").getProperty("/subReqType").toUpperCase()
                });
                aItems.forEach((oItem) => {
                    aArrayVariant.push(oItem.COSTVARIANT);
                });
                aArrayVariant = [...new Set(aArrayVariant)];
                aArrayVariant.forEach(function (sVariant) {
                    aVariant.push({
                        "VariantName": sVariant
                    });
                });
                this.getView().getModel("ViewModel").setProperty("/CostingVariants", aVariant);
                if (aVariant.length > 0) {
                    this.getView().getModel("ViewModel").setProperty("/CostingVariant", aVariant[0].VariantName);
                    this.getView().getModel("CostRollModel").setProperty("/variant", aVariant[0].VariantName);
                }

            },

            readCostDetails: function (aFilters) {
                return new Promise(async function (resolve, reject) {
                    var oList = this.oModel.bindList("/Header", null, null, aFilters, {
                        $expand: "crLineItems,crAttachments($expand=FileID)"
                    });

                    // READ request
                    await oList.requestContexts().then(function (aContexts) {
                        resolve(aContexts);
                    }.bind(this))
                        .catch(function (oError) {
                            reject(oError);
                        });
                }.bind(this));
            },

            onReset: function () {
                this.performReset();
            },

            performReset: function () {
                this.resetViewModel();
                this.resetCostRollModel();

                // Old approach temp comment
                // this.byId("ItemsTable").destroyItems();
                // Old approach temp comment
            },

            onRevImpactChange: function (oEvent) {
                if (isNaN(parseFloat(oEvent.getParameters().value))) {
                    this.getView().getModel("CostRollModel").setProperty("/revImpact", 0.0);
                    MessageBox.error(this.i18n.getText("onlyNumbersAllowedMsg"));
                }
            },

            onExpectedCostChange: function (oEvent) {
                if (isNaN(parseFloat(oEvent.getParameters().value))) {
                    this.getView().getModel("CostRollModel").setProperty(oEvent.getSource().getBindingContext("CostRollModel").getPath() + "/expectedCost", 0.0);
                    MessageBox.error(this.i18n.getText("onlyNumbersAllowedMsg"));
                }
            },

            onRequestTypeChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                this.getView().getModel("ViewModel").setProperty("/DeletedItems",
                    this.getView().getModel("ViewModel").getProperty("/DeletedItems").concat(this.getView().getModel("CostRollModel").getProperty("/crLineItems")));
                this.getView().getModel("CostRollModel").setProperty("/crLineItems", []);
                this.getView().getModel("ViewModel").setProperty("/CostingVariant", "");
                this.getView().getModel("CostRollModel").setProperty("/variant", "");
                if (oEvent.getSource().getSelectedKey() === "1") {
                    this.getView().getModel("ViewModel").setProperty("/TypeName", "1");
                    this.getView().getModel("CostRollModel").setProperty("/requestType", "Cost Roll");
                } else if (oEvent.getSource().getSelectedKey() === "2") {
                    this.getView().getModel("ViewModel").setProperty("/TypeName", "2");
                    this.getView().getModel("CostRollModel").setProperty("/requestType", "Cost Deletion");
                } else {
                    this.getView().getModel("CostRollModel").setProperty("/requestType", "");
                    this.getView().getModel("ViewModel").setProperty("/TypeName", "");
                    oEvent.getSource().setValueState("Error");
                    // if (this.byId("ItemsTable")) {
                    //     this.byId("ItemsTable").destroyItems();
                    // }

                }
                this.showBusyIndicator();
                this.loadCostDetailsFragment(false);
            },

            onCostingTypeChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                this.getView().getModel("CostRollModel").setProperty("/variant", "");
                this.getView().getModel("ViewModel").setProperty("/CostingVariant", "");
                if (oEvent.getSource().getSelectedKey() === "Standard Cost") {
                    this.getView().getModel("CostRollModel").setProperty("/subReqType", "Standard Cost");
                } else if (oEvent.getSource().getSelectedKey() === "Quoted Cost (PP2)") {
                    this.getView().getModel("CostRollModel").setProperty("/subReqType", "Quoted Cost (PP2)");
                } else {
                    this.getView().getModel("CostRollModel").setProperty("/subReqType", "");
                    oEvent.getSource().setValueState("Error");
                }
                this.filterVariant(this.getView().getModel("CostRollModel").getProperty("/subReqType"));

            },

            filterVariant: function (sSubReqType) {
                var aAllData = this.getView().getModel("ValueHelpModel").getProperty("/AllData");
                var sCompanyCode = this.getView().getModel("CostRollModel").getProperty("/companyCode");
                var sPlantCode = this.getView().getModel("CostRollModel").getProperty("/plantCode");
                var aVariant = [], aArrayVariant = [];
                var aItems = aAllData.filter((oItem) => {
                    return oItem.COMPANYCODE === sCompanyCode
                        && oItem.PLANTCODE === sPlantCode && oItem.COSTINGTYPE === sSubReqType.toUpperCase()
                });
                aItems.forEach((oItem) => {
                    aArrayVariant.push(oItem.COSTVARIANT);
                });
                aArrayVariant = [...new Set(aArrayVariant)];
                aArrayVariant.forEach(function (sVariant) {
                    aVariant.push({
                        "VariantName": sVariant
                    });
                });
                this.getView().getModel("ViewModel").setProperty("/CostingVariants", aVariant);
                this.getView().getModel("ViewModel").setProperty("/CostingVariant",
                    aVariant[0].VariantName
                );
                this.getView().getModel("CostRollModel").setProperty("/variant", aVariant[0].VariantName);
            },

            onCostingVariantChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                if (oEvent.getSource().getSelectedKey()) {
                    this.getView().getModel("CostRollModel").setProperty("/variant", oEvent.getSource().getSelectedKey());
                } else {
                    this.getView().getModel("CostRollModel").setProperty("/variant", "");
                    oEvent.getSource().setValueState("Error");
                }
            },

            onDeletionTypeChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                if (oEvent.getSource().getSelectedKey() === "Future Std Cost Estimates") {
                    this.getView().getModel("CostRollModel").setProperty("/subReqType", "Future Std Cost Estimates");
                } else if (oEvent.getSource().getSelectedKey() === "Current Std Cost Estimates") {
                    this.getView().getModel("CostRollModel").setProperty("/subReqType", "Current Std Cost Estimates");
                } else {
                    this.getView().getModel("CostRollModel").setProperty("/subReqType", "");
                    oEvent.getSource().setValueState("Error");
                }
            },

            onUploadCompleted: function (oEvent) {
                var oItem = oEvent.getParameter("item");
                var oFile = oItem.getFileObject();
                this.onUploadAttachment(oFile);
            },

            onRemovePressed: function (oEvent) {
                this.getView().getModel("ViewModel")
                    .getProperty("/Attachments")
                    .splice(parseInt(oEvent.getSource().getBindingContext("ViewModel").getPath().charAt(oEvent.getSource().getBindingContext("ViewModel").getPath().lastIndexOf("/") + 1)), 1);
                this.getView().getModel("ViewModel").refresh(true);
            },

            loadCostRollItemsFragment: function () {
                if (!this.byId("CostRollItemsTable")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.costrollrequest.fragment.CostRollItems",
                        controller: this
                    }).then(function (oContent) {
                        this.byId("ItemsTable").destroyItems();
                        this.byId("ItemsTable").addItem(oContent);
                    }.bind(this));
                }
            },

            loadCostDelItemsFragment: function () {
                if (!this.byId("CostDelItemsTable")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.costrollrequest.fragment.CostDelItems",
                        controller: this
                    }).then(function (oContent) {
                        this.byId("ItemsTable").destroyItems();
                        this.byId("ItemsTable").addItem(oContent);
                    }.bind(this));
                }
            },

            loadCostDetailsFragment: function (bRead) {
                if (!this.byId("CostDetailsVBox")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.costrollrequest.fragment.CostDetails",
                        controller: this
                    }).then(function (oContent) {
                        this.byId("CostDetailsLayout").addItem(oContent);
                        if (!bRead) {
                            this.setDefaultSubRequestType();
                        }
                        this.hideBusyIndicator();
                    }.bind(this));
                } else {
                    if (!bRead) {
                        this.setDefaultSubRequestType();
                    }
                    this.hideBusyIndicator();
                }
            },

            setDefaultSubRequestType: function () {
                this.resetValueStates();
                if (this.getView().getModel("ViewModel").getProperty("/TypeName") === "1") {
                    this.getView().getModel("ViewModel").setProperty("/CostingType",
                        this.getView().getModel("ViewModel").getProperty("/CostingTypes")[0].TypeName
                    );
                    this.getView().getModel("CostRollModel").setProperty("/subReqType", this.getView().getModel("ViewModel").getProperty("/CostingTypes")[0].TypeName);
                    this.filterVariant(this.getView().getModel("CostRollModel").getProperty("/subReqType"));
                } else if (this.getView().getModel("ViewModel").getProperty("/TypeName") === "2") {
                    this.getView().getModel("ViewModel").setProperty("/DeletionType",
                        this.getView().getModel("ViewModel").getProperty("/DeletionTypes")[0].TypeName
                    );
                    this.getView().getModel("CostRollModel").setProperty("/subReqType", this.getView().getModel("ViewModel").getProperty("/DeletionTypes")[0].TypeName);
                }
            },

            resetValueStates: function () {
                this.getView().getModel("ViewModel").setProperty("/CostingTypeValueState", "None");
                this.getView().getModel("ViewModel").setProperty("/CostingVariantValueState", "None");
                this.getView().getModel("ViewModel").setProperty("/DeletionTypeValueState", "None");
            },

            onPartNumberChange: function (oEvent) {
                var sPath = oEvent.getSource().getBindingContext("CostRollModel").getPath();
                if (!this.validatePartEntered(sPath)) {
                    this.getView().getModel("CostRollModel").setProperty(sPath + "/partNumber", "");
                    MessageToast.show(this.i18n.getText("partNumberAlreadyEntered"));
                }
                this.getView().getModel("CostRollModel").setProperty(sPath + "/flagFetchDetails", false);
            },

            validatePartEntered: function (sPath) {
                var aItems = this.getView().getModel("CostRollModel").getProperty("/crLineItems");
                var aFilteredItems = [];
                aFilteredItems = aItems.filter((oItem) => {
                    return oItem.partNumber === this.getView().getModel("CostRollModel").getProperty(sPath + "/partNumber")
                });
                if (aFilteredItems.length > 1) {
                    return false;
                } else {
                    return true;
                }
            },

            onAddItem: function () {
                this.getView().getModel("CostRollModel").getProperty("/crLineItems").push(this.prepareEmptyItem());
                this.getView().getModel("CostRollModel").setProperty("/crLineItems",
                    this.getView().getModel("CostRollModel").getProperty("/crLineItems"));
                this.getView().getModel("CostRollModel").refresh(true);
            },

            onDeleteAll: function () {
                this.getView().getModel("ViewModel").setProperty("/DeletedItems",
                    this.getView().getModel("ViewModel").getProperty("/DeletedItems").concat(this.getView().getModel("CostRollModel").getProperty("/crLineItems")));
                this.getView().getModel("CostRollModel").setProperty("/crLineItems", []);
                this.getView().getModel("CostRollModel").refresh(true);
            },

            onDeleteAllAttachments: function () {
                this.getView().getModel("ViewModel").setProperty("/DeletedAttachments",
                    this.getView().getModel("ViewModel").getProperty("/DeletedItems").concat(this.getView().getModel("CostRollModel").getProperty("/UploadAttachments")));
                this.getView().getModel("ViewModel").setProperty("/UploadAttachments", []);
            },

            prepareEmptyItem: function () {
                if (this.getView().getModel("ViewModel").getProperty("/TypeName") === "1") {
                    return {
                        "partNumber": "",
                        "profitCenter": "",
                        "STDpriceToday": 0.0,
                        "materialType": "",
                        "plannedPrice": 0.0,
                        "futurePrice": 0.0,
                        "futurePriceFrom": null,
                        "futurePriceLocal": 0.0,
                        "futurePriceFromLocal": null,
                        "futurePriceGroup": 0.0,
                        "futurePriceFromGroup": null,
                        "expectedCost": 0.0,
                        "flagFetchDetails": false,
                        "routeID": ""
                        // "addedNow": true
                    };
                } else {
                    return {
                        "partNumber": "",
                        "profitCenter": "",
                        "actualCost": 0.0,
                        "materialType": "",
                        "flagFetchDetails": false,
                        "routeID": ""
                        // "addedNow": true
                    };
                }
            },

            onItemDelete: function (oEvent) {
                var aDeletedItems = this.getView().getModel("CostRollModel")
                    .getProperty("/crLineItems")
                    .splice(parseInt(oEvent.getSource().getBindingContext("CostRollModel").getPath().charAt(oEvent.getSource().getBindingContext("CostRollModel").getPath().lastIndexOf("/") + 1)), 1);
                this.getView().getModel("ViewModel").setProperty("/DeletedItems",
                    this.getView().getModel("ViewModel").getProperty("/DeletedItems").concat(aDeletedItems));
                this.getView().getModel("CostRollModel").refresh(true);
            },

            onAttachmentDelete: function (oEvent) {
                var aDeletedItems = this.getView().getModel("ViewModel")
                    .getProperty("/UploadAttachments")
                    .splice(parseInt(oEvent.getParameters().listItem.getBindingContext("ViewModel").getPath().charAt(oEvent.getParameters().listItem.getBindingContext("ViewModel").getPath().lastIndexOf("/") + 1)), 1);
                this.getView().getModel("ViewModel").setProperty("/DeletedAttachments",
                    this.getView().getModel("ViewModel").getProperty("/DeletedAttachments").concat(aDeletedItems));
                this.getView().getModel("ViewModel").refresh(true);
            },

            fetchPartDetails: async function (oEvent) {
                var aLineItems = this.getView().getModel("CostRollModel").getProperty("/crLineItems");
                var aMessages = [], sMessages = "";
                if (this.validateFetchPartDetails()) {
                    this.showBusyIndicator();
                    this.getView().getModel("ViewModel").setProperty("/WarningMessage", "");
                    await this.performFetchPartDetails().then(function (oResponse) {
                        this.setPartDetails(oResponse.AdditionalDetails);
                        if (oResponse.ValidationPassed) {
                            this.getView().getModel("ViewModel").setProperty("/FetchPartDetailsFailed", false);
                            MessageToast.show(this.i18n.getText("partDetailsFetched"));
                            this.getView().getModel("CostRollModel").refresh(true);
                        } else {
                            this.getView().getModel("ViewModel").setProperty("/FetchPartDetailsFailed", true);
                            MessageBox.information(this.i18n.getText("partDetailsFetchedFailed") + oResponse.Message);
                        }
                        this.hideBusyIndicator();
                    }.bind(this)).catch(function (oError) {
                        this.displayErrorMessage(oError);
                        this.hideBusyIndicator();
                    }.bind(this));

                }

            },

            setPartDetails: function (aItems) {
                var aItemsToSet = [];
                var aWarningMessage = [];
                aItems.forEach((oItem) => {
                    delete oItem.costingRun;
                    oItem.futurePriceFrom = oItem.futurePriceFrom ? new Date(aItems[0].futurePriceFrom).toISOString().substring(0, 10) : null;
                    oItem.futurePriceFromLocal = oItem.futurePriceFromLocal ? new Date(aItems[0].futurePriceFromLocal).toISOString().substring(0, 10) : null;
                    oItem.futurePriceFromGroup = oItem.futurePriceFromGroup ? new Date(aItems[0].futurePriceFromGroup).toISOString().substring(0, 10) : null;
                    // oItem.flagFetchDetails = true;
                    if (oItem.Messagetype === "E") {
                        oItem.flagFetchDetails = false;
                    } else if (oItem.Messagetype === "W") {
                        aWarningMessage.push(oItem.Message);
                        oItem.flagFetchDetails = true;
                    } else {
                        oItem.flagFetchDetails = true;
                    }
                    aItemsToSet.push(oItem);
                });
                if (aWarningMessage.length > 0) {
                    this.getView().getModel("ViewModel").setProperty("/WarningMessage",
                        aWarningMessage.join("\n\n")
                    );
                } else {
                    this.getView().getModel("ViewModel").setProperty("/WarningMessage", "");
                }
                this.getView().getModel("CostRollModel").setProperty("/crLineItems", []);
                this.getView().getModel("CostRollModel").setProperty("/crLineItems", aItemsToSet);
                this.getView().getModel("CostRollModel").refresh(true);
            },

            onAttachmentUpload: function (oEvent) {

                Object.values(oEvent.getParameter("files")).forEach(function (oFile) {
                    this.getView().getModel("ViewModel").getProperty("/UploadAttachments").push({
                        "file": oFile,
                        "type": oFile.type,
                        "name": oFile.name,
                        "DocumentName": oFile.name.split(".")[0],
                        "DocumentType": oFile.name.split(".")[1]
                    });
                }.bind(this));
                this.getView().getModel("ViewModel").refresh(true);

            },

            onLineItemExcelUpload: function (oEvent) {
                this.showBusyIndicator();
                var aDeletedItems = this.getView().getModel("CostRollModel").getProperty("/crLineItems");
                this.getView().getModel("ViewModel").setProperty("/DeletedItems", aDeletedItems);
                this.getView().getModel("CostRollModel").setProperty("/crLineItems", []);
                this.parseAttachmentUpload(oEvent.getParameter("files")[0]);
            },

            parseAttachmentUpload: function (oFile) {
                var reader = new FileReader();
                var aLineItems = []; var aExcelLineItems;
                reader.onload = async function (e) {
                    var data = e.currentTarget.result;
                    var excelsheet = xlsx.read(data, {
                        type: "binary"
                    });
                    var bCostRoll = false;

                    for (var i = 0; i < excelsheet.SheetNames.length; i++) {

                        if (excelsheet.SheetNames[i].includes("CostRoll")) {
                            aExcelLineItems = await xlsx.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[i]]); // this is the required data in Object format
                            bCostRoll = true;
                        }
                        if (excelsheet.SheetNames[i].includes("CostRollDelete")) {
                            aExcelLineItems = await xlsx.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[i]]); // this is the required data in Object format
                        }
                    }
                    aExcelLineItems.forEach(function (oItem) {
                        if (bCostRoll) {
                            aLineItems.push({
                                "partNumber": oItem["Part Number"].toString(),
                                "profitCenter": "",
                                "STDpriceToday": 0.0,
                                "materialType": "",
                                "plannedPrice": 0.0,
                                "futurePrice": 0.0,
                                "futurePriceFrom": null,
                                "futurePriceLocal": 0.0,
                                "futurePriceFromLocal": null,
                                "futurePriceGroup": 0.0,
                                "futurePriceFromGroup": null,
                                "expectedCost": parseFloat(oItem["Expected Cost"]),
                                "flagFetchDetails": false
                            });
                        } else {
                            aLineItems.push({
                                "partNumber": oItem["Part Number"].toString(),
                                "profitCenter": "",
                                "actualCost": 0.0,
                                "materialType": "",
                                "flagFetchDetails": false
                            });
                        }
                    });
                    this.getView().getModel("CostRollModel").setProperty("/crLineItems", aLineItems);
                    this.getView().getModel("CostRollModel").refresh(true);
                    this.hideBusyIndicator();
                }.bind(this);
                reader.readAsArrayBuffer(oFile);
            },

            hideBusyIndicator: function () {
                BusyIndicator.hide();
            },

            // Shows busy indicator
            showBusyIndicator: function () {
                BusyIndicator.show();
            },

            onSaveDraft: function (oEvent) {
                this.getView().getModel("ViewModel").setProperty("/SubmitPressed", false);
                if (this.validateFieldsBeforeDraft()) {
                    this.displayDraftNameDialog();
                }
            },

            onSaveDraftDialog: function () {
                this.getView().getModel("ViewModel").setProperty("/DraftNameValueState", "None");

                if (!this.getView().getModel("ViewModel").getProperty("/DraftName")) {
                    this.getView().getModel("ViewModel").setProperty("/DraftNameValueState", "Error");
                    return;
                }

                this.byId("DraftNameDialog").close();
                this.performPost();
            },

            displayDraftNameDialog: function () {
                if (!this.byId("DraftNameDialog")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.costrollrequest.fragment.DraftNameInput",
                        controller: this
                    }).then(function (oDialog) {
                        this.getView().addDependent(oDialog);
                        if (this.checkIsDraft()) {
                            oDialog.open();
                        }
                    }.bind(this));
                } else {
                    if (this.checkIsDraft()) {
                        this.byId("DraftNameDialog").open();
                    }
                }
            },

            checkIsDraft: function () {
                if (this.getView().getModel("CostRollModel").getProperty("/draftName")) {
                    this.getView().getModel("ViewModel").setProperty("/UpdateCostRoll", true);
                    this.performPost();
                    return false;
                } else {
                    this.getView().getModel("ViewModel").setProperty("/UpdateCostRoll", false);
                    return true;
                }
            },

            onCancelDraftDialog: function () {
                this.getView().getModel("ViewModel").setProperty("/DraftNameValueState", "None");
                this.getView().getModel("ViewModel").setProperty("/DraftName", "");
                this.byId("DraftNameDialog").close();
            },

            onSubmit: function (oEvent) {
                this.getView().getModel("ViewModel").setProperty("/SubmitPressed", true);
                if (this.validateFields()) {
                    if (this.getView().getModel("CostRollModel").getProperty("/draftName")) {
                        this.getView().getModel("ViewModel").setProperty("/UpdateCostRoll", true);
                        this.getView().getModel("CostRollModel").setProperty("/draftName", "");
                    } else {
                        this.getView().getModel("ViewModel").setProperty("/UpdateCostRoll", false);
                    }
                    if (this.getView().getModel("ViewModel").getProperty("/WarningMessage")) {
                        MessageBox.confirm(this.i18n.getText("warningConirmation"), {
                            actions: [sap.m.MessageBox.Action.OK,
                            sap.m.MessageBox.Action.CANCEL],
                            onClose: function (sAction) {
                                if (sAction === sap.m.MessageBox.Action.OK) {
                                    this.performPost();
                                }
                            }.bind(this)
                        });
                    } else {
                        this.performPost();
                    }

                }
            },

            validateFieldsBeforeDraft: function () {
                var aValidationMessages = [], sValidatonMessage = "";
                if (this.getView().getModel("ViewModel").getProperty("/CompanyCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("compCodeInValidMsg"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/PlantCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("plantCodeInValidMsg"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/TypeName") === "1") {
                    if (this.getView().getModel("ViewModel").getProperty("/CostingTypeValueState") === "Error") {
                        aValidationMessages.push(this.i18n.getText("costTypeInValidMsg"));
                    }
                    if (this.getView().getModel("ViewModel").getProperty("/CostingVariantValueState") === "Error") {
                        aValidationMessages.push(this.i18n.getText("costVariantInValidMsg"));
                    }
                } else {
                    if (this.getView().getModel("ViewModel").getProperty("/DeletionTypeValueState") === "Error") {
                        aValidationMessages.push(this.i18n.getText("deleteVariantInValidMsg"));
                    }
                }
                sValidatonMessage = aValidationMessages.join("\n\n");
                if (aValidationMessages.length > 0) {
                    MessageBox.information(this.i18n.getText("reqFieldsMissingMsg") + "\n\n" + sValidatonMessage);
                    return false;
                }
                return true;
            },

            validateFields: function () {
                var aValidationMessages = [], sValidatonMessage = "";
                if (!this.getView().getModel("CostRollModel").getProperty("/companyCode")) {
                    aValidationMessages.push(this.i18n.getText("compCodeReqMsg"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/CompanyCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("compCodeInValidMsg"));
                }
                if (!this.getView().getModel("CostRollModel").getProperty("/plantCode")) {
                    aValidationMessages.push(this.i18n.getText("plantReqMsg"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/PlantCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("plantCodeInValidMsg"));
                }
                if (!this.getView().getModel("CostRollModel").getProperty("/requestType")
                    && this.byId("RequestTypeComboBox").getValueState() === "None") {
                    aValidationMessages.push(this.i18n.getText("requestTypeReqMsg"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/TypeName") === "1") {
                    if (!this.getView().getModel("CostRollModel").getProperty("/subReqType")) {
                        aValidationMessages.push(this.i18n.getText("costingTypeMsg"));
                    }
                    if (this.getView().getModel("ViewModel").getProperty("/CostingTypeValueState") === "Error") {
                        aValidationMessages.push(this.i18n.getText("costTypeInValidMsg"));
                    }
                    if (this.getView().getModel("ViewModel").getProperty("/CostingVariantValueState") === "Error") {
                        aValidationMessages.push(this.i18n.getText("costVariantInValidMsg"));
                    } else {
                        if (!this.getView().getModel("ViewModel").getProperty("/CostingVariant")) {
                            aValidationMessages.push(this.i18n.getText("costVariantMsg"));
                        }
                    }

                } else {
                    if (!this.getView().getModel("CostRollModel").getProperty("/reason")) {
                        aValidationMessages.push(this.i18n.getText("reasonMsg"));
                    }
                    if (this.getView().getModel("ViewModel").getProperty("/DeletionTypeValueState") === "Error") {
                        aValidationMessages.push(this.i18n.getText("deleteVariantInValidMsg"));
                    } else {
                        if (!this.getView().getModel("ViewModel").getProperty("/DeletionType")) {
                            aValidationMessages.push(this.i18n.getText("deletionTypeMsg"));
                        }
                    }

                }
                if (this.getView().getModel("CostRollModel").getProperty("/crLineItems").length === 0) {
                    aValidationMessages.push(this.i18n.getText("lineItemsEmpty"));
                } else {
                    aValidationMessages = aValidationMessages.concat(this.validateItems(this.getView().getModel("CostRollModel").getProperty("/crLineItems"), true));
                }
                if (this.getView().getModel("ViewModel").getProperty("/FetchPartDetailsFailed")) {
                    aValidationMessages.push(this.i18n.getText("fetchMaterialFailed"));
                }
                sValidatonMessage = aValidationMessages.join("\n\n");
                if (aValidationMessages.length > 0) {
                    MessageBox.information(this.i18n.getText("reqFieldsMissingMsg") + "\n\n" + sValidatonMessage);
                    return false;
                }
                return true;
            },

            validateFetchPartDetails: function () {
                var aValidationMessages = [], sValidatonMessage = "";
                if (!this.getView().getModel("CostRollModel").getProperty("/companyCode")) {
                    aValidationMessages.push(this.i18n.getText("compCodeReqMsg"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/CompanyCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("compCodeInValidMsg"));
                }
                if (!this.getView().getModel("CostRollModel").getProperty("/plantCode")) {
                    aValidationMessages.push(this.i18n.getText("plantReqMsg"));
                }
                if (this.getView().getModel("ViewModel").getProperty("/PlantCodeValueState") === "Error") {
                    aValidationMessages.push(this.i18n.getText("plantCodeInValidMsg"));
                }
                if (this.getView().getModel("CostRollModel").getProperty("/crLineItems").length === 0) {
                    aValidationMessages.push(this.i18n.getText("lineItemsEmpty"));
                } else {
                    aValidationMessages = aValidationMessages.concat(this.validateItems(this.getView().getModel("CostRollModel").getProperty("/crLineItems"), false));
                }
                sValidatonMessage = aValidationMessages.join("\n\n");
                if (aValidationMessages.length > 0) {
                    MessageBox.information(this.i18n.getText("reqFieldsMissingMsg") + "\n\n" + sValidatonMessage);
                    return false;
                }
                return true;
            },

            validateItems: function (aItems, bFetch) {
                var aMessages = [];
                for (let i = 0; i < aItems.length; i++) {
                    if (!aItems[i].partNumber) {
                        aMessages.push(this.i18n.getText("partNumberEmptyMsg", [i + 1]));
                    }
                    if (bFetch && !aItems[i].flagFetchDetails) {
                        aMessages.push(this.i18n.getText("syncNotDoneMsg", [i + 1]));
                    }
                }
                return aMessages;
            },

            checkPartDetailsNotEmpty: function (oItem) {
                if (!oItem.partNumber || !oItem.profitCenter || !oItem.materialType
                    || !oItem.STDpriceToday || !oItem.plannedPrice || !oItem.futurePriceLocal
                    || !oItem.futurePriceFromLocal || !oItem.futurePriceGroup
                    || !oItem.futurePriceFromGroup || !oItem.expectedCost) {
                    return true
                } else {
                    return false
                }
            },

            performPost: async function () {
                this.showBusyIndicator();
                this.removeAllMessages();
                if (this.getView().getModel("ViewModel").getProperty("/UpdateCostRoll")) {
                    await this.updateCostRollFields()
                        .then(function () {
                            // if (!this.getView().getModel("ViewModel").getProperty("/SubmitPressed")) {
                            //     MessageToast.show(this.i18n.getText("draftSuccess", [this.getView().getModel("CostRollModel").getProperty("/draftName")]));
                            // }
                            this.removeAllMessages();
                            return this.createLineItems();
                        }.bind(this))
                        .then(function () {
                            this.removeAllMessages();
                            return this.uploadAttachmentToDMSUpdate();
                        }.bind(this))
                        .then(function () {
                            this.removeAllMessages();
                            return this.createFileIdInAttachment();
                        }.bind(this))
                        .then(function () {
                            this.removeAllMessages();
                            return this.deleteLineItems();
                        }.bind(this))
                        .then(function () {
                            this.removeAllMessages();
                            return this.submitCostRoll();

                        }.bind(this))
                        .then(function () {
                            var oDisplay = this.displayDraftOrTicket();
                            this.performReset();
                            // MessageToast.show("Update Success");
                            this.performSuccessDisplay(oDisplay);
                            this.hideBusyIndicator();
                        }.bind(this))
                        .catch(function (sError) {
                            this.displayErrorMessage(sError);
                            this.hideBusyIndicator();
                        }.bind(this));
                } else {
                    await this.createCostRollMain()
                        .then(function () {
                            return this.uploadAttachmentToDMS();
                        }.bind(this))
                        .then(function () {
                            this.removeAllMessages();
                            return this.updateFileIdInAttachment();
                        }.bind(this))
                        .then(function () {
                            // this.displayMessage(sCWAName, bSubmit, sText);
                            var oDisplay = this.displayDraftOrTicket();
                            this.performReset();
                            this.performSuccessDisplay(oDisplay);
                            this.hideBusyIndicator();
                        }.bind(this))
                        .catch(function (sError) {
                            this.getView().getModel("CostRollModel").setProperty("/draftName", "");
                            this.getView().getModel("ViewModel").setProperty("/DraftName", "");
                            this.displayErrorMessage(sError);
                            this.hideBusyIndicator();
                        }.bind(this));
                }
            },

            performSuccessDisplay: function (oDisplay) {
                if (oDisplay.bDraft) {
                    this.getView().getModel("CostRollModel").setProperty("/draftName", oDisplay.Value);
                    this.getView().getModel("ViewModel").setProperty("/DraftName", oDisplay.Value);
                    this.displaySuccessMessage(this.i18n.getText("draftSuccessMsg", [oDisplay.Value]), oDisplay);
                } else {
                    this.getView().getModel("CostRollModel").setProperty("/ticketID", oDisplay.Value);
                    this.getView().getModel("ViewModel").setProperty("/TicketId", oDisplay.Value);
                    this.showBusyIndicator();
                    this.readValueHelpData(true).then(function () {
                        this.hideBusyIndicator();
                        this.displaySuccessMessage(this.i18n.getText("submitSuccessMsg", [oDisplay.Value]), oDisplay);
                    }.bind(this))

                }
            },

            createCostRollMain: function () {
                return new Promise(function (resolve, reject) {
                    var oList = this.oModel.bindList("/Header");
                    this.prepareCreatePayload().then(function (oCostRollHeader) {
                        var oContext = oList.create(oCostRollHeader, true);
                        oList.attachCreateCompleted(function (oEvent) {
                            if (oEvent.getParameters().success) {
                                if (!this.getView().getModel("ViewModel").getProperty("/SubmitPressed")) {
                                    // MessageToast.show(this.i18n.getText("draftSuccess", [oEvent.getParameters().context.getObject().draftName]));
                                    this.getView().getModel("CostRollModel").setProperty("/draftName", oEvent.getParameters().context.getObject().draftName);
                                } else {
                                    this.getView().getModel("CostRollModel").setProperty("/ticketID", oEvent.getParameters().context.getObject().ticketID);
                                }
                                this.getView().getModel("CostRollModel").setProperty("/ID", oEvent.getParameters().context.getObject().ID);

                                if (oEvent.getParameters().context.getObject().crAttachments) {
                                    this.getView().getModel("CostRollModel").setProperty("/crAttachments", oEvent.getParameters().context.getObject().crAttachments);
                                } else {
                                    this.getView().getModel("CostRollModel").setProperty("/crAttachments", []);
                                }

                                resolve();
                            } else {
                                reject(this.prepareErrorMessage());
                            }
                        }.bind(this));
                    }.bind(this));
                }.bind(this));
            },

            prepareErrorMessage: function () {
                var aMessages = [];
                this._MessageManager.getMessageModel().getProperty("/").forEach((oMessage) => {
                    aMessages.push(oMessage.message);
                });
                return aMessages.join("\n\n");
            },

            prepareCreatePayload: async function () {
                return new Promise(async function (resolve, reject) {
                    this.getView().getModel("CostRollModel").setProperty("/ticketID", this.getView().getModel("ViewModel").getProperty("/TicketId"));
                    this.getView().getModel("CostRollModel").setProperty("/draftName", this.getView().getModel("ViewModel").getProperty("/DraftName"));
                    var oPayload = JSON.parse(JSON.stringify(this.getView().getModel("CostRollModel").getProperty("/")));
                    await this.readFileContents().then(function () {
                        if (this.getView().getModel("ViewModel").getProperty("/SubmitPressed")) {
                            oPayload.draftName = "";
                        }
                        if (!oPayload.revImpact) {
                            oPayload.revImpact = 0.0;
                        }
                        oPayload.crLineItems.forEach(function (oItem) {
                            delete oItem.flagFetchDetails;
                            delete oItem.Message;
                            delete oItem.Messagetype;
                            // delete oItem.addedNow;
                        });
                        oPayload.crAttachments = [];
                        this.getView().getModel("ViewModel").getProperty("/UploadAttachments").forEach(function (oAttachment) {
                            oPayload.crAttachments.push({
                                FileID: null
                            });
                        });
                        if (oPayload.crLineItems.length > 0) {
                            oPayload.routeID = oPayload.crLineItems[0].routeID;
                        }
                        resolve(oPayload);
                    }.bind(this));
                }.bind(this));
            },

            uploadAttachmentToDMSUpdate: function () {
                return new Promise(async function (resolve, reject) {
                    var aPromises = [];
                    await this.readFileContents().then(function () {
                        var aAttachments = this.getView().getModel("ViewModel").getProperty("/Attachments");
                        aAttachments.forEach(function (oAttachment) {
                            aPromises.push(this.performAttachmentUploadUpdate(oAttachment));
                        }.bind(this));

                        Promise.all(aPromises).then(function () {
                            resolve();
                        }, function (sError) {
                            reject(sError);
                        });
                    }.bind(this));
                }.bind(this))
            },

            uploadAttachmentToDMS: function () {
                return new Promise(async function (resolve, reject) {
                    var aPromises = [];
                    var aAttachments = this.getView().getModel("ViewModel").getProperty("/Attachments");
                    aAttachments.forEach(function (oAttachment) {
                        aPromises.push(this.performAttachmentUploadUpdate(oAttachment));
                    }.bind(this));

                    Promise.all(aPromises).then(function () {
                        resolve();
                    }, function (sError) {
                        reject(sError);
                    });

                }.bind(this))
            },

            performAttachmentUploadUpdate: async function (oAttachment) {
                return new Promise(async function (resolve, reject) {
                    await this.performAttachmentUpload(oAttachment).then(function (sFileId) {
                        var oDocument = {
                            "DmsDocumentId": sFileId,
                            "DocumentName": oAttachment.fileName.split(".")[0],
                            "DocumentType": oAttachment.fileName.split(".")[1]
                        };
                        return this.createDocument(oDocument);
                    }.bind(this))
                        .then(function () {
                            resolve();
                        })
                        .catch(function (sError) {
                            reject(sError);
                        });
                }.bind(this));
            },

            performAttachmentUpload: function (oAttachment) {
                return new Promise(async function (resolve, reject) {
                    var oUploadPayload = {
                        "folderID": this.getView().getModel("CostRollModel").getProperty("/ID"),
                        "content": oAttachment.content,
                        "mediaType": oAttachment.type,
                        "fileName": oAttachment.fileName,
                        "fileID": null
                    };
                    var oOperation = this.oModel.bindContext("/CreateMediaFile(...)");
                    oOperation.setParameter('FileData', oUploadPayload);
                    this.showBusyIndicator();
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        this.hideBusyIndicator();
                        resolve(oOperationContext.getObject().folderID);
                    }.bind(this))
                        .catch(function (oError) {
                            this.hideBusyIndicator();
                            reject(oError);
                        }.bind(this));
                }.bind(this));
            },

            createDocument: function (oDocument) {
                return new Promise(async function (resolve, reject) {
                    this.aFileIdAttachment = [];
                    var oList = this.oModel.bindList("/Documents");
                    var oContext = oList.create(oDocument, true);
                    oList.attachCreateCompleted(await function (oEvent) {
                        if (oEvent.getParameters().success) {
                            this.aFileIdAttachment.push(oEvent.getParameters().context.getObject().ID);
                            resolve();
                        } else {
                            this.aFileIdAttachment = [];
                            reject(this.prepareErrorMessage());
                        }
                    }.bind(this));
                }.bind(this));
            },

            createFileIdInAttachment: function () {
                return new Promise(async function (resolve, reject) {
                    var aPromises = [];
                    var aAttachments = this.getView().getModel("ViewModel").getProperty("/Attachments");
                    aAttachments.forEach(function (oAttachment, iIndex) {
                        aPromises.push(this.createAttachments(oAttachment, iIndex));
                    }.bind(this));

                    Promise.all(aPromises).then(function () {
                        resolve();
                    }, function (sError) {
                        reject(sError);
                    });

                }.bind(this))
            },

            createAttachments: function (oAttachment, iIndex) {
                return new Promise(function (resolve, reject) {
                    var oList = this.oModel.bindList("/Attachments");
                    var oContext = oList.create({
                        "FileID_ID": this.aFileIdAttachment[iIndex],
                        "Parent_ID": this.getView().getModel("CostRollModel").getProperty("/ID")
                    }, true);
                    oList.attachCreateCompleted(function (oEvent) {
                        if (oEvent.getParameters().success) {
                            resolve();
                        } else {
                            reject(this.prepareErrorMessage());
                        }
                    }.bind(this));
                }.bind(this));
            },

            performCreateItem: function (oLineItem) {
                return new Promise(function (resolve, reject) {
                    var oList = this.oModel.bindList("/Items", null, null, null, {
                        "$$groupId": "CostRollItemCreate"
                    });
                    var oContext = oList.create(oLineItem, true);
                    oList.attachCreateCompleted(function (oEvent) {
                        if (oEvent.getParameters().success) {
                            resolve();
                        } else {
                            reject(this.prepareErrorMessage());
                        }
                    }.bind(this));
                }.bind(this));
            },

            updateFileIdInAttachment: function () {
                return new Promise(async function (resolve, reject) {
                    var aAttachments = this.getView().getModel("CostRollModel").getProperty("/crAttachments");
                    var aPromises = [];
                    aAttachments.forEach(function (oAttachment, iIndex) {
                        var oContextBinding = this.oModel.bindContext("/Attachments(" + oAttachment.ID + ")", null, {
                            $$updateGroupId: "CostRollAttachmentChange",
                            $expand: "FileID"
                        });
                        aPromises.push(this.requestAttachmentObject(oContextBinding, iIndex));
                    }.bind(this));
                    Promise.all(aPromises).then(async function () {
                        await this.oModel.submitBatch("CostRollAttachmentChange").then(function () {
                            resolve();
                        }.bind(this)).catch(function (oError) {
                            reject(oError);
                        }.bind(this));
                    }.bind(this)).catch(function (oError) {
                        reject(oError);
                    }.bind(this));
                }.bind(this));
            },

            requestAttachmentObject: function (oContextBinding, iIndex) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(function () {
                        oContextBinding.getBoundContext().setProperty("FileID_ID", this.aFileIdAttachment[iIndex]);
                        resolve();
                    }.bind(this));
                }.bind(this));
            },

            readFileContents: function (aAttachments) {
                return new Promise(async function (resolve, reject) {
                    var aAttachments = this.getView().getModel("ViewModel").getProperty("/UploadAttachments");
                    var aPromises = [];

                    aAttachments.forEach(function (oAttachment, iIndex) {
                        if (oAttachment.file) {
                            aPromises.push(this.performReadFile(oAttachment, iIndex));
                        }

                    }.bind(this));

                    Promise.all(aPromises).then(async function () {
                        resolve();
                    }, function (sError) {
                        reject(sError);
                    });
                }.bind(this));
            },

            performReadFile: function (oAttachment, iIndex) {
                return new Promise(async function (resolve, reject) {
                    var reader = new FileReader();
                    var aAttachments = [];
                    reader.onload = function (oEvent) {
                        this.getView().getModel("ViewModel").getProperty("/Attachments").push({
                            "content": oEvent.currentTarget.result,
                            "type": oAttachment.type,
                            "fileName": oAttachment.name
                        });
                        resolve();
                    }.bind(this);
                    reader.readAsDataURL(oAttachment.file);
                }.bind(this));
            },

            displayErrorMessage: function (sError) {
                if (typeof (sError) === "object") {
                    MessageBox.error(sError.toString());
                } else if (typeof (sError) === "string") {
                    MessageBox.error(sError);
                } else {
                    MessageBox.error(this.i18n.getText("operationFailedMsg"));
                }
            },

            displayDraftOrTicket: function () {
                var oCostRoll = this.getView().getModel("CostRollModel").getProperty("/");
                var oDisplay = {
                    "Value": "",
                    "bDraft": true
                };

                if (oCostRoll.draftName) {
                    oDisplay.Value = oCostRoll.draftName;
                    oDisplay.bDraft = true;
                } else {
                    oDisplay.Value = oCostRoll.ticketID;
                    oDisplay.bDraft = false;
                }
                // else if (oCostRoll.ticketID)
                return oDisplay;
            },

            updateCostRollFields: function () {
                return new Promise(async function (resolve, reject) {
                    var iID = this.getView().getModel("CostRollModel").getProperty("/ID");
                    var oUpdate = JSON.parse(JSON.stringify(this.getView().getModel("CostRollModel").getProperty("/")));
                    var aPromises = [];

                    var oContextBinding = this.oModel.bindContext("/Header(" + iID + ")", null, {
                        $$updateGroupId: "CostRollUpdate"
                    });

                    aPromises.push(this.performUpdateCostRoll(oContextBinding, oUpdate));
                    var oItemContextBinding;
                    oUpdate.crLineItems.forEach(function (oLineItem) {
                        // delete oLineItem.flagFetchDetails;
                        if (oLineItem.ID) {
                            oItemContextBinding = this.oModel.bindContext("/Items(" + oLineItem.ID + ")", null, {
                                $$updateGroupId: "CostRollUpdate"
                            });
                            aPromises.push(this.performUpdateCostRollItems(oItemContextBinding, oLineItem));
                        }
                    }.bind(this));

                    Promise.all(aPromises).then(async function () {
                        await this.oModel.submitBatch("CostRollUpdate").then(function () {
                            resolve();
                        }.bind(this)).catch(function (oError) {
                            reject(oError);
                        }.bind(this));
                    }.bind(this), function (sError) {
                        reject(sError);
                    }.bind(this));
                }.bind(this));
            },

            createLineItems: function () {
                return new Promise(async function (resolve, reject) {
                    var oUpdate = JSON.parse(JSON.stringify(this.getView().getModel("CostRollModel").getProperty("/")));
                    var aPromises = [];
                    oUpdate.crLineItems.forEach(function (oLineItem) {
                        // delete oLineItem.flagFetchDetails;
                        delete oLineItem.Message;
                        delete oLineItem.Messagetype;
                        oLineItem.Parent_ID = this.getView().getModel("CostRollModel").getProperty("/ID");
                        if (!oLineItem.ID) {
                            aPromises.push(this.performCreateItem(oLineItem));
                        }
                    }.bind(this));
                    Promise.all(aPromises).then(async function () {
                        await this.oModel.submitBatch("CostRollItemCreate").then(function () {
                            resolve();
                        }.bind(this)).catch(function (oError) {
                            reject(oError);
                        }.bind(this));
                    }.bind(this), function (sError) {
                        reject(sError);
                    }.bind(this));
                }.bind(this));

            },

            performUpdateCostRoll: function (oContextBinding, oUpdate) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(function () {
                        var sRouteID = "";
                        if (oUpdate.crLineItems && oUpdate.crLineItems[0]) {
                            sRouteID = oUpdate.crLineItems[0].routeID
                        }
                        oContextBinding.getBoundContext().setProperty("companyCode", oUpdate.companyCode);
                        oContextBinding.getBoundContext().setProperty("plantCode", oUpdate.plantCode);
                        oContextBinding.getBoundContext().setProperty("requestType", oUpdate.requestType);
                        oContextBinding.getBoundContext().setProperty("subReqType", oUpdate.subReqType);
                        oContextBinding.getBoundContext().setProperty("workcell", oUpdate.workcell);
                        oContextBinding.getBoundContext().setProperty("sequence", oUpdate.sequence);
                        oContextBinding.getBoundContext().setProperty("remark", oUpdate.remark);
                        oContextBinding.getBoundContext().setProperty("reason", oUpdate.reason);
                        oContextBinding.getBoundContext().setProperty("revImpact", oUpdate.revImpact);
                        oContextBinding.getBoundContext().setProperty("variant", oUpdate.variant);
                        oContextBinding.getBoundContext().setProperty("routeID", sRouteID);
                        resolve();
                    }.bind(this));
                }.bind(this));
            },

            performUpdateCostRollItems: function (oContextBinding, oLineItem) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(function () {
                        oContextBinding.getBoundContext().setProperty("partNumber", oLineItem.partNumber);
                        oContextBinding.getBoundContext().setProperty("STDpriceToday", oLineItem.STDpriceToday);
                        oContextBinding.getBoundContext().setProperty("actualCost", oLineItem.actualCost);
                        oContextBinding.getBoundContext().setProperty("futurePrice", oLineItem.futurePrice);
                        oContextBinding.getBoundContext().setProperty("futurePriceFrom", oLineItem.futurePriceFrom);
                        oContextBinding.getBoundContext().setProperty("futurePriceLocal", oLineItem.futurePriceLocal);
                        oContextBinding.getBoundContext().setProperty("futurePriceFromLocal", oLineItem.futurePriceFromLocal);
                        oContextBinding.getBoundContext().setProperty("futurePriceGroup", oLineItem.futurePriceGroup);
                        oContextBinding.getBoundContext().setProperty("futurePriceFromGroup", oLineItem.futurePriceFromGroup);
                        oContextBinding.getBoundContext().setProperty("materialType", oLineItem.materialType);
                        oContextBinding.getBoundContext().setProperty("plannedPrice", oLineItem.plannedPrice);
                        oContextBinding.getBoundContext().setProperty("profitCenter", oLineItem.profitCenter);
                        oContextBinding.getBoundContext().setProperty("routeID", oLineItem.routeID);
                        if (oLineItem.expectedCost) {
                            oContextBinding.getBoundContext().setProperty("expectedCost", oLineItem.expectedCost);
                        }
                        resolve();
                    }.bind(this));
                }.bind(this));
            },

            deleteLineItems: function () {
                return new Promise(async function (resolve, reject) {
                    var aLineItems = this.getView().getModel("ViewModel").getProperty("/DeletedItems");
                    var aAttachments = this.getView().getModel("ViewModel").getProperty("/DeletedAttachments");
                    var aPromises = [];
                    var oContextBinding;

                    aLineItems.forEach(function (oLineItem) {
                        if (oLineItem.ID) {
                            oContextBinding = this.oModel.bindContext("/Items(" + oLineItem.ID + ")", null, {
                                $$updateGroupId: "CostRollDelete",
                            });
                            aPromises.push(this.requestLineItemDelete(oContextBinding));
                        }
                    }.bind(this));

                    aAttachments.forEach(function (oAttachment) {
                        if (oAttachment.ID) {
                            oContextBinding = this.oModel.bindContext("/Attachments(" + oAttachment.ID + ")", null, {
                                $$updateGroupId: "CostRollDelete",
                            });
                            aPromises.push(this.requestAttachmentDelete(oContextBinding));
                        }
                    }.bind(this));

                    Promise.all(aPromises).then(async function () {
                        await this.oModel.submitBatch("CostRollDelete").then(function () {
                            resolve();
                        }.bind(this)).catch(function (oError) {
                            reject(oError);
                        }.bind(this));
                    }.bind(this), function (sError) {
                        reject(sError);
                    }.bind(this));
                }.bind(this));
            },

            requestLineItemDelete: function (oContextBinding) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(async function () {
                        oContextBinding.getBoundContext().delete("CostRollDelete");
                        resolve();
                    }.bind(this), function () {
                        reject();
                    });
                }.bind(this));
            },

            requestAttachmentDelete: function (oContextBinding) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(async function () {
                        oContextBinding.getBoundContext().delete("CostRollDelete");
                        resolve();
                    }.bind(this), function () {
                        reject();
                    });
                }.bind(this));
            },

            submitCostRoll: function () {
                return new Promise(async function (resolve, reject) {
                    if (!this.getView().getModel("ViewModel").getProperty("/SubmitPressed")) {
                        resolve();
                        return;
                    }
                    var oOperation = this.oModel.bindContext("/SubmitCostRoll(...)");
                    var sID = this.getView().getModel("CostRollModel").getProperty("/ID");
                    oOperation.setParameter('ID', sID);
                    this.showBusyIndicator();
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        this.getView().getModel("CostRollModel").setProperty("/ticketID", oOperationContext.getObject().ticketID);
                        this.hideBusyIndicator();
                        resolve();
                    }.bind(this))
                        .catch(function (oError) {
                            this.hideBusyIndicator();
                            reject(oError.toString());
                        }.bind(this));
                }.bind(this));
            },

            removeAllMessages: function () {
                this._MessageManager.removeAllMessages();
            },

            genereateGUID: function () {
                var w = () => { return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1); }
                return `${w()}${w()}-${w()}-${w()}-${w()}-${w()}${w()}${w()}`;
            },

            onCompanyCodeValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._companyCodeValueHelpDialog) {
                    this._companyCodeValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollrequest.fragment.CompanyCodeValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._companyCodeValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("COMPANYCODE", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onValueHelpCompanyCodeSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("COMPANYCODE", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpCompanyCodeClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);
                this.setCostingVariantData();
                if (!oSelectedItem) {
                    return;
                }
                if (this.getView().getModel("CostRollModel").getProperty("/plantCode")) {
                    this.resetScreenFields("C");
                    this.setCostingVariantData();
                }

                this.getView().getModel("CostRollModel").setProperty("/companyCode", oSelectedItem.getTitle());
                this.filterPlantBasedOnComp(oSelectedItem.getTitle());
                this.getView().getModel("ViewModel").setProperty("/CompanyCodeValueState", "None");
            },

            filterPlantBasedOnComp: function (sCompanyCode) {
                var aAllData = this.getView().getModel("ValueHelpModel").getProperty("/AllData");
                var aItems = aAllData.filter((oItem) => {
                    return oItem.COMPANYCODE === sCompanyCode
                });
                var aArrayPlantCode = [], aPlant = [];
                aItems.forEach((oItem) => {
                    aArrayPlantCode.push(oItem.PLANTCODE);
                });
                aArrayPlantCode = [...new Set(aArrayPlantCode)];
                aArrayPlantCode.forEach(function (sPlant) {
                    aPlant.push({
                        "PLANTCODE": sPlant
                    });
                });
                this.getView().getModel("ValueHelpModel").setProperty("/Plant", aPlant);
                this.getView().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", aArrayPlantCode);
            },

            onCompanyCodeChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                if (this.getView().getModel("CostRollModel").getProperty("/plantCode")) {
                    this.resetScreenFields("C");
                    this.setCostingVariantData();
                }
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayCompanyCode").indexOf(oEvent.getParameters().value) === -1) {
                    this.getView().getModel("ValueHelpModel").setProperty("/Plant", []);
                    this.getView().getModel("ValueHelpModel").setProperty("/ArrayPlantCode", []);
                    oEvent.getSource().setValueState("Error");
                } else {
                    this.filterPlantBasedOnComp(oEvent.getParameters().value);
                }
            },

            onPlantCodeChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                if (this.getView().getModel("CostRollModel").getProperty("/requestType")) {
                    this.resetScreenFields("P");
                    this.setCostingVariantData();
                }
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayPlantCode").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            },

            resetScreenFields: function (sIdentifier) {
                var bCostRoll = false;
                if (this.getView().getModel("CostRollModel").getProperty("/requestType") === "Cost Roll") {
                    bCostRoll = true;
                    this.getView().getModel("CostRollModel").setProperty("/variant", "");
                    this.getView().getModel("ViewModel").setProperty("/CostingVariant", "");
                }
                if (sIdentifier === "C") {
                    // this.performReset();
                    this.getView().getModel("CostRollModel").setProperty("/plantCode", "");
                    if (bCostRoll) {
                        MessageToast.show(this.i18n.getText("compCodeReset"));
                    }
                } else if (sIdentifier === "P") {
                    // var sCompCode = this.getView().getModel("CostRollModel").getProperty("/companyCode");
                    // this.performReset();
                    if (bCostRoll) {
                        MessageToast.show(this.i18n.getText("plantCodeReset"));
                    }
                    // this.getView().getModel("CostRollModel").setProperty("/companyCode", sCompCode);
                }
            },

            onPlantValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._plantValueHelpDialog) {
                    this._plantValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollrequest.fragment.PlantCodeValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._plantValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("PLANTCODE", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onValueHelpPlantSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("PLANTCODE", FilterOperator.Contains, sValue);
                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpPlantClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);
                this.getView().getModel("CostRollModel").setProperty("/plantCode", oSelectedItem.getTitle());
                this.getView().getModel("ViewModel").setProperty("/PlantCodeValueState", "None");
                if (this.getView().getModel("CostRollModel").getProperty("/requestType")) {
                    this.resetScreenFields("P");
                    this.setCostingVariantData();
                }
                if (!oSelectedItem) {
                    return;
                }
            },

            onRouteIDValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._routeIDValueHelpDialog) {
                    this._routeIDValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollrequest.fragment.RouteIdValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._routeIDValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("routeID", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onValueHelpRouteIDSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("routeID", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpRouteIDClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);

                if (!oSelectedItem) {
                    return;
                }

                this.getView().getModel("CostRollModel").setProperty("/routeID", oSelectedItem.getTitle());
                this.getView().getModel("ViewModel").setProperty("/RouteIDValueState", "None");
            },

            onRouteIDChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayRouteID").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            },

            onDraftValueHelpRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._draftValueHelpDialog) {
                    this._draftValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.jabil.costrollrequest.fragment.DraftValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._draftValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("draft", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onValueHelpDraftSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("draft", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onValueHelpDraftClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                oEvent.getSource().getBinding("items").filter([]);

                if (!oSelectedItem) {
                    return;
                }

                this.getView().getModel("ViewModel").setProperty("/DraftName", oSelectedItem.getTitle());
                this.getView().getModel("ViewModel").setProperty("/DraftValueState", "None");
            },

            onDraftChange: function (oEvent) {
                oEvent.getSource().setValueState("None");
                if (!oEvent.getParameters().value) {
                    return;
                }
                if (this.getView().getModel("ValueHelpModel").getProperty("/ArrayDraft").indexOf(oEvent.getParameters().value) === -1) {
                    oEvent.getSource().setValueState("Error");
                }
            },

            performFetchPartDetails: function () {
                return new Promise(async function (resolve, reject) {
                    var oCostRoll = JSON.parse(JSON.stringify(this.getView().getModel("CostRollModel").getProperty("/")));
                    var oOperation = this.oModel.bindContext("/ValidateCostRoll(...)");
                    oOperation.setParameter("companyCode", oCostRoll.companyCode);
                    oOperation.setParameter("plantCode", oCostRoll.plantCode);
                    oOperation.setParameter("requestType", oCostRoll.requestType);
                    oOperation.setParameter("subReqType", oCostRoll.subReqType);
                    oCostRoll.crLineItems.forEach((oItem) => {
                        // delete oItem.flagFetchDetails;
                        delete oItem.Message;
                        delete oItem.Messagetype;
                        // delete oItem.addedNow;
                        // oItem.futurePriceFrom = new Date().toISOString().substring(0, 10);

                        // if (!oItem.futurePriceFrom) {
                        //     oItem.futurePriceFrom = null;
                        // }
                        if (!oItem.futurePriceFromLocal) {
                            oItem.futurePriceFromLocal = null;
                        }
                        if (!oItem.futurePriceFromGroup) {
                            oItem.futurePriceFromGroup = null;
                        }

                    });
                    oOperation.setParameter("Items", oCostRoll.crLineItems);
                    this.showBusyIndicator();
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        this.hideBusyIndicator();
                        resolve(oOperationContext.getObject());
                    }.bind(this))
                        .catch(function (oError) {
                            this.hideBusyIndicator();
                            reject(oError);
                        }.bind(this));
                }.bind(this));
            },

            onDelete: function () {
                var aIndices = this.byId("CostRollItemsTable").getDependents()[0].getSelectedIndices();
                var sPath, aDeleted = [];
                if (aIndices.length === 0) {
                    MessageToast.show(this.i18n.getText("noItemsSelectedDelete"));
                    return;
                }
                for (var i = aIndices.length - 1; i >= 0; i--) {
                    sPath = this.byId("CostRollItemsTable").getContextByIndex(aIndices[i]).getPath();
                    aDeleted = [];
                    aDeleted = this.getView().getModel("CostRollModel")
                        .getProperty("/crLineItems")
                        .splice(parseInt(sPath.charAt(sPath.lastIndexOf("/") + 1)), 1);
                    this.getView().getModel("ViewModel").setProperty("/DeletedItems",
                        this.getView().getModel("ViewModel").getProperty("/DeletedItems").concat(aDeleted));
                }

                this.getView().getModel("CostRollModel").refresh(true);
            },

            handlePress: function (oEvent) {
                var sFolderId = this.getView().getModel("CostRollModel").getProperty("/ID");
                var sURL = ""; var win = "";
                var sDocumentId = this.getView().getModel("ViewModel").getProperty(oEvent.getSource().getBindingContext("ViewModel").getPath()).DmsDocumentId;
                if (!sDocumentId) {
                    MessageToast.show(this.i18n.getText("CannotDownloadMsg"));
                    return;
                }
                sURL = $.sap.getModulePath("com.jabil.costrollrequest") + "/browser/CR_REQUEST_REPO/root/" + sFolderId + "?objectId=" + sDocumentId;
                win = window.open(sURL, '_blank');
                win.focus();
            },

            navigateToDashboardApp: function (sValue, bDraft) {
                var oParam = {};
                if (bDraft) {
                    oParam = {
                        "DraftName": sValue
                    };
                } else {
                    oParam = {
                        "TicketID": sValue
                    };
                }
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "CostRollDashboard",
                        action: "manage"
                    },
                    params: oParam
                })) || "";
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: hash
                    }
                });
            },

            displaySuccessMessage: function (sDisplay, oDisplay) {
                var aActions = [];
                if (oDisplay.bDraft) {
                    aActions.push(MessageBox.Action.CLOSE);
                } else {
                    aActions.push(this.i18n.getText("btnNavigate"), MessageBox.Action.CLOSE);
                }
                MessageBox.success(sDisplay, {
                    actions: aActions,
                    emphasizedAction: this.i18n.getText("btnNavigate"),
                    onClose: function (sAction) {
                        if (sAction === "Navigate") {
                            this.navigateToDashboardApp(oDisplay.Value, oDisplay.bDraft);
                        }
                    }.bind(this)
                });
            },

            onDownloadRouteMatrix: function () {
                var aData, oSettings, oSheet, fileName, sheetName;
                aData = [];

                oSettings = {
                    workbook: {
                        columns: this.createRouteDataCustomColumn(),
                        context: {
                            sheetName: "RouteMasterData"
                        }

                    },
                    dataSource: this.getView().getModel("ValueHelpModel").getProperty("/RouteData"),
                    fileName: "ApprovalMatrix.xlsx"

                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {
                        MessageToast.show(this.i18n.getText("routeDataDownload"));
                    }.bind(this))
                    .finally(oSheet.destroy);
            },

            createRouteDataCustomColumn: function () {
                var EdmType = exportLibrary.EdmType;
                return [{
                    label: this.i18n.getText("lblCompCode"),
                    property: "companyCode",
                    type: EdmType.String,
                    width: "20"
                }, {
                    label: this.i18n.getText("LblMaterialType"),
                    property: "materialType",
                    type: EdmType.String,
                    width: "20"
                }, {
                    label: this.i18n.getText("lblPlant"),
                    property: "plantCode",
                    type: EdmType.String,
                    width: "20"
                }, {
                    label: this.i18n.getText("LblProfitCenter"),
                    property: "profitCenter",
                    type: EdmType.String,
                    width: "50"
                }, {
                    label: this.i18n.getText("lblRouteID"),
                    property: "routeID",
                    type: EdmType.String,
                    width: "20"
                }, {
                    label: this.i18n.getText("lblRouteName"),
                    property: "routeName",
                    type: EdmType.String,
                    width: "20"
                }, {
                    label: this.i18n.getText("lblAppGroup1"),
                    property: "appGP1",
                    type: EdmType.String,
                    width: "40"
                }, {
                    label: this.i18n.getText("lblAppGroup2"),
                    property: "appGP2",
                    type: EdmType.String,
                    width: "40"
                }];
            },

            downloadLinteItemTemplate: function () {
                var aData, oSettings, oSheet, fileName, sheetName;
                aData = [];
                var sSheet = this.getView().getModel("ViewModel").getProperty("/TypeName") === "1" ? "CostRoll" : "CostRollDelete";

                oSettings = {
                    workbook: {
                        columns: this.createItemCustomColumn(this.getView().getModel("ViewModel").getProperty("/TypeName")),
                        context: {
                            sheetName: sSheet
                        }

                    },
                    dataSource: this.prepareDataSource(this.getView().getModel("ViewModel").getProperty("/TypeName")),
                    fileName: "LineItemTemplate.xlsx"

                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {
                        MessageToast.show(this.i18n.getText("itemTemplateDownload"));
                    }.bind(this))
                    .finally(oSheet.destroy);
            },

            createItemCustomColumn: function (sType) {
                var EdmType = exportLibrary.EdmType;
                if (sType === "1") {
                    return [{
                        label: this.i18n.getText("ColPartNumber"),
                        property: "partNumber",
                        type: EdmType.String,
                        width: "20"
                    }, {
                        label: this.i18n.getText("ColExpectedCost"),
                        property: "expectedCost",
                        type: EdmType.String,
                        width: "20"
                    }];
                } else {
                    return [{
                        label: this.i18n.getText("ColPartNumber"),
                        property: "partNumber",
                        type: EdmType.String,
                        width: "20"
                    }];
                }
            },

            prepareDataSource: function (sType) {
                if (sType === "1") {
                    return [{
                        "partNumber": undefined,
                        "expectedCost": undefined
                    }];
                } else {
                    return [{
                        "partNumber": undefined
                    }];
                }
            },

            onMessageView: function (oEvent) {
                if (this.getView().getModel("CostRollModel").getProperty(oEvent.getSource().getBindingContext("CostRollModel").getPath()).Messagetype === "E") {
                    MessageBox.error(this.getView().getModel("CostRollModel").getProperty(oEvent.getSource().getBindingContext("CostRollModel").getPath()).Message);
                } else if (this.getView().getModel("CostRollModel").getProperty(oEvent.getSource().getBindingContext("CostRollModel").getPath()).Messagetype === "W") {
                    MessageBox.information(this.getView().getModel("CostRollModel").getProperty(oEvent.getSource().getBindingContext("CostRollModel").getPath()).Message);
                } else {
                    MessageBox.information(this.getView().getModel("CostRollModel").getProperty(oEvent.getSource().getBindingContext("CostRollModel").getPath()).Message);
                }

            },

            formatRowSettings: function (sMessageType) {
                if (sMessageType === "E") {
                    return "Error";
                } else if (sMessageType === "W") {
                    return "Information";
                } else {
                    return "None";
                }
            }
        });
    });
