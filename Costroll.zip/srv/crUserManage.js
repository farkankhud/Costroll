const cds = require('@sap/cds');
const UserManageHandler = require('./Utils/cr-UserManage').UserManageHandler;
const RolesUtil = require('./Utils/roles').RolesUtil;
const axios = require("axios");
const sdk = require("@sap-cloud-sdk/connectivity");
// import { getAllDestinationsFromDestinationService } from '@sap-cloud-sdk/connectivity';
const { getDestinationFromDestinationService } = require("@sap-cloud-sdk/connectivity");
// import { retrieveDestination } from '@sap-cloud-sdk/connectivity';
module.exports = function () {

    ////////////////case insenstive User Manage Search
    this.before('READ', ['userManage_UserVH', 'userManage_RoleNameVH', 'userManage_PlantVH'], async (req) => {
        let conditions = req.query.SELECT.where;
        var newCondition = [];
        if (conditions) {
            conditions.forEach((condition, index) => {
                var scol = '';
                var sval = '';
                var sOperator = '';

                if (condition === 'and' || condition === 'or' || condition === '(' || condition === ')'
                    || condition.func != undefined
                ) {
                    newCondition.push(condition);
                }
                if (condition.ref != undefined) {
                    scol = condition.ref[0];
                    sOperator = conditions[index + 1];
                    sval = conditions[index + 2].val;
                    if (sOperator === '=') {
                        newCondition.push({ func: 'toupper', args: [{ ref: [scol] }] }, 'like', { val: `%${sval.toUpperCase()}%` });
                    } else {
                        newCondition.push({ ref: [scol] }, sOperator, { val: sval });
                    }
                }
            });
        }
        if (newCondition && newCondition.length > 0) {
            req.query.SELECT.where = newCondition;
        }
    })
    ////////////////Case insensitive User Manage Search


    // IT Reader Role Check 
    this.before('CREATE', ['UserManagement'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    this.before('UPDATE', ['UserManagement'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "target": "ReadOnly",
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    this.before('DELETE', ['UserManagement'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "target": "ReadOnly",
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    // this.on('READ', ['CompanyCode', 'PlantCode'], async function (req) {
    //     var onPremS4API = await cds.connect.to("ZOD_FICO_COSTROLL_BTP_SRV");
    //     const ans = await onPremS4API.run(req.query);
    //     return ans;
    // });

    this.on('READ', 'User', async req => {
        const service = await cds.connect.to('MicrosoftGraph');
        // var query = "/users?$filter=" + req._query.$filter;//+"&$expand=manager($select=displayName,mail)";
        // const graphUser = await service.tx(req).get(query);
        // const email = req.user.id;

        //***************** */ Start of new code Sharique 31/01/2025
        try {
            const userEmail = req.query.SELECT.where[2].val;
            let response1 = [];
            let errorMessage;
            // const fullUrl = `https://jabildev.oktapreview.com/api/v1/users`;
            // Start of Change Shariue 03/02/2025
            // const apiKey = process.env.oktaAPIkey || "00spTOwMC2nsOWQw1WQbylgwn79vsXbAoyyPCn_pwj";
            const destinationName = "OKTA_INTEGRATION_COSTROLL";

            const destination = await getDestinationFromDestinationService({ destinationName: destinationName });

            if (!destination) {
                return { error: `Destination '${destinationName}' not found` };
                // }
            }
            console.log("Destination", destination.originalProperties.URL);
            const fullUrl = destination.originalProperties.URL + "/api/v1/users";
            console.log("Full URL", fullUrl);
            const apiKey = destination.originalProperties?.SSWSKey;
            // SEnd of Change of Change Shariue 03/02/2025
            console.log("apikey", process.env.oktaAPIkey);
            // Start of change Sharique 13/03/2025
            try {
                response1 = await axios.get(fullUrl, {
                    headers: {
                        Authorization: `SSWS ${apiKey}`,
                        Accept: "application/json"
                    },
                    // params: { filter: filterQuery }
                    params: {
                        // q: userEmail,//this property searches against 3 properites(mail,name...)
                        // search: `profile.email sw "${userEmail}"`,
                        search: `profile.firstName sw "${userEmail}" or profile.lastName sw "${userEmail}"`,
                        limit: 60
                    }
                });
            } catch (error) {
                console.error("First API call failed:", error.message);
                response1 = null;
                
            }
            // response1 = await axios.get(fullUrl, {
            //     headers: {
            //         Authorization: `SSWS ${apiKey}`,
            //         Accept: "application/json"
            //     },
            //     // params: { filter: filterQuery }
            //     params: {
            //         // q: userEmail,//this property searches against 3 properites(mail,name...)
            //         // search: `profile.email sw "${userEmail}"`,
            //         search: `profile.firstName sw "${userEmail}" or profile.lastName sw "${userEmail}"`,
            //         limit: 60
            //     }
            // });


            if (!response1 || !response1.data || (Array.isArray(response1.data) && response1.data.length === 0)) {
                console.log("Trying another time with Capital P....");
                response1 = await axios.get(fullUrl, {
                    headers: {
                        Authorization: `SSWS ${apiKey}`,
                        Accept: "application/json"
                    },
                    // params: { filter: filterQuery }
                    params: {
                        // q: userEmail,//this property searches against 3 properites(mail,name...)
                        // search: `profile.email sw "${userEmail}"`,
                        search: `Profile.firstName sw "${userEmail}" or Profile.lastName sw "${userEmail}"`,
                        limit: 60
                    }
                });
            }
            // End of   change  Sharique 13/03/2025
            let users = response1.data.map(graph_user => {
                var user = {}
                user.aad_id = graph_user.profile.employeeNumber;
                user.username = graph_user.profile.email;
                user.displayName = graph_user.profile.displayName;
                user.givenName = graph_user.profile.firstName;
                user.surname = graph_user.profile.lastName;
                // user.mail = graph_user.mail;
                user.mail = graph_user.profile.email;
                return user
            })
            return users
            // return response1;
        } catch (error) {
            req.error(500, `Error fetching user: ${error.message}`);
        }
        //*********************** */ End of new code Sharique 31/01/2025
        // const email = req.query.SELECT.where[2].val;
        // const baseURL = "/users/?$filter=startswith(displayName,'"
        // const endURL = "')"
        // const url = baseURL.concat(email, endURL);
        // const graphUser = await service.tx(req).get(url);

        // let users = graphUser.map(graph_user => {
        //     var user = {}
        //     user.aad_id = graph_user.id;
        //     user.username = graph_user.userPrincipalName;
        //     user.displayName = graph_user.displayName;
        //     user.givenName = graph_user.givenName;
        //     user.surname = graph_user.surname;
        //     // user.mail = graph_user.mail;
        //     user.mail = graph_user.userPrincipalName;
        //     return user
        // })
        // return users
    });

    this.on('getAllData', UserManageHandler._getAllData);

    this.before(['CREATE', 'UPDATE',], 'UserManagement', UserManageHandler._validateMandatory)

    this.after('UPDATE', 'UserManagement', async req => {
        const userEmail = req.user;
        const roleName = req.roleName; // Single role name

        try {
            const crBTPRoles = await SELECT.from("COSTROLL_CRBTPROLEMAPPING");
            const existingRoles = new Set(crBTPRoles.map(role => role.ROLENAME));
            const roleMappings = new Map(crBTPRoles.map(role => [role.ROLENAME, role.BTPROLENAME]));

            // Check if the role exists
            if (!existingRoles.has(roleName)) {
                throw new Error(`Role '${roleName}' does not exist.`);
            }

            const xsuaa = await cds.connect.to("crXsuaa");

            // Fetch or create user
            const user = await getOrCreateUser(xsuaa, userEmail, req);

            // Identify BTP role to remove if necessary
            const btpRole = roleMappings.get(roleName);
            const rolesToRemove = new Set(
                [...existingRoles]
                    .filter(role => role !== roleName) // Exclude the current role
                    .map(role => roleMappings.get(role)) // Map to BTP role names
            );

            // Process role updates
            await Promise.all([
                // Add the single matching role (create)
                updateRole(xsuaa, btpRole, user.id, 'create'),

                // Remove other BTP roles not matching the current role
                ...[...rolesToRemove].map(nonMatchingBtpRole =>
                    updateRole(xsuaa, nonMatchingBtpRole, user.id, 'delete')
                )
            ]);

        } catch (error) {
            console.error("Error handling role update:", error);
            // Handle error as needed
        }
    });

    this.after('DELETE', 'UserManagement', async (req, res) => {
        const userEmail = res.data.user;
        console.log(userEmail);

        try {
            // Fetch all role mappings
            const crBTPRoles = await SELECT.from("COSTROLL_CRBTPROLEMAPPING");

            // Connect to xsuaa
            const xsuaa = await cds.connect.to("crXsuaa");

            // Fetch or create user
            const user = await getOrCreateUser(xsuaa, userEmail, res);
            console.log(user);

            // Process each role in the fetched role mappings
            await Promise.all(crBTPRoles.map(async roleMapping => {
                const btpRole = roleMapping.BTPROLENAME; // Get the BTP role name
                console.log(btpRole);

                // Prepare role payload
                const rolePayload = {
                    "members": [{
                        "origin": user.origin,
                        "type": "USER",
                        "value": user.id, // Assuming you need the email for the user
                        "operation": "delete"
                    }]
                };
                console.log(rolePayload);

                // Update group with new role
                await xsuaa.send({
                    method: 'PATCH',
                    path: `/Groups/${btpRole}`,
                    data: rolePayload,
                    headers: { 'If-Match': '0' }
                });
            }));

        } catch (error) {
            console.error("Error handling role deletion:", error);
            // Handle error as needed
        }
    });
    this.before('CREATE', 'UserManagement', async req => {
        const userEmail = req.data.user;
        const roleName = req.data.roleName;

        try {
            const xsuaa = await cds.connect.to("crXsuaa");

            // Fetch or create user
            const user = await getOrCreateUser(xsuaa, userEmail, req);
            // console.log("After getorcreate", user);

            // Update DB with User from API
            // req.data.User = user.userEmail;
            req.data.user = user.userEmail;
            // console.log("After getorcreate check user case", req.data.User);
            console.log("After getorcreate check user case lower case", req.data.user);
            // Fetch role mappings
            const crBTPRoles = await SELECT.from("COSTROLL_CRBTPROLEMAPPING");
            const roleMappings = new Map(crBTPRoles.map(role => [role.ROLENAME, role.BTPROLENAME]));

            // Process the single role
            const btpRole = roleMappings.get(roleName);
            if (btpRole) {
                await updateRole(xsuaa, btpRole, user.id, 'create', user.origin);
            }

        } catch (error) {
            console.error("Error handling role assignment:", error);
            // Handle error as needed
        }
    });

    this.on('getUserData', async req => {
        // console.log("Exports from @sap-cloud-sdk/connectivity:", Object.keys(sdk));
        //     try {
        //         const OktaService = await cds.connect.to("OktaService");
        //     const fullUrl = `https://jabildev.oktapreview.com/api/v1/users`;
        //     const url = `/api/v1/users`;
        //     // const graphUser = await OktaService.tx(req).get(url);
        //     const graphUser = await OktaService.get("/api/v1/users");
        //     console.log("graph users", graphUser.profile);
        //     let users = response1.data.map(graph_user => {
        //         var user = {}
        //         user.aad_id = graph_user.profile.employeeNumber;
        //         user.username = graph_user.profile.email;
        //         user.displayName = graph_user.profile.displayName;
        //         user.givenName = graph_user.profile.firstName;
        //         user.surname = graph_user.profile.lastName;
        //         // user.mail = graph_user.mail;
        //         user.mail = graph_user.profile.email;
        //         return user
        //     })
        //     console("Users", users);
        // return users;
        //     }catch (error) {
        //         req.error(500, `Failed to fetch user data: ${error.message}`);
        //     }

        try {
            // Fetch destination details
            const destinationName = "OKTA_INTEGRATION_COSTROLL";

            const destination = await getDestinationFromDestinationService({ destinationName: destinationName });
            // console.log("destinationOktaService", destination );
            // console.log("Dest Properties", destination.originalProperties );
            if (!destination) {
                // const destinationName = "OKTA_INTEGRATION_COSTROLL"; 
                // const destination = await getDestinationFromDestinationService(destinationName);
                // console.log("destinationOKTA_INTEGRATION_COSTROLL", destination );
                // if (!destination) {
                return { error: `Destination '${destinationName}' not found` };
                // }
            }
            console.log("destinationOktaService", destination);
            // // Extract SSWS key from destination properties
            const sswsKey = destination.originalProperties?.SSWSKey;
            // oauthClient + ':' + oauthSecret
            // const sswsKey = "SSWS" + ' ' + "00spTOwMC2nsOWQw1WQbylgwn79vsXbAoyyPCn_pwj";

            console.log("sswsKey", sswsKey);
            if (!sswsKey) {
                return { error: "SSWS key is missing in destination properties" };
            }

            // Connect to OktaService
            const OktaService = await cds.connect.to("OKTA_INTEGRATION_COSTROLL");

            // Define API endpoint
            const url = `/api/v1/users`;

            // Set headers dynamically using SSWS key
            const
                options = {
                    headers: {
                        // Authorization: `SSWS ${sswsKey}`,
                        Authorization: `SSWS ${sswsKey}`,
                        'Content-Type': "application/json"
                    }
                };

            // Fetch user data from Okta API with SSWS authentication
            // const response1 = await OktaService.get(url, options);
            const response1 = await OktaService.get(url, { headers: options });

            console.log("Graph Users Response:", response1);

            // Transform response data
            let users = response1.data.map(graph_user => ({
                aad_id: graph_user.profile.employeeNumber,
                username: graph_user.profile.email,
                displayName: graph_user.profile.displayName,
                givenName: graph_user.profile.firstName,
                surname: graph_user.profile.lastName,
                mail: graph_user.profile.email
            }));

            console.log("Users:", users);
            return users;

        } catch (error) {
            req.error(500, `Failed to fetch user data: ${error.message}`);
        }

    });

}
async function getOrCreateUser(xsuaa, userEmail, req) {
    // *********************************Start of new code Sharique 28/01/2025
    // Validate the userEmail from graph API in casw of mass upload
    // const service = await cds.connect.to('MicrosoftGraph');
    // var user = {}
    // const baseURL = "/users/?$filter=startswith(mail,'"
    // const endURL = "')"
    // const url = baseURL.concat(userEmail, endURL);
    // const graphUser = await service.tx(req).get(url);
    //  graphUser.map(graph_user => {
    //     userEmail = graph_user.userPrincipalName;
    // })    
    // const filterParams = [];
    // Start of Change Shariue 03/02/2025
    // const apiKey = process.env.oktaAPIkey || "00spTOwMC2nsOWQw1WQbylgwn79vsXbAoyyPCn_pwj";
    let results = [];
    const destinationName = "OKTA_INTEGRATION_COSTROLL";
    const destination = await getDestinationFromDestinationService({ destinationName: destinationName });

    if (!destination) {
        return { error: `Destination '${destinationName}' not found` };
        // }
    }
    const fullUrl = destination.originalProperties.URL + "/api/v1/users";
    const apiKey = destination.originalProperties?.SSWSKey;
    // SEnd of Change of Change Shariue 03/02/2025

    try {
        console.log("Before Okta API", userEmail);
        // const filterQuery = `profile.email eq "${userEmail}"`;
        results = await axios.get(fullUrl, {
            headers: {
                Authorization: `SSWS ${apiKey}`,
                Accept: "application/json"
            },
            params: {
                // q: userEmail 
                search: `profile.email eq "${userEmail}"`,
                limit: 60
            }
            // search: `profile.email sw "${userEmail}"`,

        });
        console.log("After Okta API 1", results);
        // if (typeof results != "undefined" && results != null && results.length != null && results.length > 0) {
        if (!results.data || !Array.isArray(results.data) || results.data.length === 0) {
            userEmail = "";
            req.error({
                message: "User email is not valid",
                status: 418
            });
            return;
        }
        else {
            console.log("After Okta API 1", results.data);
            console.log("After Okta API 2", results.data[0].profile.email);
            results.data.map(graph_user => {
                userEmail = graph_user.profile.email;
            });
        }
        console.log("After Okta API", userEmail);
    } catch (error) {
        req.error(500, `Error fetching user: ${error.message}`);
    }

    // *****************************End of new code Sharique 28/01/2025

    const userFilterUrl = `/Users?filter=email eq '${userEmail}'`;
    const response = await xsuaa.tx(req).get(userFilterUrl);

    // Check if the user already exists
    if (response.resources.length > 0) {
        // Loop through the resources to find the matching origin
        const userWithMatchingOrigin = response.resources.find(user =>
            user.origin.includes("okta")
        );

        if (userWithMatchingOrigin) {
            var returnPayload = {
                id: userWithMatchingOrigin.id,
                origin: userWithMatchingOrigin.origin,
                // userEmail: userWithMatchingOrigin.userName
                userEmail: userWithMatchingOrigin.emails[0].value
            }
            console.log("Old User", returnPayload.userEmail);
            return returnPayload;
            // return userWithMatchingOrigin.id; // Return the ID if found
        }
    }

    // If not found, create a new user
    const userFilterUrls = `/Users`;
    const responseUser = await xsuaa.tx(req).get(userFilterUrls);
    // var originUser;
    // if (response.resources.length > 0) {
    //     // Loop through the resources to find the matching origin
    //     const userWithMatching = responseUser.resources.find(user => 
    //         user.origin.includes("okta")
    //     );
    //     originUser = userWithMatching.origin;
    // }



    var originUser = process.env.origin;
    const [localPart] = userEmail.split('@');
    const [firstName, lastName] = localPart.split('_').map(part => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase());
    console.log("Before primary false", userEmail);
    const userPayload = {
        userName: userEmail,
        name: {
            familyName: lastName,
            givenName: firstName
        },
        emails: [{ value: userEmail, primary: false }],
        active: true,
        verified: true,
        origin: originUser
    };
    console.log("After primary false", userPayload.emails);
    const userCreationResponse = await xsuaa.send({
        method: 'POST',
        path: '/Users',
        data: userPayload,
        headers: { 'If-Match': '0' }
    });

    var returnPayload = {
        id: userCreationResponse.id,
        origin: userCreationResponse.origin,
        // userEmail: userCreationResponse.userName
        userEmail: userCreationResponse.emails[0].value
    }
    console.log("New User", returnPayload.userEmails);
    return returnPayload;
    // return userCreationResponse.id; // Return the newly created user's ID
}


async function updateRole(xsuaa, btpRole, userId, operation, origin) {
    const rolePayload = {
        members: [{
            origin: origin,
            type: "USER",
            value: userId,
            operation: operation
        }]
    };

    await xsuaa.send({
        method: 'PATCH',
        path: `/Groups/${btpRole}`,
        data: rolePayload,
        headers: { 'If-Match': '0' }
    });
}

