const cds = require('@sap/cds');
const user = require('@sap/cds/lib/req/user');
const CostRollRequestHandler = require('./Utils/cr-ServiceHandler').CostRollRequestHandler;
const DB = require("./Utils/dbOperations").DB;
const RolesUtil = require('./Utils/roles').RolesUtil;
const CommonUtilities = require("./Utils/common").CommonUtilities;
const mailUtil = require("./Utils/triggerEmail").mailUtility;
const XLSX = require('xlsx');
const axios = require('axios').default;
const FormData = require('form-data');
const crypto = require('crypto');
const { response } = require('express');

module.exports = function () {
    // IT Reader Role Check with BTP
    this.before('CREATE', ['Header', 'Items', 'Attachments'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    this.before('UPDATE', ['Header', 'Items', 'Attachments'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "target": "ReadOnly",
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    this.before(['SubmitCostRoll', 'withdrawTicket', 'fowrardTicket'], async (req) => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });


    //Get the User Role, Assigned Plants and Company Codes, Variants and Drafts save by user in Request Form
    this.on('getUserRoles', CostRollRequestHandler._getUserRoles);
   
    //Fetch Material Details for Part Numbers in Req Form, Validate against Route ID and Header Fields
    this.on('ValidateCostRoll', async function (req) {
        try {
            var validationResult = Boolean;
            var Message = String;
            //Validation and Fetch Material from SAP
            var fetchMaterial = await CommonUtilities.fetchMaterialDetails(req);
            //If validation failed due to Invalid Part Number
            if (fetchMaterial.some(item => item.Messagetype === 'E')) {
                return {
                    "ValidationPassed": false,
                    "Message": "Error in the Part(s). Please check the Messages",
                    "AdditionalDetails": fetchMaterial,
                }
            }
            else {
                if (!fetchMaterial.length == 0) {
                    // Validate Route ID's Profit Centers/Mat Type with Line Item's Profit Centers/Mat Type
                    var GetRouteID = await DB.CompareProfitCenter(fetchMaterial, req);
                    if (GetRouteID) {
                        return {
                            "ValidationPassed": true,
                            "Message": "Validation Passed",
                            "AdditionalDetails": fetchMaterial,
                        }
                    }
                    else {
                        return {
                            "ValidationPassed": false,
                            "Message": "All the Route IDs are not same",
                            "AdditionalDetails": fetchMaterial,
                        }
                    }
                }
                else {
                    return {
                        "ValidationPassed": false,
                        "Message": "Validation Failed due to Odata Issue",
                        "AdditionalDetails": fetchMaterial,
                    }
                }
            }
        }
        catch (error) {
            //If any error occured during Validation
            return {
                "ValidationPassed": false,
                "Message": "Technical Error while Fetch Material",
            }
        }
    });

    //On press on Submit button in Req Form with Draft, Create Ticket ID and CP number and update in the table
    this.on('SubmitCostRoll', async (req) => {
        // Get the Draft Data from Table
        var DBData = await DB.getDatafromDB(req.data.ID);
        plantCode = DBData.PLANTCODE;
        companyCode = DBData.COMPANYCODE;
        variant = DBData.VARIANT;
        requestType = DBData.REQUESTTYPE;
        subReqType = DBData.SUBREQTYPE;
        crLineItems = DBData.crLineItems;

        const currentDate = new Date();
        const day = String(currentDate.getDate()).padStart(2, '0');
        const month = String(currentDate.getMonth() + 1).padStart(2, '0');
        const year = String(currentDate.getFullYear()).slice(-2);
        const CPyear = String(currentDate.getFullYear());
        var monthNum = parseInt(month);
        var yearNum = parseInt(year);
        if (monthNum > 8) {               //To get the Fiscal year, Starts at Sep 01
            yearNum = yearNum + 1;
        }
        //Get Next Number for Ticket 
        console.log("user id from FE", req.user.id);
        var Number = await DB.getNextNumberForTicket(plantCode, yearNum);

        // Define the running number for Ticket ID and CP and CR Number
        const runningNumber = String(Number).padStart(7, '0');
        // Final Ticket Number
        var ticketID = `${plantCode}_FY${yearNum}_${runningNumber}`;
        req.data.ticketID = ticketID;
        var requestStatus_ID = 2; //Pending for Analysis
        const MMDD = month + day;
        const YYYYMMDD = CPyear + month + day;
        //Get Next Number for CP
        const nextCP = await DB.getNextNumberForCP(YYYYMMDD);
        const runningCPNumber = String(nextCP).padStart(2, '0');
        // Final CP Number
        var cpNum = `CP${MMDD}${runningCPNumber}`;
        var cpDate = YYYYMMDD;
        var cpMax = runningCPNumber;
        var draftName = '';
        //Update in the DB table
        //Data for Deletion if error
        let inputDate = YYYYMMDD;
        inputDate = inputDate.toString();
        // Parse the input date
        let yearDate = parseInt(inputDate.substring(0, 4), 10);
        let monthDate = parseInt(inputDate.substring(4, 6), 10) - 1; // Month is zero-indexed
        let dayDate = parseInt(inputDate.substring(6, 8), 10);
        // Create a Date object
        let dateObject = new Date(Date.UTC(yearDate, monthDate, dayDate));
        // Add one day
        dateObject.setUTCDate(dateObject.getUTCDate());
        // Convert to milliseconds since Unix epoch
        let epochMillis = dateObject.getTime();
        // Format as \/Date(epochMillis)\/
        let formattedCrDate = `\\/Date(${epochMillis})\\/`;
        //
        //call workflow
        var crType;
        if (requestType == 'Cost Deletion') {
            crType = "DeletionCost";
            requestStatus_ID = 11; //Pending Finance Approval
        } else if (requestType == 'Cost Roll' && subReqType == 'Standard Cost') {
            crType = "StandardCost";
        } else if (requestType == 'Cost Roll' && subReqType == 'Quoted Cost (PP2)') {
            crType = "FutureCost";
            // requestStatus_ID = 11; //Pending Finance Approval  //commented since the status shoud be pending with requestor.
        }
        var wfPayload = {
            "definitionId": "us10.jabilcfdev.costroll.costRollApprovalProcess",
            "context": {
                "costrollguid": req.data.ID,
                "counter": 1,
                "ticketid": ticketID,
                "crtype": crType
            }
        }

        return await cds.update('COSTROLL_COSTROLLMAIN')
            .set({ TICKETID: ticketID, REQUESTSTATUS_ID: requestStatus_ID, FISCAL: yearNum, NUMBER: Number, CPNUM: cpNum, CPDATE: cpDate, CPMAX: cpMax, DRAFTNAME: draftName })
            .where({ ID: req.data.ID })
            .then(async function () {
                if (requestType == 'Cost Roll') {
                    // Call CP Run till Analysis for Cost Roll Type Request 
                    var CPAnalysisResults = await CommonUtilities.RunAnalysis(req, cpNum, companyCode, plantCode, variant, crLineItems, ticketID);
                    // fill the analysis result table 
                    await INSERT.into("COSTROLL_CRANALYSISRESULT").entries(CPAnalysisResults.CK40NHeaderToAnalysis);
                    if (!CPAnalysisResults.ErrorLogToCK40N.length == 0) {
                        //filter the unique values
                        let log = CPAnalysisResults.ErrorLogToCK40N.filter((obj, index, self) =>
                            index === self.findIndex((t) => (
                                t.partNumber === obj.partNumber && t.Msgty === obj.Msgty && t.Message === obj.Message
                            ))
                        );
                        //update the error log in COSTROLL_CRERRORLOG table
                        await INSERT.into("COSTROLL_CRERRORLOG").entries(log);
                        // check if there is an error then close the ticket
                        if (CPAnalysisResults.ErrorLogToCK40N.some(item => item.Msgty === 'E')) {
                            req.data.requestStatus_ID = 8; //Closed Error
                            await sendEmail(req.data.ID, "error", req, log, CPAnalysisResults.CK40NHeaderToAnalysis);
                            // Call CP Estimate Delete
                            await CommonUtilities.DeleteCPRun(req, cpNum, formattedCrDate);
                            return {
                                "ticketID": ticketID,
                                "PreRunResults": CPAnalysisResults,
                                "DisplayMessage": "Pre Cost Run ended in errors. Please Check the Error Log.",
                                "BackendError": true,
                            }
                        }
                        else {
                            req.data.requestStatus_ID = 2; //Pending Review 
                            await sendEmail(req.data.ID, "green", req, log, CPAnalysisResults.CK40NHeaderToAnalysis);
                            var wfResults = await CommonUtilities.callWorkFlow(req.data, req, 1, wfPayload);
                            //  ******Start of Change Sharique Update WORKFLOW History****************************
                            await updateWFLog(wfResults, req, "Requester", "Pending Requestor Review");
                            // ******End of Change Sharique Update WORKFLOW History**************************** 
                            return {
                                "ticketID": ticketID,
                                "PreRunResults": CPAnalysisResults,
                                "DisplayMessage": "Pre Cost Run Completed Successfully.",
                                "BackendError": false,
                            }
                        }
                    }
                    else {
                        await sendEmail(req.data.ID, "green", req, CPAnalysisResults.ErrorLogToCK40N, CPAnalysisResults.CK40NHeaderToAnalysis);
                        var wfResults = await CommonUtilities.callWorkFlow(req.data, req, 1, wfPayload);
                        //  ******Start of Change Sharique Update WORKFLOW History****************************
                        await updateWFLog(wfResults, req, "Requester", "Pending Requestor Review");
                        // var guid = crypto.randomUUID();
                        // var payload = {
                        //     ID: guid, //new id
                        //     Parent_ID: req.data.ID,//requestGuid,//cost roll id
                        //     WorkflowID: wfResults.id,//req.data.WFID, //wf instance id
                        //     ApproverEmail: '',//ApproverEmail, 
                        //     ApproverLevel: 'Requester',//ApproverLevel,//2
                        //     ApproverName: req.user.id,//latestTask.processor,//ApproverEmail,//ApproverName,
                        //     Status: "Pending Requestor Review",
                        //     Comments: '',
                        //     createdAt: new Date().toISOString(),
                        //     createdBy: req.user.id,
                        //     modifiedAt: new Date().toISOString(),
                        //     modifiedBy: req.user.id,
                        // }
                        // await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);

                        // ******End of Change Sharique Update WORKFLOW History**************************** 
                        return {
                            "ticketID": ticketID,
                            "PreRunResults": CPAnalysisResults,
                            "DisplayMessage": "Pre Cost Run Completed Successfully.",
                            "BackendError": false,
                        }
                    }
                }
                else if (requestType == 'Cost Deletion') {
                    console.log('request type is:', requestType);
                    // Start of change Sharique Ali
                    // Commented email send to requestor in case of cost deletion
                    // await sendEmail(req.data.ID, "financeDelNotif", req, [], []);
                    // End of change Sharique Ali
                    var wfResults = await CommonUtilities.callWorkFlow(req.data, req, 1, wfPayload);
                    //  ******Start of Change Sanchit Update WORKFLOW History****************************
                    await updateWFLog(wfResults, req, "Finance", "Pending Finance Approval");
                    // var guid = crypto.randomUUID();
                    // var payload = {
                    //     ID: guid, //new id
                    //     Parent_ID: req.data.ID,//requestGuid,//cost roll id
                    //     WorkflowID: wfResults.id,//req.data.WFID, //wf instance id
                    //     ApproverEmail: '',//ApproverEmail, 
                    //     ApproverLevel: 'Finance',//4
                    //     ApproverName: '',
                    //     Status: "Pending Finance Approval",
                    //     Comments: '',
                    //     createdAt: new Date().toISOString(),
                    //     createdBy: req.user.id,
                    //     modifiedAt: new Date().toISOString(),
                    //     modifiedBy: req.user.id,
                    // }
                    // await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);

                    // ******End of Change Sanchit Update WORKFLOW History**************************** 
                    return {
                        "ticketID": ticketID,
                        "DisplayMessage": "Cost Deletion Request Submitted Successfully.",
                        "BackendError": false,
                    }
                    // Call Cost Deletion
                    // var CostDeletion = await CommonUtilities.CostDeletion(req, cpNum, companyCode, plantCode, crLineItems, subReqType);
                    // if (!CostDeletion.ErrorLogToCostEstDel.length == 0) {
                    //     return {
                    //         "CostDeletionResults": CostDeletion,
                    //         "DisplayMessage": "Cost Deletion ended in errors. Please Check the Error Log.",
                    //         "BackendError": true,
                    //     }
                    // }
                    // else {
                    //     return {
                    //         "CostDeletionResults": CostDeletion,
                    //         "DisplayMessage": "Cost Deletion Successful.",
                    //         "BackendError": false,
                    //     }
                    // }
                }


            }, function (error) {
                console.log(error);
                return 'Technical Error';
            });
    });

    // Create Ticket ID and CP number and update in the table
    this.before('CREATE', 'Header', async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
        if (!req.data.draftName) {
            const companyCode = req.data.companyCode;
            const plantCode = req.data.plantCode;
            const variant = req.data.variant;
            const crLineItems = req.data.crLineItems;
            const currentDate = new Date();
            const day = String(currentDate.getDate()).padStart(2, '0');
            const month = String(currentDate.getMonth() + 1).padStart(2, '0');
            const year = String(currentDate.getFullYear()).slice(-2);
            const CPyear = String(currentDate.getFullYear());
            var monthNum = parseInt(month);
            var yearNum = parseInt(year);
            if (monthNum > 8) {               //To get the Fiscal year, Starts at Sep 01
                yearNum = yearNum + 1;
            }
            //Get Running number for Ticket ID
            req.data.Number = await DB.getNextNumberForTicket(plantCode, yearNum); //req.data.plantCode
            req.data.Fiscal = yearNum;
            console.log("user id from FE", req.user.id);
            // Define the running number for Ticket ID and CP and CR Number
            const runningNumber = String(req.data.Number).padStart(7, '0');
            // Final Ticket Number
            req.data.ticketID = `${plantCode}_FY${yearNum}_${runningNumber}`;

            const MMDD = month + day;
            const YYYYMMDD = CPyear + month + day;
            const nextCP = await DB.getNextNumberForCP(YYYYMMDD);
            const runningCPNumber = String(nextCP).padStart(2, '0');
            // Final CP Number
            req.data.cpNum = `CP${MMDD}${runningCPNumber}`;
            req.data.cpDate = YYYYMMDD
            req.data.cpMax = runningCPNumber

            //Data for Deletion if error
            let inputDate = YYYYMMDD;
            inputDate = inputDate.toString();
            // Parse the input date
            let yearDate = parseInt(inputDate.substring(0, 4), 10);
            let monthDate = parseInt(inputDate.substring(4, 6), 10) - 1; // Month is zero-indexed
            let dayDate = parseInt(inputDate.substring(6, 8), 10);
            // Create a Date object
            let dateObject = new Date(Date.UTC(yearDate, monthDate, dayDate));
            // Add one day
            dateObject.setUTCDate(dateObject.getUTCDate());
            // Convert to milliseconds since Unix epoch
            let epochMillis = dateObject.getTime();
            // Format as \/Date(epochMillis)\/
            let formattedCrDate = `\\/Date(${epochMillis})\\/`;
            //

            // //Create Folder in DMS for keeping documents + attachments
            // Start of change Sharique Ali 06/01/2024
            // Uncommented the below 3 lines to create the DMS folder id

            const folderID = await createDMSFolder(req.data.ID); //Need Error Handling
            req.data.DmsFolderId = folderID.folderID;
            req.data.DmsFolderName = 'Folder_' + req.data.CWAName;
            // End of change Sharique Ali 06/01/2024
            //call workflow
            var crType;
            if (req.data.requestType == 'Cost Deletion') {
                crType = "DeletionCost";
            } else if (req.data.requestType == 'Cost Roll' && req.data.subReqType == 'Standard Cost') {
                crType = "StandardCost";
            } else if (req.data.requestType == 'Cost Roll' && req.data.subReqType == 'Quoted Cost (PP2)') {
                crType = "FutureCost";
            }

            var wfPayload = {
                "definitionId": "us10.jabilcfdev.costroll.costRollApprovalProcess",
                "context": {
                    "costrollguid": req.data.ID,
                    "counter": 1,
                    "ticketid": req.data.ticketID,
                    "crtype": crType
                }
            }

            if (req.data.requestType == 'Cost Roll') {
                // Call CP Run till Analysis for Cost Roll Type Request 
                var CPAnalysisResults = await CommonUtilities.RunAnalysis(req, req.data.cpNum, companyCode, plantCode, variant, crLineItems, req.data.ticketID);
                // fill the analysis result table 
                await INSERT.into("COSTROLL_CRANALYSISRESULT").entries(CPAnalysisResults.CK40NHeaderToAnalysis);
                if (!CPAnalysisResults.ErrorLogToCK40N.length == 0) {
                    //filter the unique values
                    let log = CPAnalysisResults.ErrorLogToCK40N.filter((obj, index, self) =>
                        index === self.findIndex((t) => (
                            t.partNumber === obj.partNumber && t.Msgty === obj.Msgty && t.Message === obj.Message
                        ))
                    );
                    //update the error log in COSTROLL_CRERRORLOG table
                    await INSERT.into("COSTROLL_CRERRORLOG").entries(log);
                    // check if there is an error then close the ticket
                    if (CPAnalysisResults.ErrorLogToCK40N.some(item => item.Msgty === 'E')) {
                        req.data.requestStatus_ID = 8; //Closed Error
                        await sendEmail(req.data.ID, "error", req, log, CPAnalysisResults.CK40NHeaderToAnalysis);
                        // Call CP Estimate Delete
                        await CommonUtilities.DeleteCPRun(req, req.data.cpNum, formattedCrDate);

                        return {
                            "ticketID": req.data.ticketID,
                            "PreRunResults": CPAnalysisResults,
                            "DisplayMessage": "Pre Cost Run ended in errors. Please Check the Error Log.",
                            "BackendError": true,
                        }
                    }
                    else {
                        if (CPAnalysisResults.ErrorLogToCK40N.some(item => item.Msgty === 'W')) {
                            await sendEmail(req.data.ID, "warning", req, log, CPAnalysisResults.CK40NHeaderToAnalysis);
                        }
                        else {
                            await sendEmail(req.data.ID, "green", req, log, CPAnalysisResults.CK40NHeaderToAnalysis);
                        }
                        var wfResults = await CommonUtilities.callWorkFlow(req.data, req, 1, wfPayload);
                        console.log("WF Results", wfResults);
                        console.log("WF Results 1", wfResults.data);
                        req.data.requestStatus_ID = 2; //Pending Review

                        //  ******Start of Change Sharique Update WORKFLOW History****************************
                        await updateWFLog(wfResults, req, "Requester", "Pending Requestor Review");
                        // var guid = crypto.randomUUID();
                        // var payload = {
                        //     ID: guid, //new id
                        //     Parent_ID: req.data.ID,//requestGuid,//cost roll id
                        //     WorkflowID: wfResults.id,//req.data.WFID, //wf instance id
                        //     ApproverEmail: '',//ApproverEmail, 
                        //     ApproverLevel: 'Requester',//ApproverLevel,//2
                        //     ApproverName: req.user.id,//latestTask.processor,//ApproverEmail,//ApproverName,
                        //     Status: "Pending Requestor Review",
                        //     Comments: '',
                        //     createdAt: new Date().toISOString(),
                        //     createdBy: req.user.id,
                        //     modifiedAt: new Date().toISOString(),
                        //     modifiedBy: req.user.id,
                        // }
                        // await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);

                        // ******End of Change Sharique Update WORKFLOW History****************************                        

                        return {
                            "ticketID": req.data.ticketID,
                            "PreRunResults": CPAnalysisResults,
                            "DisplayMessage": "Pre Cost Run Completed Successfully.",
                            "BackendError": false,
                        }

                    }

                }
                else {
                    await sendEmail(req.data.ID, "green", req, CPAnalysisResults.ErrorLogToCK40N, CPAnalysisResults.CK40NHeaderToAnalysis);
                    var wfResults = await CommonUtilities.callWorkFlow(req.data, req, 1, wfPayload);
                    await updateWFLog(wfResults, req, "Requester", "Pending Requestor Review");
                    req.data.requestStatus_ID = 2; //Pending Review
                    return {
                        "ticketID": req.data.ticketID,
                        "PreRunResults": CPAnalysisResults,
                        "DisplayMessage": "Pre Cost Run Completed Successfully.",
                        "BackendError": false,
                    }
                }
            }
            else if (req.data.requestType == 'Cost Deletion') {

                req.data.requestStatus_ID = 11; //Pending Finance Approval
                // Start of change Sharique Ali
                // Commented email send to requestor in case of cost deletion
                // await sendEmail(req.data.ID, "financeDelNotif", req, [], []);
                // End of change Sharique Ali
                var wfResults = await CommonUtilities.callWorkFlow(req.data, req, 1, wfPayload);
                // Call Cost Deletion
                // var CostDeletion = await CommonUtilities.CostDeletion(req, req.data.cpNum, companyCode, plantCode, crLineItems, req.data.subReqType);
                // if (!CostDeletion.ErrorLogToCostEstDel.length == 0) {
                //     return {
                //         "CostDeletionResults": CostDeletion,
                //         "DisplayMessage": "Cost Deletion ended in errors. Please Check the Error Log.",
                //         "BackendError": true,
                //     }
                // }
                // else {
                //     return {
                //         "CostDeletionResults": CostDeletion,
                //         "DisplayMessage": "Cost Deletion Successful.",
                //         "BackendError": false,
                //     }
                // }
                //  ******Start of Change Sanchit Update WORKFLOW History****************************
                await updateWFLog(wfResults, req, "Finance", "Pending Finance Approval");
                // var guid = crypto.randomUUID();
                // var payload = {
                //     ID: guid, //new id
                //     Parent_ID: req.data.ID,//requestGuid,//cost roll id
                //     WorkflowID: wfResults.id,//req.data.WFID, //wf instance id
                //     ApproverEmail: '',//ApproverEmail, 
                //     ApproverLevel: 'Finance',//4
                //     ApproverName: '',
                //     Status: "Pending Finance Approval",
                //     Comments: '',
                //     createdAt: new Date().toISOString(),
                //     createdBy: req.user.id,
                //     modifiedAt: new Date().toISOString(),
                //     modifiedBy: req.user.id,
                // }
                // await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);

                // ******End of Change Sanchit Update WORKFLOW History**************************** 

            }
        }
        else {
            //Check if there is an existing draft with same name
            checkDraftName = await DB.ExistingDraft(req.user.id);

            if (checkDraftName) {
                var SameName = checkDraftName.includes(req.data.draftName)
                if (SameName) {
                    req.error({
                        "message": "Draft Name Already Exists",
                        "status": 418
                    });
                    return;
                }
// Start of Change Sharique 10/02/2025
//Fetch DMS folder name during draft save as well
const folderID = await createDMSFolder(req.data.ID); //Need Error Handling
req.data.DmsFolderId = folderID.folderID;
req.data.DmsFolderName = 'Folder_' + req.data.CWAName;
// End of Change Sharique 10/02/2025
                req.data.requestStatus_ID = 1; //In Draft
            }
        }
        // req.data.requestor = req.user.id
    });

    //Get User's Role Dashboard
    this.on('checkAdmin', CostRollRequestHandler._checkAdmin);

    // Get user Company codes
    this.on('getUserCoCd', CostRollRequestHandler._getUserCoCd);

    //Withdrawn Action in Dashboard Validation for the requestor 
    // this.before(['withdrawTicket'], async (req) => {
    //     if (await CostRollRequestHandler.notRequestor(req)) {
    //         req.error({
    //             "message": "you are not the creator of this req",
    //             "status": 418
    //         });
    //         return;
    //     }
    // });

    //Withdrawn Action in Dashboard
    this.on('withdrawTicket', async req => {

        const IDs = req.data.ID.split(';');
        const WFIDs = req.data.WFID.split(';');
        var WithdrawRequestor = 5;
        var WithdrawAdmin = 9;
        var withdrawnStatus = {};
        var withdrawReturn = [];
        var CheckAdmin = await CostRollRequestHandler._checkAdmin(req);

        var AllTickets = await SELECT
            .distinct
            .columns(['ID', 'TICKETID', 'CREATEDBY', 'REQUESTSTATUS_ID'])
            .from('COSTROLL_COSTROLLMAIN')
            .where({ ID: IDs });

        var length = AllTickets.length;
        var workflowPayload = {
            "status": "CANCELED",
            "cascade": false
        }
        for (var i = 0; i < length; i++) {
            if (AllTickets[i].REQUESTSTATUS_ID == 2 || AllTickets[i].REQUESTSTATUS_ID == 3 || AllTickets[i].REQUESTSTATUS_ID == 4 || AllTickets[i].REQUESTSTATUS_ID == 11) {
                // if Admin wants to withdraw ticket write the logic here                
                if (CheckAdmin.Admin) {
                    const workflowService = await cds.connect.to('Workflow');
                    await workflowService.tx(req).patch('/workflow-instances/' + WFIDs[i], workflowPayload);                    //req.data.WFID
                    await cds.update('COSTROLL_COSTROLLMAIN')
                        .set({ REQUESTSTATUS_ID: WithdrawAdmin })
                        .where({ ID: AllTickets[i].ID })
                        .then(async function () {
                            withdrawnStatus.ticketID = AllTickets[i].TICKETID;
                            withdrawnStatus.Msgty = 'S';
                            withdrawnStatus.Message = 'Tickets Withdrawn Done by Admin';
                            withdrawReturn.push(withdrawnStatus);
                            withdrawnStatus = {};
                        },
                            function (error) {
                                console.log(error);
                                return 'Technical Error';
                            });
                }
                else {
                    if (req.user.id.toLowerCase() == AllTickets[i].CREATEDBY.toLowerCase()) {
                        const workflowService = await cds.connect.to('Workflow');
                        await workflowService.tx(req).patch('/workflow-instances/' + WFIDs[i], workflowPayload);
                        await cds.update('COSTROLL_COSTROLLMAIN')
                            .set({ REQUESTSTATUS_ID: WithdrawRequestor })
                            .where({ ID: AllTickets[i].ID })
                            .then(async function () {
                                withdrawnStatus.ticketID = AllTickets[i].TICKETID;
                                withdrawnStatus.Msgty = 'S';
                                withdrawnStatus.Message = 'Ticket Withdrawn Done';
                                withdrawReturn.push(withdrawnStatus);
                                withdrawnStatus = {};
                            },
                                function (error) {
                                    console.log(error);
                                    return 'Technical Error';
                                });
                    }
                    else {
                        withdrawnStatus.ticketID = AllTickets[i].TICKETID;
                        withdrawnStatus.Msgty = 'E';
                        withdrawnStatus.Message = 'Not Requestor';
                        withdrawReturn.push(withdrawnStatus);
                        withdrawnStatus = {};
                    }
                }
            }
            else {
                withdrawnStatus.ticketID = AllTickets[i].TICKETID;
                withdrawnStatus.Msgty = 'E';
                withdrawnStatus.Message = 'Not Possible to Withdraw Ticket';
                withdrawReturn.push(withdrawnStatus);
                withdrawnStatus = {};
            }
        }

        return withdrawReturn;



        // if Admin wants to withdraw ticket write the logic here
        // var CheckAdmin = await CostRollRequestHandler._checkAdmin(req);
        // if (CheckAdmin) {
        //     await cds.update('COSTROLL_COSTROLLMAIN')
        //         .set({ REQUESTSTATUS_ID: requestStatus_ID })
        //         .where({ ID: IDs })
        //         .then(async function () {
        //             // withdrawnStatus.ticketID = AllTickets[i].TICKETID;
        //             // withdrawnStatus.Msgty = 'S';
        //             withdrawnStatus.Message = 'Tickets Withdrawn Done by Admin';
        //             withdrawReturn.push(withdrawnStatus);
        //         },
        //             function (error) {
        //                 console.log(error);
        //                 return 'Technical Error';
        //             });
        // }
        // else {
        //     var AllTickets = await SELECT
        //         .distinct
        //         .columns(['ID', 'TICKETID', 'CREATEDBY'])
        //         .from('COSTROLL_COSTROLLMAIN')
        //         .where({ ID: IDs });

        //     var length = AllTickets.length;
        //     for (var i = 0; i < length; i++) {
        //         if (req.user.id == AllTickets[i].CREATEDBY) {
        //             await cds.update('COSTROLL_COSTROLLMAIN')
        //                 .set({ REQUESTSTATUS_ID: requestStatus_ID })
        //                 .where({ ID: AllTickets[i].ID })
        //                 .then(async function () {
        //                     withdrawnStatus.ticketID = AllTickets[i].TICKETID;
        //                     withdrawnStatus.Msgty = 'S';
        //                     withdrawnStatus.Message = 'Ticket Withdrawn Done';
        //                     withdrawReturn.push(withdrawnStatus);
        //                 },
        //                     function (error) {
        //                         console.log(error);
        //                         return 'Technical Error';
        //                     });
        //         }
        //         else {
        //             withdrawnStatus.ticketID = AllTickets[i].TICKETID;
        //             withdrawnStatus.Msgty = 'E';
        //             withdrawnStatus.Message = 'Not Requestor';
        //             withdrawReturn.push(withdrawnStatus);
        //         }
        //     }
        // }

    });

    //fowrard Ticket Action in Dashboard
    this.on('fowrardTicket', async req => {
        var forwardStatus = {};
        var forwardReturn = [];
        const IDs = req.data.ID.split(';');
        const WFIDs = req.data.WFID.split(';');
        var length = WFIDs.length;
        // if Admin wants to forward ticket write the logic here
        var CheckAdmin = await CostRollRequestHandler._checkAdmin(req);
        if (CheckAdmin.Admin) {
            var workflowPayload = {
                "recipientUsers": req.data.Email
            }
            console.log("forwardworkflowPayload", workflowPayload);
            const workflowService = await cds.connect.to('Workflow');
            for (var i = 0; i < length; i++) {

                const wfdetails = await workflowService.tx(req).get('/workflow-instances/' + WFIDs[i] + '/execution-logs');
                const subflowCreatedLogs = wfdetails.filter(log => log.type === "REFERENCED_SUBFLOW_STARTED");
                if (subflowCreatedLogs.length == 0) {
                    var userTaskCreatedLogs = wfdetails.filter(log => log.type === "USERTASK_CREATED");
                    var lastLogIndex = userTaskCreatedLogs.length - 1;
                    var taskId = userTaskCreatedLogs[lastLogIndex]?.taskId;
                } else {
                    const subFlowID = subflowCreatedLogs[0].subflow.workflowInstanceId;
                    const subWfdetails = await workflowService.tx(req).get('/workflow-instances/' + subFlowID + '/execution-logs');
                    const userTaskCreatedLogs = subWfdetails.filter(log => log.type === "USERTASK_CREATED");
                    var lastLogIndex = userTaskCreatedLogs.length - 1;
                    var taskId = userTaskCreatedLogs[lastLogIndex]?.taskId;
                }

                // Start of change Sharique 17/01/2025 
                // email notification to the person who receives the forwarded workitem
                crData = await SELECT.one.from("COSTROLL_CRWFHISTORY").where({ WorkflowID: WFIDs[i] }).orderBy("createdAt desc");
                req.data.ID = crData.PARENT_ID;
                // var userId = req.user.id.toLowerCase();
                // const [crDataMain] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: req.data.ID });
                // const crDataRoute = await SELECT.from("COSTROLL_MANAGEROUTES");//.where({ routeID: crDataMain.ROUTEID });
                // result = await getUser(crDataRoute, req.data.Email);findMatchingEmail
                // const matchingEmail = await findMatchingEmail(crDataRoute, req.data.Email);
                // const matchingEmail = await findMatchingEmail1(crDataRoute, req.data.Email);
                const matchingEmail = await findMatchingEmail1(req.data.Email);
                workflowPayload = {
                    "recipientUsers": matchingEmail
                }
                // End of cchange sharique 17/01/2025

                console.log("taskId", taskId);
                await workflowService.tx(req).patch('/task-instances/' + taskId, workflowPayload);

                // Start of change Sharique 17/01/2025
                // email notification to the person who receives the forwarded workitem
                // crData = await SELECT.one.from("COSTROLL_CRWFHISTORY").where({ WorkflowID: WFIDs[i] }).orderBy("createdAt desc");
                // req.data.ID = crData.PARENT_ID;
                // var userId = req.user.id.toLowerCase();
                // const [crDataMain] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: userId });
                // const [crDataRoute] = await SELECT.from("COSTROLL_MANAGEROUTES").where({ routeID: crData.ROUTEID });


                console.log("cost roll id", req.data.ID);
                await sendEmailForward(crData.PARENT_ID, crData.APPROVERLEVEL, req);
                // await sendEmailForward(crData.PARENT_ID, "forward", req);
                // await sendEmailForward(crData.PARENT_ID, crData.ApproverLevel, req);
                // console.log("Email sent successfuly");
                // End of cchange sharique 17/01/2024

            }
            forwardStatus.Msgty = 'S';
            forwardStatus.Message = 'Ticket Forward is Successful';
            forwardReturn.push(forwardStatus);
            forwardStatus = {};
        }
        else {

        }

        return forwardReturn;
    });


    
    this.on('getApprovalDetails', async req => {
        const requestGuid = req.data.RequestID;
        const counter = req.data.Counter;
        const [crData] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: requestGuid });
        const [routeData] = await SELECT.from("COSTROLL_MANAGEROUTES").where({ routeID: crData.ROUTEID });
        const requestType = crData.REQUESTTYPE;
        const subReqType = crData.SUBREQTYPE;
        let btpCockpitEmail;

        if (requestType == 'Cost Roll') {
            if (subReqType == 'Standard Cost') {
                if (counter == 1) {
                    var approverLevel = "Requester";
                    var approverEmail = crData.CREATEDBY;
                    var status = "PendingApprover";
                    var mailStatus = "PendingRequester";
                } else if (counter == 2) {
                    var approverLevel = "Approver";
                    var approverEmail = routeData.APPGP1;
                    var status = "PendingFinance";
                    var mailStatus = "PendingApprover";
                } else if (counter == 3) {
                    var approverLevel = "Finance";
                    var approverEmail = routeData.APPGP2;
                    var status = "closed";
                    var mailStatus = "PendingFinance";
                }
                // if (approverEmail == 'sharique_ali@jabil.com') {
                //     approverEmail = 'Sharique_Ali@jabil.com';
                // }
                var Approvers = {
                    "Parent": crData.ID,
                    "ApproverLevel": approverLevel,
                    "ApproverEmail": approverEmail
                }

                // Create the final response object
    // Start of change Sharique Ali 27/02/2025
     btpCockpitEmail = await get_verified_emails(Approvers.ApproverEmail, req);
    if (btpCockpitEmail) {
      console.log("BTP Cockpit Approvers1", btpCockpitEmail);
      Approvers.ApproverEmail = btpCockpitEmail;
    }
    // Get all the users verified from BTP cockpit
           
    // End of change Sharique Ali  27/02/2025
                const CWAApproverResponse = {
                    totalCount: 4,
                    indexCount: counter + 1,
                    Approvers: Approvers,
                    status: status,
                    mailStatus: mailStatus,
                    requestType: requestType
                };
                return CWAApproverResponse;
            } else {
                if (counter == 1) {
                    var approverLevel = "Requester";
                    var approverEmail = crData.CREATEDBY;
                    var status = "PendingFinance";
                    var mailStatus = "PendingRequester";
                } else if (counter == 2) {
                    var approverLevel = "Finance";
                    var approverEmail = routeData.APPGP2;
                    var status = "closed";
                    var mailStatus = "PendingFinance";
                }
                var Approvers = {
                    "Parent": crData.ID,
                    "ApproverLevel": approverLevel,
                    "ApproverEmail": approverEmail
                }

                // Create the final response object

    // Start of change Sharique Ali 27/02/
    // Get all the users verified from BTP cockpit
 btpCockpitEmail = await get_verified_emails(Approvers.ApproverEmail, req);
      if (btpCockpitEmail) {
        Approvers.ApproverEmail = btpCockpitEmail;
        console.log("BTP Cockpit Approvers2", btpCockpitEmail);
      }
      
    // End of change Sharique Ali  27/02/2025

                const CWAApproverResponse = {
                    totalCount: 3,
                    indexCount: counter + 1,
                    Approvers: Approvers,
                    status: status,
                    mailStatus: mailStatus,
                    requestType: requestType
                };
                return CWAApproverResponse;
            }
        } else {
            // if (counter == 1) {
            //     var approverLevel = "Approver";
            //     var approverEmail = routeData.APPGP1;
            //     var status = "PendingFinance";
            // } else if (counter == 2) {
            //     var approverLevel = "Finance";
            //     var approverEmail = routeData.APPGP2;
            //     var status = "closed";
            // }
            var approverLevel = "Finance";
            var approverEmail = routeData.APPGP2;
            var status = "closed";
            // Start of Change sharique 13/01/2024
            // for Cost deletion, after submission the status sent to finance will be different
            // Commented the line below to add a condition
            // var mailStatus = "PendingFinance";
            if (requestType == 'Cost Deletion') {
                var mailStatus = "financeDelNotif";
            } else {
                var mailStatus = "PendingFinance";
            }
            // End of change Sharique    13/01/2024

            var Approvers = {
                "Parent": crData.ID,
                "ApproverLevel": approverLevel,
                "ApproverEmail": approverEmail
            }

            // Create the final response object

            // Start of change Sharique Ali 27/02/
    // Get all the users verified from BTP cockpit
 btpCockpitEmail = await get_verified_emails(Approvers.ApproverEmail, req);
if (btpCockpitEmail) {
    Approvers.ApproverEmail = btpCockpitEmail;
  console.log("BTP Cockpit Approvers3", btpCockpitEmail);
}

// End of change Sharique Ali  27/02/2025

            const CWAApproverResponse = {
                totalCount: 1,
                indexCount: counter + 1,
                Approvers: Approvers,
                status: status,
                mailStatus: mailStatus,
                requestType: requestType
            };
            return CWAApproverResponse;
        }

    });

    this.on('updateRequestFromWF', async req => {
        const { RequestID: requestGuid } = req.data;
        try {
            if (requestGuid) {
    
    // Start of Change 12/02/2025
// If the status code is 07(rejected) don't change the status to completed
const [CrEntity] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: requestGuid });
    
    if (CrEntity.REQUESTSTATUS_ID == '6' || CrEntity.REQUESTSTATUS_ID == '7' 
        || CrEntity.REQUESTSTATUS_ID == '10' ) {
        
    }else{
// End of Change 12/02/2025
        await UPDATE.entity("COSTROLL_COSTROLLMAIN").with({ requestStatus_ID: 10 }).where({ ID: requestGuid });
 // Start of Change 12/02/2025 
    }
 // End of Change 12/02/2025               
            }
            return { "CostRollID": requestGuid, "MessageType": "S", "Message": "Success" }
        } catch (error) {
            return { "CostRollID": requestGuid, "MessageType": "E", "Message": error }
        }
    });
    this.on('updateWorkflow', async req => {
        var guid = crypto.randomUUID();
        var { RequestID: requestGuid, ApproverLevel: ApproverLevel, STATUS: status, ApproverName: ApproverName, ApproverEmail: ApproverEmail, Comments: Comments, wfStatus: wfStatus } = req.data;
        let statusId;
        const [crData] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: requestGuid });
        try {


            // ****************Start of new code to add actual workitem processor shariqueali 26/12/2024 
            var latestTask;
            var wfService = await cds.connect.to("Workflow");
            // Extract the workflow instance ID from the request data
            const workflowInstanceId = req.data.WFID;
            // const status = "COMPLETED";
            // Construct the URL with the dynamic workflowInstanceId and status
            const taskInstancesUrl = `/task-instances?workflowInstanceId=${workflowInstanceId}&status=COMPLETED`;
            const tasksResponse = await wfService.tx(req).get(taskInstancesUrl);
            console.log('tasksResponse:', tasksResponse);
            if (tasksResponse && tasksResponse.length > 0) {
                // Sort tasks by `createdAt` to get the latest one
                latestTask = tasksResponse.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];

                console.log('Latest Task:', latestTask);

                // Perform further operations with the latestTask if needed
            } else {
                console.log('No tasks found for the specified workflowInstanceId and status.');
            }
            // return response; 

            // ****************End of new code to add actual workitem processor shariqueali 26/12/2024 

            console.log('Latest Task:', latestTask.processor);
            if (status === "Approved") {
                if (wfStatus == "PendingApprover") {
                    statusId = 3;
                } else if (wfStatus == "PendingFinance") {
                    statusId = 4;
                } else {
                    statusId = 4;
                }
                var payload = {
                    ID: guid,
                    Parent_ID: requestGuid,
                    WorkflowID: req.data.WFID,
                    ApproverEmail: ApproverEmail,
                    ApproverLevel: ApproverLevel,
                    ApproverName: latestTask.processor,//ApproverEmail,//ApproverName,
                    Status: "Approved",
                    Comments: Comments,
                    createdAt: new Date().toISOString(),
                    createdBy: req.user.id,
                    modifiedAt: new Date().toISOString(),
                    modifiedBy: req.user.id,
                }
                await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);

            } else if (status === "Rejected") {
                if (ApproverLevel == "Requester") {
                    statusId = 5;
                } else if (ApproverLevel == "Approver") {
                    statusId = 6;
                } else if (ApproverLevel == "Finance") {
                    statusId = 7;
                }
                var payload = {
                    ID: guid,
                    Parent_ID: requestGuid,
                    WorkflowID: req.data.WFID,
                    ApproverEmail: ApproverEmail,
                    ApproverLevel: ApproverLevel,
                    ApproverName: latestTask.processor,//ApproverName,
                    Status: "Rejected",
                    Comments: Comments,
                    createdAt: new Date().toISOString(),
                    createdBy: req.user.id,
                    modifiedAt: new Date().toISOString(),
                    modifiedBy: req.user.id,
                }
                await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);
                let inputDate = crData.CPDATE;
                inputDate = inputDate.toString();
                // Parse the input date
                let year = parseInt(inputDate.substring(0, 4), 10);
                let monthDate = parseInt(inputDate.substring(4, 6), 10) - 1; // Month is zero-indexed
                let dayDate = parseInt(inputDate.substring(6, 8), 10);
                // Create a Date object
                let dateObject = new Date(Date.UTC(year, monthDate, dayDate));
                // Add one day
                dateObject.setUTCDate(dateObject.getUTCDate());
                // Convert to milliseconds since Unix epoch
                let epochMillis = dateObject.getTime();
                // Format as \/Date(epochMillis)\/
                let formattedCrDate = `\\/Date(${epochMillis})\\/`;


                // Call CP Estimate Delete
                var CPDeletion = await CommonUtilities.DeleteCPRun(req, crData.CPNUM, formattedCrDate);
            }
            if (statusId) {
                console.log('Status Before Update', statusId);
                await UPDATE.entity("COSTROLL_COSTROLLMAIN").with({ requestStatus_ID: statusId }).where({ ID: requestGuid });
            }
            return { "CWARequestID": requestGuid, "MessageType": "S", "Message": "Success" }

        } catch (error) {
            return { "CWARequestID": requestGuid, "MessageType": "E", "Message": error }
        }
    });
    this.on('triggerEmail', async (req) => {
        console.log(req.data);
        var { RequestID: requestGuid, ApproverLevel: ApproverLevel, STATUS: status, ApproverEmail: ApproverEmail, Comments: Comments } = req.data;
        // Mapping status to text
        if (status == "PendingRequester") {
            return { "CWARequestID": requestGuid, "MessageType": "S", "Message": "Success" };
        }
        var financeApprovers = ApproverEmail;//Used in cost deletion rejevtion cc email Sharique Ali 14/01/2024
        const statusMapping = {
            "PartialRelease": "Partial Release",
            "FullRelease": "Full Release",
            "FullUpdate": "Full Update",
            "PartialUpdate": "Partial Update",
            "NoUpdate": "No Update",
            "FullDeletion": "Full Deletion",
            "PartialDeletion": "Partial Deletion",
            "NoDeletion": "No Deletion"
        };
        const templateMapping = {
            "Rejected": "wfRejectionNotification",
            "RejectRelease": "wfRejectionNotification",//new status added Sharique 27/12/2024
            "closed": "closedNotification",
            "PendingApprover": "approverNotification",
            "PendingFinance": "financeNotification",
            "financeDelNotif": "financeDelNotification",
            "PartialRelease": "financeFinal",
            "FullRelease": "financeFinal",
            "FullUpdate": "financeFinal",
            "PartialUpdate": "financeFinal",
            "NoUpdate": "financeFinal",
            "FullDeletion": "closeFullDeletion",//"financeFinal",//Template replaced Sharique 01/03/2024
            "PartialDeletion": "closePartialDeletion",//"financeFinal",//Template replaced Sharique 01/03/2024
            "NoDeletion": "closeNoDeletion",//"financeFinal"//Template replaced Sharique 01/03/2024
        };
        console.log('status', status);
        const statusText = statusMapping[status] || "Unknown Status";
        const template = templateMapping[status] || "Unknown Template";

        // Fetching CWA data
        const [crData] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: requestGuid });
        const crAnalysis = await SELECT.from("COSTROLL.CRANALYSISRESULT").where({ ticketID: crData.TICKETID });
        const crAnalysisMessage = await SELECT.from("COSTROLL.CRERRORLOG").where({ ticketID: crData.TICKETID });

        //Start of change Sharique 14/01/2024
        let subjectline;
        console.log('Request type', crData.REQUESTTYPE);
        if (crData.REQUESTTYPE === 'Cost Deletion') {
            subjectline = 'Notification of rejection: Cost Deletion ';
        } else {
            subjectline = 'Notification of rejection: Cost Roll ';
        }
        //End of Change Sharique  14/01/2024

        const subjectMapping = {
            //Start of change Sharique 14/01/2024
            // Commented the line below to accommodate different subjectlines for cost roll and cost deletion
            // "Rejected": "Notification of rejection: Cost Roll " + `${crData.TICKETID}`,
            "Rejected": `${subjectline}` + `${crData.TICKETID}`,
            //End of Change Sharique  14/01/2024

            "closed": "Finance has closed the request form " + `${crData.TICKETID}`,
            "PendingApprover": "Action Required: Please review the analysis results of the cost roll " + `${crData.TICKETID}` + " and approve or reject the request",
            "PendingFinance": "Action Required: Cost Roll " + `${crData.TICKETID}` + " was approver and pending your execution",
            "financeDelNotif": "Action Required: Cost Deletion " + `${crData.TICKETID}`,
            "PartialRelease": "Finance has closed the request form " + `${crData.TICKETID}` + " with status Partial Release",
            "FullRelease": "Finance has closed the request form " + `${crData.TICKETID}` + " with status Full Release",
            "FullUpdate": "Finance has closed the request form " + `${crData.TICKETID}` + " with status Full Update",
            "PartialUpdate": "Finance has closed the request form " + `${crData.TICKETID}` + " with status Partial Update",
            "NoUpdate": "Finance has closed the request form " + `${crData.TICKETID}` + " with status No Update",
            // Start of change Sharique 03/01/2024
            // Email Subject line changed
            // "FullDeletion": "Finance has closed the request form " + `${crData.TICKETID}` + " with status Full Deletion",
            "FullDeletion": "Notification of closure: cost  deletion " + `${crData.TICKETID}` + " with status Full Deletion",

            // "PartialDeletion": "Finance has closed the request form " + `${crData.TICKETID}` + " with status Partial Deletion",
            "PartialDeletion": "Notification of closure: cost  deletion " + `${crData.TICKETID}` + " with status Partial Deletion",

            // "NoDeletion": "Finance has closed the request form " + `${crData.TICKETID}` + " with status No Deletion"
            "NoDeletion": "Notification of closure: cost  deletion " + `${crData.TICKETID}` + " with status No Deletion"
            // End of change Sharique 03/01/2024
        };
        const subject = subjectMapping[status] || "Action Required";

        const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site/digitalapps";
        console.log("apiUrl", process.env.apiUrl);
        console.log("apiUrl", apiUrl);

        // var url = apiUrl + "#cwa-RequestCreate?TicketID=" + cwaData.CWANAME;
        var url = apiUrl + "#CostRollDashboard-manage?TicketID=" + crData.TICKETID;
        var inBoxUrl = apiUrl + "#WorkflowTask-DisplayMyInbox?sap-ui-app-id-hint=saas_approuter_com.sap.spa.inbox"
        // const subject = "CWA ACTION REQUIRED: " + ApproverLevel + " Approval " + cwaData.CWANAME;
        const from = process.env.FromEmail || "CostRoll_workflow_dev@jabil.com";
        // ****************Start of new code to add actual workitem processor shariqueali 26/12/2024 
        if (status === 'Rejected' || status === 'RejectRelease') {

            const latest = await SELECT.one.from("COSTROLL_CRWFHISTORY").where({ Parent_ID: requestGuid }).orderBy("createdAt desc");
            console.log('latest', latest);
            ApproverEmail = latest.APPROVERNAME;
            // var latestTask;
            // var wfService = await cds.connect.to("Workflow");
            // // Extract the workflow instance ID from the request data
            // const workflowInstanceId = req.data.WFID;
            // // const status = "COMPLETED";
            // // Construct the URL with the dynamic workflowInstanceId and status
            // const taskInstancesUrl = `/task-instances?workflowInstanceId=${workflowInstanceId}&status=COMPLETED`;
            // const tasksResponse = await wfService.tx(req).get(taskInstancesUrl);
            // console.log('tasksResponse:', tasksResponse);
            // if (tasksResponse && tasksResponse.length > 0) {
            //     // Sort tasks by `createdAt` to get the latest one
            //      latestTask = tasksResponse.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
            //     ApproverEmail = latestTask.processor;
            //     console.log('Latest Task:', latestTask);

            //     // Perform further operations with the latestTask if needed
            // } else {
            //     console.log('No tasks found for the specified workflowInstanceId and status.');
            // }
            // return response; 
        }
        // ****************End of new code to add actual workitem processor shariqueali 26/12/2024 
        const data = {
            requestorName: crData.CREATEDBY,
            approverName: ApproverEmail,
            requestNumber: crData.TICKETID,
            comment: Comments,
            approvalRejectLink: url,
            inBoxUrl: inBoxUrl,
            level: ApproverLevel,
            dashboardUrl: url,
            tableData: crAnalysisMessage,
            status: statusText
        };
        //get Template
        // const templateName = template; // Template file name (without extension)
        // const template = await getTemplate(templateName);
        // Start of change Sharique 02/01/2024
        const crDataReq = await SELECT.one.from("COSTROLL_COSTROLLMAIN").where({ ID: requestGuid });
        let cc;
        if (crDataReq.REQUESTTYPE === 'Cost Deletion' && ApproverLevel === 'Finance') {
            if (status === 'Rejected') {
                cc = financeApprovers + ";" + crData.CREATEDBY;
            }else{
                cc = crData.CREATEDBY;   
            }

        } else {
            cc = crData.CREATEDBY;
        }
        // End of change Sharique  02/01/2024
        var ccEmails = cc;//crData.CREATEDBY;change Sharique  02/01/2024
        const excelData = await generateExcel(crAnalysis);
        const attachment = excelData.excelFile;
        const attchmentName = crData.TICKETID + "ANALYSIS.xlsx";
        const responseMailStatus = await mailUtil.sendEmail(template, data, from, ApproverEmail, subject, ccEmails, req, attachment, attchmentName);
        if (responseMailStatus == "Success") {
            return { "CWARequestID": requestGuid, "MessageType": "S", "Message": "Success" }
        } else {
            return { "CWARequestID": requestGuid, "MessageType": "E", "Message": "Error" }
        }

    });

    this.on('triggerCKAction', async (req) => {
        console.log(req.data);
        var { RequestID: requestGuid, ApproverLevel: ApproverLevel, STATUS: status, ApproverEmail: ApproverEmail, Comments: Comments } = req.data;
        var errorFlag = false;
        // Fetching CR data
        var attachmentData = [];
        var errorLogData = [];
        const [crData] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: requestGuid });
        const crLineItems = await SELECT.from("COSTROLL_CRLINEITEMS").where({ Parent_ID: requestGuid });
        const currentDate = new Date();
        const day = String(currentDate.getDate()).padStart(2, '0');
        const month = String(currentDate.getMonth() + 1).padStart(2, '0');
        const CPyear = String(currentDate.getFullYear());
        const MMDD = month + day;
        const YYYYMMDD = CPyear + month + day;
        //Get Next Number for CP
        const nextCR = await DB.getNextNumberForCR(YYYYMMDD);
        const runningCRNumber = String(nextCR).padStart(2, '0');
        // Final CR Number

        var crNum = `CR${MMDD}${runningCRNumber}`;
        var crDate = YYYYMMDD;
        var crMax = runningCRNumber;
        var statusId;
        if (status == "CKACTION") {
            let inputDate = crData.CPDATE;
            inputDate = inputDate.toString();
            let year = parseInt(inputDate.substring(0, 4), 10);
            let monthDate = parseInt(inputDate.substring(4, 6), 10) - 1; // Month is zero-indexed
            let dayDate = parseInt(inputDate.substring(6, 8), 10);
            // Create a Date object
            let dateObject = new Date(Date.UTC(year, monthDate, dayDate));
            // Add one day
            dateObject.setUTCDate(dateObject.getUTCDate());
            // Convert to milliseconds since Unix epoch
            let epochMillis = dateObject.getTime();
            // Format as \/Date(epochMillis)\/
            let formattedCrDate = `\\/Date(${epochMillis})\\/`;
            if (crData.REQUESTTYPE == 'Cost Roll') {

                // Call CP Run till Analysis for Cost Roll Type Request 
                var CPAnalysisResults = await CommonUtilities.RunAnalysis(req, crNum, crData.COMPANYCODE, crData.PLANTCODE, crData.VARIANT, crLineItems, crData.TICKETID);
                if (!CPAnalysisResults.ErrorLogToCK40N.length == 0) {
                    //filter the unique values
                    let log = CPAnalysisResults.ErrorLogToCK40N.filter((obj, index, self) =>
                        index === self.findIndex((t) => (
                            t.partNumber === obj.partNumber && t.Msgty === obj.Msgty && t.Message === obj.Message
                        ))
                    );
                    //update the error log in COSTROLL_CRERRORLOG table
                    await INSERT.into("COSTROLL_CRERRORLOG").entries(log);
                    errorLogData = log;
                    if (CPAnalysisResults.ErrorLogToCK40N.some(item => item.Msgty === 'E')) {
                        statusId = 8; //Closed Error
                        errorFlag = true;
                        status = "error";
                    }
                    else {
                        statusId = 4; //Pending Review
                        status = "warning";
                    }
                }
                // }
                status = "green";
                statusId = 4
                await UPDATE.entity("COSTROLL_COSTROLLMAIN").with({ CRNUM: crNum, CRDATE: crDate, CRMAX: crMax, requestStatus_ID: statusId }).where({ ID: requestGuid });
                //update the analysis result in COSTROLL_CRANALYSISRESULT table
                await INSERT.into("COSTROLL_CRANALYSISRESULT").entries(CPAnalysisResults.CK40NHeaderToAnalysis);
                attachmentData = CPAnalysisResults.CK40NHeaderToAnalysis;
            }
            else if (crData.REQUESTTYPE == 'Cost Deletion') {
                // Call Cost Deletion
                var CostDeletion = await CommonUtilities.CostDeletion(req, crNum, crData.COMPANYCODE, crData.PLANTCODE, crLineItems, crData.SUBREQTYPE, formattedCrDate);
                // status = "green";//Replaced below with a new status priceDelete Sharique 14/01/2024
                status = "priceDelete";
                if (!CostDeletion.ErrorLogToCostEstDel.length == 0) {
                    errorLogData = CostDeletion.ErrorLogToCostEstDel;
                }
                if (!CostDeletion.CostEstimatinDelToLog.length == 0) {
                    attachmentData = CostDeletion.CostEstimatinDelToLog;
                }

            }
        } else if (status == "RELEASEACTION") {
            let inputDate = crData.CRDATE;
            inputDate = inputDate.toString();
            let year = parseInt(inputDate.substring(0, 4), 10);
            let monthDate = parseInt(inputDate.substring(4, 6), 10) - 1; // Month is zero-indexed
            let dayDate = parseInt(inputDate.substring(6, 8), 10);
            // Create a Date object
            let dateObject = new Date(Date.UTC(year, monthDate, dayDate));
            // Add one day
            dateObject.setUTCDate(dateObject.getUTCDate());
            // Convert to milliseconds since Unix epoch
            let epochMillis = dateObject.getTime();
            // Format as \/Date(epochMillis)\/
            let formattedCrDate = `\\/Date(${epochMillis})\\/`;
            if (crData.REQUESTTYPE == 'Cost Roll' && crData.SUBREQTYPE == 'Standard Cost') {

                // Call CP Run till Analysis for Cost Roll Type Request 
                var CPAnalysisResults = await CommonUtilities.RunReleaseOrUpdate(req, crData.CRNUM, crData.COMPANYCODE, crData.PLANTCODE, crData.VARIANT, crLineItems, crData.TICKETID, formattedCrDate);
                if (!CPAnalysisResults.ErrorLog.length == 0) {
                    if (CPAnalysisResults.ErrorLog.some(item => item.Msgty === 'E')) {
                        errorFlag = true;
                    }
                    attachmentData = CPAnalysisResults.ErrorLog;
                }
                // }
                status = "release";

            }

        } else if (status == "PRICEUPDATE") {
            let inputDate = crData.CRDATE;
            inputDate = inputDate.toString();
            // Parse the input date
            let year = parseInt(inputDate.substring(0, 4), 10);
            let monthDate = parseInt(inputDate.substring(4, 6), 10) - 1; // Month is zero-indexed
            let dayDate = parseInt(inputDate.substring(6, 8), 10);
            // Create a Date object
            let dateObject = new Date(Date.UTC(year, monthDate, dayDate));
            // Add one day
            dateObject.setUTCDate(dateObject.getUTCDate());
            // Convert to milliseconds since Unix epoch
            let epochMillis = dateObject.getTime();
            // Format as \/Date(epochMillis)\/
            let formattedCrDate = `\\/Date(${epochMillis})\\/`;
            if (crData.REQUESTTYPE == 'Cost Roll' && crData.SUBREQTYPE == 'Quoted Cost (PP2)') {

                // Call CP Run till Analysis for Cost Roll Type Request 
                var CPAnalysisResults = await CommonUtilities.RunReleaseOrUpdate(req, crData.CRNUM, crData.COMPANYCODE, crData.PLANTCODE, crData.VARIANT, crLineItems, crData.TICKETID, formattedCrDate);
                if (!CPAnalysisResults.ErrorLog.length == 0) {
                    if (CPAnalysisResults.ErrorLog.some(item => item.Msgty === 'E')) {
                        errorFlag = true;
                    }
                    attachmentData = CPAnalysisResults.ErrorLog;
                }
                status = "priceUpdate";
            }

        } else if (status == "DELETE") {
            let inputDate = crData.CPDATE;
            inputDate = inputDate.toString();
            // Parse the input date
            let year = parseInt(inputDate.substring(0, 4), 10);
            let monthDate = parseInt(inputDate.substring(4, 6), 10) - 1; // Month is zero-indexed
            let dayDate = parseInt(inputDate.substring(6, 8), 10);
            // Create a Date object
            let dateObject = new Date(Date.UTC(year, monthDate, dayDate));
            // Add one day
            dateObject.setUTCDate(dateObject.getUTCDate());
            // Convert to milliseconds since Unix epoch
            let epochMillis = dateObject.getTime();
            // Format as \/Date(epochMillis)\/
            let formattedCrDate = `\\/Date(${epochMillis})\\/`;


            // Call CP Estimate Delete
            // var CPEstDeletion = await CommonUtilities.DeleteEstimation(req, crData.CPNUM, crData.COMPANYCODE, crData.PLANTCODE, crData.VARIANT, crLineItems, crData.TICKETID, formattedCrDate);
            var CPDeletion = await CommonUtilities.DeleteCPRun(req, crData.CPNUM, formattedCrDate);


        }
        if (status != "DELETE") {
            // Mapping Template
            const templateMapping = {
                "green": "greenNotificationFinance",// "reveted to original template Shariqueali 13/01/2024"
                "warning": "warningNotificationFinance",
                "priceDelete": "priceDeletionNotification",//mapped to a new template for cost deletion
                "error": "errorNotificationFinance",
                "release": "releaseNotification",
                "priceUpdate": "priceUpdateNotification"
            };

            const template = templateMapping[status] || "Unknown Template";
            // const crAnalysis = await SELECT.from("COSTROLL.CRANALYSISRESULT").where({ ticketID: crData.TICKETID });
            // const crAnalysisMessage = await SELECT.from("COSTROLL.CRERRORLOG").where({ ticketID: crData.TICKETID });
            const subjectMapping = {
                // Start of change Sharique 03/01/2024
                // Commented the subjectline in case of cost deletion for green
                // Reverted the subjectline to original 
                "green": "Action Required: Cost Roll " + `${crData.TICKETID}` + " pending your execution",
                "priceDelete": "Action Required: Cost deletion " + `${crData.TICKETID}` + " were executed",
                // End of Change Sharique 03/01/2024
                "warning": "Action Required: Cost Roll " + `${crData.TICKETID}` + " pending your execution",
                "error": "Action Required: Cost Roll " + `${crData.TICKETID}` + " contains error",
                "release": "Action Required: Marking&Release of cost roll  " + `${crData.TICKETID}` + " were executed",
                "priceUpdate": "Action Required: Price update of cost roll " + `${crData.TICKETID}` + " were executed"
            };
            const subject = subjectMapping[status] || "Action Required";

            const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site/digitalapps";
            console.log("apiUrl", process.env.apiUrl);
            console.log("apiUrl", apiUrl);
            // var url = apiUrl + "#cwa-RequestCreate?TicketID=" + cwaData.CWANAME;
            var url = apiUrl + "#CostRollDashboard-manage?TicketID=" + crData.TICKETID;
            var inBoxUrl = apiUrl + "#WorkflowTask-DisplayMyInbox?sap-ui-app-id-hint=saas_approuter_com.sap.spa.inbox"
            // const subject = "CWA ACTION REQUIRED: " + ApproverLevel + " Approval " + cwaData.CWANAME;
            const from = process.env.FromEmail || "CostRoll_workflow_dev@jabil.com";
            const data = {
                requestorName: crData.CREATEDBY,
                approverName: ApproverEmail,
                requestNumber: crData.TICKETID,
                comment: Comments,
                approvalRejectLink: url,
                inBoxUrl: inBoxUrl,
                level: ApproverLevel,
                dashboardUrl: url,
                tableData: errorLogData

            };
            //get Template
            // const templateName = template; // Template file name (without extension)
            // const template = await getTemplate(templateName);
            var ccEmails = crData.CREATEDBY;
            const excelData = await generateExcel(attachmentData);
            const attachment = excelData.excelFile;
            const attchmentName = crData.TICKETID + "ANALYSIS.xlsx";
            const responseMailStatus = await mailUtil.sendEmail(template, data, from, ApproverEmail, subject, ccEmails, req, attachment, attchmentName);
        }
        if (!errorFlag) {
            return { "CostRollID": requestGuid, "MessageType": "S", "Message": "Success" }
        } else {
            return { "CostRollID": requestGuid, "MessageType": "E", "Message": "Error" }
        }

    });

    this.on('DownloadDocument', async (req) => {
        let { dmsDocumentId } = req.data.dmsDocumentID;
        let destination_details = await CommonUtilities.getDestinations("DMS");
        const connJwtToken = await _fetchJwtToken(destination_details?.tokenServiceURL, destination_details?.clientId, destination_details?.clientSecret)
        let result = await _downloadFile(destination_details.URL, connJwtToken, SDM_REPOSTITOR_ID, dmsDocumentId);
        return result;
    });
    this.on('CreateMediaFile', async (req) => {
        // debugger;
        req.data = req.data.FileData;
        var base64Data = req.data.content.split(',')[1];
        // const url = process.env.url || "https://jabilcfdev.authentication.us10.hana.ondemand.com";
        const url = process.env.dmsURL || "https://jabilcfdev.authentication.us10.hana.ondemand.com";
        const clientid = process.env.clientId || "sb-cd24e476-ae80-4d27-8676-ec24c3273bf8!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
        const clientSecret = process.env.clientSecret || "BH2LRs/p0MzdSHNmxMxgMNhOFeQ=";
        var repositoryId = "CR_REQUEST_REPO";
        const connJwtToken = await fetchJwtToken(url, clientid, clientSecret);
        var folderID = req.data.folderID;
        var base64 = base64Data;
        var fileType = req.data.mediaType;
        var eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
        var fileName = req.data.fileName;
        try {
            console.log("JWT in CreateMediaFile", connJwtToken);
            console.log("FolderID in CreateMediaFile", folderID);
            req.data.fileID = await CommonUtilities.createFile(eURL, connJwtToken, repositoryId, folderID, fileName, fileType, base64);
        } catch (error) {
            //do nothing for now => to be handled
        }
        // debugger;
        return { "folderID": req.data.fileID };

    });


}
const createDMSFolder = async function (repoId) {
    const folderName = repoId;
    // const url = process.env.url || "https://jabilcfdev.authentication.us10.hana.ondemand.com";
    const url = process.env.dmsURL || "https://jabilcfdev.authentication.us10.hana.ondemand.com";
    const clientid = process.env.clientId || "sb-cd24e476-ae80-4d27-8676-ec24c3273bf8!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
    const clientSecret = process.env.clientSecret || "BH2LRs/p0MzdSHNmxMxgMNhOFeQ=";
    // var clientid = sdmCredentials.uaa.clientid;
    // var clientSecret = sdmCredentials.uaa.clientsecret;
    const repositoryId = "CR_REQUEST_REPO";
    const connJwtToken = await fetchJwtToken(url, clientid, clientSecret);
    const eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
    const folderId = await createFolder(eURL, connJwtToken, repositoryId, folderName);
    return { 'folderID': folderId };
}
const fetchJwtToken = async function (oauthUrl, oauthClient, oauthSecret) {
    // This is to get the oauth token , which is used to create the folder ID
    const tokenUrl = oauthUrl + '/oauth/token?grant_type=client_credentials&response_type=token'
    const config = {
        headers: {
            Authorization: "Basic " + Buffer.from(oauthClient + ':' + oauthSecret).toString("base64")
        }
    };
    let token = await axios.get(tokenUrl, config)
        .then(response => {
            return response.data.access_token;
        })
        .catch(error => {
            return error;
        });

    return token;

}

// This is to create a folder in the repository for every new book that is getting created.
// So basically we create a new folder for every book id and user can add their respective attachments in that folder.
const createFolder = async function (sdmUrl, jwtToken, repositoryId, forlderName) {
    const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root"
    const formData = new FormData();
    // formData.append("objectId", repositoryId);
    formData.append("cmisaction", "createFolder");
    formData.append("propertyId[0]", "cmis:name");
    formData.append("propertyValue[0]", forlderName);
    formData.append("propertyId[1]", "cmis:objectTypeId");
    formData.append("propertyValue[1]", "cmis:folder");
    formData.append("succinct", 'true');


    let headers = formData.getHeaders();
    headers["Authorization"] = "Bearer " + jwtToken;

    const config = {
        headers: headers
    };

    let folderID = await axios.post(folderCreateURL, formData, config)
        .then(response => {
            return response.data.succinctProperties["cmis:objectId"];
        })
        .catch(error => {
            return error;
        });

    return folderID;

}
const createFile = async function (sdmUrl, jwtToken, repositoryId, rootFolderId, forlderName, fileName, base64) {
    return new Promise((resolve, reject) => {
        const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/c27e0192-9271-4339-8980-5684eaf64d04";
        // const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/";

        // var sDecodedFile = window.atob(base64);
        var decodedPdfContent = atob(base64);
        var byteArray = new Uint8Array(decodedPdfContent.length);
        var t = Buffer.from(decodedPdfContent);
        for (var i = 0; i < decodedPdfContent.length; i++) {
            byteArray[i] = decodedPdfContent.charCodeAt(i);
        }
        var blob = new Blob([byteArray.buffer], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        });
        // var buf = blob;
        //blob = Buffer.from(blob);
        var buf = Buffer.from(base64, "base64");
        const formData = new FormData();
        // formData.append("objectId", forlderName);
        formData.append("cmisaction", "createDocument");
        formData.append("propertyId[0]", "cmis:name");
        formData.append("propertyValue[0]", fileName);
        formData.append("propertyId[1]", "cmis:objectTypeId");
        formData.append("propertyValue[1]", "cmis:document");
        // formData.append("datafile", buf);
        formData.append('content', buf, {
            contentType: blob,
            filename: fileName
        })
        // formData.append("filename", fileName);
        // formData.append("succinct", "true");
        formData.append("_charset", "UTF-8");
        formData.append("includeAllowableActions", "true");
        const headers = {
            ...formData.getHeaders(),
            'Content-Length': formData.getLengthSync()
        }
        // let headers = formData.getHeaders();
        headers["Authorization"] = "Bearer " + jwtToken;
        // headers["cmis:contentStreamMimeType"] = "application/pdf";

        const config = {
            headers: headers
        }

        axios.post(folderCreateURL, formData, config)
            .then(response => {
                resolve(response.data.properties['cmis:objectId'].value)
            })
            .catch(error => {
                reject(error)
            })


    })
}
const deleteFile = async function (sdmUrl, jwtToken, repositoryId, forlderName, docId) {
    const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/" + forlderName
    const formData = new FormData();
    // formData.append("objectId", repositoryId);
    formData.append("cmisaction", "delete");
    formData.append("objectId", docId);


    let headers = formData.getHeaders();
    headers["Authorization"] = "Bearer " + jwtToken;

    const config = {
        headers: headers
    };

    let response = await axios.post(folderCreateURL, formData, config)
        .then(response => {
            return response;
        })
        .catch(error => {
            return error;
        });

    return response;

}
const generateExcel = async function (excelData) {
    const dataArray = [
        { Name: 'John Doe', Age: 30, Email: 'john@example.com' },
        { Name: 'Jane Smith', Age: 25, Email: 'jane@example.com' }
    ];

    // Create a new workbook and add a worksheet
    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.json_to_sheet(excelData);

    // Append the worksheet to the workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Data');

    // Write the workbook to a buffer
    const excelBuffer = XLSX.write(workbook, {
        bookType: 'xlsx',
        type: 'buffer'
    });

    // Convert the buffer to Base64
    const base64Excel = excelBuffer.toString('base64');

    // Return the Base64 string
    return { excelFile: base64Excel };
}

// Create Workflow History Log
async function updateWFLog(wfResults, req, Level, status) {
    var guid = crypto.randomUUID();
    var payload = {
        ID: guid, //new id
        Parent_ID: req.data.ID,//requestGuid,//cost roll id
        WorkflowID: wfResults.id,//req.data.WFID, //wf instance id
        ApproverEmail: '',//ApproverEmail, 
        ApproverLevel: Level,//ApproverLevel,//2
        ApproverName: req.user.id,//latestTask.processor,//ApproverEmail,//ApproverName,
        Status: status,
        Comments: '',
        createdAt: new Date().toISOString(),
        createdBy: req.user.id,
        modifiedAt: new Date().toISOString(),
        modifiedBy: req.user.id,
    }
    await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);
}
async function sendEmail(requestGuid, status, req, errorlog, Analysis) {

    const statusMapping = {
        "green": "greenNotification",
        "warning": "warningNotification",
        "error": "errorNotification"
    };
    const templateMapping = {
        "green": "greenNotification",
        "warning": "warningNotification",
        "error": "errorNotification",
        "financeDelNotif": "financeDelNotification",
    };

    const statusText = statusMapping[status] || "Unknown Status";
    const template = templateMapping[status] || "Unknown Template";

    // Fetching CWA data
    const [crData] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: requestGuid });
    const subjectMapping = {
        "green": "Action Required: Cost Roll " + `${req.data.ticketID}` + " pending your execution",
        "warning": "Action Required: Cost Roll " + `${req.data.ticketID}` + " pending your execution",
        "error": "Action Required: Cost Roll " + `${req.data.ticketID}` + " was rejected as it contains error",
        "financeDelNotif": "Action Required: Cost Deletion " + `${req.data.ticketID}`,
    };
    const subject = subjectMapping[status] || "Action Required";

    const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site/digitalapps";
    console.log("apiUrl", process.env.apiUrl);
    console.log("apiUrl", apiUrl);
    // var url = apiUrl + "#cwa-RequestCreate?TicketID=" + cwaData.CWANAME;
    var url = apiUrl + "#CostRollDashboard-manage?TicketID=" + req.data.ticketID;
    var inBoxUrl = apiUrl + "#WorkflowTask-DisplayMyInbox?sap-ui-app-id-hint=saas_approuter_com.sap.spa.inbox"
    // const subject = "CWA ACTION REQUIRED: " + ApproverLevel + " Approval " + cwaData.CWANAME;
    const from = process.env.FromEmail || "CostRoll_workflow_dev@jabil.com";
    const namePart = req.user.id.split('@')[0];
    const [firstName, lastName] = namePart.split('_');
    const fullName = `${firstName} ${lastName}`;
    const data = {
        requestorName: fullName,
        approverName: fullName,
        requestNumber: req.data.ticketID,
        comment: "",
        approvalRejectLink: url,
        inBoxUrl: inBoxUrl,
        level: "Requester",
        dashboardUrl: url,
        tableData: errorlog
    };
    //get Template
    // const templateName = template; // Template file name (without extension)
    // const template = await getTemplate(templateName);
    var ccEmails = "";
    const excelData = await generateExcel(Analysis);
    var attachment = excelData.excelFile;
    var attchmentName = req.data.ticketID + "ANALYSIS.xlsx";
    if (status == "financeDelNotif") {
        attachment = "";
        attchmentName = "";
    }
    const responseMailStatus = await mailUtil.sendEmail(template, data, from, req.user.id, subject, ccEmails, req, attachment, attchmentName);
    if (responseMailStatus == "Success") {
        return { "CWARequestID": requestGuid, "MessageType": "S", "Message": "Success" }
    } else {
        return { "CWARequestID": requestGuid, "MessageType": "E", "Message": "Error" }
    }

};

async function sendEmailForward(requestGuid, status, req) {

    // const statusMapping = {
    //     "green": "greenNotification",
    //     "warning": "warningNotification",
    //     "error": "errorNotification"
    // };
    const templateMapping = {
        // "green": "greenNotification",
        // "warning": "warningNotification",
        // "error": "errorNotification",
        // "financeDelNotif": "financeDelNotification",
        "Finance": "financeNotification",// Added for forward Sharique 17/01/2024
        "Approver": "approverNotification",// Added for forward Sharique 17/01/2024
        "Requester": "approverNotification"// Added for forward Sharique 17/01/2024
        // "forward": "financeNotification"// Added for forward Sharique 17/01/2024
    };

    // const statusText = statusMapping[status] || "Unknown Status";
    const template = templateMapping[status] || "Unknown Template";

    // Fetching CWA data
    const [crData] = await SELECT.from("COSTROLL_COSTROLLMAIN").where({ ID: requestGuid });
    // if (req.data.ticketID == undefined || req.data.ticketID == '') {
    req.data.ticketID = crData.TICKETID;//Added Sharique 17/01/2024 sometimes req.data.ticketID is blank  
    // }
    let errorlog = await SELECT.from("COSTROLL_CRERRORLOG").where({ TICKETID: req.data.ticketID });  // need this code to send the log 
    console.log("after error log data", errorlog);
    if (crData.REQUESTTYPE === 'Cost Deletion') {
        subjectline = 'Action Required: Cost Deletion ';
    } else {
        subjectline = 'Action Required: Cost Roll ';
    }


    const subjectMapping = {
        // "green": "Action Required: Cost Roll " + `${req.data.ticketID}` + " pending your execution",
        // "warning": "Action Required: Cost Roll " + `${req.data.ticketID}` + " pending your execution",
        // "error": "Action Required: Cost Roll " + `${req.data.ticketID}` + " was rejected as it contains error",
        // "financeDelNotif": "Action Required: Cost Deletion " + `${req.data.ticketID}`,


        // "forward": "Action Required: Cost Roll " + `${req.data.ticketID}`
        "Finance": `${subjectline}` + `${req.data.ticketID}`,
        "Approver": `${subjectline}` + `${req.data.ticketID}`,
        "Requester": `${subjectline}` + `${req.data.ticketID}`,

    };
    const subject = subjectMapping[status] || "Action Required";

    const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site/digitalapps";
    // var url = apiUrl + "#cwa-RequestCreate?TicketID=" + cwaData.CWANAME;
    var url = apiUrl + "#CostRollDashboard-manage?TicketID=" + req.data.ticketID;
    var inBoxUrl = apiUrl + "#WorkflowTask-DisplayMyInbox?sap-ui-app-id-hint=saas_approuter_com.sap.spa.inbox"
    // const subject = "CWA ACTION REQUIRED: " + ApproverLevel + " Approval " + cwaData.CWANAME;
    const from = process.env.FromEmail || "CostRoll_workflow_dev@jabil.com";
    // start of change Sharique 17/01/2024
    // Pass the id of the person to whom th item has been forwarded instead of user id
    console.log("Userid Split", req.user.id.split('@')[0]);
    let to;
    // if (status == 'forward') {
    to = req.data.Email.split('@')[0];
    // }
    // else{
    //  to = req.user.id.split('@')[0];
    console.log("Toemail pre", to);
    // }
    // End of change Sharique 17/01/2024
    console.log("Toemail post", to);
    const namePart = to;//req.user.id.split('@')[0];


    const [firstName, lastName] = namePart.split('_');
    const fullName = `${firstName} ${lastName}`;
    const data = {
        requestorName: fullName,
        approverName: fullName,
        requestNumber: req.data.ticketID,
        comment: "",
        approvalRejectLink: url,
        inBoxUrl: inBoxUrl,
        level: "Requester",
        dashboardUrl: url,
        tableData: errorlog
    };
    //get Template
    // const templateName = template; // Template file name (without extension)
    // const template = await getTemplate(templateName);
    var ccEmails = "";
    // // start of change Sharique 17/01/2024
    // // stop excel generation in case of forward
    // if (status == 'forward') {

    // } else {

    // start of change Sharique 17/01/2024
    // stop excel generation in case of forward
    // if (status != 'forward') {
    //     const excelData = await generateExcel(Analysis);
    //     var attachment = excelData.excelFile;
    //     var attchmentName = req.data.ticketID + "ANALYSIS.xlsx";
    // }
    // End of change Sharique 17/01/2024
    // if (status == "financeDelNotif") {
    // if (status == "financeDelNotif" || status == "forward") { //Added an additional cond for forward Sharique Ali
    attachment = "";
    attchmentName = "";
    // }
    // start of change Sharique 17/01/2024
    // Commented the below line to replace  req.user.id by "to"   
    // const responseMailStatus = await mailUtil.sendEmail(template, data, from, req.user.id, subject, ccEmails, req, attachment, attchmentName);
    const responseMailStatus = await mailUtil.sendEmail(template, data, from, req.data.Email, subject, ccEmails, req, attachment, attchmentName);
    console.log("mail status", responseMailStatus);
    // start of change Sharique 17/01/2024
    if (responseMailStatus == "Success") {
        return { "CWARequestID": requestGuid, "MessageType": "S", "Message": "Success" }
    } else {
        return { "CWARequestID": requestGuid, "MessageType": "E", "Message": "Error" }
    }

};

async function getUser(req, emailToMatch) {


    // Convert the string to an array
    const emailArray = req.APPGP1.split(",");



    // Find the email with exact match and same case
    const matchedEmail = emailArray.find(email => email.toLowerCase() === emailToMatch.toLowerCase());
    if (matchedEmail == undefined || '') {
        // Convert the string to an array
        const emailArray = req.APPGP2.split(",");
        const matchedEmail = emailArray.find(email => email.toLowerCase() === emailToMatch.toLowerCase());
        return matchedEmail;
    }
    return matchedEmail;
    // Store the result in the same case as in the original array
    console.log(matchedEmail);

};

async function findMatchingEmail1(searchEmail) {
    // Convert the searchEmail to lowercase 
    const searchEmailLower = searchEmail.toLowerCase();
    var UserRoleDetails = await SELECT
        .one
        .from('COSTROLL_USERMANAGEMENT')
        .where([{
            func: 'tolower',
            args: [{ ref: ['USER'] }],
        },
            '=',
        { val: `${searchEmailLower}` },
        ]);


    // If a match is found, return the first matched email
    if (UserRoleDetails.USER) {
        return UserRoleDetails.USER;
    }
    // }
    return null; //If no match found
}

async function get_verified_emails(approverEmails, req) {
    const xsuaa = await cds.connect.to("crXsuaa");

    // Extract and create an array of comma separated emails
    const emails = approverEmails.split(',').map(email => email.trim());

    // Function to fetch and verify each email
    const fetchUserEmail = async (email) => {
        const userFilterUrl = `/Users?filter=email eq '${email}'`;
        const response = await xsuaa.tx(req).get(userFilterUrl);

        if (response.resources.length > 0) {
            const userWithMatchingOrigin = response.resources.find(user =>
                user.origin.includes("okta")
            );

            if (userWithMatchingOrigin) {
                return userWithMatchingOrigin.emails[0].value;
            }
        }
        return null; // Return null if user not found
    };

    const verifiedEmails = await Promise.all(emails.map(email => fetchUserEmail(email)));

    // Filter out null values (users not found)
    // return verifiedEmails.filter(email => email !== null);
    return verifiedEmails.filter(email => email !== null).join(',');
}



// async function findMatchingEmail1(data, searchEmail) {
//     // Convert the searchEmail to lowercase 
//     const searchEmailLower = searchEmail.toLowerCase();
//     var UserRoleDetails = await SELECT
//                     .one
//                     .from('COSTROLL_USERMANAGEMENT')
//                     .where([{
//                         func: 'tolower',
//                         args: [{ ref: ['USER'] }],
//                     },
//                         '=',
//                     { val: `${searchEmailLower}` },
//                     ]);
    

//         // If a match is found, return the first matched email
//         if (UserRoleDetails.USER) {
//             return UserRoleDetails.USER;
//         }
//     // }
//     return null; //If no match found
// }
