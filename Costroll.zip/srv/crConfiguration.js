const cds = require('@sap/cds');
const RolesUtil = require('./Utils/roles').RolesUtil;

module.exports = function () {
    // IT Reader Role Check 
    this.before('CREATE', ['MasterData', 'HeaderValues'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    this.before('UPDATE', ['MasterData', 'HeaderValues'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "target": "ReadOnly",
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    this.before('DELETE', ['MasterData', 'HeaderValues'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "target": "ReadOnly",
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });
}