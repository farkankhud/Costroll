const cds = require('@sap/cds');
const DB = require("./Utils/dbOperations").DB;
const ApprovalMatrixHandler = require('./Utils/cr-ApproverMatrix').ApprovalMatrixHandler;
const CommonUtilities = require("./Utils/common").CommonUtilities;
const RolesUtil = require('./Utils/roles').RolesUtil;

module.exports = function () {
    // IT Reader Role Check A
    this.before('CREATE', ['ApproverMatrix', 'ManageRoutes'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    this.before('UPDATE', ['ApproverMatrix', 'ManageRoutes'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "target": "ReadOnly",
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });

    this.before('DELETE', ['ApproverMatrix', 'ManageRoutes'], async req => {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "target": "ReadOnly",
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }
    });
    // this.on('getValues', ApprovalMatrixHandler._getValues);
    // Create Route ID and update in the table Manage Route
    this.before('CREATE', 'ManageRoutes', async req => {
        const plant = req.data.plantCode;
        const CoCd = req.data.companyCode;
        //Get running number for Route ID
        req.data.Number = await DB.getNextNumberRoute(plant);
        const runningNumber = String(req.data.Number).padStart(3, '0');

        // Final Route Number
        req.data.routeID = `RID${CoCd}${plant}${runningNumber}`;
    });

    this.on('getEmails', ApprovalMatrixHandler._getEmails)
}