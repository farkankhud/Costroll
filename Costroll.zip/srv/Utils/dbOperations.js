
class DBOperations {

    // Validate Route ID's Profit Centers/Mat Type with fetchMaterial's Profit Centers/Mat Type
    static async CompareProfitCenter(fetchMaterial, req) {
        const db = await cds.connect.to("db");
        const CoCd = req.data.companyCode;
        const PlCd = req.data.plantCode;
        var NotOKParts = [];
        // const aSenderStats = await SELECT
        //     .from('COSTROLL_APPROVERMATRIX')
        //     .columns('PROFITCENTER', 'MATERIALTYPE', 'ROUTEID')
        //     .where({ COMPANYCODE: CoCd, PLANTCODE: PlCd })
        //     .groupBy('PROFITCENTER', 'MATERIALTYPE', 'ROUTEID');

        //Apply loop in fetch material to get the route ID each line item
        var FMlength = fetchMaterial.length;
        var ProCtr = String;
        var MatType = String; //'%FERT%'
        var ApprovalMatrixRoute = String;
        var compareRoute = Boolean;
        for (var i = 0; i < FMlength; i++) {
            ProCtr = fetchMaterial[i].profitCenter;
            MatType = `%${fetchMaterial[i].materialType}%`;
            ApprovalMatrixRoute = await db.run(`SELECT "ROUTEID" FROM "COSTROLL_APPROVERMATRIX" WHERE COMPANYCODE = '${CoCd}' AND PLANTCODE = '${PlCd}' AND PROFITCENTER = '${ProCtr}' AND MATERIALTYPE like '${MatType}'`)
                .then((result) => {
                    if (result[0].ROUTEID) {
                        return result[0].ROUTEID;
                    } else {
                        return "";
                    }      
                })
                .catch((error) => {
                    return error;
                });
            fetchMaterial[i].routeID = ApprovalMatrixRoute
            if (fetchMaterial[0].routeID == ApprovalMatrixRoute) { //comapre the new route with the first route
                // compareRoute = true; // same route ID
            }
            else{
                compareRoute = false; // No same route ID
            }

        }


        // var ApprovalMatrix = await SELECT
        //     .one
        //     .columns('ROUTEID')
        //     .from('COSTROLL_APPROVERMATRIX')
        //     .where({ COMPANYCODE: CoCd, PLANTCODE: PlCd, PROFITCENTER: pc, MATERIALTYPE: mt });

        // var ApprovalMatrix = await db.run(`SELECT ("ROUTEID") FROM "COSTROLL_APPROVERMATRIX" WHERE COMPANYCODE = '${CoCd}' AND PLANTCODE = '${PlCd}' AND PROFITCENTER = '${pc}' AND MATERIALTYPE like '${mt}'`)
        //     .then((result) => {
        //         if (result.length == 0) {
        //             return 1;
        //         } else if (result.length != 0) return 1;
        //     })
        //     .catch((error) => {
        //         return error;
        //     });

        // if (ApprovalMatrix) {
        //     var ProfitCenters = ApprovalMatrix.PROFITCENTER;
        //     var MatTypes = ApprovalMatrix.MATERIALTYPE;

        //     if (fetchMaterial) {
        //         var length = fetchMaterial.length;

        //         for (var i = 0; i < length; i++) {
        //             if (!(ProfitCenters.includes(fetchMaterial[i].profitCenter) && MatTypes.includes(fetchMaterial[i].materialType))) {
        //                 fetchMaterial[i].Message = "Route ID is not having the Profict Center and/or Material Type"
        //                 fetchMaterial[i].Messagetype = "E"
        //                 NotOKParts.push(fetchMaterial[i].partNumber);
        //                 console.log("Profict Center" + " " + fetchMaterial[i].profitCenter + " " + "is not present in Route ID" + " " + ROUTEID);
        //             }
        //         }
        //     }
        // }
        return compareRoute;
    }

    // Get the Draft Data from Table
    static async getDatafromDB(ID) {
        const db = await cds.connect.to("db");
        var CostRoll = await SELECT
            .one
            .from('COSTROLL_COSTROLLMAIN')
            .where({ ID: ID });
        if (CostRoll) {
            var crLineItems = await SELECT
                .distinct
                .from('COSTROLL_CRLINEITEMS')
                .where({ PARENT_ID: ID })
                .columns(['PARTNUMBER']);
            CostRoll.crLineItems = [];
            CostRoll.crLineItems = crLineItems;
            return CostRoll;
        }
    }

    //Get Next Number for Ticket
    static async getNextNumberForTicket(Plant, Fiscal) {
        const db = await cds.connect.to("db");
        var nextNumber = await db.run(`SELECT MAX("NUMBER") FROM "COSTROLL_COSTROLLMAIN" WHERE PLANTCODE = '${Plant}' AND FISCAL = '${Fiscal}'`)
            .then((result) => {
                if (result.length == 0 || result[0]["MAX(NUMBER)"] == null) {
                    return 1;
                } else if (result.length != 0) return result[0]["MAX(NUMBER)"] + 1;
            })
            .catch((error) => {
                return error;
            });
        return nextNumber;
    }

    //Get Next Number for Route ID
    static async getNextNumberRoute(Plant) {
        const db = await cds.connect.to("db");
        var nextNumber = await db.run(`SELECT MAX("NUMBER") FROM "COSTROLL_MANAGEROUTES" WHERE PLANTCODE = '${Plant}'`)
            .then((result) => {
                if (result.length == 0 || result[0]["MAX(NUMBER)"] == null) {
                    return 1;
                } else if (result.length != 0) return result[0]["MAX(NUMBER)"] + 1;
            })
            .catch((error) => {
                return error;
            });
        return nextNumber;
    }

    //Check if there is an existing draft with same name
    static async ExistingDraft(Requestor) {
        var drafts = [];
        var UserDrafts = await SELECT
            .distinct
            .from('COSTROLL_COSTROLLMAIN')
            .where({ CREATEDBY: Requestor })
            .columns(['DRAFTNAME']);

        if (UserDrafts) {
            var filteredDrafts = UserDrafts.filter(function (el) {
                return el.DRAFTNAME != '';
            });
            drafts = filteredDrafts.map((item) => {
                return item.DRAFTNAME
            });
        }
        return drafts;
    }

    //Get Next Number for CP
    static async getNextNumberForCP(Day) {
        const db = await cds.connect.to("db");
        var nextCPNumber = await db.run(`SELECT MAX("CPMAX") FROM "COSTROLL_COSTROLLMAIN" WHERE CPDATE = '${Day}'`)
            .then((result) => {
                if (result[0]["MAX(CPMAX)"] == null) {
                    return 1;
                } else if (result.length != 0) return result[0]["MAX(CPMAX)"] + 1;
            })
            .catch((error) => {
                return error;
            });
        return nextCPNumber;

    }

    //Get Next Number for CR
    static async getNextNumberForCR(Day) {
        const db = await cds.connect.to("db");
        var nextCPNumber = await db.run(`SELECT MAX("CRMAX") FROM "COSTROLL_COSTROLLMAIN" WHERE CRDATE = '${Day}'`)
            .then((result) => {
                if (result[0]["MAX(CRMAX)"] == null) {
                    return 1;
                } else if (result.length != 0) return result[0]["MAX(CRMAX)"] + 1;
            })
            .catch((error) => {
                return error;
            });
        return nextCPNumber;

    }

    // //Get running number for Route ID
    // static async getNextNumberForRoute() {
    //     const db = await cds.connect.to("db");
    //     var nextNumber = await db.run(`SELECT MAX("NUMBER") FROM "COSTROLL_MANAGEROUTES"`)
    //         .then((result) => {
    //             if (result.length == 0 || result[0]["MAX(NUMBER)"] == null) {
    //                 return 1;
    //             } else if (result.length != 0) return result[0]["MAX(NUMBER)"] + 1;
    //         })
    //         .catch((error) => {
    //             return error;
    //         });
    //     return nextNumber;
    // }

}

module.exports = {
    DB: DBOperations
}