const cds = require('@sap/cds');
const DB = require('./dbOperations').DB;
const RoleUtility = require("./roles").RolesUtil;

class CostRollRequest {
    //Get the User Role, Assigned Plants and Company Codes and Drafts save by user in Request Form
    static async _getUserRoles(data) {
        // var RouteID = await SELECT
        //     .distinct
        //     .from('COSTROLL_APPROVERMATRIX')
        //     .columns(['ROUTEID']);

        // var filteredRouteID = RouteID.filter(function (el) {
        //     return el.ROUTEID != '';
        // });
        // let RouteIDs = filteredRouteID.map((item) => {
        //     return item.ROUTEID
        // });

        var userId = data.user.id.toLowerCase();
        // var allowedRoleNames = new Set();

        var UserRoleDetails = await SELECT
            .one
            .from('COSTROLL_USERMANAGEMENT')
            .where([{
                func: 'tolower',
                args: [{ ref: ['USER'] }],
            },
                '=',
            { val: `${userId}` },
            ]);

        // allRoles.forEach(item => {
        //     if (item.ROLENAME) {
        //         item.ROLENAME.split(',').forEach(role => allowedRoleNames.add(role.trim()));
        //     }
        // });

        // var UserRoleDetails = await SELECT
        //     .one
        //     .from('COSTROLL_USERMANAGEMENT')
        //     .where({ USER: data.user.id });

        // var UserDrafts = await SELECT
        //     .distinct
        //     .from('COSTROLL_COSTROLLMAIN')
        //     .where({ CREATEDBY: data.user.id })
        //     .columns(['DRAFTNAME']);

        var UserDrafts = await SELECT
            .distinct
            .from('COSTROLL_COSTROLLMAIN')
            .where([{
                func: 'tolower',
                args: [{ ref: ['CREATEDBY'] }],
            },
                '=',
            { val: `${userId}` },
            ])
            .columns(['DRAFTNAME']);;

        var filteredDrafts = UserDrafts.filter(function (el) {
            return el.DRAFTNAME != '';
        });
        let drafts = filteredDrafts.map((item) => {
            return item.DRAFTNAME
        });

        if (!UserRoleDetails) return;

        return await CostRollRequest._getAssignments(UserRoleDetails, drafts);      //RouteIDs, 
    }

    static async _getUserCoCd(req) {
        var user = req.user.id;
        var userCoCd = await CostRollRequest.getCompanyCode(user);
        return userCoCd.join(",");
    }
   
    //Get the Assigned Plants and Company Codes, Variants in Request Form
    static async _getAssignments(UserRoleDetails, drafts) {                         //RouteIDs, 
        var allowedCompanyCodes = UserRoleDetails.COMPANYCODE.split(",").map(item => item.trim());
        var allowedPlantCodes = UserRoleDetails.PLANTCODE.split(",").map(item => item.trim());

        //Cases
        if (allowedCompanyCodes.includes('*')) {
            //return all Company Codes from MasterData
            var CompanyCodeData = await SELECT
                .distinct
                .columns(['COMPANYCODE'])
                .from('COSTROLL_HEADERVALUES');
            if (!CompanyCodeData) return;
        } else {
            var CompanyCodeData = await SELECT
                .distinct
                .columns(['COMPANYCODE'])
                .from('COSTROLL_HEADERVALUES')
                .where({ COMPANYCODE: allowedCompanyCodes });
            if (!CompanyCodeData) return;
        }


        if (allowedPlantCodes.includes('*')) {
            //return all PLANTCODE from MasterData
            var PlantData = await SELECT
                .distinct
                .columns(['COMPANYCODE', 'PLANTCODE', 'COSTINGTYPE', 'COSTVARIANT'])
                .from('COSTROLL_HEADERVALUES')
                .where({ COMPANYCODE: CompanyCodeData.map((CoCd) => CoCd.COMPANYCODE) });
            if (!PlantData) return;
        } else {
            var PlantData = await SELECT
                .distinct
                .columns(['COMPANYCODE', 'PLANTCODE', 'COSTINGTYPE', 'COSTVARIANT'])
                .from('COSTROLL_HEADERVALUES')
                .where({ PLANTCODE: allowedPlantCodes })
                .and({ COMPANYCODE: CompanyCodeData.map((CoCd) => CoCd.COMPANYCODE) });
            if (!PlantData) return;
        }


        return {
            // "RouteID": RouteIDs,
            "RoleName": UserRoleDetails.ROLENAME,
            "AllData": PlantData,
            "Draft": drafts,
        };
    }
    // Check if user is an Admin
    static async _checkAdmin(data) {
        var userId = data.user.id.toLowerCase();
        // var userRoles = data.Role_Name;
        var UserRoleDetails = await SELECT
            .one
            .from('COSTROLL_USERMANAGEMENT')
            .where([{
                func: 'tolower',
                args: [{ ref: ['USER'] }],
            },
                '=',
            { val: `${userId}` },
            ]);

        if (UserRoleDetails.ROLENAME == 'Admin') {
            // return true
            return {
                "Admin": true,
                "UserID": data.user.id,
            }
        }
        else {
            // return false
            return {
                "Admin": false,
                "UserID": data.user.id,
            }
        }
    }
    // Check the assigned company code to the user
    static async getCompanyCode(user) {
        var userId = user.toLowerCase();

        var UserRoleDetails = await SELECT
            .one
            .from('COSTROLL_USERMANAGEMENT')
            .where([{
                func: 'tolower',
                args: [{ ref: ['USER'] }],
            },
                '=',
            { val: `${userId}` },
            ]);

        if (!UserRoleDetails) return;

        var allowedCompanyCodes = UserRoleDetails.COMPANYCODE.split(",").map(item => item.trim());
        return allowedCompanyCodes;
        // //Cases
        // if (allowedCompanyCodes.includes('*')) {
        //     //return all Company Codes from MasterData
        //     var CompanyCodeData = await SELECT
        //         .distinct
        //         .columns(['COMPANYCODE'])
        //         .from('COSTROLL_HEADERVALUES');
        //     if (!CompanyCodeData) return;
        // } else {
        //     var CompanyCodeData = await SELECT
        //         .distinct
        //         .columns(['COMPANYCODE'])
        //         .from('COSTROLL_HEADERVALUES')
        //         .where({ COMPANYCODE: allowedCompanyCodes });
        //     if (!CompanyCodeData) return;
        // }
        // return {
        //     "CoCd": CompanyCodeData
        // };

    }

    static async notRequestor(req) {
        var TicketOwner = await SELECT
            .columns(['CREATEDBY'])
            .from('COSTROLL_COSTROLLMAIN')
            .where({ ID: req.data.ID });

        if (TicketOwner == data.user.id) {
            return false;
        }
        else { return true; }

    }
}

module.exports = {
    CostRollRequestHandler: CostRollRequest
}