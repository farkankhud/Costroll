const cds = require('@sap/cds');
const DB = require('./dbOperations').DB;

class UserManage {
    static async _getAllData(req) {
        var CompanyCodes = await SELECT
            .distinct
            .columns(['COMPANYCODE'])   //
            .from('COSTROLL_HEADERVALUES');
        if (!CompanyCodes) return;

        var Plants = await SELECT
            .distinct
            .columns(['COMPANYCODE', 'PLANTCODE'])
            .from('COSTROLL_HEADERVALUES')
            .where({ COMPANYCODE: CompanyCodes.map((CompanyCodes) => CompanyCodes.COMPANYCODE) });
        if (!Plants) return;


        return {
            "COMPANYCODE": CompanyCodes,
            "PLANT": Plants
        };
    }

    static async _validateMandatory(req) {

        if (!req.data.user) {
            let err = `User can not be blank`
            req.error({
                code: '501',
                message: err,
                status: 418
            });
            return;
        }
        if (!req.data.roleName) {
            let err = `Role Name can not be blank`
            req.error({
                code: '501',
                message: err,
                status: 418
            });
            return;
        }
        else {
            if (req.data.roleName == 'Admin' || req.data.roleName == 'Finance' ||
                req.data.roleName == 'Business Unit Approver' || req.data.roleName == 'Purchasing Lead Approver'
                || req.data.roleName == 'Requestor' || req.data.roleName == 'IT Reader') { }
            else {
                let err = `Please select the correct Role Name`
                req.error({
                    code: '501',
                    message: err,
                    status: 418
                });
                return;
            }
        }

    }
}

module.exports = {
    UserManageHandler: UserManage
}