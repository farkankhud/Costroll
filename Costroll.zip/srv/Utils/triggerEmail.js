const fs = require('fs');
const path = require('path');
class mailUtility {

    //Read all roles of the user
    static async sendEmail(templateName, data, from, to, subject, cc, req, attachment, attachmentName) {
        // const templateName = 'workflowNotification'; // Template file name (without extension)
        console.log("Send Email Called", templateName);
        var environment = process.env.Environment || ' ';
        if (environment !== ' ') {
            environment = "(" + environment + ") ";
        }
        const template = await getTemplate(templateName);
        const emailContent = await fillTemplate(template, data);
        var mailPayload =
        {
            "mail_details": {
                "from": from,
                "to": to,
                "subject": environment + subject,
                "cc": cc,
                "bcc": "",
                "body": emailContent,
                "attachment": attachment,
                "attachmentName": attachmentName
            }
        }
        const mailService = await cds.connect.to('CPI');
        try {
            await mailService.tx(req).post('/send/mail/bp', mailPayload);
            return "Success";
        } catch (error) {
            console.log("Error during email sending");
            console.log(error);
            return "Error";
        }



    }

}


module.exports = {
    mailUtility: mailUtility
}

async function getTemplate(templateName) {
    const templatePath = path.resolve(__dirname, '../templates', `${templateName}.html`);
    return new Promise((resolve, reject) => {
        fs.readFile(templatePath, 'utf8', (err, data) => {
            if (err) return reject(err);
            resolve(data);
        });
    });
}
// async function fillTemplate(template, data) {
//     return template.replace(/{{(.*?)}}/g, (_, key) => data[key.trim()] || '');
// }
// async function fillTemplate(template, data) {

//     var filledTemplate;
//     // Check if tableData is an array and if it's populated
//     if (Array.isArray(data.tableData) && data.tableData.length > 0) {
//         let tableRows = data.tableData.map(row => {
//             // Create table rows dynamically for each item
//             return `<tr>
//                 <td style="padding: 8px;">${row.TICKETID}</td>
//                 <td style="padding: 8px;">${row.COSTINGRUN}</td>
//                 <td style="padding: 8px;">${row.PLANT}</td>
//                 <td style="padding: 8px;">${row.PARTNUMBER}</td>
//                 <td style="padding: 8px;">${row.MASGTY}</td>
//                 <td style="padding: 8px;">${row.MESSAGE}</td>
//             </tr>`;
//         }).join('');  // Join the array of rows into a single string

//         // Replace the {{tableRows}} placeholder with the generated rows
//         filledTemplate = template.replace('{{tableRows}}', tableRows);
//     } else {
//         // If no data for tableRows, replace it with an empty table or a placeholder
//         filledTemplate = template.replace('{{tableRows}}', '<tr><td colspan="3">No data available.</td></tr>');
//     }
//     // Replace simple placeholders like {{requestNumber}}, {{inBoxUrl}}, etc.
//         filledTemplate = filledTemplate.replace(/{{(.*?)}}/g, (_, key) => {
//         key = key.trim();  // Clean up the key
//         // Check if the key exists in the data and return its value, or empty string
//         return data[key] !== undefined ? data[key] : '';
//     });

//     return filledTemplate;
// }
async function fillTemplate(template, data) {
    var filledTemplate;

    // Helper function to get the value of a field regardless of case
    const getFieldValue = (row, fieldName) => {
        // Normalize all keys to lowercase for comparison
        const normalizedFieldName = fieldName.toLowerCase();
        const field = Object.keys(row).find(key => key.toLowerCase() === normalizedFieldName);
        return field ? row[field] : ''; // Return value if field exists, otherwise empty string
    };

    // Check if tableData is an array and if it's populated
    if (Array.isArray(data.tableData) && data.tableData.length > 0) {
        let tableRows = data.tableData.map(row => {
            // Create table rows dynamically for each item
            return `<tr>
                <td style="padding: 8px;">${getFieldValue(row, 'TICKETID')}</td>
                <td style="padding: 8px;">${getFieldValue(row, 'COSTINGRUN')}</td>
                <td style="padding: 8px;">${getFieldValue(row, 'PLANT')}</td>
                <td style="padding: 8px;">${getFieldValue(row, 'PARTNUMBER')}</td>
                <td style="padding: 8px;">${getFieldValue(row, 'MSGTY')}</td>
                <td style="padding: 8px;">${getFieldValue(row, 'MESSAGE')}</td>
            </tr>`;
        }).join(''); // Join the array of rows into a single string

        // Replace the {{tableRows}} placeholder with the generated rows
        filledTemplate = template.replace('{{tableRows}}', tableRows);
    } else {
        // If no data for tableRows, replace it with an empty table or a placeholder
        filledTemplate = template.replace('{{tableRows}}', '<tr><td colspan="6">No data available.</td></tr>');
    }

    // Replace simple placeholders like {{requestNumber}}, {{inBoxUrl}}, etc.
    filledTemplate = filledTemplate.replace(/{{(.*?)}}/g, (_, key) => {
        key = key.trim(); // Clean up the key
        // Check if the key exists in the data and return its value, or empty string
        return data[key] !== undefined ? data[key] : '';
    });

    return filledTemplate;
}
