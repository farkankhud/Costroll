class RoleUtility {

    //Read all roles of the user
    static async getAllRoles(userId) {
        userId = userId.toLowerCase();
        var allowedRoleNames = new Set();

        var allRoles = await SELECT
            .from('COSTROLL_USERMANAGEMENT')
            .where([{
                func: 'tolower',
                args: [{ ref: ['USER'] }],
            },
                '=',
            { val: `${userId}` },
            ]);

        allRoles.forEach(item => {
            if (item.ROLENAME) {
                item.ROLENAME.split(',').forEach(role => allowedRoleNames.add(role.trim()));
            }
        });
        return {
            RoleNames: allowedRoleNames.has('*') ? ['*'] : Array.from(allowedRoleNames)
        }
    }

    // static async isValidForUser(userId, CoCd) {

    // }

    static async userIsReaderOnly(req) {
        console.log("Inside userIsReaderOnly Method");
        var userId = req.user.id;
        //get all BTP roles assigned to user
        var userRoles = await this.getAllRoles(userId);
        console.log("User Roles: " + userRoles.RoleNames);

        //get which role to check from env file
        var readerRole = process.env.ITReaderBTPRole
        console.log("Reader Role " + userRoles.RoleNames.includes(readerRole));
        //check if userRoles have readerRole
        if (userRoles.RoleNames.includes(readerRole)) return true;
        else return false;
    }
}

module.exports = {
    RolesUtil: RoleUtility
}