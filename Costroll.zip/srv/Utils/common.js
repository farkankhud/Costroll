const axios = require("axios");
const cds = require("@sap/cds/libx/_runtime/cds");
const FormData = require('form-data');
const { mailUtility } = require("./triggerEmail");
const crypto = require('crypto');

class CommonUtilities {
    //Fetch Material Details from S4 as per Part Numbers in Req Form
    static async fetchMaterialDetails(req) {
        var onPremS4API = await cds.connect.to("ZOD_FICO_COSTROLL_BTP_SRV");

        var validationResults = [];
        let payload = {};
        payload.FormHeaderToItem = [];
        var AlreadyFetched = [];
        var Item = {};
        payload.costingRun = "X";
        payload.Plant = req.data.plantCode;
        payload.Type = req.data.requestType;
        payload.Subtype = req.data.subReqType;
        let Items = [];
        Items = req.data.Items;
        var length = Items.length;

        for (var i = 0; i < length; i++) {
            if (!Items[i].flagFetchDetails) {
                Item.costingRun = "X"
                Item.partNumber = Items[i].partNumber;
                Item.ID = Items[i].ID;
                Item.expectedCost = Items[i].expectedCost ? Items[i].expectedCost.toString() : undefined
                payload.FormHeaderToItem.push(Item);
                Item = {};
            }
            else {
                AlreadyFetched.push(Items[i]);
            }
        }

        await onPremS4API.tx(req).post("/FormHeaderSet", payload)
            .then(function (results) {
                validationResults = results.FormHeaderToItem;
                return results;
            }.bind(this), function (error) {
                debugger;
                validationResults.push(error);
                return error;
            })
        //);
        return validationResults.concat(AlreadyFetched);
    }
    // Call CR Run Marking and Release after Analysis
    static async RunReleaseOrUpdate(req, crNum, companyCode, plantCode, variant, crLineItems, ticketID, crDate) {
        var onPremS4API = await cds.connect.to("ZOD_FICO_COSTROLL_BTP_SRV");
        var backendError = Boolean;
        var CostRun = [];
        let payload = {};
        payload.CK40FinNHeaderToItem = [];
        payload.ErrorLog = [];
        // payload.CK40NHeaderToAnalysis = [];
        var Item = {};
        payload.ticketID = ticketID;
        payload.costingRun = crNum;
        payload.companyCode = companyCode;
        payload.costingRunDate = crDate;
        payload.Variant = variant;
        payload.costingVariant = variant;
        payload.costingVersion = "01";
        payload.COArea = "0010";

        // payload.Plant = req.data.plantCode;
        // payload.Type = req.data.requestType;
        // payload.Subtype = req.data.subReqType;

        let Items = [];
        Items = crLineItems;
        var length = Items.length;

        for (var i = 0; i < length; i++) {
            Item.costingRun = crNum;
            Item.partNumber = Items[i].PARTNUMBER || Items[i].partNumber;
            Item.Plant = plantCode;
            Item.companyCode = companyCode;
            payload.CK40FinNHeaderToItem.push(Item);
            Item = {};

            // ErrorLog.costingRun = cpNum
            // payload.ErrorLogToCK40N.push(ErrorLog);
            // ErrorLog = {};
        }

        await onPremS4API.tx(req).post("/CK40N_HDR_FinanceSet", payload)
            .then(function (results) {
                CostRun = results;              //.CK40NHeaderToItem
                return results;
            }.bind(this), function (error) {
                CostRun.push(error);
                // backendError = true;
                return error;
            })
        //);
        return CostRun;
    }

    // Call CP Run till Analysis 1st time for Requestor and 2nd Time for Finance
    static async RunAnalysis(req, cpNum, companyCode, plantCode, variant, crLineItems, ticketID) {
        var onPremS4API = await cds.connect.to("ZOD_FICO_COSTROLL_BTP_SRV");
        var backendError = Boolean;
        var CostRun = [];
        let payload = {};
        payload.CK40NHeaderToItem = [];
        payload.ErrorLogToCK40N = [];
        payload.CK40NHeaderToAnalysis = [];
        var Item = {};
        payload.ticketID = ticketID;
        payload.costingRun = cpNum;
        payload.companyCode = companyCode;
        payload.costingRunDate = null;
        payload.Variant = variant;
        payload.costingVariant = variant;
        payload.costingVersion = "01";
        payload.COArea = "0010";

        // payload.Plant = req.data.plantCode;
        // payload.Type = req.data.requestType;
        // payload.Subtype = req.data.subReqType;

        let Items = [];
        Items = crLineItems;
        var length = Items.length;

        for (var i = 0; i < length; i++) {
            Item.costingRun = cpNum;
            Item.partNumber = Items[i].PARTNUMBER || Items[i].partNumber;
            Item.Plant = plantCode;
            Item.companyCode = companyCode;
            payload.CK40NHeaderToItem.push(Item);
            Item = {};

            // ErrorLog.costingRun = cpNum
            // payload.ErrorLogToCK40N.push(ErrorLog);
            // ErrorLog = {};
        }

        await onPremS4API.tx(req).post("/CK40N_HDRSet", payload)
            .then(function (results) {
                CostRun = results;              //.CK40NHeaderToItem
                return results;
            }.bind(this), function (error) {
                CostRun.push(error);
                // backendError = true;
                return error;
            })
        //);
        return CostRun;
    }
    // Delete Estimation
    static async DeleteEstimation(req, cpNum, companyCode, plantCode, variant, crLineItems, ticketID) {
        var onPremS4API = await cds.connect.to("ZOD_FICO_COSTROLL_BTP_SRV");
        var backendError = Boolean;
        var CostRun = [];
        let payload = {};
        payload.CostEstimatinoDelete = [];
        payload.ErrorLogToCostEstDel = [];
        var Item = {};
        payload.costingRun = cpNum;
        payload.Subtype = "Current Std Cost Estimates";
        let Items = [];
        Items = crLineItems;
        var length = Items.length;

        for (var i = 0; i < length; i++) {
            Item.costingRun = cpNum;
            Item.partNumber = Items[i].PARTNUMBER || Items[i].partNumber;
            Item.Plant = plantCode;
            Item.CompCode = companyCode;
            payload.CostEstimatinoDelete.push(Item);
            Item = {};

            // ErrorLog.costingRun = cpNum
            // payload.ErrorLogToCK40N.push(ErrorLog);
            // ErrorLog = {};
        }

        await onPremS4API.tx(req).post("/DELETE_COST_ESTSet", payload)
            .then(function (results) {
                CostRun = results;              //.CK40NHeaderToItem
                return results;
            }.bind(this), function (error) {
                CostRun.push(error);
                // backendError = true;
                return error;
            })
        //);
        return CostRun;
    }

    // Delete CP Run 
    static async DeleteCPRun(req, cpNum, crDate) {
        var onPremS4API = await cds.connect.to("ZOD_FICO_COSTROLL_BTP_SRV");
        var CostRun = [];
        let payload = {};
        payload.costingRun = cpNum;
        payload.costingRunDate = crDate;
        payload.costingVersion = "01";

        await onPremS4API.tx(req).post("/Delete_Costing_RunSet", payload)
            .then(function (results) {
                CostRun = results;              //.CK40NHeaderToItem
                return results;
            }.bind(this), function (error) {
                CostRun.push(error);
                // backendError = true;
                return error;
            })
        //);
        return CostRun;
    }

    // Call CKR1 for Cost Deletion
    static async CostDeletion(req, cpNum, companyCode, plantCode, crLineItems, subReqType, crDate) {
        var onPremS4API = await cds.connect.to("ZOD_FICO_COSTROLL_BTP_SRV");
        var backendError = Boolean;
        var DeletionResult = [];
        let payload = {};
        payload.CostEstimatinoDelete = [];
        payload.ErrorLogToCostEstDel = [];
        payload.CostEstimatinDelToLog = [];
        var Item = {};
        // payload.ticketID = ticketID;
        payload.costingRun = cpNum;
        // payload.companyCode = companyCode;
        // payload.costingRunDate = crDate;
        // payload.Variant = variant;
        // payload.costingVariant = variant;
        // payload.costingVersion = "01";
        // payload.COArea = "0010";
        // payload.Plant = req.data.plantCode;
        // payload.Type = req.data.requestType;
        payload.Subtype = subReqType;

        let Items = [];
        Items = crLineItems;
        var length = Items.length;

        for (var i = 0; i < length; i++) {
            Item.costingRun = cpNum;
            Item.partNumber = Items[i].PARTNUMBER || Items[i].partNumber;
            Item.Plant = plantCode;
            Item.CompCode = companyCode;
            payload.CostEstimatinoDelete.push(Item);
            Item = {};

        }

        await onPremS4API.tx(req).post("/DELETE_COST_EST_HDRSet", payload)
            .then(function (results) {
                DeletionResult = results;              //.CK40NHeaderToItem
                return results;
            }.bind(this), function (error) {
                DeletionResult.push(error);
                // backendError = true;
                return error;
            })
        //);
        return DeletionResult;
    }

    // static async RunAnalysiswithDraft(req, cpNum) {
    //     var onPremS4API = await cds.connect.to("ZOD_FICO_COSTROLL_BTP_SRV");

    //     var CostRun = [];
    //     let payload = {};
    //     payload.CK40NHeaderToItem = [];
    //     payload.ErrorLogToCK40N = [];
    //     var Item = {};
    //     var ErrorLog = {};
    //     payload.costingRun = cpNum;
    //     // payload.costingRunDate = cpNum;
    //     payload.companyCode = req.data.companyCode;
    //     payload.Variant = req.data.variant;
    //     payload.costingVariant = req.data.variant;
    //     payload.costingVersion = "01";
    //     payload.COArea = "0010";


    //     // payload.Plant = req.data.plantCode;
    //     // payload.Type = req.data.requestType;
    //     // payload.Subtype = req.data.subReqType;
    //     let Items = [];
    //     Items = req.data.Items;
    //     var length = Items.length;

    //     for (var i = 0; i < length; i++) {
    //         Item.costingRun = cpNum
    //         Item.partNumber = Items[i].partNumber;
    //         Item.Plant = req.data.companyCode;
    //         Item.companyCode = req.data.companyCode;
    //         payload.CK40NHeaderToItem.push(Item);
    //         Item = {};

    //         // ErrorLog.costingRun = cpNum
    //         // payload.ErrorLogToCK40N.push(ErrorLog);
    //         // ErrorLog = {};
    //     }

    //     await onPremS4API.tx(req).post("/CK40N_HDRSet", payload)
    //         .then(function (results) {
    //             CostRun = results;              //.CK40NHeaderToItem
    //             return results;
    //         }.bind(this), function (error) {
    //             debugger;
    //             CostRun.push(error);
    //             return error;
    //         })
    //     //);
    //     return CostRun;
    // }

    static async callWorkFlow(data, req, invoker, wfPayload) {
        var wfService = await cds.connect.to("Workflow");
        const response = await wfService.tx(req).post("/workflow-instances", wfPayload);
        console.log('Divye:' + response.toString());
        return response;
    }

    static async createFile(sdmUrl, jwtToken, repositoryId, rootFolderId, fileName, fileType, base64) {
        return new Promise((resolve, reject) => {
            console.log("JWT in CreateFile", jwtToken);
            const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/" + rootFolderId;
            console.log("FolderUrl", folderCreateURL);
            var decodedPdfContent = atob(base64);
            var byteArray = new Uint8Array(decodedPdfContent.length);
            var t = Buffer.from(decodedPdfContent);
            for (var i = 0; i < decodedPdfContent.length; i++) {
                byteArray[i] = decodedPdfContent.charCodeAt(i);
            }
            var blob = new Blob([byteArray.buffer], {
                type: fileType
            });
            var buf = Buffer.from(base64, "base64");
            const formData = new FormData();
            // formData.append("objectId", forlderName);
            formData.append("cmisaction", "createDocument");
            formData.append("propertyId[0]", "cmis:name");
            formData.append("propertyValue[0]", fileName);
            formData.append("propertyId[1]", "cmis:objectTypeId");
            formData.append("propertyValue[1]", "cmis:document");
            // formData.append("datafile", buf);
            formData.append('content', buf, {
                contentType: blob,
                filename: fileName
            })
            // formData.append("filename", fileName);
            // formData.append("succinct", "true");
            formData.append("_charset", "UTF-8");
            formData.append("includeAllowableActions", "true");
            const headers = {
                ...formData.getHeaders(),
                'Content-Length': formData.getLengthSync()
            }
            // let headers = formData.getHeaders();
            headers["Authorization"] = "Bearer " + jwtToken;
            // headers["cmis:contentStreamMimeType"] = "application/pdf";

            const config = {
                headers: headers
            }
            console.log("config", config.headers);
            axios.post(folderCreateURL, formData, config)
                .then(response => {
                    console.log("Response received");
                    console.log("Folderid", response.data.properties['cmis:objectId'].value);
                    resolve(response.data.properties['cmis:objectId'].value)
                })
                .catch(error => {
                    reject(error)
                    console.log(error.message);
                })


        })
    }

    static async processCostRollForReminder(costroll, req) {
        var mailReceivers = [];
        var wfLogs = await SELECT
            .from("COSTROLL_CRWFHISTORY")
            .where({ Parent_ID: costroll.ID })
            .orderBy("CREATEDAT");
        // check with whom the ticket is currently pending
        if (costroll.REQUESTSTATUS_ID == 2) {            //pending with requestor
            mailReceivers.push(costroll.CREATEDBY);
            console.log("Sending Reminder Email for Cost Role to Requestor " + costroll.TICKETID);
            this.sendReminderMail(costroll, mailReceivers, req, "greenNotification");
            //append wfhistory table
            var payload = {
                ID: crypto.randomUUID(),
                Parent_ID: costroll.ID,
                WorkflowID: wfLogs[0].WORKFLOWID,
                createdAt: new Date().toISOString(),
                createdBy: 'System',
                Status: "Reminded"
            }
            await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);
        }
        else if (costroll.REQUESTSTATUS_ID == 3) {        //'Pending with Approver'
            var Approvers = await SELECT.one.from("COSTROLL_MANAGEROUTES")
                .where({ ROUTEID: costroll.ROUTEID })
                .columns('APPGP1');
            if (!Approvers) {
                console.log("Apprvers Email IDs missing in Approval Matrix Table for " + costroll.ROUTEID);
            }
            else {
                // mailReceivers = Approvers[0].APPGP1.split(",").map(s => s.trim());

                console.log("Sending Reminder Email for Cost Role to Approver " + Approvers.APPGP1);
                this.sendReminderMail(costroll, Approvers.APPGP1, req, "approverNotification");
                //append wfhistory table
                var payload = {
                    ID: crypto.randomUUID(),
                    Parent_ID: costroll.ID,
                    WorkflowID: wfLogs[0].WORKFLOWID,
                    createdAt: new Date().toISOString(),
                    createdBy: 'System',
                    Status: "Reminded"
                }
                await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);
            }
        }
        else if (costroll.REQUESTSTATUS_ID == 4) {        //'Pending with Finance'
            var Finance = await SELECT.one.from("COSTROLL_MANAGEROUTES")
                .where({ ROUTEID: costroll.ROUTEID })
                .columns('APPGP2');
            if (!Finance) {
                console.log("Finance Email IDs missing in Approval Matrix Table for " + costroll.ROUTEID);
            }
            else
                // mailReceivers = Finance[0].APPGP2.split(",").map(s => s.trim());

                console.log("Sending Reminder Email for Cost Role to Finance 4" + Finance.APPGP2);
            this.sendReminderMail(costroll, Finance.APPGP2, req, "financeNotification");
            //append wfhistory table
            var payload = {
                ID: crypto.randomUUID(),
                Parent_ID: costroll.ID,
                WorkflowID: wfLogs[0].WORKFLOWID,
                createdAt: new Date().toISOString(),
                createdBy: 'System',
                Status: "Reminded"
            }
            await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);
        }
        else if (costroll.REQUESTSTATUS_ID == 11) {        //'Pending with Finance Del'
            var Finance = await SELECT.one.from("COSTROLL_MANAGEROUTES")
                .where({ ROUTEID: costroll.ROUTEID })
                .columns('APPGP2');
            if (!Finance) {
                console.log("Finance Email IDs missing in Approval Matrix Table for " + costroll.ROUTEID);
            }
            else
                // mailReceivers = Finance[0].APPGP2.split(",").map(s => s.trim());

                console.log("Sending Reminder Email for Cost Role to Finance " + Finance);
            this.sendReminderMail(costroll, Finance.APPGP2, req, "financeNotification");
            //append wfhistory table
            var payload = {
                ID: crypto.randomUUID(),
                Parent_ID: costroll.ID,
                WorkflowID: wfLogs[0].WORKFLOWID,
                createdAt: new Date().toISOString(),
                createdBy: 'System',
                Status: "Reminded"
            }
            await INSERT.into("COSTROLL_CRWFHISTORY").entries(payload);
        }

    }

    static async sendReminderMail(costroll, mailReceivers, req, templateName) {
        var from = process.env.FromEmail || "CostRoll_workflow_dev@jabil.com";
        var to = mailReceivers;
        console.log("Sending reminder email to " + to);
        var cc = costroll.CREATEDBY;
        const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site/digitalapps";
        console.log("apiUrl", process.env.apiUrl);
        console.log("apiUrl", apiUrl);
        var url = apiUrl + "#CostRollDashboard-manage?TicketID=" + costroll.TICKETID;
        var inBoxUrl = apiUrl + "#WorkflowTask-DisplayMyInbox?sap-ui-app-id-hint=saas_approuter_com.sap.spa.inbox"
        var errorlog = [];
        const mailData = {
            requestorName: costroll.CREATEDBY,
            approverName: mailReceivers,
            requestNumber: costroll.TICKETID,
            comment: "",
            approvalRejectLink: "",
            inBoxUrl: inBoxUrl,
            level: "Requester",
            dashboardUrl: url,
            tableData: errorlog
        };

        var subject = "[REMINDER] COSTROLL ACTION REQUIRED " + costroll.TICKETID;
        console.log("Sending reminder email for ", mailData.requestorName);
        try {
            
            var responseMailStatus = await mailUtility.sendEmail(templateName, mailData, from, to, subject, cc, req, "", "");
            console.log("Reminder email SENT");
        } catch (error) {
            console.log("Error while Sending reminder email ");
            console.log(error);
        }
    }

}

module.exports = {
    CommonUtilities: CommonUtilities
}