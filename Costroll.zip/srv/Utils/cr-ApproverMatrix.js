const cds = require('@sap/cds');
const DB = require('./dbOperations').DB;

class ApprovalMatrix {

    static async _getEmails(data) {
        var UserEmails = await SELECT
            .distinct
            .columns(['USER', 'ROLENAME'])
            .from('COSTROLL_USERMANAGEMENT')
            .where({ ROLENAME: 'Business Unit Approver' })
            .or({ ROLENAME: 'Purchasing Lead Approver' })
            .or({ ROLENAME: 'Finance' });

        return {
            "EmailIDs": UserEmails
        }
    }

    // static async _getValues(data) {
    //     var RouteID = await SELECT
    //         .distinct
    //         .from('COSTROLL_MANAGEROUTES')
    //         .columns(['ROUTEID']);
    //     if (!RouteID) return;

    //     var CompanyCodeData = await SELECT
    //         .distinct
    //         .columns(['COMPANYCODE'])
    //         .from('COSTROLL_MASTERDATA');
    //     if (!CompanyCodeData) return;

    //     var PlantData = await SELECT
    //         .distinct
    //         .columns(['COMPANYCODE', 'PLANTCODE'])
    //         .from('COSTROLL_VARIANTS')
    //         .where({ COMPANYCODE: CompanyCodeData.map((CoCd) => CoCd.COMPANYCODE) });
    //     if (!PlantData) return;

    //     var PlantData = await SELECT
    //         .distinct
    //         .columns(['COMPANYCODE', 'PLANTCODE'])
    //         .from('COSTROLL_VARIANTS')
    //         .where({ COMPANYCODE: CompanyCodeData.map((CoCd) => CoCd.COMPANYCODE) });
    //     if (!PlantData) return;

    //     return await CostRollRequest._getAssignments(RouteID, UserRoleDetails, drafts);
    // }
}

module.exports = {
    ApprovalMatrixHandler: ApprovalMatrix
}