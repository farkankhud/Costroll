const cds = require('@sap/cds');
const { CommonUtilities } = require("./Utils/common");

module.exports = function () {
    this.on('reminderEmail', async function (req) {
        console.log("Reminder Email action called");
        var pendingCostRoll = await SELECT.from("COSTROLL_COSTROLLMAIN")
            .where({ REQUESTSTATUS_ID: 2 })
            .or({ REQUESTSTATUS_ID: 3 })
            .or({ REQUESTSTATUS_ID: 4 })
            .or({ REQUESTSTATUS_ID: 11 });
        console.log("Total pending Tickets found = " + pendingCostRoll.length);
        for (let index = 0; index < pendingCostRoll.length; index++) {
            const element = pendingCostRoll[index];
            console.log("Processing CostRoll: " + element.TICKETID);
            await CommonUtilities.processCostRollForReminder(element, req);
        }
    });
}