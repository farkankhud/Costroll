sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
  ],
  function (BaseController, Filter, FilterOperator, JSONModel,formatter) {
    "use strict";

    return BaseController.extend("com.jabil.crworkflowuimodule.controller.App", {
      formatter: formatter,
      onInit: async function () {
        // this.loadCostDetailsFragment();
        this.oModel = this.getOwnerComponent().getModel("v4Model");
        this.getView().setModel(this.getCostRollModelObject(), "CostRollModel");
        // var aFilters = [],
        //   aTicketId = [];
        // aTicketId.push(new sap.ui.model.Filter("ticketID", sap.ui.model.FilterOperator.EQ, "MY01_FY25_0000027"));
        // aFilters.push(new sap.ui.model.Filter(aTicketId, false));

        // await this.readCostDetails(aFilters).then(async function (aContexts) {
        //   if (aContexts.length > 0) {
        //     this.getView().getModel("CostRollModel").setProperty("/", aContexts[0].getObject());

        //   } else {
        //     this.performReset();
        //     MessageBox.error(this.i18n.getText("noEntryFound"));
        //   }

        //   //   this.hideBusyIndicator();
        // }.bind(this)).catch(function (oError) {
        //   //   this.resetCostRollModel();
        //   //   this.hideBusyIndicator();
        // }.bind(this));
      },
      onAfterRendering: async function () {
        let ticketId = this.getOwnerComponent().getModel('context').getProperty('/CRTicketID');
        var aFilters = [],
          aTicketId = [];
        aTicketId.push(new sap.ui.model.Filter("ticketID", sap.ui.model.FilterOperator.EQ, ticketId));
        aFilters.push(new sap.ui.model.Filter(aTicketId, false));

        await this.readCostDetails(aFilters).then(async function (aContexts) {
          if (aContexts.length > 0) {
            this.getView().getModel("CostRollModel").setProperty("/", aContexts[0].getObject());

          } else {
            this.performReset();
            MessageBox.error(this.i18n.getText("noEntryFound"));
          }

          //   this.hideBusyIndicator();
        }.bind(this)).catch(function (oError) {
          //   this.resetCostRollModel();
          //   this.hideBusyIndicator();
        }.bind(this));
      },
      getCostRollModelObject: function () {
        var oCostRollModel = new JSONModel({
          "ID": "",
          "ticketID": "",
          "draftName": "",
          "companyCode": "",
          "plantCode": "",
          "requestType": "",
          "subReqType": "",
          "variant": "",
          "remark": "",
          "revImpact": 0.0,
          "workcell": "",
          "reason": "",
          "sequence": "",
          "crLineItems": [],
          "crAttachments": []
        });
        return oCostRollModel;
      },
    //   isFieldVisible: function (sTypeName) {
    //     const sRequestType = this.getView().getModel("CostRollModel").getProperty("/requestType");
    //     return sTypeName === "1" && sRequestType === "Cost Roll";
    // },
    
      readCostDetails: function (aFilters) {
        return new Promise(async function (resolve, reject) {
          var oList = this.oModel.bindList("/Header", null, null, aFilters, {
            $expand: "crLineItems,crAttachments($expand=FileID)"
          });

          // READ request
          await oList.requestContexts().then(function (aContexts) {
            resolve(aContexts);
          }.bind(this))
            .catch(function (oError) {
              reject(oError);
            });
        }.bind(this));
      },
      handlePress: function (oEvent) {
        var sFolderId = this.getView().getModel("CostRollModel").getProperty("/ID");
        var sURL = ""; var win = "";
        // var sDocumentId = this.getView().getModel("ViewModel").getProperty(oEvent.getSource().getBindingContext("ViewModel").getPath()).DmsDocumentId;
        var sDocumentId = this.getView().getModel("CostRollModel").getProperty(oEvent.getSource().getBindingContext("CostRollModel").getPath()).FileID.DmsDocumentId;
        if (!sDocumentId) {
            MessageToast.show(this.i18n.getText("CannotDownloadMsg"));
            return;
        }
        // sURL = $.sap.getModulePath("com.jabil.costrollrequest") + "/browser/CR_REQUEST_REPO/root/" + sFolderId + "?objectId=" + sDocumentId;
        sURL = $.sap.getModulePath("com.jabil.crworkflowuimodule") + "/browser/CR_REQUEST_REPO/root/" + sFolderId + "?objectId=" + sDocumentId;
        win = window.open(sURL, '_blank');
        win.focus();
    },
    });
  }
);
