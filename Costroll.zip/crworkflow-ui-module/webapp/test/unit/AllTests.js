sap.ui.define([
	"comjabil/crworkflow-ui-module/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
