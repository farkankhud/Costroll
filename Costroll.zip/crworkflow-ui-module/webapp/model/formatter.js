sap.ui.define([], function () {
    "use strict";

    return {
        /**
         * Determines the visibility of fields based on requestType and TypeName.
         * @param {string} sTypeName - The value of TypeName from ViewModel.
         * @param {string} sRequestType - The value of requestType from CostRollModel.
         * @returns {boolean} - True if the field should be visible, false otherwise.
         */
        isFieldVisible: function (sTypeName, sRequestType) {
            return sTypeName === "1" && sRequestType === "Cost Roll";
        }
    };
});
