sap.ui.define(
  [
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/jabil/crworkflowuimodule/model/models",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Label",
    "sap/m/library",
    "sap/m/MessageToast",
    "sap/m/Text",
    "sap/m/TextArea",
    "sap/ui/core/Element",
    "sap/m/ComboBox",
    "sap/ui/core/Item",
  ],
  function (UIComponent, Device, models, MessageBox, JSONModel, Dialog, Button, Label, mobileLibrary, MessageToast, Text, TextArea, Element,ComboBox,Item) {
    "use strict";
    var ButtonType = mobileLibrary.ButtonType;

      // shortcut for sap.m.DialogType
      var DialogType = mobileLibrary.DialogType;

    return UIComponent.extend(
      "com.jabil.crworkflowuimodule.Component",
      {
        metadata: {
          manifest: "json",
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
          // call the base component's init function
          UIComponent.prototype.init.apply(this, arguments);

          // enable routing
          this.getRouter().initialize();

          // set the device model
          this.setModel(models.createDeviceModel(), "device");

          this.setTaskModels();

          // this.getInboxAPI().addAction(
          //   {
          //     action: "APPROVE",
          //     label: "Approve",
          //     type: "accept", // (Optional property) Define for positive appearance
          //   },
          //   function () {
          //     this.onSubmitDialogPress(true, rejectOutcomeId);
          //     // this.completeTask(true);
          //   },
          //   this
          // );

          // this.getInboxAPI().addAction(
          //   {
          //     action: "REJECT",
          //     label: "Reject",
          //     type: "reject", // (Optional property) Define for negative appearance
          //   },
          //   function () {
          //     this.completeTask(false);
          //   },
          //   this
          // );
          // const rejectOutcomeId = "reject";
          // this.getInboxAPI().addAction(
          //   {
          //     action: rejectOutcomeId,
          //     label: "Reject",
          //     type: "reject",
          //   },
          //   function () {
          //     this.onSubmitDialogPress(true, rejectOutcomeId);
          //     // this.completeTask(false, rejectOutcomeId);
          //   },
          //   this
          // );
          // const approveOutcomeId = "approve";
          // this.getInboxAPI().addAction(
          //   {
          //     action: approveOutcomeId,
          //     label: "Approve",
          //     type: "accept",
          //     id: "idTest"
          //   },
          //   function () {
          //     this.onSubmitDialogApprovedPress(true, approveOutcomeId);
          //     // this.completeTask(true, approveOutcomeId);
          //   },
          //   this
          // );
        },
        onSubmitDialogPress: function (approvalStatus, outcomeId) {
          if (!this.oSubmitDialog) {
            this.oSubmitDialog = new Dialog({
              type: DialogType.Message,
              title: "Reject",
              content: [
                new Label({
                  text: "Do you want to Reject this #Cost Roll Request?",
                  labelFor: "submissionNote"
                }),
                new TextArea("submissionNote", {
                  width: "100%",
                  placeholder: "Add rejection note (optional)",
                  liveChange: function (oEvent) {
                    // this._updateSubmitButtonState();
                    var sText = oEvent.getParameter("value");
                    this.oSubmitDialog.getBeginButton().setEnabled(sText.length > 0);
                  }.bind(this)
                })

              ],
              beginButton: new Button({
                type: ButtonType.Emphasized,
                text: "Reject",
                enabled: false,
                press: function () {
                  var sText = Element.getElementById("submissionNote").getValue();
                  var reason = "Rejection Reason: " + sText;
                  this.getModel("context").setProperty("/comment", reason);
                  this.oSubmitDialog.close();
                  this.onCloseRejectDialog();
                  this.completeTask(approvalStatus, outcomeId);
                }.bind(this)
              }),
              endButton: new Button({
                text: "Cancel",
                press: function () {
                  this.oSubmitDialog.close();
                  this.onCloseRejectDialog()
                }.bind(this)
              })
            });
          }

          this.oSubmitDialog.open();
        },
        onSubmitDialogApprovedPress: function (approvalStatus, outcomeId) {
          if (!this.oSubmitApproveDialog) {
            this.oSubmitApproveDialog = new Dialog({
              type: DialogType.Message,
              title: "Approve",
              content: [
                new Label({
                  text: "Do you want to Approve this #Cost Roll Request?",
                  labelFor: "submissionNoteApproved"
                }),
                new TextArea("submissionNoteApproved", {
                  width: "100%",
                  placeholder: "Add Approval note (optional)",
                  liveChange: function (oEvent) {
                    var sText = oEvent.getParameter("value");
                    // this.oSubmitApproveDialog.getBeginButton().setEnabled(sText.length > 0);
                  }.bind(this)
                })
              ],
              beginButton: new Button({
                type: ButtonType.Emphasized,
                text: "Approve",
                enabled: true,
                press: function () {
                  var sText = Element.getElementById("submissionNoteApproved").getValue();
                  this.getModel("context").setProperty("/comment", sText);
                  this.oSubmitApproveDialog.close();
                  this.onCloseApprovedDialog();
                  this.completeTask(approvalStatus, outcomeId);
                }.bind(this)
              }),
              endButton: new Button({
                text: "Cancel",
                press: function () {
                  this.oSubmitApproveDialog.close();
                  this.onCloseApprovedDialog();
                }.bind(this)
              })
            });
          }

          this.oSubmitApproveDialog.open();
          //this.onCloseApprovedDialog();
        },
        onCloseApprovedDialog: function () {
          this.oSubmitApproveDialog.destroy();
        },
        onCloseRejectDialog: function () {
          this.oSubmitDialog.destroy();
        },

        setTaskModels: function () {
          // set the task model
          var startupParameters = this.getComponentData().startupParameters;
          this.setModel(startupParameters.taskModel, "task");

          // set the task context model
          var taskContextModel = new sap.ui.model.json.JSONModel(
            this._getTaskInstancesBaseURL() + "/context"
          );
          // Return a promise that resolves when the data is loaded
          var taskContextModelPromise = new Promise((resolve, reject) => {
            taskContextModel.attachRequestCompleted(function () {
              resolve();
            });
            taskContextModel.attachRequestFailed(function () {
              reject(new Error("Failed to load task context model"));
            });
          });
          taskContextModelPromise.then( async function () {
            console.log("Task Context Model Data Loaded");
            this.setModel(taskContextModel, "context");
            //Code to get CR Details
            var crType = this.getModel("context").getData().CRTYPE;
            var FlowStep = this.getModel("context").getData().FlowStep;
            var outcomeId,label,type,message;
            if (crType == "StandardCost" && FlowStep == "Common") {
              outcomeId = "approve";
              label = "Approve";
              type = "accept";
              this.createDynamicAction(outcomeId,label,type)
              outcomeId = "reject";
              label = "Reject";
              type = "reject";
              this.createDynamicAction(outcomeId,label,type)
            } else if (crType == "StandardCost" && FlowStep == "MarketRelease") {
              outcomeId = "approve";
              label = "Execute Marking&Release";
              type = "accept";
              this.createDynamicAction(outcomeId,label,type)
              outcomeId = "reject";
              label = "Reject";
              type = "reject";
              this.createDynamicAction(outcomeId,label,type)
            } else if (crType == "StandardCost" && FlowStep == "PreFinal") {
  // Start of Change Sharique 14/01/2024
  // In case of errors don't show Full Release button
              // outcomeId = "approve";
              // label = " Close Full Release";
              // type = "accept";
              // message = "FullRelease";
              // this.createDynamicAction(outcomeId,label,type,message)
//  End of Change sharique 14/01/2024
              outcomeId = "approve";
              label = " Close Partial Release";
              type = "accept";
              message = "PartialRelease";
              this.createDynamicAction(outcomeId,label,type,message)
              outcomeId = "approve";
              label = " Re Release";
              type = "accept";
              message = "ReRelease";
              this.createDynamicAction(outcomeId,label,type,message)
            } else if (crType == "StandardCost" && FlowStep == "Final") {
              outcomeId = "approve";
              label = " Close Full Release";
              type = "accept";
              message = "FullRelease";
              this.createDynamicAction(outcomeId,label,type,message)
  // Start of Change Sharique 14/01/2024
  // In case of no errors show only Full Release button
              // outcomeId = "approve";
              // label = " Close Partial Release";
              // type = "accept";
              // message = "PartialRelease";
              // this.createDynamicAction(outcomeId,label,type,message)
//  End of Change sharique 14/01/2024
              // outcomeId = "approve";
              // label = " Re Release";
              // type = "accept";
              // message = "ReRelease";
              // this.createDynamicAction(outcomeId,label,type,message)
            } else if (crType == "FutureCost" && FlowStep == "Common") {
              outcomeId = "approve";
              label = "Approve";
              type = "accept";
              this.createDynamicAction(outcomeId,label,type)
              outcomeId = "reject";
              label = "Reject";
              type = "reject";
              this.createDynamicAction(outcomeId,label,type)
            } else if (crType == "FutureCost" && FlowStep == "PriceUpdate") {
              outcomeId = "approve";
              label = "Execute Price Update";
              type = "accept";
              this.createDynamicAction(outcomeId,label,type)
              outcomeId = "reject";
              label = "Reject";
              type = "reject";
              this.createDynamicAction(outcomeId,label,type)
            } else if (crType == "FutureCost" && FlowStep == "Final") {
              outcomeId = "approve";
              label = " Close Full Update";
              type = "accept";
              message = "FullUpdate";
              this.createDynamicAction(outcomeId,label,type,message)
              outcomeId = "approve";
              label = " Close Partial Update";
              type = "accept";
              message = "PartialUpdate";
              this.createDynamicAction(outcomeId,label,type,message)
              outcomeId = "approve";
              label = " Close No Update";
              type = "accept";
              message = "NoUpdate";
              this.createDynamicAction(outcomeId,label,type,message)
              
            } else if (crType == "DeletionCost" && FlowStep == "Common") {
              outcomeId = "approve";
              label = "Approve";
              type = "accept";
              this.createDynamicAction(outcomeId,label,type)
              outcomeId = "reject";
              label = "Reject";
              type = "reject";
              this.createDynamicAction(outcomeId,label,type)
            }  else if (crType == "DeletionCost" && FlowStep == "Final") {
              outcomeId = "approve";
              label = " Close Full Deletion";
              type = "accept";
              message = "FullDeletion";
              this.createDynamicAction(outcomeId,label,type,message)
              outcomeId = "approve";
              label = " Close Partial Deletion";
              type = "accept";
              message = "PartialDeletion";
              this.createDynamicAction(outcomeId,label,type,message)
              outcomeId = "approve";
              label = " Close No Deletion";
              type = "accept";
              message = "NoDeletion";
              this.createDynamicAction(outcomeId,label,type,message)
            }
           
            // BusyIndicator.hide();
            this.getRouter().navTo("RouteMain");

          }.bind(this));

          // this.setModel(taskContextModel, "context");
        },

        createDynamicAction : function (outcomeId,label,type,message) {
          this.getInboxAPI().addAction(
            {
              action: outcomeId,
              label: label,
              type: type,
            },
            function () {
              if(outcomeId == "reject") {
                this.onSubmitDialogPress(true, outcomeId);
              } else {
                this.getModel("context").setProperty("/StepExecuted", message);
                this.onSubmitDialogApprovedPress(true, outcomeId,message);
              }
              // this.completeTask(false, rejectOutcomeId);
            },
            this
          );
        },

        _getTaskInstancesBaseURL: function () {
          return (
            this._getWorkflowRuntimeBaseURL() +
            "/task-instances/" +
            this.getTaskInstanceID()
          );
        },

        _getWorkflowRuntimeBaseURL: function () {
          var appId = this.getManifestEntry("/sap.app/id");
          var appPath = appId.replaceAll(".", "/");
          var appModulePath = jQuery.sap.getModulePath(appPath);

          return appModulePath + "/bpmworkflowruntime/v1";
        },

        getTaskInstanceID: function () {
          return this.getModel("task").getData().InstanceID;
        },

        getInboxAPI: function () {
          var startupParameters = this.getComponentData().startupParameters;
          return startupParameters.inboxAPI;
        },

        completeTask: function (approvalStatus,outcomeId) {
          this.getModel("context").setProperty("/approved", approvalStatus);
          this._patchTaskInstance(outcomeId);
          this._refreshTaskList();
        },

        _patchTaskInstance: function (outcomeId) {
          const context = this.getModel("context").getData();
          var data = {
            status: "COMPLETED",
            context: { ...context, comment: context.comment || '' },
            decision: outcomeId
        };

          jQuery.ajax({
            url: this._getTaskInstancesBaseURL(),
            method: "PATCH",
            contentType: "application/json",
            async: false,
            data: JSON.stringify(data),
            headers: {
              "X-CSRF-Token": this._fetchToken(),
            },
          });
        },

        _fetchToken: function () {
          var fetchedToken;

          jQuery.ajax({
            url: this._getWorkflowRuntimeBaseURL() + "/xsrf-token",
            method: "GET",
            async: false,
            headers: {
              "X-CSRF-Token": "Fetch",
            },
            success(result, xhr, data) {
              fetchedToken = data.getResponseHeader("X-CSRF-Token");
            },
          });
          return fetchedToken;
        },

        _refreshTaskList: function () {
          this.getInboxAPI().updateTask("NA", this.getTaskInstanceID());
        },
        getCRDetails: function(reqId) {
          return new Promise((resolve, reject) => {
              var urlCap = $.sap.getModulePath("com.jabil.crworkflowuimodule") + "/odata/v2/cost-roll/Header";
              
              $.ajax({
                  url: urlCap,
                  type: 'GET',
                  contentType: 'application/json',
                  success: function(oData) {
                    console.log(oData);
                      resolve(oData.d.results);
                  },
                  error: function(oError) {
                      reject(oError);
                  }
              });
          });
        },
      }
    );
  }
);
