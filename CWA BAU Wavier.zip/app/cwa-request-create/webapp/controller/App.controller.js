sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("cwa.fiori.request.cwarequestcreate.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  