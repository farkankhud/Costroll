sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "cwa/fiori/request/cwarequestcreate/model/jszip",
    "cwa/fiori/request/cwarequestcreate/model/xlsx",
    "sap/m/MessageBox",
    "sap/ui/core/BusyIndicator",
    "sap/m/MessageToast",
    "sap/ui/core/Messaging",
    "sap/ui/export/Spreadsheet"
],
    function (Controller, JSONModel, jszip, xlsx, MessageBox, BusyIndicator, MessageToast, Messaging, Spreadsheet) {
        "use strict";
        return Controller.extend("cwa.fiori.request.cwarequestcreate.controller.CreateRequestForm", {

            // init method to define ViewModel and CWACreateRequestModel
            onInit: function () {
                this.oModel = this.getOwnerComponent().getModel("v4Model");
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                this._MessageManager = sap.ui.getCore().getMessageManager();
                this._MessageManager.registerObject(this.getView(), true);
                this.getOwnerComponent().setModel(this._MessageManager.getMessageModel(), "message");
                this.bDefaultValueSet = false;

                this.sCWAName = "";
                if (this.getOwnerComponent().getComponentData() && this.getOwnerComponent().getComponentData().startupParameters && this.getOwnerComponent().getComponentData().startupParameters.CWAName) {
                    this.sCWAName = this.getOwnerComponent().getComponentData().startupParameters.CWAName[0];
                }

                var ov2Model = this.getOwnerComponent().getModel();
                ov2Model.metadataLoaded().then(function () {
                    var oContext = ov2Model.createEntry("/Header", {
                        properties: {
                            "SAPLocalTime": "",
                            "SAPReqPlan": ""
                        }
                    });
                    this.byId("SAPDemandOForm").setBindingContext(oContext);
                }.bind(this));

                var oViewModel = new JSONModel({

                    "Action": "",
                    "ExistingCWAID": "",
                    "ExistingCWAName": "",
                    "DmsFolderId": "",
                    "InputCWARequestName": "",
                    "CWAItemToDisplay": {},
                    "CurrentItemAttachment": {},
                    "CurrentCWAItem": {},
                    "CWAItemAttachments": [],
                    "CWAAttachments": [],
                    "CWAApprovers": [],
                    "DeletedCWAAttachments": [],
                    "DeletedCWAItemAttachments": [],
                    "CurrentCWAItems": [],
                    "CurrentCWAAttachments": [],
                    "DeletedCWAItems": [],
                    "SaveAllowed": false,
                    "SubmitAllowed": false,
                    "ToBeDeletedDocumentIDs": [],
                    "ToBeDeletedDMSDocumentIDs": [],
                    "ChangedApprovers": [],
                    "ReadViaGo": false,
                    "NotSingleItem": true,
                    "ReqPlanVersion": [{
                        "Version": "00"
                    }],
                    "TimeZone": [{
                        "Key": "UTC+8",
                        "Value": "UTC+8"
                    }],
                    "PartValidFailed": true,
                    "ExportMS": [],
                    "CreateErrorMessages": [],
                    "SubmitResponse": {},
                    "FileUpload": true
                });

                // Model to bind properties to handle view
                this.getView().setModel(oViewModel, "ViewModel");

                // Model to store CWA Request details
                this.setCWACreateRequestModel();

                if (this.sCWAName) {
                    this.getView().getModel("ViewModel").setProperty("/InputCWARequestName", this.sCWAName);
                    this.onCWAInputGo();
                }

            },

            // Hides busy indicator
            hideBusyIndicator: function () {
                BusyIndicator.hide();
            },

            // Shows busy indicator
            showBusyIndicator: function () {
                BusyIndicator.show();
            },

            // Sets CWARequestModel to view
            setCWACreateRequestModel: function () {
                var oCWACreateRequestModel = new JSONModel(Object.assign({}, this.prepareCWACreateRequestObject()));
                this.getView().setModel(oCWACreateRequestModel, "CWACreateRequestModel");
            },

            // Returns CWA Request object
            prepareCWACreateRequestObject: function () {
                var oCWACreateRequestModel = {
                    "Site": "",
                    "Number": undefined,
                    "Customer": "",
                    "Status": {
                        "name": ""
                    },
                    "Division": "",
                    "Region": "",
                    "Segment": "",
                    "CWAName": "",
                    "Comment": "",
                    "CWAItems": [],
                    "CWAApprovers": [],
                    "SAPReqPlan": "",
                    "SAPUTCConvert": false,
                    "SAPLocalTime": ""
                };
                return oCWACreateRequestModel;
            },

            // Event handler method for press event of Go button
            onCWAInputGo: async function (oEvent) {
                var aFilters = [],
                    aRequestName = [],
                    aSite = [];

                this.performResetForGo();

                // If request id is not entered then display error
                if (!this.getView().getModel("ViewModel").getProperty("/InputCWARequestName")) {
                    MessageBox.error(this.i18n.getText("emptyCWANameError"));
                    return;
                }

                aRequestName.push(new sap.ui.model.Filter("CWAName", sap.ui.model.FilterOperator.EQ, this.getView().getModel("ViewModel").getProperty("/InputCWARequestName")));
                aFilters.push(new sap.ui.model.Filter(aRequestName, false));
                this.showBusyIndicator();

                await this.readCWAHeader(aFilters).then(async function (aContexts) {
                    if (aContexts.length > 0) {
                        // Sets response to the model
                        this.getView().getModel("CWACreateRequestModel").setProperty("/", Object.assign({}, aContexts[0].getObject()));
                        this.getView().getModel("ViewModel").setProperty("/ExistingCWAID", this.getView().getModel("CWACreateRequestModel").getProperty("/ID"));
                        this.getView().getModel("ViewModel").setProperty("/ExistingCWAName", this.getView().getModel("CWACreateRequestModel").getProperty("/CWAName"));
                        this.getView().getModel("ViewModel").setProperty("/ReadViaGo", true);
                        this.getView().getModel("ViewModel").setProperty("/DmsFolderId", aContexts[0].getObject().DmsFolderId);
                        if (this.byId("TimeZoneSf").getInnerControls().length > 0 && this.byId("TimeZoneSf").getInnerControls()[0].setValue) {
                            this.byId("TimeZoneSf").getInnerControls()[0].setValue(aContexts[0].getObject().SAPLocalTime);
                        }
                        if (this.byId("TimeZoneSf").getInnerControls().length > 0 && this.byId("TimeZoneSf").getInnerControls()[0].setText) {
                            this.byId("TimeZoneSf").getInnerControls()[0].setText(aContexts[0].getObject().SAPLocalTime);
                        }
                        if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue) {
                            this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue(aContexts[0].getObject().SAPReqPlan);
                        }
                        if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setText) {
                            this.byId("ReqPlanVersionSf").getInnerControls()[0].setText(aContexts[0].getObject().SAPReqPlan);
                        }

                        this.setTimeZoneSfEditable(aContexts[0].getObject().SAPUTCConvert);

                        if (aContexts[0].getObject().Status_ID === 1) {
                            this.getView().getModel("ViewModel").setProperty("/SaveAllowed", true);
                            this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", false);
                        } else {
                            this.getView().getModel("ViewModel").setProperty("/SaveAllowed", false);
                            this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", false);
                        }

                        var oCWARequest = JSON.parse(JSON.stringify(this.getView().getModel("CWACreateRequestModel").getProperty("/")));
                        var aCWAAttachmentsAll = []; var aCWAItemDocuments = [];
                        var sProfitCenters = "";
                        oCWARequest.CWAItems.forEach(function (oItem) {
                            aCWAAttachmentsAll = aCWAAttachmentsAll.concat(oItem.CWAAttachments);
                            aCWAItemDocuments.push(oItem.FileID);
                            if (sProfitCenters === "") {
                                sProfitCenters = oItem.ProfitCenters;
                            } else {
                                sProfitCenters = sProfitCenters + "," + oItem.ProfitCenters;
                            }

                        }.bind(this));
                        this.setCWAItemAttachments(aCWAItemDocuments);
                        this.getView().getModel("ViewModel").setProperty("/CurrentCWAAttachments", aCWAAttachmentsAll);
                        this.getView().getModel("ViewModel").setProperty("/CurrentCWAItems", oCWARequest.CWAItems);
                        this.getView().getModel("ViewModel").setProperty("/CWAItemToDisplay", Object.assign({}, this.calculateFieldsBasedOnItems(aContexts[0].getObject().CWAItems, true)));

                        // if (oCWARequest.CWAItems.length === 1) {
                        //     // this.getView().getModel("ViewModel").setProperty("/NotSingleItem", false);
                        // } else {
                        //     // this.getView().getModel("ViewModel").setProperty("/NotSingleItem", true);
                        // }

                        this.getView().getModel("ViewModel").setProperty("/Action", "HEADER_UPDATE");

                        var aDocuments = [];
                        aContexts[0].getObject().CWAItems.forEach(function (oItem) {
                            oItem.CWAAttachments.forEach(function (oAttachment) {
                                aDocuments.push(oAttachment.FileID);

                            });
                        });
                        this.setCWAAttachments(aDocuments);

                        this.removeAllMessages();
                        await this.callValidateCWA(aContexts[0].getObject());
                        this.getView().getModel("CWACreateRequestModel").refresh();
                        this.hideBusyIndicator();
                    } else {
                        // If no request is found, display error and reset the model
                        this.getView().getModel("ViewModel").setProperty("/ReadViaGo", true);
                        this.getView().getModel("ViewModel").setProperty("/CurrentCWAAttachments", []);
                        this.getView().getModel("ViewModel").setProperty("/CurrentCWAItems", []);
                        this.getView().getModel("ViewModel").setProperty("/SaveAllowed", false);
                        this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", false);
                        this.getView().getModel("ViewModel").setProperty("/DmsFolderId", "");
                        this.setCWAApproversInView([]);
                        this.resetCWAData();
                        this.hideBusyIndicator();
                        MessageBox.error("CWA Request is not found");
                    }


                }.bind(this))
                    .catch(function (oError) {
                        this.resetCWAData();
                        this.hideBusyIndicator();
                        MessageBox.error(oError.toString());
                    }.bind(this));
            },

            // Resets the screen when GO is pressed.
            performResetForGo: function () {
                this.removeAllMessages();
                this.resetCWAViewData(true);
                this.byId("CWAItemAttachment").clear();
                this.byId("CWAItemAttachment").setValue();
            },

            // Action Import call to validate the CWA
            callValidateCWA: function (oCWARequest) {
                return new Promise(async function (resolve, reject) {
                    // var oModel = this.getView().getModel();
                    var oOperation = this.oModel.bindContext("/ValidateCWA(...)");
                    oOperation.setParameter('ID', oCWARequest.ID);
                    // Action Import POST call
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        this.getView().getModel("ViewModel").setProperty("/SaveAllowed", oOperationContext.getObject().SaveAllowed);
                        this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", oOperationContext.getObject().SubmitAllowed);
                        this.setCWAApproversInView(this.orderApproversForView(oCWARequest.CWAApprovers, oOperationContext.getObject().CWAApprovers));
                        resolve();

                    }.bind(this))
                        .catch(function (oError) {
                            this.resetCWAData();
                            this.hideBusyIndicator();
                            MessageBox.error(oError.toString());
                        }.bind(this));
                }.bind(this));
            },

            // Returns approvers as per how it needs to be displayed in the screen
            orderApproversForView: function (aSelCWAApprovers, oApproverList) {
                var aApproversItems = [];
                aSelCWAApprovers.forEach(function (oApprover) {
                    if (oApprover.ApproverLevel === "WCM") {
                        aApproversItems[0] = {
                            "ID": oApprover.ID,
                            "ApproverLevel": oApprover.ApproverLevel,
                            "ApproverName": oApprover.ApproverName,
                            "ApproversList": oApproverList.WCM,
                            "ApproverEmail": oApprover.ApproverEmail
                        };
                    }
                    if (oApprover.ApproverLevel === "BUM") {
                        aApproversItems[1] = {
                            "ID": oApprover.ID,
                            "ApproverLevel": oApprover.ApproverLevel,
                            "ApproverName": oApprover.ApproverName,
                            "ApproversList": oApproverList.BUM,
                            "ApproverEmail": oApprover.ApproverEmail
                        };
                    }
                    if (oApprover.ApproverLevel === "SPM") {
                        aApproversItems[2] = {
                            "ID": oApprover.ID,
                            "ApproverLevel": oApprover.ApproverLevel,
                            "ApproverName": oApprover.ApproverName,
                            "ApproversList": oApproverList.SPM,
                            "ApproverEmail": oApprover.ApproverEmail
                        };
                    }
                });
                return aApproversItems;
            },

            // Event handler for approver change
            onCWAApproverChange: function (oEvent) {
                this.getView().getModel("ViewModel").setProperty(oEvent.getSource().getBindingContext("ViewModel").getPath() + "/ApproverEmail",
                    this.getView().getModel("ViewModel").getProperty(oEvent.getSource().getSelectedItem().getBindingContext("ViewModel").getPath()).Email);
            },

            // Logic to calculate fields based on the logic
            calculateFieldsBasedOnItems: function (aItems, bCurrent) {

                var oDisplayItem;
                if (bCurrent) {
                    oDisplayItem = {
                        "CurrentMS": 0,
                        "ProposedMS": 0,
                        "MonthTM1": 0,
                        "ApprovedWaiver": 0,
                        "CurrentMonthShipment": 0,
                        "BalanceMonth": 0,
                        "MPSAlignmentPer": 0,
                        "MPSVariance": 0,
                        "MPSAlignmentWaiverPer": 0,
                        "MPSVarianceWaiver": 0,
                        "GeneralEO": [{
                            "Text": this.i18n.getText("excessTotalSTDText"),
                            "Proposed": 0,
                            "Current": 0
                        }, {
                            "Text": this.i18n.getText("obsoleteTotalSTDText"),
                            "Proposed": 0,
                            "Current": 0
                        }],
                        "FileFromRR": null,
                        "ProfitCenters": ""
                    };
                } else {
                    oDisplayItem = this.getView().getModel("ViewModel").getProperty("/CWAItemToDisplay");
                }
                aItems.forEach(function (oItem) {
                    // In table
                    oDisplayItem.CurrentMS = (parseFloat(oDisplayItem.CurrentMS) + parseFloat(oItem.CurrentMS)).toFixed(2);
                    oDisplayItem.ProposedMS = (parseFloat(oDisplayItem.ProposedMS) + parseFloat(oItem.ProposedMS)).toFixed(2);
                    oDisplayItem.MonthTM1 = (parseFloat(oDisplayItem.MonthTM1) + parseFloat(oItem.MonthTM1)).toFixed(2);
                    oDisplayItem.ApprovedWaiver = (parseFloat(oDisplayItem.ApprovedWaiver) + parseFloat(oItem.ApprovedWaiver)).toFixed(2);
                    oDisplayItem.GeneralEO[0].Proposed = (parseFloat(oDisplayItem.GeneralEO[0].Proposed) + parseFloat(oItem.ExcessTotalProposed)).toFixed(2);
                    oDisplayItem.GeneralEO[0].Current = (parseFloat(oDisplayItem.GeneralEO[0].Current) + parseFloat(oItem.ExcessTotalCurrent)).toFixed(2);
                    oDisplayItem.GeneralEO[1].Proposed = (parseFloat(oDisplayItem.GeneralEO[1].Proposed) + parseFloat(oItem.ObsoleteTotalProposed)).toFixed(2);
                    oDisplayItem.GeneralEO[1].Current = (parseFloat(oDisplayItem.GeneralEO[1].Current) + parseFloat(oItem.ObsoleteTotalCurrent)).toFixed(2);
                    oDisplayItem.CurrentMonthShipment = (parseFloat(oDisplayItem.CurrentMonthShipment) + parseFloat(oItem.CurrentMonthShipment)).toFixed(2);
                    oDisplayItem.BalanceMonth = (parseFloat(oDisplayItem.BalanceMonth) + parseFloat(oItem.BalanceMonth)).toFixed(2);

                    if (oDisplayItem.ProfitCenters === "") {
                        oDisplayItem.ProfitCenters = oItem.ProfitCenters;
                    } else {
                        oDisplayItem.ProfitCenters = oDisplayItem.ProfitCenters + "," + oItem.ProfitCenters;
                    }
                });
                // Send to table
                oDisplayItem.MPSAlignmentPer = this.calculateMPSAlignmentPer(oDisplayItem).toFixed(2);
                oDisplayItem.MPSVariance = this.calculateMPSVariance(oDisplayItem).toFixed(2);
                oDisplayItem.MPSAlignmentWaiverPer = this.calculateMPSAlignmentWaiverPer(oDisplayItem).toFixed(2);
                oDisplayItem.MPSVarianceWaiver = this.calculateMPSVarianceWaiver(oDisplayItem).toFixed(2);
                oDisplayItem.FileFromRR = this.getFileFromRR(oDisplayItem, aItems);
                return oDisplayItem;
            },

            // To calculate MPSAlignmentPer field
            calculateMPSAlignmentPer: function (oItem) {
                oItem.MPSAlignmentPer = 100 * (oItem.MonthTM1 / (parseFloat(oItem.BalanceMonth) + parseFloat(oItem.CurrentMonthShipment)));
                return oItem.MPSAlignmentPer;
            },

            // To calculate MPSVariance field
            calculateMPSVariance: function (oItem) {
                oItem.MPSVariance = oItem.MonthTM1 - oItem.BalanceMonth - oItem.CurrentMonthShipment;
                return oItem.MPSVariance;
            },
            // To calculate MPSAlignmentWaiverPer field
            calculateMPSAlignmentWaiverPer: function (oItem) {
                oItem.MPSAlignmentWaiverPer = 100 * ((parseFloat(oItem.MonthTM1) + parseFloat(oItem.ApprovedWaiver)) / (parseFloat(oItem.BalanceMonth) + parseFloat(oItem.CurrentMonthShipment)));
                return oItem.MPSAlignmentWaiverPer;
            },

            // To calculate MPSVarianceWaiver field
            calculateMPSVarianceWaiver: function (oItem) {
                oItem.MPSVarianceWaiver = oItem.MonthTM1 - oItem.BalanceMonth - oItem.CurrentMonthShipment + parseFloat(oItem.ApprovedWaiver);
                return oItem.MPSVarianceWaiver;
            },

            // To retrieve FileFromRR field
            getFileFromRR: function (oDisplayItem, aItems) {
                var bItemFlag = true;
                for (let i = 0; i < aItems.length; i++) {
                    if (!aItems[i].FileFromRR) {
                        bItemFlag = false;
                        break;
                    }
                }
                if (oDisplayItem.FileFromRR !== null) {
                    bItemFlag = bItemFlag && oDisplayItem.FileFromRR
                }
                return bItemFlag;
            },

            // Sets CWA Item Attachments
            setCWAItemAttachments: function (aDocuments) {
                this.getView().getModel("ViewModel").setProperty("/CWAItemAttachments", aDocuments);
                this.getView().getModel("ViewModel").setProperty("/DeletedCWAItemAttachments", []);
            },

            // Sets CWA Other Attachments
            setCWAAttachments: function (aDocuments) {
                if (aDocuments.length === 0) {
                    this.getView().getModel("ViewModel").setProperty("/CWAAttachments", []);
                } else {
                    this.getView().getModel("ViewModel").setProperty("/CWAAttachments", aDocuments);
                }
            },

            // Event handler for press event of Clear button and resets the view.
            onClearCWARequestNumber: function () {
                this.resetCWAData();
                this.getView().getModel("ViewModel").setProperty("/InputCWARequestName", "");
            },

            // change event handler method of CWA Item Attachment file uploader
            onCWAItemAttachmentChange: function (oEvent) {
                this.showBusyIndicator();
                this.getView().setBusy(true);
                this.getView().getModel("ViewModel").setProperty("/ReadViaGo", false);

                this.resetCWAData(true);
                this.getView().getModel("ViewModel").setProperty("/CurrentItemAttachment", oEvent.getParameter("files")[0]);
                this.parseAttachmentUpload(oEvent.getParameter("files")[0]);
            },

            // Reading of excel when uploaded to browser
            parseAttachmentUpload: async function (oFile) {
                this.bReadAsArrayBufferCalled = false;
                if (this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment") && window.FileReader) {
                    var reader = new FileReader();
                    reader.onload = async function (e) {

                        var data = e.currentTarget.result;
                        var excelsheet = xlsx.read(data, {
                            type: "binary"
                        });
                        if (!excelsheet.Workbook) {
                            this.getView().getModel("ViewModel").setProperty("/CurrentItemAttachment/Content", e.currentTarget.result);
                            this.getView().setBusy(false);
                            this.hideBusyIndicator();
                            return;
                        }


                        var sJSONData = {}, sPartValidJSON = {}, sExportMSJson = {}, oExcelRow;
                        var bSummaryFlag = false, bPartValidFlag = false, bExportMSFlag = false;
                        // var aDates = []; var aMPRDates = [];
                        for (var i = 0; i < excelsheet.SheetNames.length; i++) {

                            if (excelsheet.SheetNames[i].includes("Part Valid")) {
                                oExcelRow = await xlsx.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[i]]); // this is the required data in Object format
                                sPartValidJSON = JSON.stringify(oExcelRow); // this is the required data in String format
                                bPartValidFlag = true;
                            }
                            if (excelsheet.SheetNames[i] === "Summary for BTP") {
                                oExcelRow = await xlsx.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[i]]); // this is the required data in Object format
                                sJSONData = JSON.stringify(oExcelRow); // this is the required data in String format
                                bSummaryFlag = true;
                            }
                            if (excelsheet.SheetNames[i].includes("Export Propose MS")) {
                                oExcelRow = await xlsx.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[i]]); // this is the required data in Object format
                                sExportMSJson = JSON.stringify(oExcelRow); // this is the required data in String format
                                // oExcelRow.forEach(function (oItem) {
                                //     aDates.push(this.getExcelDateAsDate(oItem.Date));
                                //     aMPRDates.push(this.getExcelDateAsDate(oItem["MRP Date"]));
                                // }.bind(this));

                                bExportMSFlag = true;
                            }
                            if (bSummaryFlag && bPartValidFlag && bExportMSFlag) {
                                break;
                            }

                        }

                        this.getView().getModel("ViewModel").setProperty("/ExportMS", JSON.parse(sExportMSJson));
                        this.validateCWAFileData(sJSONData, JSON.parse(sPartValidJSON));

                    }.bind(this);
                    reader.onloadend = async function () {
                        if (!this.bReadAsArrayBufferCalled) {
                            this.bReadAsArrayBufferCalled = true;
                            reader.readAsArrayBuffer(this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment"));
                        }
                    }.bind(this);

                    // reader.readAsBinaryString(this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment"));

                    reader.readAsDataURL(this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment"));

                }
            },

            // getExcelDateAsDate: function (excelDate) {
            //     // Convert Excel date to milliseconds (accounting for timezone offset)
            //     var unixTimestamp = (excelDate - 25569) * 86400000 - (new Date().getTimezoneOffset() * 60000);
            //     return new Date(unixTimestamp);
            // },

            // Event handler for file uploader attachment change
            onCWAAttachmentChange: function (oEvent) {

                Object.values(oEvent.getParameter("files")).forEach(function (oFile) {
                    this.handleReadCWAAttachment(oFile);
                }.bind(this));

                this.byId("CWAAttachment").clear();
                this.byId("CWAAttachment").setValue();
            },

            // Parse the file and push the attachment to ViewModel property CWAAttachments
            handleReadCWAAttachment: function (oFile) {
                var reader = new FileReader();
                reader.readAsDataURL(oFile);
                reader.onload = async function (e) {

                    var data = e.currentTarget.result;
                    var oDocument = {
                        "FileKind": {
                            "ID": 1
                        },
                        "DmsDocumentId": null,
                        // "DocumentName": oFile.name.split(".")[0],
                        // "DocumentType": oFile.name.split(".")[1],
                        "DocumentName": this.returnFileName(oFile.name),
                        "DocumentType": this.returnFileType(oFile.name),
                        "Document": oFile,
                        "Content": data
                    };
                    this.getView().getModel("ViewModel").getProperty("/CWAAttachments").push(oDocument);
                    this.getView().getModel("ViewModel").setProperty("/CWAAttachments", this.getView().getModel("ViewModel").getProperty("/CWAAttachments"));
                }.bind(this);
            },

            returnFileName: function (sName) {
                return sName.substring(0, sName.lastIndexOf("."));
            },

            returnFileType: function (sName) {
                return sName.substring(sName.lastIndexOf(".") + 1);
            },

            // Validates the uploaded excel
            validateCWAFileData: async function (sCWAFileData, aPartValid) {
                this.showBusyIndicator();
                var oParsedData = this.prepareCWAFileData(JSON.parse(sCWAFileData));

                var oOperation = this.oModel.bindContext("/ValidateFileData(...)");
                oOperation.setParameter('Header', oParsedData.Header);
                oOperation.setParameter('Item', oParsedData.Item);
                // if (sPartValidString.toUpperCase().includes("IF YOU SEE HERE SOME PARTS")) {
                //     this.getView().getModel("ViewModel").setProperty("/PartValidFailed", false);
                // }
                if (aPartValid.length <= 1) {
                    this.getView().getModel("ViewModel").setProperty("/PartValidFailed", false);
                }
                // Action Import POST call
                await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();

                    if (oOperationContext.getObject().ValidationPassed) {
                        let oResponseData = oOperationContext.getObject();
                        this.getView().getModel("ViewModel").setProperty("/ExistingCWAID", oResponseData.AdditionalDetails.ExistingCWAID);
                        this.getView().getModel("ViewModel").setProperty("/ExistingCWAName", oResponseData.AdditionalDetails.ExistingCWAName);
                        this.setCWAData(oParsedData, oResponseData);
                        this.setViewModelData(oParsedData, oResponseData);
                        if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue) {
                            this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue("00");
                            this.bDefaultValueSet = true;
                        }
                        if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setText) {
                            this.byId("ReqPlanVersionSf").getInnerControls()[0].setText("00");
                            this.bDefaultValueSet = true;
                        }
                        if (oOperationContext.getObject().Message) {
                            MessageBox.information(oOperationContext.getObject().Message);
                        }
                    } else {
                        this.setCWAData();
                        this.setViewModelData();
                        this.getView().getModel("ViewModel").setProperty("/CWAItemAttachments", []);
                        this.byId("CWAItemAttachment").clear();
                        this.byId("CWAItemAttachment").setValue();
                        MessageBox.error(oOperationContext.getObject().Message);
                    }
                    this.hideBusyIndicator();

                }.bind(this))
                    .catch(function (oError) {
                        this.hideBusyIndicator();
                        MessageBox.error(oError.toString());
                    }.bind(this));
            },

            // Returns payload for Action Import
            prepareCWAFileData: function (oCWAFileDataJSON) {
                var oHeaderData = {
                    "Site": oCWAFileDataJSON[1].value,
                    "Customer": oCWAFileDataJSON[2].value
                }, oItemData = {
                    "FileFromRR": oCWAFileDataJSON[0].value === "x" || oCWAFileDataJSON[0].value === "X" ? true : false,
                    "CurrentMS": parseFloat(oCWAFileDataJSON[3].value),
                    "CurrentMonthShipment": parseFloat(oCWAFileDataJSON[4].value),
                    "ProposedMS": parseFloat(oCWAFileDataJSON[5].value),
                    "BalanceMonth": parseFloat(oCWAFileDataJSON[6].value),
                    "MonthTM1": parseFloat(oCWAFileDataJSON[7].value),
                    "ApprovedWaiver": parseFloat(oCWAFileDataJSON[10].value),
                    "ExcessTotalProposed": parseFloat(oCWAFileDataJSON[11].value),
                    "ExcessTotalCurrent": parseFloat(oCWAFileDataJSON[12].value),
                    "ObsoleteTotalProposed": parseFloat(oCWAFileDataJSON[13].value),
                    "ObsoleteTotalCurrent": parseFloat(oCWAFileDataJSON[14].value),
                    "ProfitCenters": this.joinProfiterCenters(oCWAFileDataJSON)
                };
                return { Header: oHeaderData, Item: oItemData };
            },

            // Concatenates profit centers
            joinProfiterCenters: function (oCWAFileDataJSON) {
                var aProfitCenters = [];
                oCWAFileDataJSON.forEach(function (oRow) {
                    if (oRow.Name === "Prof Center") {
                        aProfitCenters.push(oRow.value);
                    }
                });
                return aProfitCenters.join(",");
            },

            // Set CWA Data to the model
            setCWAData: async function (oCWARequestData, oResponseData) {
                if (oCWARequestData) {
                    this.getView().getModel("CWACreateRequestModel").setProperty("/Customer", oCWARequestData.Header.Customer);
                    this.getView().getModel("CWACreateRequestModel").setProperty("/Site", oCWARequestData.Header.Site);
                    this.getView().getModel("CWACreateRequestModel").setProperty("/Region", oResponseData.AdditionalDetails.Region);
                    this.getView().getModel("CWACreateRequestModel").setProperty("/Segment", oResponseData.AdditionalDetails.Segment);
                    this.getView().getModel("CWACreateRequestModel").setProperty("/Division", oResponseData.AdditionalDetails.Division);

                    this.getView().getModel("CWACreateRequestModel").setProperty("/Status", {
                        "name": "0010",
                        "descr": "In Draft"
                    });
                    this.getView().getModel("CWACreateRequestModel").setProperty("/Status_ID", 1);

                    this.getView().getModel("CWACreateRequestModel").setProperty("/CWAItems", [{
                        "FileFromRR": oCWARequestData.Item.FileFromRR,
                        "CurrentMS": oCWARequestData.Item.CurrentMS,
                        "CurrentMonthShipment": oCWARequestData.Item.CurrentMonthShipment,
                        "ProposedMS": oCWARequestData.Item.ProposedMS,
                        "BalanceMonth": oCWARequestData.Item.BalanceMonth,
                        "MonthTM1": oCWARequestData.Item.MonthTM1,
                        "ApprovedWaiver": oCWARequestData.Item.ApprovedWaiver,
                        "ExcessTotalProposed": oCWARequestData.Item.ExcessTotalProposed,
                        "ExcessTotalCurrent": oCWARequestData.Item.ExcessTotalCurrent,
                        "ObsoleteTotalProposed": oCWARequestData.Item.ObsoleteTotalProposed,
                        "ObsoleteTotalCurrent": oCWARequestData.Item.ObsoleteTotalCurrent,
                        "ProfitCenters": oCWARequestData.Item.ProfitCenters
                    }]);

                    // If action is ITEM_CREATE, read HEADER data to sum the amounts of few fields
                    if (oResponseData.Action === "ITEM_CREATE") {
                        var aRequestName = [], aFilters = [];
                        aRequestName.push(new sap.ui.model.Filter("CWAName", sap.ui.model.FilterOperator.EQ, this.getView().getModel("ViewModel").getProperty("/ExistingCWAName")));
                        aFilters.push(new sap.ui.model.Filter(aRequestName, false));

                        await this.readCWAHeader(aFilters).then(function (aContexts) {
                            var aFileIDs = [];

                            aContexts[0].getObject().CWAItems.forEach(function (oContext) {
                                this.getView().getModel("CWACreateRequestModel").getProperty("/CWAItems").push(oContext);
                                aFileIDs.push(oContext.FileID);
                            }.bind(this));

                            this.getView().getModel("CWACreateRequestModel").setProperty("/ID", aContexts[0].getObject().ID);
                            this.getView().getModel("CWACreateRequestModel").setProperty("/Comment", aContexts[0].getObject().Comment);
                            this.getView().getModel("CWACreateRequestModel").setProperty("/SAPReqPlan", aContexts[0].getObject().SAPReqPlan);
                            this.getView().getModel("CWACreateRequestModel").setProperty("/SAPUTCConvert", aContexts[0].getObject().SAPUTCConvert);
                            this.getView().getModel("ViewModel").setProperty("/DmsFolderId", aContexts[0].getObject().DmsFolderId);
                            if (this.byId("TimeZoneSf").getInnerControls().length > 0 && this.byId("TimeZoneSf").getInnerControls()[0].setValue) {
                                this.byId("TimeZoneSf").getInnerControls()[0].setValue(aContexts[0].getObject().SAPLocalTime);
                            }
                            if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue) {
                                this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue(aContexts[0].getObject().SAPReqPlan);
                            }

                            var oCWARequest = JSON.parse(JSON.stringify(this.getView().getModel("CWACreateRequestModel").getProperty("/")));
                            this.getView().getModel("ViewModel").setProperty("/CurrentCWAItems", oCWARequest.CWAItems);
                            this.setCWAItemAttachments(aFileIDs);

                            var aItems = [oCWARequestData.Item];
                            aItems = aItems.concat(aContexts[0].getObject().CWAItems);

                            this.getView().getModel("ViewModel").setProperty("/CWAItemToDisplay",
                                Object.assign({}, this.calculateFieldsBasedOnItems(aItems, true)));

                            this.getView().getModel("CWACreateRequestModel").setProperty("/CWAApprovers", aContexts[0].getObject().CWAApprovers);
                            var aApproversItems = [{
                                "ID": aContexts[0].getObject().CWAApprovers[0].ID,
                                "ApproverLevel": aContexts[0].getObject().CWAApprovers[0].ApproverLevel,
                                "ApproverName": aContexts[0].getObject().CWAApprovers[0].ApproverName,
                                "ApproversList": this.getView().getModel("ViewModel").getProperty("/CWAApprovers/0/ApproversList"),
                                "ApproverEmail": aContexts[0].getObject().CWAApprovers[0].ApproverEmail
                            }, {
                                "ID": aContexts[0].getObject().CWAApprovers[1].ID,
                                "ApproverLevel": aContexts[0].getObject().CWAApprovers[1].ApproverLevel,
                                "ApproverName": aContexts[0].getObject().CWAApprovers[1].ApproverName,
                                "ApproversList": this.getView().getModel("ViewModel").getProperty("/CWAApprovers/1/ApproversList"),
                                "ApproverEmail": aContexts[0].getObject().CWAApprovers[1].ApproverEmail
                            }, {
                                "ID": aContexts[0].getObject().CWAApprovers[2].ID,
                                "ApproverLevel": aContexts[0].getObject().CWAApprovers[2].ApproverLevel,
                                "ApproverName": aContexts[0].getObject().CWAApprovers[2].ApproverName,
                                "ApproversList": this.getView().getModel("ViewModel").getProperty("/CWAApprovers/2/ApproversList"),
                                "ApproverEmail": aContexts[0].getObject().CWAApprovers[2].ApproverEmail,
                            }];
                            this.setCWAApproversInView(aApproversItems);

                        }.bind(this))
                            .catch(function (oError) {
                                this.resetCWAData();
                                this.hideBusyIndicator();
                                MessageBox.error(oError.toString());
                            }.bind(this));
                    }

                } else {
                    this.resetCWAData();
                }
                this.hideBusyIndicator();
            },

            // Sets ViewModel data
            setViewModelData: function (oCWARequestData, oResponseData) {
                if (oCWARequestData) {
                    this.getView().getModel("ViewModel").setProperty("/Action", oResponseData.Action);
                    this.getView().getModel("ViewModel").setProperty("/ExistingCWAID", oResponseData.AdditionalDetails.ExistingCWAID);
                    this.getView().getModel("ViewModel").setProperty("/ExistingCWAName", oResponseData.AdditionalDetails.ExistingCWAName);

                    if (oResponseData.Action !== "ITEM_CREATE") {
                        this.getView().getModel("ViewModel").setProperty("/CWAItemToDisplay", this.calculateFieldsBasedOnItems([oCWARequestData.Item], true));
                    }

                    this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", oResponseData.AdditionalDetails.SubmitAllowed);
                    this.getView().getModel("ViewModel").setProperty("/SaveAllowed", oResponseData.AdditionalDetails.SaveAllowed);
                    this.getView().getModel("ViewModel").setProperty("/CWAApprovers", []);

                    var aApproversItems = [{
                        "ID": null,
                        "ApproverLevel": "WCM",
                        "ApproverName": "",
                        "ApproversList": oResponseData.AdditionalDetails.CWAApprovers.WCM,
                        "ApproverEmail": ""
                    }, {
                        "ID": null,
                        "ApproverLevel": "BUM",
                        "ApproverName": "",
                        "ApproversList": oResponseData.AdditionalDetails.CWAApprovers.BUM,
                        "ApproverEmail": ""
                    }, {
                        "ID": null,
                        "ApproverLevel": "SPM",
                        "ApproverName": "",
                        "ApproversList": oResponseData.AdditionalDetails.CWAApprovers.SPM,
                        "ApproverEmail": ""
                    }];
                    this.setCWAApproversInView(aApproversItems);
                } else {
                    this.getView().getModel("ViewModel").setProperty("/Action", undefined);
                    this.getView().getModel("ViewModel").setProperty("/ExistingCWAID", undefined);
                    this.getView().getModel("ViewModel").setProperty("/ExistingCWAName", "");
                    this.getView().getModel("ViewModel").setProperty("/CWAItemToDisplay", {});
                    // this.getView().getModel("ViewModel").setProperty("/CurrentCWAItem", {});
                    this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", false);
                    this.getView().getModel("ViewModel").setProperty("/SaveAllowed", false);
                    this.getView().getModel("ViewModel").setProperty("/PartValidFailed", true);
                    this.getView().getModel("ViewModel").setProperty("/ExportMS", []);
                    this.setCWAApproversInView([]);
                }
            },

            // Sets CWA Approvers in the viewModel property CWAApprovers
            setCWAApproversInView: function (aApproversItems) {
                this.getView().getModel("ViewModel").setProperty("/CWAApprovers", aApproversItems);
            },

            // Reset CWA Data in the view
            resetCWAData: function (bRetainFile) {
                this.resetCWAViewData(false);
                var oCWACreateRequestModel = Object.assign({}, this.prepareCWACreateRequestObject());
                this.getView().getModel("CWACreateRequestModel").setProperty("/", oCWACreateRequestModel);
                this.getView().getModel("CWACreateRequestModel").setProperty("/Status/name", "");
                if (!bRetainFile) {
                    this.byId("CWAItemAttachment").clear();
                    this.byId("CWAItemAttachment").setValue();
                }
                this.byId("CWAAttachment").clear();
                this.byId("CWAAttachment").setValue();
            },

            // Resets ViewModel data
            resetCWAViewData: function (bGo) {
                if (!bGo) {
                    this.getView().getModel("ViewModel").setProperty("/InputCWARequestName", "");
                }
                this.getView().getModel("ViewModel").setProperty("/CWAItemToDisplay", {});
                this.getView().getModel("ViewModel").setProperty("/ExistingCWAID", "");
                this.getView().getModel("ViewModel").setProperty("/ExistingCWAName", "");
                this.getView().getModel("ViewModel").setProperty("/Action", "");
                this.getView().getModel("ViewModel").setProperty("/DmsFolderId", "");
                this.getView().getModel("ViewModel").setProperty("/CWAItemAttachments", []);
                this.getView().getModel("ViewModel").setProperty("/CWAAttachments", []);
                this.getView().getModel("ViewModel").setProperty("/DeleteCWAAttachments", []);
                this.getView().getModel("ViewModel").setProperty("/DeletedCWAAttachments", []);
                this.getView().getModel("ViewModel").setProperty("/DeletedCWAItemAttachments", []);
                this.getView().getModel("ViewModel").setProperty("/CWAItemToDisplay", {});
                this.getView().getModel("ViewModel").setProperty("/CurrentItemAttachment", {});
                this.getView().getModel("ViewModel").setProperty("/CWAApprovers", []);
                this.getView().getModel("ViewModel").setProperty("/SaveAllowed", false);
                this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", false);
                this.getView().getModel("ViewModel").setProperty("/CurrentCWAItems", []);
                this.getView().getModel("ViewModel").setProperty("/CurrentCWAAttachments", []);
                this.getView().getModel("ViewModel").setProperty("/DeletedCWAItems", []);
                this.getView().getModel("ViewModel").setProperty("/ToBeDeletedDocumentIDs", []);
                this.getView().getModel("ViewModel").setProperty("/ToBeDeletedDMSDocumentIDs", []);
                this.getView().getModel("ViewModel").setProperty("/ChangedApprovers", []);
                this.getView().getModel("ViewModel").setProperty("/ReadViaGo", false);
                this.getView().getModel("ViewModel").setProperty("/PartValidFailed", true);
                this.getView().getModel("ViewModel").setProperty("/ExportMS", []);
                this.getView().getModel("ViewModel").setProperty("/FileUpload", true);
                this.getView().getModel("ViewModel").setProperty("/CreateErrorMessages", []);
                this.getView().getModel("ViewModel").setProperty("/SubmitResponse", {});

                if (this.byId("TimeZoneSf").getInnerControls().length > 0 && this.byId("TimeZoneSf").getInnerControls()[0].setValue) {
                    this.byId("TimeZoneSf").getInnerControls()[0].setValue("");
                }
                if (this.byId("TimeZoneSf").getInnerControls().length > 0 && this.byId("TimeZoneSf").getInnerControls()[0].setText) {
                    this.byId("TimeZoneSf").getInnerControls()[0].setText("");
                }
                if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue) {
                    this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue("");
                }
                if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setText) {
                    this.byId("ReqPlanVersionSf").getInnerControls()[0].setText("");
                }
                this.bDefaultValueSet = false;

            },

            // GET call to read CWA entered
            readCWAHeader: function (aFilters) {
                return new Promise(async function (resolve, reject) {
                    var oList = this.oModel.bindList("/Header", null, null, aFilters, {
                        $expand: "CWAItems($expand=CWAAttachments($expand=FileID),FileID),Status,CWAApprovers"
                    });

                    // READ request
                    await oList.requestContexts().then(function (aContexts) {
                        resolve(aContexts);
                    }.bind(this))
                        .catch(function (oError) {
                            reject(oError);
                        });
                }.bind(this));
            },

            // press Event handler method of Submit Button
            onCWARequestSubmit: function () {
                if (this.validateRequiredFields()) {
                    if (!this.getView().getModel("ViewModel").getProperty("/ReadViaGo") && this.getView().getModel("ViewModel").getProperty("/PartValidFailed")) {
                        MessageBox.warning(this.i18n.getText("requiredPartsValid"), {
                            icon: MessageBox.Icon.QUESTION,
                            actions: ["Modify", "Proceed to Submit"],
                            onClose: function (oAction) {
                                if (oAction === "Proceed to Submit") {
                                    this.performPOSTOperation(true);
                                }
                            }.bind(this)
                        });
                    } else {
                        this.performPOSTOperation(true);
                    }
                }

            },

            // press Event handler method of Save Button
            onCWARequestSave: function () {
                if (this.validateRequiredFields()) {
                    // this.performPOSTOperation(false);
                    if (!this.getView().getModel("ViewModel").getProperty("/ReadViaGo") && this.getView().getModel("ViewModel").getProperty("/PartValidFailed")) {
                        MessageBox.warning(this.i18n.getText("requiredPartsValidSave"), {
                            icon: MessageBox.Icon.QUESTION,
                            actions: ["Modify", "Proceed to Save"],
                            onClose: function (oAction) {
                                if (oAction === "Proceed to Save") {
                                    this.performPOSTOperation(false);
                                }
                            }.bind(this)
                        });
                    } else {
                        this.performPOSTOperation(false);
                    }
                }
            },

            // Validate Required fields for Save and Submit
            validateRequiredFields: function () {
                var aApprovers = this.getView().getModel("ViewModel").getProperty("/CWAApprovers");
                var aErrorMessages = [];
                var bDeletion = Boolean(this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").length === 0
                    && this.getView().getModel("ViewModel").getProperty("/Action") === "HEADER_UPDATE");
                if (!aApprovers[0].ApproverName || !aApprovers[1].ApproverName || !aApprovers[2].ApproverName && !bDeletion) {
                    aErrorMessages.push(this.i18n.getText("requiredFieldsCWAApprovers"));
                }

                if (!this.byId("ReqPlanVersionSf").getValue() && !bDeletion) {
                    aErrorMessages.push(this.i18n.getText("requiredSAPReqPlan"));
                }

                if (aErrorMessages.length > 0 && !bDeletion) {
                    aErrorMessages.push(this.i18n.getText("msgPleaseTryAgain"));
                    var sErrorMessage = aErrorMessages.join(" \n\n ");
                    MessageBox.error(sErrorMessage);
                    return false;
                }
                return true;
            },

            // POST operation on SAVE and SUBMIT
            performPOSTOperation: async function (bSubmit) {
                var sText = bSubmit ? "Submitted" : "Saved";
                this.showBusyIndicator();
                this.removeAllMessages();
                switch (this.getView().getModel("ViewModel").getProperty("/Action")) {
                    case "HEADER_CREATE":
                        // CWA Header Create
                        await this.performHeaderCreate(bSubmit)
                            .then(function () {
                                var sName = this.getView().getModel("ViewModel").getProperty("/ExistingCWAName");
                                MessageToast.show(this.i18n.getText("cwaSaved", [sName]));
                                this.removeAllMessages();
                                // Upload Attachments - Item
                                return this.uploadCWAItemAttachment(this.getView().getModel("ViewModel").getProperty("/DmsFolderId"));
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Update File Id in CWA Item
                                return this.updateFileIdInCWAItem();
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Upload Attachments - Attachment
                                return this.uploadCWAAttachment(this.getView().getModel("ViewModel").getProperty("/DmsFolderId"));
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Update File Id in Attachment
                                return this.updateFileIdInCWAAttachment();
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Submit Operation
                                return this.submitCWA(bSubmit);

                            }.bind(this))
                            .then(function () {
                                var sCWAName = this.getView().getModel("ViewModel").getProperty("/ExistingCWAName");
                                this.displayMessage(sCWAName, bSubmit, sText);
                                this.hideBusyIndicator();
                            }.bind(this))
                            .catch(function (sError) {
                                this.hideBusyIndicator();
                                this.displayErrorMessage(sError);
                            }.bind(this));
                        break;
                    case "ITEM_CREATE":
                        this.setToBeUpdatedApprovers();
                        await this.performItemCreate(bSubmit)
                            .then(function () {
                                var sName = this.getView().getModel("ViewModel").getProperty("/ExistingCWAName");
                                MessageToast.show(this.i18n.getText("cwaSaved", [sName]));
                                // Upload Attachments - Item
                                this.removeAllMessages();
                                return this.uploadCWAItemAttachment(this.getView().getModel("ViewModel").getProperty("/DmsFolderId"));
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Update File Id in CWA Item
                                return this.updateFileIdInCWAItem();
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Upload Attachments - Attachment
                                return this.uploadCWAAttachment(this.getView().getModel("ViewModel").getProperty("/DmsFolderId"));
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Delete CWA Attachments
                                return this.deleteCWAAttachments();
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Update File Id in Attachment
                                return this.updateFileIdInCWAAttachment();
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Update CWA Header Fields
                                return this.updateCWAHeaderFields();
                            }.bind(this))
                            .then(function () {
                                this.removeAllMessages();
                                // Submit Operation
                                return this.submitCWA(bSubmit);
                            }.bind(this))
                            .then(function () {
                                var sCWAName = this.getView().getModel("ViewModel").getProperty("/ExistingCWAName");
                                this.displayMessage(sCWAName, bSubmit, sText);
                                this.hideBusyIndicator();
                            }.bind(this))
                            .catch(function (sError) {
                                this.hideBusyIndicator();
                                this.displayErrorMessage(sError);
                            }.bind(this));
                        break;
                    case "HEADER_UPDATE":
                        this.setToBeUpdatedApprovers();
                        if (this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").length === 0) {
                            await this.deleteCWAHeader()
                                .then(function () {
                                    this.removeAllMessages();
                                    // Delete CWA attachments
                                    return this.deleteCWAAttachments();
                                }.bind(this))
                                .then(function () {
                                    var sCWAName = this.getView().getModel("CWACreateRequestModel").getProperty("/CWAName");
                                    sText = this.i18n.getText("deletedMsg");
                                    MessageBox.success(this.i18n.getText("cwaHeaderDeleteSuccessMsg", [sCWAName, sText]));
                                    this.resetCWAData();
                                    this.hideBusyIndicator();
                                }.bind(this))
                                .catch(function (sError) {
                                    this.hideBusyIndicator();
                                    this.displayErrorMessage(sError);
                                }.bind(this));
                        } else {
                            // Update CWA Header Fields
                            await this.updateCWAHeaderFields()
                                .then(function () {
                                    this.removeAllMessages();
                                    // Delete CWA attachments
                                    return this.deleteCWAAttachments();
                                }.bind(this))
                                .then(function () {
                                    this.removeAllMessages();
                                    return this.submitCWA(bSubmit);
                                }.bind(this))
                                .then(function () {
                                    var sCWAName = this.getView().getModel("CWACreateRequestModel").getProperty("/CWAName");
                                    this.displayMessage(sCWAName, bSubmit, sText);
                                    this.hideBusyIndicator();
                                }.bind(this))
                                .catch(function (sError) {
                                    this.hideBusyIndicator();
                                    this.displayErrorMessage(sError);
                                }.bind(this));
                        }
                }
            },

            // Display message based on ODATA response
            displayMessage: function (sCWAName, bSubmit, sText) {
                if (!bSubmit) {
                    MessageBox.success(this.i18n.getText("cwaItemSuccessMsg", [sCWAName, sText]), {
                        actions: [this.i18n.getText("btnNavigate"), MessageBox.Action.CLOSE],
                        emphasizedAction: this.i18n.getText("btnNavigate"),
                        onClose: function (sAction) {
                            if (sAction === "Navigate") {
                                this.resetCWAData();
                                this.triggerGOOnSuccess(sCWAName);
                                this.navigateToDashboardApp(sCWAName);
                            } else {
                                this.resetCWAData();
                                this.triggerGOOnSuccess(sCWAName);
                            }
                        }.bind(this)
                    });
                } else {
                    this.displaySubmitMessage(sCWAName);
                }
            },

            // Display message based on ODATA response - SUBMIT
            displaySubmitMessage: function (sCWAName) {
                var oResponse = this.getView().getModel("ViewModel").getProperty("/SubmitResponse");
                if (oResponse.BackendError) {
                    console.log(oResponse.BackendErrorObject);
                    if (oResponse.SimulationResults.length === 0) {
                        MessageBox.error(oResponse.DisplayMessage);
                    } else {
                        MessageBox.error(oResponse.DisplayMessage, {
                            actions: [this.i18n.getText("btnDownload"), MessageBox.Action.CLOSE],
                            emphasizedAction: this.i18n.getText("btnDownload"),
                            onClose: function (sAction) {
                                if (sAction === "Download") {
                                    this.downloadSimulateErrorMessages();
                                }
                            }.bind(this)
                        });
                    }
                } else {
                    if (oResponse.SimulationResults.length > 0) {
                        MessageBox.success(oResponse.DisplayMessage, {
                            actions: [this.i18n.getText("btnDownload"), this.i18n.getText("btnNavigate"), MessageBox.Action.CLOSE],
                            emphasizedAction: this.i18n.getText("btnDownload"),
                            onClose: function (sAction) {
                                if (sAction === "Download") {
                                    this.downloadSimulateErrorMessages();
                                    this.resetCWAData();
                                    this.triggerGOOnSuccess(sCWAName);
                                } else if (sAction === "Navigate") {
                                    this.resetCWAData();
                                    this.triggerGOOnSuccess(sCWAName);
                                    this.navigateToDashboardApp(sCWAName);
                                } else {
                                    this.resetCWAData();
                                    this.triggerGOOnSuccess(sCWAName);
                                }
                            }.bind(this)
                        });
                    } else {
                        MessageBox.success(oResponse.DisplayMessage, {
                            actions: [this.i18n.getText("btnNavigate"), MessageBox.Action.CLOSE],
                            emphasizedAction: this.i18n.getText("btnNavigate"),
                            onClose: function (sAction) {
                                if (sAction === "Navigate") {
                                    this.resetCWAData();
                                    this.triggerGOOnSuccess(sCWAName);
                                    this.navigateToDashboardApp(sCWAName);
                                } else {
                                    this.resetCWAData();
                                    this.triggerGOOnSuccess(sCWAName);
                                }
                            }.bind(this)
                        });
                    }
                }
            },

            // Display Message for Simulation Error
            displayCreateSimulationError: function () {
                MessageBox.error(this.i18n.getText("cwaSimulationError"), {
                    actions: [this.i18n.getText("btnDownload"), MessageBox.Action.CLOSE],
                    emphasizedAction: this.i18n.getText("btnDownload"),
                    onClose: function (sAction) {
                        if (sAction === "Download") {
                            this.downloadSimulateErrorMessages();
                        }
                    }.bind(this)
                });
            },

            // Action Import call for Submit CWA
            submitCWA: function (bSubmit) {
                return new Promise(async function (resolve, reject) {
                    this.getView().getModel("ViewModel").setProperty("/SubmitResponse", {});
                    if (!bSubmit) {
                        resolve();
                    } else {
                        var oOperation = this.oModel.bindContext("/SubmitCWA(...)");
                        var sID = this.getView().getModel("CWACreateRequestModel").getProperty("/ID");
                        oOperation.setParameter('ID', sID);
                        // Action Import POST call
                        await oOperation.invoke().then(function () {
                            var oOperationContext = oOperation.getBoundContext();
                            this.getView().getModel("ViewModel").setProperty("/SubmitResponse", oOperationContext.getObject());
                            resolve();

                        }.bind(this))
                            .catch(function (oError) {
                                this.resetCWAData();
                                this.hideBusyIndicator();
                                reject(oError.toString());
                            }.bind(this));
                    }
                }.bind(this));
            },

            // Get error message from response
            getErrorMessageFromResponse: function (oResponseObject) {
                this.getView().getModel("ViewModel").setProperty("/SubmitResponse", oResponseObject);
                if (oResponseObject && oResponseObject.SimulationResults) {
                    this.getView().getModel("ViewModel").setProperty("/CreateErrorMessages", oMessage.SimulationResults);
                    return "Create Simulation Error";
                }
                return "";
            },

            // Sets CWAName on Success
            triggerGOOnSuccess: function (sCWAName) {
                this.getView().getModel("ViewModel").setProperty("/InputCWARequestName", sCWAName);
            },

            // Sets ToBeUpdated Approvers during SAVE or SUBMIT
            setToBeUpdatedApprovers: function () {
                var aDBApprovers = this.getView().getModel("CWACreateRequestModel").getProperty("/").CWAApprovers;
                var oCWARequest = JSON.parse(JSON.stringify(this.getView().getModel("ViewModel").getProperty("/")));
                var aCWAApprovers = oCWARequest.CWAApprovers;
                var aChangedApprovers = [];
                var aWCM = [], aBUM = [], aSPM = [];
                aWCM = aDBApprovers.filter(function (oApprover) {
                    return oApprover.ApproverLevel === "WCM" && aCWAApprovers[0].ApproverName === oApprover.ApproverName
                });
                aBUM = aDBApprovers.filter(function (oApprover) {
                    return oApprover.ApproverLevel === "BUM" && aCWAApprovers[1].ApproverName === oApprover.ApproverName
                });
                aSPM = aDBApprovers.filter(function (oApprover) {
                    return oApprover.ApproverLevel === "SPM" && aCWAApprovers[2].ApproverName === oApprover.ApproverName
                });
                if (aWCM.length === 0) {
                    aChangedApprovers.push(aCWAApprovers[0]);
                }
                if (aBUM.length === 0) {
                    aChangedApprovers.push(aCWAApprovers[1]);
                }
                if (aSPM.length === 0) {
                    aChangedApprovers.push(aCWAApprovers[2]);
                }
                this.getView().getModel("ViewModel").setProperty("/ChangedApprovers", aChangedApprovers);
            },

            // Display error message
            displayErrorMessage: function (sError) {
                MessageBox.error(sError);
            },

            // ODATA Create for Header
            performHeaderCreate: function (bSubmit) {
                return new Promise(function (resolve, reject) {
                    var oList = this.oModel.bindList("/Header");
                    var oCWAHeader = this.prepareCreatePayload(bSubmit);
                    var oContext = oList.create(oCWAHeader, true);
                    oList.attachCreateCompleted(function (oEvent) {
                        if (oEvent.getParameters().success) {
                            this.getView().getModel("CWACreateRequestModel").setProperty("/CWAName", oEvent.getParameters().context.getObject().CWAName);
                            this.getView().getModel("CWACreateRequestModel").setProperty("/ID", oEvent.getParameters().context.getObject().ID);
                            this.getView().getModel("ViewModel").setProperty("/ExistingCWAName", oEvent.getParameters().context.getObject().CWAName);
                            this.getView().getModel("ViewModel").setProperty("/InputCWARequestName", oEvent.getParameters().context.getObject().CWAName);
                            this.getView().getModel("ViewModel").setProperty("/DmsFolderId", oEvent.getParameters().context.getObject().DmsFolderId);
                            this.getView().getModel("CWACreateRequestModel").setProperty("/CWAItems", oEvent.getParameters().context.getObject().CWAItems);
                            resolve();
                        } else {
                            var sMessage = this.getErrorMessagesForCreate();
                            if (sMessage) {
                                reject(sMessage);
                            } else {
                                reject(this.i18n.getText("operationFailed"));
                            }

                        }
                    }.bind(this));
                }.bind(this));
            },

            getErrorMessagesForCreate: function () {
                var aMessageData = this.getView().getModel("messageModel").getData();
                if (aMessageData && aMessageData.length && aMessageData[0].message.includes("SimulationResults")) {
                    this.getView().getModel("ViewModel").setProperty("/CreateErrorMessages", JSON.parse(aMessageData[0].message).SimulationResults);
                    if (JSON.parse(aMessageData[0].message).BackendError) {
                        return JSON.parse(aMessageData[0].message).SimulationResults[0].reason.message;
                    } else {
                        return "Create Simulation Error";
                    }
                }
                if (aMessageData && aMessageData.length && aMessageData[0].message) {
                    return aMessageData[0].message;
                }
            },

            // Returns payload for Header ODATA create
            prepareCreatePayload: function (bSubmit) {
                var oCWAHeader = JSON.parse(JSON.stringify(this.getView().getModel("CWACreateRequestModel").getProperty("/")));
                var aCWAApprovers = this.prepareCWAApprovers();
                oCWAHeader.CWAApprovers = aCWAApprovers;
                delete oCWAHeader.Status;
                var aAttachments = this.getView().getModel("ViewModel").getProperty("/CWAAttachments");
                oCWAHeader.CWAItems[0].CWAAttachments = [];
                oCWAHeader.CWAItems[0].Action = bSubmit ? 2 : 1;
                oCWAHeader.CurrentApprover = aCWAApprovers[0].ApproverEmail;
                oCWAHeader.CurrentApproverLevel = aCWAApprovers[0].ApproverLevel;
                // Setting FileID null will create empty Attachment objects based on no of attachments uploaded for this item
                aAttachments.forEach(function () {
                    oCWAHeader.CWAItems[0].CWAAttachments.push({
                        FileID: null
                    });
                });
                oCWAHeader.SAPLocalTime = this.byId("TimeZoneSf").getValue();
                oCWAHeader.SAPReqPlan = this.byId("ReqPlanVersionSf").getValue();
                return oCWAHeader;
            },

            // Prepare CWA Approvers for POST operation
            prepareCWAApprovers: function () {
                var oCWAApprovers = Object.assign({}, this.getView().getModel("ViewModel").getProperty("/"));
                var aCWAApprovers = oCWAApprovers.CWAApprovers;
                var aPayloadCWAApporvers = [];
                aCWAApprovers.forEach(function (oApprover) {
                    delete oApprover.ApproversList;
                    delete oApprover.ID;
                    aPayloadCWAApporvers.push(oApprover);
                });
                return aPayloadCWAApporvers;

            },

            // ODATA Create for Item
            performItemCreate: function (bSubmit) {
                return new Promise(async function (resolve, reject) {
                    var oList = this.oModel.bindList("/Items");
                    var oCWAItems = this.prepareCreatePayload(bSubmit).CWAItems[0];
                    oCWAItems.Parent_ID = this.getView().getModel("ViewModel").getProperty("/ExistingCWAID");
                    var oContext = oList.create(oCWAItems, true);
                    await oList.attachCreateCompleted(function (oEvent) {
                        if (oEvent.getParameters().success) {
                            this.getView().getModel("CWACreateRequestModel").setProperty("/CWAItems/0/ID", oEvent.getParameters().context.getObject().ID);
                            if (oEvent.getParameters().context.getObject().CWAAttachments.length > 0) {
                                this.getView().getModel("CWACreateRequestModel").setProperty("/CWAItems/0/CWAAttachments", oEvent.getParameters().context.getObject().CWAAttachments);
                            } else {
                                this.getView().getModel("CWACreateRequestModel").setProperty("/CWAItems/0/CWAAttachments", []);
                            }
                            resolve();
                        } else {
                            var sMessage = this.getErrorMessagesForCreate();
                            if (sMessage) {
                                reject(sMessage);
                            } else {
                                reject(this.i18n.getText("operationFailed"));
                            }
                        }
                    }.bind(this));
                }.bind(this));
            },

            // Upload item attachment to DMS
            uploadCWAItemAttachment: function (sFolderId) {
                return new Promise(async function (resolve, reject) {
                    await this.performUploadItemAttachment(sFolderId).then(function (sFileId) {
                        var oDocument = {
                            "FileKind": {
                                "ID": 2
                            },
                            "DmsDocumentId": sFileId,
                            // "DocumentName": this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment").name.split(".")[0],
                            // "DocumentType": this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment").name.split(".")[1]
                            "DocumentName": this.returnFileName(this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment").name),
                            "DocumentType": this.returnFileType(this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment").name)
                        };
                        return this.updateDocumentDetailsForItem(oDocument, true);
                    }.bind(this))
                        .then(function () {
                            resolve();
                        })
                        .catch(function (sError) {
                            reject(sError);
                        });

                }.bind(this))
            },

            // Perform upload item attachment to DMS
            performUploadItemAttachment: async function (sFolderId) {
                return new Promise(async function (resolve, reject) {
                    var oUploadPayload = {
                        "folderID": this.getView().getModel("CWACreateRequestModel").getProperty("/ID"),
                        "content": this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment").Content,
                        "mediaType": this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment").type,
                        "fileName": this.getView().getModel("ViewModel").getProperty("/CurrentItemAttachment").name,
                        "fileID": null
                    };
                    var oOperation = this.oModel.bindContext("/CreateMediaFile(...)");
                    oOperation.setParameter('FileData', oUploadPayload);
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        resolve(oOperationContext.getObject().folderID);
                    }.bind(this))
                        .catch(function (oError) {
                            reject(oError);
                        }.bind(this));
                }.bind(this));
            },

            getErrorMessagesForItemUpload: function () {
                var aMessageData = this.getView().getModel("messageModel").getData();
                if (aMessageData && aMessageData.length && aMessageData[0].message) {
                    return aMessageData[0].message;
                }
            },

            // genereateGUID: function () {
            //     var w = () => { return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1); }
            //     return `${w()}${w()}-${w()}-${w()}-${w()}-${w()}${w()}${w()}`;
            // },

            // CREATE operation of Document entity
            updateDocumentDetailsForItem: async function (oDocument) {
                return new Promise(async function (resolve, reject) {
                    var oList = this.oModel.bindList("/Documents");
                    var oContext = oList.create(oDocument, true);
                    oList.attachCreateCompleted(await function (oEvent) {
                        if (oEvent.getParameters().success) {
                            this.iFileId = oEvent.getParameters().context.getObject().ID;
                            resolve();
                        } else {
                            var sMessage = this.getErrorMessagesForItemUpload();
                            if (sMessage) {
                                reject(sMessage);
                            } else {
                                reject(this.i18n.getText("operationFailed"));
                            }
                        }
                    }.bind(this));
                }.bind(this));
            },

            // Update FileID_ID foreign key in Items
            updateFileIdInCWAItem: async function () {
                return new Promise(async function (resolve, reject) {
                    var oContextBinding = this.oModel.bindContext("/Items(" + this.getView().getModel("CWACreateRequestModel").getProperty("/CWAItems/0/ID") + ")", null, {
                        $$updateGroupId: "CWAItemChange",
                        $expand: "FileID"
                    });
                    await oContextBinding.requestObject().then(function () {
                        oContextBinding.getBoundContext().setProperty("FileID_ID", this.iFileId);
                    }.bind(this));
                    await this.oModel.submitBatch("CWAItemChange").then(function () {
                        resolve();
                    }).catch(function (oError) {
                        reject(oError);
                    }.bind(this));
                }.bind(this));
            },

            // Upload other attachments to DMS - CWAAttachments
            uploadCWAAttachment: function (sFolderId) {

                return new Promise(async function (resolve, reject) {
                    var aPromises = [];
                    var oRequest = Object.assign({}, this.getView().getModel("ViewModel").getProperty("/"));
                    var aAttachments = oRequest.CWAAttachments;
                    aAttachments.forEach(function (oAttachment) {
                        // delete oAttachment.Document;
                        aPromises.push(this.performCWAAttachmentUpload(oAttachment));
                    }.bind(this));

                    Promise.all(aPromises).then(function () {
                        resolve();
                    }, function (sError) {
                        reject(sError);
                    });

                }.bind(this))
            },

            // perform Upload other attachments to DMS - CWAAttachments and update Document entity
            performCWAAttachmentUpload: async function (oAttachment) {
                return new Promise(async function (resolve, reject) {
                    await this.performUploadAttachment(oAttachment).then(function (sFileId) {
                        var oDocument = {
                            "FileKind": {
                                "ID": 1
                            },
                            "DmsDocumentId": sFileId,
                            // "DocumentName": oAttachment.Document.name.split(".")[0],
                            // "DocumentType": oAttachment.Document.name.split(".")[1]
                            "DocumentName": this.returnFileName(oAttachment.Document.name),
                            "DocumentType": this.returnFileType(oAttachment.Document.name)
                        };
                        return this.callUpdateDocumentAttach(oDocument);
                    }.bind(this))
                        .then(function () {
                            resolve();
                        })
                        .catch(function (sError) {
                            reject(sError);
                        });
                }.bind(this));
            },

            // Uplaod other attachment
            performUploadAttachment: function (oAttachment) {
                return new Promise(async function (resolve, reject) {
                    var oUploadPayload = {
                        "folderID": this.getView().getModel("CWACreateRequestModel").getProperty("/ID"),
                        "content": oAttachment.Content,
                        "mediaType": oAttachment.Document.type,
                        "fileName": oAttachment.Document.name,
                    };
                    var oOperation = this.oModel.bindContext("/CreateMediaFile(...)");
                    oOperation.setParameter('FileData', oUploadPayload);
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        resolve(oOperationContext.getObject().folderID);
                    }.bind(this))
                        .catch(function (oError) {
                            reject(oError);
                        }.bind(this));
                }.bind(this));
            },

            // Update document details
            updateDocumentDetailsForAttachment: async function () {
                return new Promise(async function (resolve, reject) {
                    var oRequest = Object.assign({}, this.getView().getModel("ViewModel").getProperty("/"));
                    var aAttachments = oRequest.CWAAttachments;
                    var aPromises = [];
                    aAttachments.forEach(function (oAttachment) {
                        delete oAttachment.Document;
                        aPromises.push(this.callUpdateDocumentAttach(oAttachment));
                    }.bind(this));
                    Promise.all(aPromises).then(function () {
                        resolve();
                    }, function (sError) {
                        reject(sError);
                    });
                }.bind(this));
            },

            // Update document details
            callUpdateDocumentAttach: function (oDocument) {
                return new Promise(async function (resolve, reject) {
                    this.aFileIdAttachment = [];
                    var oList = this.oModel.bindList("/Documents");
                    var oContext = oList.create(oDocument, true);
                    oList.attachCreateCompleted(await function (oEvent) {
                        if (oEvent.getParameters().success) {
                            this.aFileIdAttachment.push(oEvent.getParameters().context.getObject().ID);
                            resolve();
                        } else {
                            this.aFileIdAttachment = [];
                            var sMessage = this.getErrorMessagesForItemUpload();
                            if (sMessage) {
                                reject(sMessage);
                            } else {
                                reject(this.i18n.getText("operationFailed"));
                            }
                        }
                    }.bind(this));
                }.bind(this));
            },

            // Delete CWA Attachments - item files, other attachment and respective Document entity data
            deleteCWAAttachments: function () {
                return new Promise(async function (resolve, reject) {
                    var aAttachments = this.getView().getModel("ViewModel").getProperty("/DeletedCWAItemAttachments");
                    var aPromises = [];

                    // Delete document of the CWA Item
                    aAttachments.forEach(function (oAttachment) {
                        var oContextBinding = this.oModel.bindContext("/Documents(" + oAttachment.ID + ")", null, {
                            $$updateGroupId: "CWAAttachmentDelete",
                        });
                        aPromises.push(this.requestCWAAttachmentDelete(oContextBinding));
                        aPromises.push(this.deleteFileFromDMS(oAttachment.DmsDocumentId));
                    }.bind(this));

                    // Delete Documents of the attachments present for the Item
                    var aToBeDeletedDocumentIDs = this.getView().getModel("ViewModel").getProperty("/ToBeDeletedDocumentIDs");
                    aToBeDeletedDocumentIDs.forEach(function (iDocumentId) {
                        var oDocContextBinding = this.oModel.bindContext("/Documents(" + iDocumentId + ")", null, {
                            $$updateGroupId: "CWAAttachmentDelete",
                        });
                        aPromises.push(this.requestCWAAttachmentDelete(oDocContextBinding));
                    }.bind(this));

                    // Delete DMS File
                    var aToBeDeletedDMSDocumentIDs = this.getView().getModel("ViewModel").getProperty("/ToBeDeletedDMSDocumentIDs");
                    aToBeDeletedDMSDocumentIDs.forEach(function (iDocumentId) {
                        aPromises.push(this.deleteFileFromDMS(iDocumentId));
                    }.bind(this));

                    // Delete CWA Item
                    var aDeletedItems = this.getView().getModel("ViewModel").getProperty("/DeletedCWAItems");
                    if (this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").length !== 0) {
                        aDeletedItems.forEach(function (oItem) {
                            var oItemContextBinding = this.oModel.bindContext("/Items(" + oItem.ID + ")", null, {
                                $$updateGroupId: "CWAAttachmentDelete",
                            });
                            aPromises.push(this.requestCWAAttachmentDelete(oItemContextBinding));
                        }.bind(this));
                    }

                    // Delete Attachments
                    if (this.getView().getModel("ViewModel").getProperty("/ReadViaGo")) {
                        var aToBeDeletedAttachments = this.getView().getModel("ViewModel").getProperty("/DeletedCWAAttachments");
                        aToBeDeletedAttachments.forEach(function (oAttachment) {
                            var oAttachmentContextBinding = this.oModel.bindContext("/Attachments(" + oAttachment.ID + ")", null, {
                                $$updateGroupId: "CWAAttachmentDelete",
                            });
                            aPromises.push(this.requestCWAAttachmentDelete(oAttachmentContextBinding));
                        }.bind(this));
                    }

                    Promise.all(aPromises).then(async function () {
                        await this.oModel.submitBatch("CWAAttachmentDelete").then(function () {
                            resolve();
                        }.bind(this)).catch(function (oError) {
                            reject(this.i18n.getText("deleteFailed"));
                        }.bind(this));
                    }.bind(this), function (sError) {
                        reject(sError);
                    }.bind(this));
                }.bind(this));
            },

            // Delete CWA Attachments delete
            requestCWAAttachmentDelete: function (oContextBinding) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(async function () {
                        oContextBinding.getBoundContext().delete("CWAAttachmentDelete");
                        resolve();
                    }.bind(this), function () {
                        reject();
                    });

                }.bind(this));


            },

            // Delete file from DMS
            deleteFileFromDMS: function (sDocumentId) {
                return new Promise(async function (resolve, reject) {
                    var oOperation = this.oModel.bindContext("/deleteDMSDocument(...)");
                    oOperation.setParameter('docId', sDocumentId);
                    oOperation.setParameter('folderID', this.getView().getModel("CWACreateRequestModel").getProperty("/ID"));
                    await oOperation.invoke().then(function () {
                        var oOperationContext = oOperation.getBoundContext();
                        resolve();
                    }.bind(this))
                        .catch(function (oError) {
                            reject(oError);
                        }.bind(this));
                }.bind(this));
            },

            // Update file id in CWA Attachment table
            updateFileIdInCWAAttachment: function (iID) {
                return new Promise(async function (resolve, reject) {
                    var aAttachments = this.getView().getModel("CWACreateRequestModel").getProperty("/").CWAItems[0].CWAAttachments;

                    var aPromises = [];
                    aAttachments.forEach(function (oAttachment, iIndex) {
                        var oContextBinding = this.oModel.bindContext("/Attachments(" + oAttachment.ID + ")", null, {
                            $$updateGroupId: "CWAAttachmentChange",
                            $expand: "FileID"
                        });
                        aPromises.push(this.requestAttachmentObject(oContextBinding, iIndex));
                    }.bind(this));
                    Promise.all(aPromises).then(async function () {
                        await this.oModel.submitBatch("CWAAttachmentChange").then(function () {
                            resolve();
                        }.bind(this)).catch(function (oError) {
                            reject(oError);
                        }.bind(this));
                    }.bind(this)).catch(function (oError) {
                        reject(oError);
                    }.bind(this));
                }.bind(this));
            },

            // Request CWAAttachment entity object
            requestAttachmentObject: function (oContextBinding, iIndex) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(function () {
                        oContextBinding.getBoundContext().setProperty("FileID_ID", this.aFileIdAttachment[iIndex]);
                        resolve();
                    }.bind(this));
                }.bind(this));
            },

            // Update CWA Header fields in the database
            updateCWAHeaderFields: function () {
                return new Promise(async function (resolve, reject) {
                    var aApprovers = this.getView().getModel("ViewModel").getProperty("/ChangedApprovers");
                    var aPromises = [];

                    var iID = this.getView().getModel("CWACreateRequestModel").getProperty("/ID");
                    var sComment = this.getView().getModel("CWACreateRequestModel").getProperty("/Comment"),
                        sSAPReqPlan = this.getView().getModel("CWACreateRequestModel").getProperty("/SAPReqPlan"),
                        bSAPUTCConvert = this.getView().getModel("CWACreateRequestModel").getProperty("/SAPUTCConvert");

                    var aCWAApprovers = this.prepareCWAApprovers();
                    var sCurrentApprover = aCWAApprovers[0].ApproverEmail;
                    var sCurrentApproverLevel = aCWAApprovers[0].ApproverLevel;

                    aApprovers.forEach(function (oApprover) {
                        var oContextBinding = this.oModel.bindContext("/Approvers(" + oApprover.ID + ")", null, {
                            $$updateGroupId: "CWAHeaderUpdate"
                        });
                        aPromises.push(this.performUpdateCWAApprovers(oContextBinding, oApprover));
                    }.bind(this));

                    var oContextBinding = this.oModel.bindContext("/Header(" + iID + ")", null, {
                        $$updateGroupId: "CWAHeaderUpdate"
                    });
                    aPromises.push(this.performUpdateCWAHeader(oContextBinding, { sComment, sSAPReqPlan, bSAPUTCConvert, sCurrentApprover, sCurrentApproverLevel }));

                    Promise.all(aPromises).then(async function () {
                        await this.oModel.submitBatch("CWAHeaderUpdate").then(function (oPromise) {
                            var oMessage = this.checkForBatchErrorMessage();
                            if (oMessage) {
                                reject(oMessage);
                            } else {
                                resolve();
                            }
                        }.bind(this), function (oError) {
                            reject(oError);
                        }.bind(this))
                    }.bind(this), function (sError) {
                        reject(sError);
                    }.bind(this));
                }.bind(this));
            },

            checkForBatchErrorMessage: function () {
                var aMessages = this._MessageManager.getMessageModel().getProperty("/");
                var aFilter = [];
                if (aMessages.length > 0) {
                    aFilter = aMessages.filter((oMessage) => {
                        return oMessage.target.includes("ReadOnly")
                    });
                }
                if (aFilter.length > 0) {
                    return aFilter[0].getMessage();
                } else if (aMessages.length > 0) {
                    return aMessages[0].getMessage();
                } else {
                    return null;
                }
            },

            // Delete CWA Header from the database
            deleteCWAHeader: function () {
                return new Promise(async function (resolve, reject) {
                    var oHeaderContextBinding = this.oModel.bindContext("/Header(" + this.getView().getModel("CWACreateRequestModel").getProperty("/ID") + ")", null, {
                        $$updateGroupId: "CWAHeaderDelete",
                    });
                    await oHeaderContextBinding.requestObject().then(async function () {
                        oHeaderContextBinding.getBoundContext().delete("CWAHeaderDelete");
                    }.bind(this));
                    await this.oModel.submitBatch("CWAHeaderDelete").then(function () {
                        var oMessage = this.checkForBatchErrorMessage();
                        if (oMessage) {
                            reject(oMessage);
                        } else {
                            resolve();
                        }
                    }.bind(this)).catch(function (oError) {
                        reject(oError);
                    }.bind(this));
                }.bind(this));
            },

            // Update CWA Approvers in the database
            performUpdateCWAApprovers: function (oContextBinding, oApprover) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(function () {
                        oContextBinding.getBoundContext().setProperty("ApproverName", oApprover.ApproverName);
                        oContextBinding.getBoundContext().setProperty("ApproverEmail", oApprover.ApproverEmail);
                        resolve();
                    }.bind(this));
                }.bind(this));
            },

            // Update CWA Header fields in the database
            performUpdateCWAHeader: function (oContextBinding, oUpdate) {
                return new Promise(async function (resolve, reject) {
                    oContextBinding.requestObject().then(function () {

                        oContextBinding.getBoundContext().setProperty("Comment", oUpdate.sComment);
                        oContextBinding.getBoundContext().setProperty("CurrentApprover", oUpdate.sCurrentApprover);
                        oContextBinding.getBoundContext().setProperty("CurrentApproverLevel", oUpdate.sCurrentApproverLevel);
                        oContextBinding.getBoundContext().setProperty("SAPUTCConvert", oUpdate.bSAPUTCConvert);
                        oContextBinding.getBoundContext().setProperty("SAPLocalTime", this.byId("TimeZoneSf").getValue());
                        oContextBinding.getBoundContext().setProperty("SAPReqPlan", this.byId("ReqPlanVersionSf").getValue());
                        resolve();
                    }.bind(this));
                }.bind(this));
            },

            // Event handler method when item attachment is deleted from menu button
            onCWAItemAttachmentDelete: async function (oEvent) {
                var iIndex = parseInt(oEvent.getParameters().item.getBindingContext("ViewModel").getPath().charAt(oEvent.getParameters().item.getBindingContext("ViewModel").getPath().lastIndexOf("/") + 1));
                var aCWAItemAttachments = this.getView().getModel("ViewModel").getProperty("/CWAItemAttachments");
                var aCWADeleted = aCWAItemAttachments.splice(iIndex, 1);

                this.getView().getModel("ViewModel").getProperty("/DeletedCWAItemAttachments").push(aCWADeleted[0]);
                this.getView().getModel("ViewModel").setProperty("/CWAItemAttachments", aCWAItemAttachments);

                var iIndex = this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").findIndex(function (oItem) {
                    return oItem.FileID_ID === aCWADeleted[0].ID;
                });

                var aDeletedItems = this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").splice(iIndex, 1);
                var aToBeDeletedDocumentIDs = [];
                var aToBeDeletedDMSDocumentIDs = [];
                if (aDeletedItems.length > 0) {
                    aDeletedItems[0].CWAAttachments.forEach(function (oAttachment) {
                        aToBeDeletedDocumentIDs.push(oAttachment.FileID_ID);
                        aToBeDeletedDMSDocumentIDs.push(oAttachment.FileID.DmsDocumentId);
                    });
                }

                this.getView().getModel("ViewModel").setProperty("/ToBeDeletedDocumentIDs",
                    this.getView().getModel("ViewModel").getProperty("/ToBeDeletedDocumentIDs").concat(aToBeDeletedDocumentIDs));
                this.getView().getModel("ViewModel").setProperty("/ToBeDeletedDMSDocumentIDs",
                    this.getView().getModel("ViewModel").getProperty("/ToBeDeletedDMSDocumentIDs").concat(aToBeDeletedDMSDocumentIDs));

                this.getView().getModel("ViewModel").getProperty("/DeletedCWAItems").push(aDeletedItems[0]);

                var sProfitCenters = this.getView().getModel("ViewModel").getProperty("/CWAItemToDisplay/ProfitCenters");
                this.getView().getModel("ViewModel").setProperty("/CWAItemToDisplay", Object.assign({}, this.calculateFieldsBasedOnItems(this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems"), true)));

                if (this.getView().getModel("ViewModel").getProperty("/ReadViaGo")) {
                    // if (this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").length === 1) {
                    //     // this.getView().getModel("ViewModel").setProperty("/NotSingleItem", false);

                    // }

                    if (this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").length === 0) {
                        this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", false);
                        this.getView().getModel("ViewModel").setProperty("/SaveAllowed", true);
                        this.getView().getModel("ViewModel").setProperty("/SubmitAllowed", false);
                        this.getView().getModel("ViewModel").setProperty("/FileUpload", false);
                        MessageToast.show(this.i18n.getText("warningItemDelete"));
                    }

                    var aDocuments = [];
                    this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").forEach(function (oItem) {
                        oItem.CWAAttachments.forEach(function (oAttachment) {
                            aDocuments.push(oAttachment.FileID);
                        });
                    });
                    this.setCWAAttachments(aDocuments);
                }
            },

            // Prepare payload validation
            preparePayloadForValidation: function () {
                var oCWARequest = JSON.parse(JSON.stringify(this.getView().getModel("CWACreateRequestModel").getProperty("/")));
                var oCWAItemToDisplay = this.getView().getModel("ViewModel").getProperty("/CWAItemToDisplay");
                var oPayload = {
                    "Header": {
                        "Customer": oCWARequest.Customer,
                        "Site": oCWARequest.Site
                    },
                    "Item": {
                        "ApprovedWaiver": oCWAItemToDisplay.ApprovedWaiver,
                        "BalanceMonth": oCWAItemToDisplay.BalanceMonth,
                        "CurrentMS": oCWAItemToDisplay.CurrentMS,
                        "CurrentMonthShipment": oCWAItemToDisplay.GeneralEO[1].Proposed,
                        "ExcessTotalCurrent": oCWAItemToDisplay.GeneralEO[0].Current,
                        "ExcessTotalProposed": oCWAItemToDisplay.ExcessTotalProposed,
                        "FileFromRR": oCWAItemToDisplay.FileFromRR,
                        "MonthTM1": oCWAItemToDisplay.MonthTM1,
                        "ObsoleteTotalCurrent": oCWAItemToDisplay.GeneralEO[1].Current,
                        "ObsoleteTotalProposed": oCWAItemToDisplay.GeneralEO[1].Proposed,
                        "ProfitCenters": oCWAItemToDisplay.ProfitCenters,
                        "ProposedMS": oCWAItemToDisplay.ProposedMS
                    }
                };
                return oPayload;
            },

            // Read Document table from database
            readDocuments: function (aFilters) {
                return new Promise(async function (resolve, reject) {
                    var oList = this.oModel.bindList("/Documents", null, null, aFilters);
                    // READ request
                    await oList.requestContexts().then(function (aContexts) {
                        resolve(aContexts);
                    }.bind(this));
                }.bind(this));
            },

            // Event handler method when other attachment is deleted from menu button
            onCWAAttachmentDelete: function (oEvent) {

                if (this.getView().getModel("ViewModel").getProperty("/ReadViaGo")) {
                    this.performDeleteForGo(oEvent);
                } else {
                    this.performDeleteForNonGo(oEvent);
                }
            },

            // When attachment deleted post GO operation
            performDeleteForGo: function (oEvent) {
                var iIndex = parseInt(oEvent.getParameters().item.getBindingContext("ViewModel").getPath().charAt(oEvent.getParameters().item.getBindingContext("ViewModel").getPath().lastIndexOf("/") + 1));
                var aCWAAttachments = this.getView().getModel("ViewModel").getProperty("/CWAAttachments");
                var aCWADeleted = aCWAAttachments.splice(iIndex, 1);
                var aDeletedCWAAttachment = this.getView().getModel("ViewModel").getProperty("/CurrentCWAAttachments").filter(function (oAttachment) {
                    return oAttachment.FileID_ID === aCWADeleted[0].ID;
                });

                // When an attachment is removed at attachment level, then attachment needs to be spliced in CurrentCWAItems model as well.
                var iItemIndex = this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems").findIndex(function (oItem) {
                    return oItem.ID === aDeletedCWAAttachment[0].Parent_ID;
                });
                var iAttachmentIndex = this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems")[iItemIndex].CWAAttachments.findIndex(function (oAttachment) {
                    return oAttachment.ID === aDeletedCWAAttachment[0].ID;
                });
                this.getView().getModel("ViewModel").getProperty("/CurrentCWAItems")[iItemIndex].CWAAttachments.splice(iAttachmentIndex, 1);

                this.getView().getModel("ViewModel").setProperty("/DeletedCWAAttachments",
                    this.getView().getModel("ViewModel").getProperty("/DeletedCWAAttachments").concat(aDeletedCWAAttachment[0]));
                this.getView().getModel("ViewModel").setProperty("/ToBeDeletedDocumentIDs",
                    this.getView().getModel("ViewModel").getProperty("/ToBeDeletedDocumentIDs").concat([aCWADeleted[0].ID]));
                this.getView().getModel("ViewModel").setProperty("/ToBeDeletedDMSDocumentIDs",
                    this.getView().getModel("ViewModel").getProperty("/ToBeDeletedDMSDocumentIDs").concat([aDeletedCWAAttachment[0].FileID.DmsDocumentId
                    ]));

                this.getView().getModel("ViewModel").setProperty("/CWAAttachments", aCWAAttachments);
            },

            // When attachment deleted post FILE UPLOAD operation
            performDeleteForNonGo: function (oEvent) {
                var iIndex = parseInt(oEvent.getParameters().item.getBindingContext("ViewModel").getPath().charAt(oEvent.getParameters().item.getBindingContext("ViewModel").getPath().lastIndexOf("/") + 1));
                var aCWAAttachments = this.getView().getModel("ViewModel").getProperty("/CWAAttachments");
                var aCWADeleted = aCWAAttachments.splice(iIndex, 1);
                this.getView().getModel("ViewModel").setProperty("/DeletedCWAAttachments", aCWADeleted);
                this.getView().getModel("ViewModel").setProperty("/CWAAttachments", aCWAAttachments);
            },

            // Remove all messages from Message manager
            removeAllMessages: function () {
                this._MessageManager.removeAllMessages();
            },

            // Download simulate error messages from response
            downloadSimulateErrorMessages: function () {
                var aExportMessages = this.getView().getModel("ViewModel").getProperty("/SubmitResponse").SimulationResults;
                var aErrorMessages = [];
                aExportMessages.forEach(function (oMessage) {
                    if (oMessage.Message) {
                        aErrorMessages.push(oMessage);
                    }
                });
                var aCols = [{
                    label: this.i18n.getText("colErrorMessage"),
                    property: "Message"
                }];
                var oSettings = {
                    workbook: {
                        columns: aCols,
                        context: {
                            sheetName: this.i18n.getText("excelName")
                        }
                    },
                    dataSource: aErrorMessages,
                    fileName: this.i18n.getText("excelName")
                };
                var oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {
                        MessageToast.show(this.i18n.getText("mesasgeDownloadMsg"));
                    }.bind(this))
                    .finally(function () {
                        oSheet.destroy();
                    });
            },

            // Navigate to dashboard app with CWAName as the urlparameter
            navigateToDashboardApp: function (sCWAName) {
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "cwadashboard",
                        action: "manage"
                    },
                    params: { "CWAName": sCWAName }
                })) || "";
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: hash
                    }
                });
            },

            // Event handler method for inner control created of Timezone Smart Field
            onInnerControlsCreatedTimeZone: function (oEvent) {
                var sLocalTime = this.getView().getModel("CWACreateRequestModel").getProperty("/SAPLocalTime");
                if (this.byId("TimeZoneSf").getInnerControls().length > 0 && this.byId("TimeZoneSf").getInnerControls()[0].setValue) {
                    this.setTimeZoneSfEditable(this.getView().getModel("CWACreateRequestModel").getProperty("/SAPUTCConvert"));
                    this.byId("TimeZoneSf").getInnerControls()[0].setValue(sLocalTime);
                }
                if (this.byId("TimeZoneSf").getInnerControls().length > 0 && this.byId("TimeZoneSf").getInnerControls()[0].setText) {
                    this.byId("TimeZoneSf").getInnerControls()[0].setText(sLocalTime);
                }
            },

            // Event handler method for inner control created of Version Smart Field
            onInnerControlsCreatedVersions: function () {
                var sSAPReqPlan = this.getView().getModel("CWACreateRequestModel").getProperty("/SAPReqPlan");
                if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue) {
                    this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue(sSAPReqPlan);
                    if (this.bDefaultValueSet) {
                        this.bDefaultValueSet = false;
                        this.byId("ReqPlanVersionSf").getInnerControls()[0].setValue("00");
                    }
                }
                if (this.byId("ReqPlanVersionSf").getInnerControls().length > 0 && this.byId("ReqPlanVersionSf").getInnerControls()[0].setText) {
                    this.byId("ReqPlanVersionSf").getInnerControls()[0].setText(sSAPReqPlan);
                    if (this.bDefaultValueSet) {
                        this.bDefaultValueSet = false;
                        this.byId("ReqPlanVersionSf").getInnerControls()[0].setText("00");
                    }
                }
            },

            // Download Template
            onDownloadTemplate: async function () {
                // Read the table and get dms doucment id where template is active
                this.showBusyIndicator();
                var aActive = [], aFilters = [];
                aActive.push(new sap.ui.model.Filter("Active", sap.ui.model.FilterOperator.EQ, true));
                aFilters.push(new sap.ui.model.Filter(aActive, false));
                await this.readTemplateData(aFilters).then(async function (aContexts) {
                    if (aContexts.length > 0) {
                        this.downloadTemplate(aContexts[0].getObject().URL);
                        this.hideBusyIndicator();
                    } else {
                        this.hideBusyIndicator();
                        MessageBox.error(this.i18n.getText("templateDownloadFailed"));
                    }
                }.bind(this))
                    .catch(function (oError) {
                        this.resetCWAData();
                        this.hideBusyIndicator();
                        MessageBox.error(oError.toString());
                    }.bind(this));

            },

            // Read template data 
            readTemplateData: function (aFilters) {
                return new Promise(async function (resolve, reject) {
                    var oList = this.oModel.bindList("/TemplateStore", null, null, aFilters);
                    // READ request
                    await oList.requestContexts().then(function (aContexts) {
                        resolve(aContexts);
                    }.bind(this))
                        .catch(function (oError) {
                            reject(oError);
                        });
                }.bind(this));
            },

            // Download Template from DMS
            downloadTemplate: function (sResopnseURL) {
                var sFolderId = this.getView().getModel("CWACreateRequestModel").getProperty("/ID");
                var sURL = ""; var win = "";
                sURL = $.sap.getModulePath("cwa.fiori.request.cwarequestcreate") + sResopnseURL;
                win = window.open(sURL, '_blank');
                win.focus();
            },

            // Download all CWA Item attachments
            onDownloadCWAItemAttachments: function () {
                var sFolderId = this.getView().getModel("CWACreateRequestModel").getProperty("/ID");
                var oCWAItems = this.getView().getModel("ViewModel").getProperty("/CWAItemAttachments");
                var sURL = ""; var win = "";
                oCWAItems.forEach(function (oItem) {
                    sURL = $.sap.getModulePath("cwa.fiori.request.cwarequestcreate") + "/browser/CWA_REQUEST_REPO/root/" + sFolderId + "?objectId=" + oItem.DmsDocumentId;
                    win = window.open(sURL, '_blank');
                    win.focus();
                });
            },

            // Download all CWA Other attachments
            onDownloadCWAAttachments: function () {
                var sFolderId = this.getView().getModel("CWACreateRequestModel").getProperty("/ID");
                var oCWAAttachments = this.getView().getModel("ViewModel").getProperty("/CWAAttachments");
                var sURL = ""; var win = "";
                oCWAAttachments.forEach(function (oAttachment) {
                    sURL = $.sap.getModulePath("cwa.fiori.request.cwarequestcreate") + "/browser/CWA_REQUEST_REPO/root/" + sFolderId + "?objectId=" + oAttachment.DmsDocumentId;
                    win = window.open(sURL, '_blank');
                    win.focus();
                });
            },

            // Menu button formatter
            formatMenuButtonText: function (sDocumentName, sDocumentType, sCreatedBy, sCreatedAt) {
                if (sDocumentName && sDocumentType && sCreatedBy && sCreatedAt) {
                    var dDate = new Date(sCreatedAt);
                    var sDate = [dDate.getUTCFullYear(), this.getMonthWithZero(dDate.getUTCMonth() + 1), this.getDateWithZero(dDate.getUTCDate())].join("");
                    return sDocumentName + "." + sDocumentType + "," + sCreatedBy + "," + sDate;
                }
                if (!sCreatedBy && !sCreatedAt) {
                    return sDocumentName + "." + sDocumentType + "," + "NA" + "," + "NA";
                }
            },


            getMonthWithZero: function (iMonth) {
                if (iMonth > 9) {
                    return iMonth;
                } else {
                    return "0" + iMonth;
                }
            },

            getDateWithZero: function (iDate) {
                if (iDate > 9) {
                    return iDate;
                } else {
                    return "0" + (iDate);
                }
            },

            // Event handler for UTC Convert checkbox select
            onUTCConvertCheck: function (oEvent) {
                this.setTimeZoneSfEditable(oEvent.getParameters().selected);
            },

            // Sets Timezone smart field editable
            setTimeZoneSfEditable: function (bSelected) {
                if (this.byId("TimeZoneSf").getInnerControls().length > 0 && this.byId("TimeZoneSf").getInnerControls()[0].setValue) {
                    if (bSelected) {
                        this.byId("TimeZoneSf").getInnerControls()[0].setEditable(true);
                    } else {
                        this.byId("TimeZoneSf").getInnerControls()[0].setEditable(false);
                        this.byId("TimeZoneSf").getInnerControls()[0].setValue("");
                    }
                }
            }

        });
    });