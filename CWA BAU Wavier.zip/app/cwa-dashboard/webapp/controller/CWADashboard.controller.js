sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/export/Spreadsheet",
    "sap/ui/core/BusyIndicator",
    "sap/ui/core/Fragment"
],
    function (Controller, JSONModel, MessageToast, MessageBox, Spreadsheet, BusyIndicator, Fragment) {
        "use strict";

        return Controller.extend("com.jabil.cwadashboard.controller.CWADashboard", {

            // Assigns CWAName from start up parameter (if exists) and sets CurrentLogDetails model
            onInit: function () {
                this.oModel = this.getOwnerComponent().getModel();
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                var oViewModel = new JSONModel({
                    "CurrentLogDetails": [],
                    "RowMode": "Interactive"
                });

                this.sCWAName = "";
                this.getView().setModel(oViewModel, "ViewModel");
                if (this.getOwnerComponent().getComponentData() && this.getOwnerComponent().getComponentData().startupParameters && this.getOwnerComponent().getComponentData().startupParameters.CWAName) {
                    this.sCWAName = this.getOwnerComponent().getComponentData().startupParameters.CWAName[0];
                }

            },

            // Sets the CWAName to filter as soon as Filter initialises
            onSmartFilterBarInitialised: function (oEvent) {
                if (this.sCWAName) {
                    this.byId("CWADashboardSmartFilterId").setFilterData({
                        "CWAName": {
                            "items": [{
                                "key": this.sCWAName,
                                "text": ""
                            }]
                        }
                    });
                    this.sCWAName = "";
                    this.byId("CWADashboardSmartFilterId").fireSearch();
                }
            },

            // Sets expand navigation property before rebind of the table
            onBeforeRebind: function (oEvent) {
                let oBindingParam = oEvent.getParameter("bindingParams");
                // Status
                oBindingParam.parameters["expand"] = "FileID,CWAAttachments,CWAItems($expand=FileID,CWAAttachments($expand=FileID)),CWAApprovers,CWAWFHistory,ToBeCWACurrentApproval";
            },

            // Calls UploadDemand action import
            onUploadDemand: function (oEvent) {
                var oSmartFilter = this.byId("CWADashboardSmartFilterId");
                var sId = this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath() + "/ID");
                var sPath = oEvent.getSource().getBindingContext().getPath();
                this.showBusyIndicator();
                this.oModel.callFunction("/UploadDemand", {
                    method: "POST",
                    urlParameters: {
                        ID: sId
                    },
                    success: function (oData) {
                        this.processResponseOfUploadDemand(oData.UploadDemand, true);
                        oSmartFilter.fireSearch();
                    }.bind(this),
                    error: function (oError) {
                        this.hideBusyIndicator();
                        this.displayErrorMessages(oError);
                        // MessageBox.error(this.i18n.getText("operationFailedMsg"));
                    }.bind(this)
                });
            },

            // Formatter for Demand Button text
            getDemandButtonText: function (sJobStatus, sCWAStatus) {
                if (sCWAStatus === 1 || sCWAStatus === 2 || sCWAStatus === 3) {
                    return this.i18n.getText("btnUploadDemand");
                } else {
                    return this.i18n.getText("btnUploadDemand");
                }
            },

            // Formatter for Demand Button enabled property value
            getDemandButtonEnabled: function (sJobStatus, sCWAStatus) {
                // if (sCWAStatus === 1 || sCWAStatus === 2) {
                //     return false;
                // } else 

                if (sCWAStatus === 3 || sCWAStatus === 7) {
                    return true;
                } else {
                    return false;
                }
            },

            // Processess the response of Upload Demand Function Import
            processResponseOfUploadDemand: function (oResponse, bRefresh) {
                var oSmartFilter = this.byId("CWADashboardSmartFilterId");
                this.hideBusyIndicator();
                if (oResponse.BackendError) {
                    console.log(oResponse.BackendErrorObject);
                    if (oResponse.SimulationResults.length === 0) {
                        MessageBox.error(oResponse.DisplayMessage);
                    } else {
                        MessageBox.error(oResponse.DisplayMessage, {
                            actions: [this.i18n.getText("btnDownload"), MessageBox.Action.CLOSE],
                            emphasizedAction: this.i18n.getText("btnDownload"),
                            onClose: function (sAction) {
                                if (sAction === "Download") {
                                    if (bRefresh) {
                                        oSmartFilter.fireSearch();
                                    }
                                    this.downloadSimulateErrorMessages(oResponse.SimulationResults);
                                } else {
                                    if (bRefresh) {
                                        oSmartFilter.fireSearch();
                                    }
                                }
                            }.bind(this)
                        });
                    }
                } else {
                    if (oResponse.SimulationResults.length > 0) {
                        MessageBox.success(oResponse.DisplayMessage, {
                            actions: [this.i18n.getText("btnDownload"), MessageBox.Action.CLOSE],
                            emphasizedAction: this.i18n.getText("btnDownload"),
                            onClose: function (sAction) {
                                if (sAction === "Download") {
                                    if (bRefresh) {
                                        oSmartFilter.fireSearch();
                                    }
                                    this.downloadSimulateErrorMessages(oResponse.SimulationResults);
                                } else {
                                    if (bRefresh) {
                                        oSmartFilter.fireSearch();
                                    }
                                }
                            }.bind(this)
                        });
                    } else {
                        MessageBox.success(oResponse.DisplayMessage, {
                            actions: [MessageBox.Action.CLOSE],
                            onClose: function (sAction) {
                                if (bRefresh) {
                                    oSmartFilter.fireSearch();
                                }
                            }.bind(this)
                        });
                    }
                }
            },

            // Downloads Simulation Error Messages
            downloadSimulateErrorMessages: function (aExportMessages) {
                var aErrorMessages = [];
                if (aExportMessages.length === 0) {
                    MessageBox.information(this.i18n.getText("noMsgToDownload"));
                    return;
                }
                aExportMessages.forEach(function (oMessage) {
                    if (oMessage.Message) {
                        aErrorMessages.push(oMessage);
                    }
                });
                var aCols = [{
                    label: this.i18n.getText("colErrorMessage"),
                    property: "Message"
                }];
                var oSettings = {
                    workbook: {
                        columns: aCols,
                        context: {
                            sheetName: this.i18n.getText("excelName")
                        }
                    },
                    dataSource: aErrorMessages,
                    fileName: this.i18n.getText("excelName")
                };
                var oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {
                        MessageToast.show(this.i18n.getText("mesasgeDownloadMsg"));
                    }.bind(this))
                    .finally(function () {
                        oSheet.destroy();
                    });
            },

            // Calls Action Import to forward workflow
            onTrigger: function (oEvent) {
                var oSmartFilter = this.byId("CWADashboardSmartFilterId");
                var oSource = oEvent.getSource();
                var aKeys = Object.keys(oSource.getModel().getPendingChanges()).filter(function (sKey) {
                    return "/" + sKey === oSource.getBindingContext().getPath();
                });
                var sPath = oSource.getBindingContext().getPath();
                var oCWA = oSource.getBindingContext().getModel().getProperty(sPath);
                // Checks whether there is no change in the approver
                if (aKeys.length === 0) {
                    MessageToast.show(this.i18n.getText("noChangeOfApprover"));
                    return;
                }
                var sCurrentApproval = oSource.getModel().getProperty("/" + aKeys[0]).CWACurrentApprovalFlag;

                // Checks whether there is workflow details for the selected CWA
                if (oSource.getBindingContext().getModel().getProperty(sPath).CWAWFHistory.__list.length === 0) {
                    MessageBox.error(this.i18n.getText("noWorkFlowDetails"));
                    oSource.getModel().resetChanges(["/" + aKeys[0]]);
                    return;
                }

                this.showBusyIndicator();
                var oPayload = {
                    ID: oCWA.ID,
                    WFID: oSource.getBindingContext().getModel().getProperty("/" + oSource.getBindingContext().getModel().getProperty(sPath).CWAWFHistory.__list[0]).WorkflowID,
                    EMAIL: oSource.getModel().getProperty("/" + aKeys[0]).CWACurrentApproval,
                    NAME: oSource.getBindingContext().getModel().getProperty("/ToBeCWACurrentApproval('" + oSource.getModel().getProperty("/" + aKeys[0]).CWACurrentApproval + "')").User
                };
                this.oModel.create("/forwardWorkflow", oPayload, {
                    success: function (oData) {
                        this.hideBusyIndicator();
                        if (oData.forwardWorkflow.MSGType === "E") {
                            MessageBox.error(oData.forwardWorkflow.MSG.reason.message);
                        } else {
                            MessageBox.success(oData.forwardWorkflow.MSG);
                            oSmartFilter.fireSearch();
                        }
                    }.bind(this),
                    error: function (oError) {
                        this.hideBusyIndicator();
                        this.displayErrorMessages(oError);
                        this.oModel.resetChanges();
                    }.bind(this)
                });
            },

            displayErrorMessages: function (oError) {
                if (oError.responseText && JSON.parse(oError.responseText).error
                    && JSON.parse(oError.responseText).error.message && JSON.parse(oError.responseText).error.message.value) {
                    MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                } else {
                    MessageBox.error(this.i18n.getText("operationFailedMsg"));
                }
            },

            // DMS Download Call for CWA Item Attachment
            onCWAItemAttachmentDownload: function (oEvent) {
                var sDMSDocumentId = this.oModel.getProperty(oEvent.getParameters().item.getBindingContext().getPath()).DmsDocumentId;
                var sFolderId = this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath() + "/ID");
                var sURL = $.sap.getModulePath("com.jabil.cwadashboard") + "/browser/CWA_REQUEST_REPO/root/" + sFolderId + "?objectId=" + sDMSDocumentId;
                var win = window.open(sURL, '_blank');
                win.focus();
            },

            // DMS Download Call for CWA Other Attachments
            onCWAAttachmentDownload: function (oEvent) {
                // var sDMSDocumentId = this.oModel.getProperty(oEvent.getParameters().item.getBindingContext().getPath()).DmsDocumentId;
                var sDMSDocumentId = this.oModel.getProperty("/" + this.oModel.getProperty(oEvent.getParameters().item.getBindingContext().getPath()).FileID.__ref).DmsDocumentId;
                var sFolderId = this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath() + "/ID");
                var sURL = $.sap.getModulePath("com.jabil.cwadashboard") + "/browser/CWA_REQUEST_REPO/root/" + sFolderId + "?objectId=" + sDMSDocumentId;
                var win = window.open(sURL, '_blank');
                win.focus();
            },

            // Calls Function Import to cancel the CWA
            onSetToCancel: function (oEvent) {
                var sCWAName = this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath() + "/CWAName");
                var sPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(this.i18n.getText("cancelConfirmation", [sCWAName]), {
                    onClose: function (sAction) {
                        if (sAction === "OK") {
                            this.performCancel(sPath);
                        }
                    }.bind(this)
                });
            },

            performCancel: function (sPath) {
                var oSmartFilter = this.byId("CWADashboardSmartFilterId");
                var sId = this.oModel.getProperty(sPath + "/ID");
                var sWFID = null;
                if (this.oModel.getProperty(sPath).CWAWFHistory.__list.length > 0) {
                    sWFID = this.oModel.getProperty("/" + this.oModel.getProperty(sPath).CWAWFHistory.__list[0]).WorkflowID
                }

                this.showBusyIndicator();
                this.oModel.callFunction("/CancelCWA", {
                    method: "GET",
                    urlParameters: {
                        ID: sId,
                        WFID: sWFID
                    },
                    success: function (oData) {
                        this.hideBusyIndicator();
                        MessageToast.show(oData.CancelCWA);
                        oSmartFilter.fireSearch();
                        // MessageBox.information(oData.CancelCWA, {
                        //     onClose: function (sAction) {
                        //         oSmartFilter.fireSearch();
                        //     }.bind(this)
                        // });
                    }.bind(this),
                    error: function (oError) {
                        this.hideBusyIndicator();
                        this.displayErrorMessages(oError);
                        // MessageBox.error(this.i18n.getText("operationFailedMsg"));
                    }.bind(this)
                });
            },

            // Displays approver log details in the Dialog
            onViewLogDetails: function (oEvent) {
                if (!this.setLogDetailsModel(oEvent)) {
                    return;
                }
                if (!this.byId("LogDetailsDialog")) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.jabil.cwadashboard.view.fragment.LogDetails",
                        controller: this
                    }).then(function (oDialog) {
                        this.getView().addDependent(oDialog);
                        oDialog.open();
                    }.bind(this));
                } else {
                    this.byId("LogDetailsDialog").open();
                }
            },

            // Sets CurrentLogDetails model for the selected CWA
            setLogDetailsModel: function (oEvent) {
                if (this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath()).CWAWFHistory.__list.length > 0) {
                    var aLogDetails = [];
                    this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath()).CWAWFHistory.__list.forEach(function (sPath) {
                        aLogDetails.push(this.oModel.getProperty("/" + sPath));
                    }.bind(this));
                    this.getView().getModel("ViewModel").setProperty("/CurrentLogDetails", aLogDetails);
                    return true;
                } else {
                    MessageBox.error(this.i18n.getText("noLogHistoryDetails"));
                    return false;
                }
            },

            // Closes the log details dialog
            onCloseLogDetails: function () {
                this.getView().getModel("ViewModel").setProperty("/CurrentLogDetails", []);
                this.byId("LogDetailsDialog").close();
            },

            // Hides busy indicator
            hideBusyIndicator: function () {
                BusyIndicator.hide();
            },

            // Shows busy indicator
            showBusyIndicator: function () {
                BusyIndicator.show();
            },

            // Function Import to download the error messages for the Job
            onDonwloadErrorMessage: function (oEvent) {
                var sId = this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath() + "/ID");
                var sJobId = this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath() + "/SAPJobDetails_ID");
                this.showBusyIndicator();
                this.oModel.callFunction("/GetSAPJOBIDError", {
                    method: "GET",
                    urlParameters: {
                        jobname: sJobId,
                        cwanum: sId
                    },
                    success: function (oData) {
                        this.hideBusyIndicator();
                        this.processResponseOfUploadDemand(oData.GetSAPJOBIDError, false);
                    }.bind(this),
                    error: function (oError) {
                        this.hideBusyIndicator();
                        this.displayErrorMessages(oError);
                        // MessageBox.error(this.i18n.getText("operationFailedMsg"));
                    }.bind(this)
                });
            },

            // Navigates to CWA Create app
            onCWANameClick: function (oEvent) {
                var sCWAName = this.oModel.getProperty(oEvent.getSource().getBindingContext().getPath() + "/CWAName");
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "cwa",
                        action: "RequestCreate"
                    },
                    params: { "CWAName": sCWAName }
                })) || "";
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: hash
                    }
                });
            },

            // Formatter for the status color
            formatStatusColor: function (iId) {
                switch (iId) {
                    case 1:
                        // draft
                        return sap.ui.core.IndicationColor.Indication06;
                        break;
                    case 2:
                        // pending approval
                        return sap.ui.core.IndicationColor.Indication07;
                        break;
                    case 3:
                        // trigger demand
                        return sap.ui.core.IndicationColor.Indication08;
                        break;
                    case 4:
                        // closed
                        return sap.ui.core.IndicationColor.Indication05;
                        break;
                    case 5:
                        // rejected
                        return sap.ui.core.IndicationColor.Indication02;
                        break;
                    case 6:
                        // cancelled
                        return sap.ui.core.IndicationColor.Indication01;
                        break;
                    case 7:
                        // demand error
                        return sap.ui.core.IndicationColor.Indication03;
                        break;
                    case 8:
                        // demand triggered
                        return sap.ui.core.IndicationColor.Indication04;
                        break;
                    default:
                        // no value
                        return sap.ui.core.IndicationColor.Indication01;
                }
            },

            onApproverChange: function (oEvent) {
                var oModel = this.getView().getModel();
                var sPath = oEvent.getSource().getBindingContext().getPath();
                var oCWA = oModel.getProperty(sPath);
                if (oCWA.CWACurrentApproval) {
                    oModel.setProperty(sPath + "/CWACurrentApprovalFlag", oCWA.CWACurrentApproval);
                } else {
                    oEvent.getSource().setSelectedKey("");
                }
            }
        });
    });
