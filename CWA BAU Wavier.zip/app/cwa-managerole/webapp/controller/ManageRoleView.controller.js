sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/Device",
    "sap/base/Log",
    'sap/ui/model/odata/v2/ODataModel',
    'sap/ui/model/json/JSONModel',
    'sap/m/Label',
    "sap/ui/core/Fragment",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/comp/smartvariants/PersonalizableInfo',
    'sap/m/MessageToast',
    "sap/m/MessageBox"
],
    function (Controller, Device, Log, ODataModel, JSONModel, Label, Fragment, Filter, FilterOperator, PersonalizableInfo, MessageToast, MessageBox) {
        "use strict";

        return Controller.extend("cwa.managerole.cwamanagerole.controller.ManageRoleView", {
            onInit: function () {
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },
            // Action on List Item press to get the pressed list Item ID
            onListItemPress: function (oEvent) {
                var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();
                this.getSplitAppObj().toDetail(this.createId(sToPageId));
                this.getSplitAppObj().hideMaster();
            },
            // Action on List Item press to Load the pressed list Item
            getSplitAppObj: function () {
                var result = this.byId("SplitAppManageRole");
                if (!result) {
                    Log.info("SplitApp object can't be found");
                }
                return result;
            },

            // Role Name Master 
            // To load the fragment to add row in Role Name
            // This code is not required for now, might use in next phase
            // onAddRowRoleName: function () {
            //     if (!this.oRoleDialog) {
            //         this.oRoleDialog = this.loadFragment({
            //             name: "cwa.managerole.cwamanagerole.fragment.AddRowRoleName"
            //         });
            //     }
            //     this.oRoleDialog.then(function (oDialogRole) {
            //         this.oDialogRole = oDialogRole;
            //         this.oDialogRole.open();
            //     }.bind(this));
            // },

            // // To save a new approval role
            // createAddRoleName: function (oEvent) {
            //     var that = this;
            //     var oModel = this.getView().byId("UITabRoleName").getModel();
            //     var newRole = this.getView().byId("InRoleName").getValue();
            //     var newDesc = this.getView().byId("InRoleDesc").getValue();
            //     var oItem = {
            //         "RoleNam": newRole,
            //         "RoleDesc": newDesc
            //     };
            //     oModel.create("/RoleName", oItem, {
            //         success: function (odata) {
            //             that.getView().byId("UITabRoleName").getModel().refresh();
            //             that.oDialogRole.close();
            //             MessageToast.show(that.i18n.getText("saved"));
            //         },
            //         error: function (oError) {
            //             that.oDialogRole.close();
            //             that.getView().byId("UITabRoleName").getModel().refresh();
            //             MessageBox.error(JSON.parse(oError.responseText).error.message.value);
            //         }
            //     }

            //     )
            // },

            // // To Close Add Row Dialog for Approval Role
            // closeDialogAddRoleName: function () {
            //     this.oDialogRole.close();
            // },

            // // To delete the Role Name
            // onDeleteRoleName: function (oEvent) {
            //     var that = this;
            //     var oModel = this.getOwnerComponent().getModel();
            //     var oPath = oEvent.getSource().getBindingContext().getPath();
            //     oModel.remove(oPath);
            //     MessageToast.show(that.i18n.getText("deleted"));
            // },
            // This code is not required for now, might use in next phase


            // to Edit the Role Description
            onEditRoleName: function (oEvent) {
                var oPath = oEvent.getSource().getBindingContext().getPath();
                if (!this.oRoleEditDialog) {
                    this.oRoleEditDialog = this.loadFragment({
                        name: "cwa.managerole.cwamanagerole.fragment.EditRowRoleDesc"
                    });
                }
                this.oRoleEditDialog.then(function (oDialogEditRole) {
                    this.oDialogEditRole = oDialogEditRole;
                    this.oDialogEditRole.open();
                    this.oDialogEditRole.bindElement({ path: oPath });
                }.bind(this));
            },

            // To close the edit description dialog
            closeDialogEditRoleDesc: function () {
                this.oDialogEditRole.close();
            },
            // To save the new Description
            EditRoleDescSave: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabRoleName").getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                var editedDesc = this.getView().byId("InEditRoleDesc").getValue();
                var oItem = { "RoleDesc": editedDesc };
                oModel.update(oPath, oItem, {
                    success: function (odata) {
                        that.getView().byId("UITabRoleName").getModel().refresh();
                        that.oDialogEditRole.close();
                        MessageToast.show(that.i18n.getText("Updated"));
                    },
                    error: function (oError) {
                        that.oDialogEditRole.close();
                        that.getView().byId("UITabRoleName").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }
                )
            },

            // Approval Role Type
            beforeOpenTable: function (oEvent) {
                let oBindingParam = oEvent.getParameter("bindingParams");
                oBindingParam.parameters["expand"] = "RoleDesc";
            },

            // This code is not required for now, might use in next phase
            // To load the fragment to add row in Approval Role
            // onAddRowApprovalRole: function () {
            //     if (!this.oAppRoleDialog) {
            //         var oContext = this.getOwnerComponent().getModel().createEntry("/TM1Hierarchy", {
            //             properties: {
            //                 "Plant": "",
            //                 "Customer": "",
            //                 "ProfitCenter": ""
            //             }
            //         });
            //         this.oAppRoleDialog = this.loadFragment({
            //             name: "cwa.managerole.cwamanagerole.fragment.AddRowApprovalRole"
            //         });
            //     }
            //     this.oAppRoleDialog.then(function (oDialogAppRole) {
            //         if (!this.byId("AddRowApprovalRole").getBindingContext()) {
            //             this.byId("AddRowApprovalRole").setBindingContext(oContext);
            //         }
            //         this.oDialogAppRole = oDialogAppRole;
            //         this.oDialogAppRole.open();
            //     }.bind(this));
            // },

            // // To save a new approval role
            // createApprovalRole: function (oEvent) {
            //     var that = this;
            //     var oModel = this.getView().byId("UITabApprovalRole").getModel();
            //     var newRole = this.getView().byId("InApprovalRole").getValue();
            //     var newSite = this.getView().byId("InSite").getAllInnerControls()[0].getValue();
            //     var newType = this.getView().byId("InApprovalType").getValue();
            //     var newLevel = this.getView().byId("InApprovalLevel").getValue();
            //     var oItem = {
            //         "RoleName": newRole,
            //         "Site": newSite,
            //         "ApprovalType": newType,
            //         "ApprovalLevel": parseInt(newLevel)
            //     };
            //     oModel.create("/ApprovalRole", oItem, {
            //         success: function (odata) {
            //             that.getView().byId("UITabApprovalRole").getModel().refresh();
            //             that.oDialogAppRole.close();
            //             MessageToast.show(that.i18n.getText("saved"));
            //         },
            //         error: function (oError) {
            //             that.oDialogAppRole.close();
            //             that.getView().byId("UITabApprovalRole").getModel().refresh();
            //             MessageBox.error(JSON.parse(oError.responseText).error.message.value);
            //         }
            //     }

            //     )
            // },

            // // To Close Add Row Dialog for Approval Role
            // closeDialogApprovalRole: function () {
            //     this.oDialogAppRole.close();
            // },
            // // To delete the Approval Role 
            // onDeleteApprovalRole: function (oEvent) {
            //     var that = this;
            //     var oModel = this.getOwnerComponent().getModel();
            //     var oPath = oEvent.getSource().getBindingContext().getPath();
            //     oModel.remove(oPath);
            //     MessageToast.show(that.i18n.getText("deleted"));
            // },
            // This code is not required for now, might use in next phase

            // MPS & BU Waiver Threshold
            // Open Add Ror Fragment
            onAddRowMPSBUWaiverThreshold: function () {
                if (!this.oAppWaiverThreshold) {
                    var oContextSeg = this.getOwnerComponent().getModel().createEntry("/SegmentVH", {
                        properties: {
                            "Segment": ""
                        }
                    });
                    var oContextDiv = this.getOwnerComponent().getModel().createEntry("/DivisionVH", {
                        properties: {
                            "Division": ""
                        }
                    });
                    this.oAppWaiverThreshold = this.loadFragment({
                        name: "cwa.managerole.cwamanagerole.fragment.AddRowWaiverThreshold"
                    });
                }
                this.oAppWaiverThreshold.then(function (oDialogWaiverThreshold) {
                    if (!this.byId("InSegment").getBindingContext()) { this.byId("InSegment").setBindingContext(oContextSeg); }
                    if (!this.byId("InDivision").getBindingContext()) { this.byId("InDivision").setBindingContext(oContextDiv); }
                    this.oDialogWaiverThreshold = oDialogWaiverThreshold;
                    this.oDialogWaiverThreshold.open();
                }.bind(this));
            },

            // 
            createWaiverThreshold: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabMPSBUWaiverThreshold").getModel();
                var newSegment = this.getView().byId("InSegment").getAllInnerControls()[0].getValue();
                var newDivision = this.getView().byId("InDivision").getAllInnerControls()[0].getValue();
                var newLevel = this.getView().byId("InLevel").getValue();
                var newWaiverType = this.getView().byId("InWaiverType").getValue();
                var newThresholdPer = this.getView().byId("InThresholdPer").getValue();
                var newThresholdVal = this.getView().byId("InThresholdVal").getValue();
                var oItem = {
                    "Segment": newSegment,
                    "Division": newDivision,
                    "Level": newLevel,
                    "WaiverType": newWaiverType,
                    "ThresholdPerc": parseInt(newThresholdPer),
                    "Threshold": parseInt(newThresholdVal)
                };
                oModel.create("/MPSBUWaiverThreshold", oItem, {
                    success: function (odata) {
                        that.getView().byId("UITabMPSBUWaiverThreshold").getModel().refresh();
                        that.closeDialogWaiverThreshold();
                        MessageToast.show(that.i18n.getText("saved"));
                    },
                    error: function (oError) {
                        that.closeDialogWaiverThreshold();
                        that.getView().byId("UITabMPSBUWaiverThreshold").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }

                )
            },


            // To Close Add Row Dialog for Approval Role
            closeDialogWaiverThreshold: function () {
                this.oDialogWaiverThreshold.close();
                this.byId("InSegment").getInnerControls()[0].setValue("");
                this.byId("InDivision").getInnerControls()[0].setValue("");
                this.byId("InLevel").setValue("");
                this.byId("InWaiverType").setValue("");
                this.byId("InThresholdPer").setValue("");
                this.byId("InThresholdVal").setValue("");
            },
            // To delete the Approval Role 
            onDeleteMPSBUWaiverThreshold: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("deleteTHreshold"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.remove(oPath, {
                                success: function (data) {
                                    MessageToast.show(that.i18n.getText("deleted"));
                                },
                                error: function (oError) {
                                    that.displayErrorMessages(oError);
                                    that.getView().byId("UITabMPSBUWaiverThreshold").getModel().refresh();
                                }
                            });
                            // MessageToast.show(that.i18n.getText("deleted"));
                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },

            // BU Waiver Rule Closure
            // To delete the Waiver Rule Closure 
            onDeleteBUWaiverRuleClosure: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("deleteRuleClos"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.remove(oPath, {
                                success: function (data) {
                                    MessageToast.show(that.i18n.getText("deleted"));
                                },
                                error: function (oError) {
                                    that.displayErrorMessages(oError);
                                    that.getView().byId("UITabBUWaiverRuleClosure").getModel().refresh();
                                }
                            });
                            // MessageToast.show(that.i18n.getText("deleted"));
                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },

            displayErrorMessages: function (oError) {
                if (oError.responseText && JSON.parse(oError.responseText).error
                    && JSON.parse(oError.responseText).error.message && JSON.parse(oError.responseText).error.message.value) {
                    MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                } else {
                    MessageBox.error(this.i18n.getText("operationFailedMsg"));
                }
            },

            // Formatter code for Active button
            actionButton: function (Active) {
                if (Active === true) {
                    return "Active";
                } else {
                    return "Off";
                }
            }
        });
    });
