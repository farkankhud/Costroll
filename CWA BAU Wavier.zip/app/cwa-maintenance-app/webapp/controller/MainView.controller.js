sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/Device",
    "sap/base/Log",
    'sap/ui/model/odata/v2/ODataModel',
    'sap/ui/model/json/JSONModel',
    'sap/m/Label',
    "sap/ui/core/Fragment",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/comp/smartvariants/PersonalizableInfo',
    'sap/m/MessageToast',
    "sap/m/MessageBox",
    "sap/m/plugins/UploadSetwithTable"
],
    function (Controller, Device, Log, ODataModel, JSONModel, Label, Fragment, Filter, FilterOperator, PersonalizableInfo, MessageToast, MessageBox, UploadSetwithTable) {
        "use strict";

        return Controller.extend("com.jabil.cwamaintenanceapp.controller.MainView", {
            onInit: function () {
                this.bInitial = true;
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },

            onBeforeRendering: function () {
                var that = this;
                this.getOwnerComponent().getModel().callFunction("/getPanelAccess", {
                    method: "POST",
                    urlParameters: {},
                    success: function (oData) {
                        var jModel = new JSONModel();
                        var myData = {};
                        myData = oData.getPanelAccess;
                        jModel.setData(myData);
                        this.getView().setModel(jModel, "getPanelAccess");
                    }.bind(this),
                    error: function (oError) {
                        that.displayErrorMessages(oError);
                    }.bind(this)
                });
            },

            displayErrorMessages: function (oError) {
                if (oError.responseText && JSON.parse(oError.responseText).error
                    && JSON.parse(oError.responseText).error.message && JSON.parse(oError.responseText).error.message.value) {
                    MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                } else {
                    MessageBox.error(this.i18n.getText("operationFailedMsg"));
                }
            },
            // Action on List Item press to get the pressed list Item ID
            onListItemPress: function (oEvent) {
                var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();
                this.getSplitAppObj().toDetail(this.createId(sToPageId));
                this.getSplitAppObj().hideMaster();
            },
            // Action on List Item press to Load the pressed list Item
            getSplitAppObj: function () {
                var result = this.byId("SplitAppMasterHierarchy");
                if (!result) {
                    Log.info("SplitApp object can't be found");
                }
                return result;
            },
            // CWA Rejection Reason
            // To load the fragment of add row rejection reason
            onAddRowRejReason: function () {
                if (!this.oRejDialog) {
                    this.oRejDialog = this.loadFragment({
                        name: "com.jabil.cwamaintenanceapp.fragment.AddRowRejectReason"
                    });
                }
                this.oRejDialog.then(function (oDialog) {
                    this.oDialog = oDialog;
                    this.oDialog.open();
                }.bind(this));
            },
            // to close the add row dialog
            closeDialogRejReason: function () {
                this.byId("InRejReason").setValue("");
                this.oDialog.close();
            },
            // on click save button for rejection reason 
            createRejReason: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabRejectionReason").getModel();
                var reasonDescription = this.getView().byId("InRejReason").getValue();
                var oItem = { "Description": reasonDescription };
                oModel.create("/RejectionReason", oItem, {
                    success: function (odata) {
                        that.getView().byId("UITabRejectionReason").getModel().refresh();
                        that.closeDialogRejReason();
                        MessageToast.show(that.i18n.getText("saved"));
                    },
                    error: function (oError) {
                        that.closeDialogRejReason();
                        that.getView().byId("UITabRejectionReason").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }
                )
            },
            // to update the rejection reason description
            onEditRejReason: function (oEvent) {
                var oPath = oEvent.getSource().getBindingContext().getPath();
                if (!this.oRejEditDialog) {
                    this.oRejEditDialog = this.loadFragment({
                        name: "com.jabil.cwamaintenanceapp.fragment.EditRowRejectReason"
                    });
                }
                this.oRejEditDialog.then(function (oDialogEdit) {
                    this.oDialogEdit = oDialogEdit;
                    this.oDialogEdit.open();
                    this.oDialogEdit.bindElement({ path: oPath });
                }.bind(this));
            },
            // To close the edit description dialog
            closeDialogEditRejReason: function () {
                this.oDialogEdit.close();
            },
            // To save the new description
            EditRejReasonSave: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabRejectionReason").getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                var editedDescription = this.getView().byId("InEditRejReason").getValue();
                var oItem = { "Description": editedDescription };
                oModel.update(oPath, oItem, {
                    success: function (odata) {
                        that.getView().byId("UITabRejectionReason").getModel().refresh();
                        that.oDialogEdit.close();
                        MessageToast.show(that.i18n.getText("Updated"));
                    },
                    error: function (oError) {
                        that.oDialogEdit.close();
                        that.getView().byId("UITabRejectionReason").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }
                )
            },
            // To delete the rejection reason
            onDeleteRejReason: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("RejReasonDelete"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.remove(oPath, {
                                success: function (data) {
                                    MessageToast.show(that.i18n.getText("deleted"));
                                },
                                error: function (oError) {
                                    that.displayErrorMessages(oError);
                                    that.getView().byId("UITabRejectionReason").getModel().refresh();
                                }
                            });

                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }

                    }
                });
            },

            // CWA Request Rule
            // TO load the fragment to add row in request rule
            onAddRowReqRule: function (oEvent) {
                if (!this.oRRuleDialog) {
                    var oContext = this.getOwnerComponent().getModel().createEntry("/TM1Hierarchy", {
                        properties: {
                            "Plant": "",
                            "Customer": "",
                            "ProfitCenter": ""
                        }
                    });
                    this.oRRuleDialog = this.loadFragment({
                        name: "com.jabil.cwamaintenanceapp.fragment.AddRowRequestRule"
                    });

                }
                this.oRRuleDialog.then(function (oDialogRRule) {
                    if (!this.byId("CustomerForm").getBindingContext()) { this.byId("CustomerForm").setBindingContext(oContext); }
                    this.oDialogRRule = oDialogRRule;
                    this.oDialogRRule.open();
                }.bind(this));
            },

            // To update the checkbox value for Customer Rule 
            onCustRuleCB: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                var oValueCustRuleCheck = oEvent.mParameters.selected;
                MessageBox.confirm(that.i18n.getText("RuleChange"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.update(oPath, {
                                CustomerRule: oValueCustRuleCheck,
                            }, {
                                success: function (odata) {
                                    MessageToast.show(that.i18n.getText("Updated"));
                                },
                                error: function (oError) {
                                    MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                                    that.getView().byId("UITabRequestRule").getModel().resetChanges();
                                    that.getView().byId("UITabRequestRule").getModel().refresh();

                                }
                            });
                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                            that.getView().byId("UITabRequestRule").getModel().resetChanges();
                            that.getView().byId("UITabRequestRule").getModel().refresh();
                        }
                    }
                });
            },

            // On save button for creating a new request rule
            createReqRule: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabRequestRule").getModel();
                var newSite = this.getView().byId("SiteInRR").getAllInnerControls()[0].getValue();
                var newCustomer = this.getView().byId("CustomerIn").getAllInnerControls()[0].getValue();
                var CustomerRule = this.getView().byId("CustomerRuleCBDialog").getSelected();
                var oItem = {
                    "Site": newSite,
                    "CustomerName": newCustomer,
                    "CustomerRule": CustomerRule,
                };
                oModel.create("/RequestRule", oItem, {
                    success: function (odata) {
                        that.getView().byId("UITabRequestRule").getModel().refresh();
                        that.closeDialogReqRule();
                        MessageToast.show(that.i18n.getText("saved"));
                    },
                    error: function (oError) {
                        that.closeDialogReqRule();
                        that.getView().byId("UITabRequestRule").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }
                )
            },
            // To close add row dialog in request rule
            closeDialogReqRule: function () {
                this.oDialogRRule.close();
                this.byId("CustomerIn").getAllInnerControls()[0].setValue("");
                this.byId("CustomerRuleCBDialog").setSelected(false);
            },

            // To delete the Request Rule
            onDeleteReqRule: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("RuleDelete"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.remove(oPath, {
                                success: function (data) {
                                    MessageToast.show(that.i18n.getText("deleted"));
                                },
                                error: function (oError) {
                                    that.displayErrorMessages(oError);
                                    that.getView().byId("UITabRequestRule").getModel().refresh();
                                }
                            });

                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },

            // Escalation Matrix
            // Add row Escalation Matrix
            onAddRowEsclMat: function (oEvent) {
                if (!this.oEsclMatDialog) {
                    var oContext = this.getOwnerComponent().getModel().createEntry("/TM1Hierarchy", {
                        properties: {
                            "Plant": "",
                            "Customer": "",
                            "ProfitCenter": ""
                        }
                    });
                    this.oEsclMatDialog = this.loadFragment({
                        name: "com.jabil.cwamaintenanceapp.fragment.AddRowEsclMat"
                    });
                }
                this.oEsclMatDialog.then(function (oDialogEsclMat) {
                    if (!this.byId("EsclMatForm").getBindingContext()) { this.byId("EsclMatForm").setBindingContext(oContext); }
                    this.oDialogEsclMat = oDialogEsclMat;
                    this.oDialogEsclMat.open();
                }.bind(this));
            },
            // On save button for creating a new escalation matrix
            createEsclMat: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabEscalationMatrix").getModel();
                var newCustomer = this.getView().byId("CustomerInEsclMat").getAllInnerControls()[0].getValue();
                var newSite = this.getView().byId("SiteInEsclMat").getAllInnerControls()[0].getValue();
                var CycleInd = this.getView().byId("CyIndCheck").getSelected();
                var ByHour = this.getView().byId("InputEsclMatHour").getValue();
                var oItem = {
                    "Customer": newCustomer,
                    "Site": newSite,
                    "CycleIndicator": CycleInd,
                    "ByHour": parseInt(ByHour),
                    "Active": true
                };
                oModel.create("/EscalationMatrix", oItem, {
                    success: function (odata) {
                        that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                        that.closeDialogEsclMat();
                        MessageToast.show(that.i18n.getText("saved"));
                    },
                    error: function (oError) {
                        that.closeDialogEsclMat();
                        that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }
                )
            },
            // To close the add row dialog for Escalation Matrix
            closeDialogEsclMat: function () {
                this.oDialogEsclMat.close();
                this.byId("CustomerInEsclMat").getAllInnerControls()[0].setValue("");
                this.byId("SiteInEsclMat").getAllInnerControls()[0].setValue("");
                this.byId("CyIndCheck").setSelected(false);
                this.byId("InputEsclMatHour").setValue("");
            },

            // On click on cycle Indicator checkbox to update the value
            onCycleIndicatorCB: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                var oValue = oEvent.mParameters.selected;
                MessageBox.confirm(that.i18n.getText("CycleIndChange"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.update(oPath, { CycleIndicator: oValue }, {
                                success: function (odata) {
                                    MessageToast.show(that.i18n.getText("Updated"));
                                },
                                error: function (oError) {
                                    MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                                    that.getView().byId("UITabEscalationMatrix").getModel().resetChanges();
                                    that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                                }
                            });
                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                            that.getView().byId("UITabEscalationMatrix").getModel().resetChanges();
                            that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                        }
                    }
                });
            },
            // on Active button to update the escalation matrix
            onActiveEsclMat: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                if (this.getView().getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/Active")) {
                    MessageBox.confirm(that.i18n.getText("deactivateEscalation"), {
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        emphasizedAction: MessageBox.Action.OK,
                        onClose: function (sAction) {
                            if (sAction === MessageBox.Action.OK) {
                                oModel.update(oPath, { Active: false }, {
                                    success: function (odata) {
                                        that.getView().getModel().setProperty(oEvent.getSource().getBindingContext().getPath() + "/Active", false)
                                        MessageToast.show(that.i18n.getText("deactivatedEscl"));
                                    },
                                    error: function (oError) {
                                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                                        that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                                    }
                                });
                            }
                            else {
                                MessageToast.show(that.i18n.getText("actionCancel"));
                            }
                        }
                    });

                } else {
                    MessageBox.confirm(that.i18n.getText("activateEscalation"), {
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        emphasizedAction: MessageBox.Action.OK,
                        onClose: function (sAction) {
                            if (sAction === MessageBox.Action.OK) {
                                oModel.update(oPath, { Active: true }, {
                                    success: function (odata) {
                                        that.getView().getModel().setProperty(oEvent.getSource().getBindingContext().getPath() + "/Active", true)
                                        MessageToast.show(that.i18n.getText("activatedEscl"));
                                    },
                                    error: function (oError) {
                                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                                        that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                                    }
                                });
                            }
                            else {
                                MessageToast.show(that.i18n.getText("actionCancel"));
                            }
                        }
                    });
                }
            },
            // To edit the Escalation Matrix Row
            onEditEsclMat: function (oEvent) {
                var oPath = oEvent.getSource().getBindingContext().getPath();
                this.oPath = oPath;
                if (!this.oEsclEditDialog) {
                    this.oEsclEditDialog = this.loadFragment({
                        name: "com.jabil.cwamaintenanceapp.fragment.EditRowEscalation"
                    });
                }
                this.oEsclEditDialog.then(function (oDialogEditEscalation) {
                    this.oDialogEditEscalation = oDialogEditEscalation;
                    this.oDialogEditEscalation.bindElement({ path: oPath });
                    this.oDialogEditEscalation.open();
                }.bind(this));
            },
            // Save the Edited values in Escalation Mat
            EditEsclMat: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabEscalationMatrix").getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                var editedCycInd = this.getView().byId("InEditCyIndEscl").getSelected();
                var editedHour = this.getView().byId("InEditByHour").getValue();
                var oItem = {
                    "CycleIndicator": editedCycInd,
                    "ByHour": parseInt(editedHour)
                };
                oModel.update(oPath, oItem, {
                    success: function (odata) {
                        that.oDialogEditEscalation.close();
                        MessageToast.show(that.i18n.getText("Updated"));
                        that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                    },
                    error: function (oError) {
                        that.oDialogEditEscalation.close();
                        that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }
                )
            },
            // Close the Edit Dialog Escalation Mat
            closeDialogEsclMatEdit: function () {
                this.oDialogEditEscalation.close();
            },

            // To delete the Escalation Matrix
            onDeleteEsclMat: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("deleteEsclMat"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.remove(oPath, {
                                success: function (data) {
                                    MessageToast.show(that.i18n.getText("deleted"));
                                },
                                error: function (oError) {
                                    that.displayErrorMessages(oError);
                                    that.getView().byId("UITabEscalationMatrix").getModel().refresh();
                                }
                            });

                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },

            // Formatter code for Active button
            activeEsclMat: function (ActiveEsclmat) {
                if (ActiveEsclmat === true) {
                    return "Active";
                } else {
                    return "Off";
                }
            },


            // TM1 Master Hierarchy
            // on Active button to update the Profit Center
            onActiveProfCtr: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                if (this.getView().getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/Active")) {
                    MessageBox.confirm(that.i18n.getText("deactivatedProf"), {
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        emphasizedAction: MessageBox.Action.OK,
                        onClose: function (sAction) {
                            if (sAction === MessageBox.Action.OK) {
                                oModel.update(oPath, { Active: false }, {
                                    success: function (odata) {
                                        that.getView().getModel().setProperty(oEvent.getSource().getBindingContext().getPath() + "/Active", false)
                                        MessageToast.show(that.i18n.getText("deactivatedProfCtr"));
                                    },
                                    error: function (oError) {
                                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                                        that.getView().byId("UITabMasterHierarchy").getModel().refresh();
                                    }
                                });
                            }
                            else {
                                MessageToast.show(that.i18n.getText("actionCancel"));
                            }
                        }
                    });
                } else {
                    MessageBox.confirm(that.i18n.getText("activateProf"), {
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        emphasizedAction: MessageBox.Action.OK,
                        onClose: function (sAction) {
                            if (sAction === MessageBox.Action.OK) {
                                oModel.update(oPath, { Active: true }, {
                                    success: function (odata) {
                                        that.getView().getModel().setProperty(oEvent.getSource().getBindingContext().getPath() + "/Active", true)
                                        MessageToast.show(that.i18n.getText("activatedProf"));
                                    },
                                    error: function (oError) {
                                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                                        that.getView().byId("UITabMasterHierarchy").getModel().refresh();
                                    }
                                });
                            }
                            else {
                                MessageToast.show(that.i18n.getText("actionCancel"));
                            }
                        }
                    });
                }
            },
            // Formatter code for Active button for TM1
            activeButton: function (Active) {
                if (Active === true) {
                    return "Active";
                } else {
                    return "Off";
                }
            },
            activeButtontype: function (Active) {
                if (Active === true) {
                    return "Emphasized";
                } else {
                    return "Default";
                }
            },

            // Email Notification
            // On add row button to load fragment for Email Notification 
            // -------- This code in Commented Now, may need in next phase-------
            // onAddRowEmailNotify: function () {
            //     if (!this.oEmailNotDialog) {
            //         this.oEmailNotDialog = this.loadFragment({
            //             name: "com.jabil.cwamaintenanceapp.fragment.AddRowEmailNotif"
            //         });
            //     }
            //     this.oEmailNotDialog.then(function (oDialogEmail) {
            //         this.oDialogEmail = oDialogEmail;
            //         this.oDialogEmail.open();
            //     }.bind(this));
            // },
            // onSelectType: function () {
            //     if (this.byId("InTypeEN").getValue() == 'Master Hierarchy') {
            //         this.byId("InStatusEN").setValue("Change");
            //         this.byId("InStatusEN").setProperty("editable", false);
            //     }
            //     else {
            //         this.byId("InStatusEN").setProperty("editable", true);
            //         this.byId("InStatusEN").setValue("");
            //     }

            // },
            // // On save button tocreate email notification entry
            // createEmailNotif: function (oEvent) {
            //     var that = this;
            //     var oModel = this.getView().byId("UITabEmailNotifControl").getModel();
            //     var newType = this.getView().byId("InTypeEN").getValue();
            //     var newStatus = this.getView().byId("InStatusEN").getValue();
            //     var newRecipient = this.getView().byId("InEmailNotify").getSelectedItems().map(function (oToken) {
            //         return oToken.getKey();
            //     }).join(",");
            //     var oItem = {
            //         "Type": newType,
            //         "Status": newStatus,
            //         "EmailNotify": newRecipient
            //     };
            //     oModel.create("/EmailNotify", oItem, {
            //         success: function (odata) {
            //             that.getView().byId("UITabEmailNotifControl").getModel().refresh();
            //             that.closeDialogEmailNotif();
            //             MessageToast.show(that.i18n.getText("saved"));
            //         },
            //         error: function (oError) {
            //             MessageBox.error(JSON.parse(oError.responseText).error.message.value);
            //             that.closeDialogEmailNotif();
            //             that.getView().byId("UITabEmailNotifControl").getModel().refresh();

            //         }
            //     })
            // },
            // // To close dialog email notification
            // closeDialogEmailNotif: function () {
            //     this.oDialogEmail.close();
            //     this.byId("InTypeEN").setValue("");
            //     this.byId("InStatusEN").setValue("");
            //     this.byId("InEmailNotify").setSelectedItems([]);
            // },
            // -------- This code in Commented Now, may need in next phase-------

            // Open Edit Row Dialog for Email Notify
            onEditEmailNotify: function (oEvent) {
                var oPath = oEvent.getSource().getBindingContext().getPath();
                this.oPath = oPath;
                if (!this.oEmailEditDialog) {
                    this.oEmailEditDialog = this.loadFragment({
                        name: "com.jabil.cwamaintenanceapp.fragment.EditRowEmailNotify"
                    });
                }
                this.oEmailEditDialog.then(function (oDialogEditEmail) {
                    if (!this.bInitial) {
                        this.onRowSelect();
                    }
                    this.oDialogEditEmail = oDialogEditEmail;
                    this.oDialogEditEmail.open();
                }.bind(this));
            },
            // After loading the edit row dialog, to load the selected values 
            onAfterOpenEditDialog: function () {
                if (this.bInitial) {
                    this.onRowSelect();
                }
                this.bInitial = false;
            },
            // To fill the values of selected line into Edit Row Dialog
            onRowSelect: function () {
                this.byId("InEditTypeEN").setValue(this.getView().getModel().getProperty(this.oPath).Type);
                this.byId("InEditStatusEN").setValue(this.getView().getModel().getProperty(this.oPath).Status);
                var aEmailNotif = [];
                aEmailNotif = this.getView().getModel().getProperty(this.oPath).EmailNotify.split(',');
                this.byId("InEditEmailNotify").setSelectedKeys(aEmailNotif);
            },
            // Save the Edited values in Email Notify
            EditEmailNotif: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabEmailNotifControl").getModel();
                var oPath = this.oPath;
                var editedEmailNotif = this.getView().byId("InEditEmailNotify").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");


                var oItem = {
                    "EmailNotify": editedEmailNotif
                };
                oModel.update(oPath, oItem, {
                    success: function (odata) {
                        that.oDialogEditEmail.close();
                        MessageToast.show(that.i18n.getText("Updated"));
                        that.getView().byId("UITabEmailNotifControl").getModel().refresh();
                    },
                    error: function (oError) {
                        that.oDialogEditEmail.close();
                        that.getView().byId("UITabEmailNotifControl").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }
                )
            },
            // Close the Edit Dialog 
            closeDialogEmailNotifEdit: function () {
                this.oDialogEditEmail.close();
            },

            // To delete email notification 
            onDeleteEmailNotify: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("deleteEmail"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.remove(oPath, {
                                success: function (data) {
                                    MessageToast.show(that.i18n.getText("deleted"));
                                },
                                error: function (oError) {
                                    that.displayErrorMessages(oError);
                                    that.getView().byId("UITabEmailNotifControl").getModel().refresh();
                                }
                            });

                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },

            // BTP Role Mapping
            // On add row button to load fragment for Email Notification 
            onAddRowBtpRoleMapping: function () {
                if (!this.oBTPRoleMapDialog) {
                    this.oBTPRoleMapDialog = this.loadFragment({
                        name: "com.jabil.cwamaintenanceapp.fragment.AddRowBTPRoleMap"
                    });
                }
                this.oBTPRoleMapDialog.then(function (oDialogBTPRole) {
                    this.oDialogBTPRole = oDialogBTPRole;
                    this.oDialogBTPRole.open();
                }.bind(this));
            },
            // On save button tocreate email notification entry
            createBTPRole: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabBtpRoleMapping").getModel();
                var newRole = this.getView().byId("InRoleName").getValue();
                var newBTPRole = this.getView().byId("InBTPRole").getValue();
                var oItem = {
                    "RoleName": newRole,
                    "BTPRoleName": newBTPRole
                };
                // commented the code for create/update customer              
                oModel.create("/BtpRoleMapping", oItem, {
                    success: function (odata) {
                        that.getView().byId("UITabBtpRoleMapping").getModel().refresh();
                        that.closeDialogBTPRole();
                        MessageToast.show(that.i18n.getText("saved"));
                    },
                    error: function (oError) {
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                        that.closeDialogBTPRole();
                        that.getView().byId("UITabBtpRoleMapping").getModel().refresh();

                    }
                })
            },
            // To close dialog email notification
            closeDialogBTPRole: function () {
                this.oDialogBTPRole.close();
                this.byId("InRoleName").setValue("");
                this.byId("InBTPRole").setValue("");
            },
            // To delete email notification 
            onDeleteBtpRoleMapping: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("deleteRole"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.remove(oPath, {
                                success: function (data) {
                                    MessageToast.show(that.i18n.getText("deleted"));
                                },
                                error: function (oError) {
                                    that.displayErrorMessages(oError);
                                    that.getView().byId("UITabBtpRoleMapping").getModel().refresh();
                                }
                            });

                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },


            // Upload Page
            onUploadCompleted: function (oEvent) {
                var oFileUploader = this.getView().byId("table-uploadSet");
                var oItem = oEvent.getParameter("item");
                var oFile = oItem.getFileObject();
                this.onUploadAttachment(oFile, oFileUploader);
            },

            openPreview: function (oEvent) {
                const oSource = oEvent.getSource();
                const oBindingContext = oSource.getBindingContext();
                const docId = oBindingContext.getObject().DmsDocumentId;
                const docType = oBindingContext.getObject().DocumentType;
                const docName = oBindingContext.getObject().DocumentName;
                var that1 = this;
                var oModel = this.getView().getModel();
                var urlCap = $.sap.getModulePath("com.jabil.cwamaintenanceapp") + "/browser/CWA_REQUEST_REPO/root/c27e0192-9271-4339-8980-5684eaf64d04?objectId=" + docId;
                var win = window.open(urlCap, '_blank');
                win.focus();
            },
            onDownloadFiles: function (oEvent) {
                const oContexts = this.byId("table-uploadSet").getSelectedContexts();
                if (oContexts && oContexts.length) {
                    oContexts.forEach((oContext) => this.oUploadPluginInstance.download(oContext, true));
                }
            },
            onPluginActivated: function (oEvent) {
                this.oUploadPluginInstance = oEvent.getParameter("oPlugin");
            },
            onUploadAttachment: async function (oFile, oFileUploader) {
                sap.ui.core.BusyIndicator.show();
                var that = this;
                var reader = new FileReader();
                reader.onload = function (oEvent) {
                    // get an access to the content of the file
                    this.content = oEvent.currentTarget.result;
                    var oImageData = {
                        "content": this.content,
                        "mediaType": oFile.type,
                        "fileName": oFile.name
                    };
                    var oDataModel = this.getView().getModel();
                    oDataModel.create("/MediaFile", oImageData, {
                        success: function (oData, oResponse) {
                            var sMsg = "File Uploaded Successfully";
                            MessageBox.success(sMsg);
                            that.getView().getModel().refresh(true);
                            sap.ui.core.BusyIndicator.hide();
                        },
                        error: function (jqXHR, textStatus) {
                            MessageBox.error("Error while uploading");
                            sap.ui.core.BusyIndicator.hide();
                        },
                    });
                }.bind(this);
                reader.readAsDataURL(oFile);
            },
            getIconSrc: function (mediaType, thumbnailUrl) {
                return UploadSetwithTable.getIconForFileType(mediaType, thumbnailUrl);
            },
            handleMainTemplate: function (oEvent) {
                var that1 = this;
                var oContext = oEvent.getSource().getParent().getBindingContextPath();
                var sActive = oEvent.getParameter("selected");
                if (sActive) {
                }
                var oTemplateData = that1.getView().getModel().getProperty(oContext);
                var oDataModel = this.getOwnerComponent().getModel();
                var oPayload = {
                    "ID": oTemplateData.ID
                }
                var MainMessage = "Post Activating, This Template will be set as default template";
                var Maintitle = "Change in Template";


                if (oTemplateData.Active === false) {
                    new sap.m.MessageBox.confirm(
                        MainMessage, {
                        icon: sap.m.MessageBox.Icon.CONFIRM,
                        title: Maintitle,
                        actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                        onClose: function (oAction) {
                            if (oAction === sap.m.MessageBox.Action.YES) {
                                var urlToRead = "/handleActiveTemplate";
                                oDataModel.create(urlToRead, oPayload, {
                                    success: function (oData, response) {
                                        MessageBox.success("Successfully Activated")
                                        that1.getView().getModel().refresh(true);
                                    }.bind(this),
                                    error: function (error) {
                                        //MessageBox.error("Activation Failed")
                                        that1.displayErrorMessages(error);
                                        that1.getView().getModel().refresh(true);
                                    }.bind(this)
                                });

                            } else {
                                MessageToast.show(that.i18n.getText("actionCancel"))
                                that1.getView().getModel().refresh(true);
                            }
                        }
                    });
                }
            },
            onRemoveHandler: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                var sDocumentId = this.getView().getModel().getProperty(oPath).DmsDocumentId;
                MessageBox.confirm("Please confirm if you want to Delete the Document", {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.callFunction("/deleteDMSDocument", {
                                method: "POST",
                                urlParameters: {
                                    'docId': sDocumentId
                                },
                                success: function (oData) {
                                    oModel.remove(oPath, {
                                        success: function (data) {
                                            MessageToast.show(that.i18n.getText("deleted"));
                                        },
                                        error: function (oError) {
                                            that.displayErrorMessages(oError);
                                        }
                                    });

                                }.bind(this),
                                error: function (oError) {
                                   // MessageToast.show("Error While Deleting");
                                   that.displayErrorMessages(oError);
                                }.bind(this)
                            });
                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },
            onSearchCWATemp: function (oEvent) {
                var oTableSearchState = [],
                    sQuery = oEvent.getParameter("query");

                if (sQuery && sQuery.length > 0) {
                    oTableSearchState = [new Filter("DocumentName", FilterOperator.Contains, sQuery)];
                }

                this.getView().byId("table-uploadSet").getBinding("items").filter(oTableSearchState, "Application");
            }
        }
        )
    }

);

