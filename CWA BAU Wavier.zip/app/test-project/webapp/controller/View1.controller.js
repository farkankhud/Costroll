sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
    //"../../app/cwa-request-create/model/xlsx"

],
    function (Controller, MessageToast, MessageBox, Filter, FilterOperator) {
        "use strict";

        return Controller.extend("testproject.controller.View1", {
            onAfterRendering: function () {
                //Abhishek
                debugger;
            },
            onTriggerReminder: async function () {
                debugger;
                var oModel = this.getView().getModel("tm1"),
                    oOperation = oModel.bindContext("/ApprovalReminder(...)");
                    return await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },
            onTriggerEmail: async function () {
                debugger;
                var oModel = this.getView().getModel(),
                    oOperation = oModel.bindContext("/TestMail(...)");
                oOperation.setParameter('Header', { "createdBy": "deepak_tewari3388@jabil.com", "CWAName": "CWA-MY01-KEY-120924-0060", "Region": "SOUTH ASIA ELECTRONICS", "Site": "MY01" });
                oOperation.setParameter('Status', "4");
                return await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },
            onBgJob: async function () {
                var oModel = this.getView().getModel("tm1"),
                    oOperation = oModel.bindContext("/UpdateDBData(...)");
                return await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },

            onUploadCWA: async function () {
                var oModel = this.getView().getModel(),
                    oOperation = oModel.bindContext("/ValidateCWA(...)");
                oOperation.setParameter('ID', '6dd24588-9f3d-472e-a4c5-76ca6ac8a919');
                return await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },

            onUploadDemand: async function () {
                var oModel = this.getView().getModel(),
                    oOperation = oModel.bindContext("/UploadDemand(...)");
                oOperation.setParameter('ID', '6d46ccb1-a45d-493e-8f00-12d4dad9d836');
                debugger;
                return await oOperation.invoke().then(function () {
                    debugger;
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },

            onSAPJOBIDStatus: async function () {
                var oModel = this.getView().getModel(),
                    oOperation = oModel.bindContext("/UploadDemandStatus(...)");
                oOperation.setParameter('ID', '04a76877-9bfb-43ee-b6d3-1db013d8ae6f');
                debugger;
                return await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                    debugger;
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },

            onSAPJOBIDStatusError: async function () {
                var oModel = this.getView().getModel(),
                    oOperation = oModel.bindContext("/GetError(...)");
                oOperation.setParameter('ID', '04a76877-9bfb-43ee-b6d3-1db013d8ae6f');
                debugger;
                return await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                    debugger;
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },


            onSAPJOBIDError: async function () {
                var oModel = this.getView().getModel(),
                    oOperation = oModel.bindContext("/GetSAPJOBIDError(...)");
                oOperation.setParameter('jobname', 'ZUPL_CHG_CREATE_20240829130621');
                oOperation.setParameter('cwanum', '04a76877-9bfb-43ee-b6d3-1db013d8ae6f');
                debugger;
                return await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                    debugger;
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },

            onUploadFile: async function () {
                //Read the file and get the below details from file
                var oHeaderData = {
                    "Site": "CA02",
                    "Customer": "RADIUS",
                    "Status_ID": 1
                }, oItemData = {
                    "ProfitCenters": "0115RADIUS",
                    "CurrentMS": 4563258,
                    "ProposedMS": 44225566,
                    "MonthTM1": 122,
                    "ApprovedWaiver": 45789655,
                    "FileFromRR": true,
                };

                //Validate The file
                var validationResult = await this._validateFile(oHeaderData, oItemData);
                if (!validationResult) return;

                if (validationResult.ValidationPassed) {
                    switch (validationResult.Action) {
                        case 'HEADER_CREATE':
                            oHeaderData.Division = validationResult.AdditionalDetails.Division;
                            oHeaderData.Segment = validationResult.AdditionalDetails.Segment;
                            oHeaderData.Region = validationResult.AdditionalDetails.Region;
                            //await this.createCWA(oHeaderData, oItemData);
                            break;
                        case 'ITEM_CREATE':
                            oItemData.Parent_ID = validationResult.AdditionalDetails.ExistingCWAID;
                            //this.createCWAItem(oItemData);
                            break;
                        default:
                            break;
                    }

                } else {
                    MessageToast.show(validationResult.Message);
                }
            },
            onSearch: function (oEvent) {
                // add filter for search
                var aFilters = [];
                var sQuery = oEvent.getSource().getValue();
                if (sQuery && sQuery.length > 0) {
                    var filter = new Filter("displayName", FilterOperator.StartsWith, sQuery);
                    aFilters.push(filter);
                }

                // update list binding
                var oList = this.byId("idList");
                var oBinding = oList.getBinding("items");
                oBinding.filter(aFilters, "Application");
            },

            createCWA: async function (headerData, itemData) {
                var deepPayload = { ...headerData, "CWAItems": [itemData] };

                var oModel = this.getView().getModel();
                var oList = oModel.bindList("/Header");
                oList.create(deepPayload, false);
                oList.attachCreateCompleted(function (oEvent) {
                    if (oEvent.getParameters().success == true) {
                        MessageToast.show("New Entry " + oEvent.getParameters().context.getProperty('ID') + " created successfully");
                        oEvent.getSource().getModel().refresh();
                    }
                });
            },

            createCWAItem: async function (itemData) {
                var oModel = this.getView().getModel();
                var oList = oModel.bindList("/Items");
                oList.create(itemData, false);
                oList.attachCreateCompleted(function (oEvent) {
                    if (oEvent.getParameters().success == true) {
                        MessageToast.show("New CWA Item " + oEvent.getParameters().context.getProperty('ID') + " created successfully");
                        oEvent.getSource().getModel().refresh();
                    }
                });
            },

            _validateFile: async function (headerData, itemData) {
                var oModel = this.getView().getModel(),
                    oOperation = oModel.bindContext("/ValidateFileData(...)");
                oOperation.setParameter('Header', headerData);
                oOperation.setParameter('Item', itemData);
                return await oOperation.invoke().then(function () {
                    var oOperationContext = oOperation.getBoundContext();
                    return oOperationContext.getObject();
                }.bind(this), function (oError) {
                    MessageBox.error(oError.message);
                });
            },

            onDownloadFile: function () {
                var oModel = this.getView().getModel(),
                    oOperation = oModel.bindContext("/DownloadDocument(...)");
                oOperation.setParameter('dmsDocumentID', "test_id");
                oOperation.invoke().then(function () {
                }.bind(this), function (oError) {
                    MessageToast.show(oError.message);
                }
                );
            },
            onUploadComplete: function (e) {
                var that = this;
                var file = e.getParameter("files") && e.getParameter("files")[0];
                var reader = new FileReader();
                reader.onload = function (evt) {
                    var data = evt.target.result;
                    var workbook = XLS.read(data, {
                        type: 'binary'
                    });
                    workbook.SheetNames.forEach(function (sheetName) {
                        excelData = XLS.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
                    });
                }
            },
            onUploadAttachment: async function (oFile, oFileUploader) {
                this.busyDialogGlobal = new sap.m.BusyDialog({
                    title: "Attachment",
                    text: "Uploading Attachment.."
                });
                this.busyDialogGlobal.open();
                this.modelDocument = this.getView().getModel("modelDocument").getData();
                var sRepoId = "TIA_ECERA_REPO";
                var url = $.sap.getModulePath("com.test.ecerarouting") + '/browser/' + sRepoId + '/root/' + this.folderUUID;
                this.dmsData = [];
                var fileName = oFile.name;
                var fileType = oFile.type;

                var form = new FormData();
                form.append("filename", fileName);
                form.append("cmisaction", "createDocument");
                form.append("propertyId[0]", "cmis:name");
                form.append("propertyValue[0]", fileName);
                form.append("propertyId[1]", "cmis:objectTypeId");
                form.append("propertyValue[1]", "cmis:document");
                form.append("succinct", "true");
                form.append("media", oFile);

                await $.ajax(url, {
                    type: 'POST',
                    data: form,
                    cache: false,
                    processData: false,
                    contentType: false,
                    success: function (oData) {
                        // BusyIndicator.hide();
                        this.busyDialogGlobal.close();
                        oData.succinctProperties['cmis:objectId'];
                        MessageBox.success("File Uploaded Successfully");
                        var objectId = oData.succinctProperties['cmis:objectId'];//oData.properties['cmis:objectId'].value;
                        var objectURL = $.sap.getModulePath("com.test.ecerarouting") + '/browser/' + sRepoId + '/root/' + this.folderUUID + '?objectId=' + objectId;
                        var oTempObject = {
                            "CERA_ID": "",
                            "DOC_ID": objectId,
                            "FILENAME": fileName,
                            "UPLOADEDBY": this.oFullName,
                            "MIMETYPE": fileType,
                            "URL": objectURL
                        }
                        this.modelDocument.push(oTempObject);
                        this.getView().getModel("modelDocument").refresh();

                    }.bind(this),
                    error: function (oError) {
                        // oFileUploader.getItems().shift();    
                        this.busyDialogGlobal.close();
                        // BusyIndicator.hide();
                        if (oError.responseJSON) {
                            MessageBox.error(oError.responseJSON.message);
                        } else {
                            MessageBox.error("Error while uploading attachement!!");
                        }

                    }.bind(this)
                })

            },


        });
    });
