sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/Device",
    "sap/base/Log",
    'sap/ui/model/odata/v2/ODataModel',
    'sap/ui/model/json/JSONModel',
    'sap/m/Label',
    "sap/ui/core/Fragment",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/comp/smartvariants/PersonalizableInfo',
    'sap/m/MessageToast',
    "sap/m/MessageBox",
    "sap/ushell/Container"

],
    function (Controller, Device, Log, ODataModel, JSONModel, Label, Fragment, Filter, FilterOperator, PersonalizableInfo, MessageToast, MessageBox, Container) {
        "use strict";
        var allowedAssignments;
        return Controller.extend("com.jabil.role.cwaroleassign.controller.RoleAssign", {
            onInit: function () {
                this.bInitial = true;
                this.GAdmin = false;
                this.RAdmin = false;
                this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },

            onBeforeRebindTableExtension: function (oEvent) {
                let oBindingParam = oEvent.getParameter("bindingParams");
                oBindingParam.parameters["expand"] = "RoleDesc";
            },

            onRegionChange: function (oEvent) {
                if (this.byId("InRegion2").getSelectedKeys()[0]) {
                    if (!this.GAdmin) {
                        this.byId("InSiteAssignAdd2").setProperty("editable", true);
                        var selectedItems = oEvent.getSource().getSelectedItems();
                        var aFilters = selectedItems.map((item) => { return new Filter('REGION', FilterOperator.EQ, item.getKey()) });
                        this.byId('InSiteAssignAdd2').getBinding("items").filter(aFilters);
                    }
                }
                else {
                    this.byId("InSiteAssignAdd2").setSelectedItems([]);
                    this.byId("InCustomerAssign2").setSelectedItems([]);
                    this.byId("InProCenter2").setSelectedItems([]);
                    this.byId("InSiteAssignAdd2").setProperty("editable", false);
                    this.byId("InCustomerAssign2").setProperty("editable", false);
                    this.byId("InProCenter2").setProperty("editable", false);
                }
            },

            onPlantChange: function (oEvent) {
                if (this.byId("InSiteAssignAdd2").getSelectedKeys()[0]) {
                    if (!this.RAdmin) {
                        this.byId("InCustomerAssign2").setProperty("editable", true);
                        //any Plant changes => apply filter Customer list binding 
                        var selectedItems = oEvent.getSource().getSelectedItems();
                        var selectedItemsRegion = this.byId("InRegion2").getSelectedItems();
                        var aFilters = selectedItems.map((item) => { return new Filter('PLANT', FilterOperator.EQ, item.getKey()) });
                        var aFiltersRegion = selectedItemsRegion.map((item) => { return new Filter('REGION', FilterOperator.EQ, item.getKey()) });
                        aFilters.push(...aFiltersRegion);
                        this.byId('InCustomerAssign2').getBinding("items").filter(aFilters);
                    }
                }
                else {
                    this.byId("InCustomerAssign2").setSelectedItems([]);
                    this.byId("InProCenter2").setSelectedItems([]);
                    this.byId("InCustomerAssign2").setProperty("editable", false);
                    this.byId("InProCenter2").setProperty("editable", false);
                }
            },

            onCustChange: function (oEvent) {
                if (this.byId("InCustomerAssign2").getSelectedKeys()[0]) {
                    this.byId("InProCenter2").setProperty("editable", true);
                    //any Customer changes => apply filter Profit Center list binding 
                    var selectedItems = oEvent.getSource().getSelectedItems();
                    var selectedItemsRegion = this.byId("InRegion2").getSelectedItems();
                    var selectedItemsPlant = this.byId("InSiteAssignAdd2").getSelectedItems();
                    var aFilters = selectedItems.map((item) => { return new Filter('CUSTOMER', FilterOperator.EQ, item.getKey()) });
                    var aFiltersRegion = selectedItemsRegion.map((item) => { return new Filter('REGION', FilterOperator.EQ, item.getKey()) });
                    var aFiltersPlant = selectedItemsPlant.map((item) => { return new Filter('PLANT', FilterOperator.EQ, item.getKey()) });
                    aFilters.push(...aFiltersRegion);
                    aFilters.push(...aFiltersPlant);
                    this.byId('InProCenter2').getBinding("items").filter(aFilters);
                }
                else {
                    this.byId("InProCenter2").setSelectedItems([]);
                    this.byId("InProCenter2").setProperty("editable", false);
                }
            },

            onAddRowRoleAssignment2: function () {
                sap.ui.core.BusyIndicator.show();
                var graphModel = new JSONModel({
                    'Results': {}
                });
                this.getView().setModel(graphModel, "GraphUser");

                if (!this.oRoleAssign2) {
                    this.oRoleAssign2 = this.loadFragment({
                        name: "com.jabil.role.cwaroleassign.fragment.AddRowRoleAssign2"
                    });
                }
                this.oRoleAssign2.then(function (oRoleDialog2) {
                    this.oRoleDialog2 = oRoleDialog2;
                    this.oRoleDialog2.open();
                }.bind(this));
            },

            onBeforeOpenAddDialog2: function () {
                var that = this;
                this.getOwnerComponent().getModel().callFunction("/getAllowedAssignments", {
                    method: "POST",
                    urlParameters: {},
                    success: function (oData) {
                        var allowedAssignments = {};
                        allowedAssignments = oData.getAllowedAssignments;
                        var lRegion = allowedAssignments.REGION.length;
                        var lPlant = allowedAssignments.PLANT.length;
                        var allRegions = allowedAssignments.REGION;
                        var aRegions = [];
                        for (var i in allRegions)
                            aRegions.push([allRegions[i].REGION]);
                        var allPlants = allowedAssignments.PLANT;
                        var aPlants = [];
                        for (var i in allPlants)
                            aPlants.push([allPlants[i].PLANT]);

                        if (allowedAssignments.Roles == 'Global Admin') {
                            this.GAdmin = true;
                        }
                        else if (allowedAssignments.Roles == 'Regional Admin') {
                            this.RAdmin = true;
                            this.byId("InRegion2").setSelectedKeys(aRegions);
                            this.getView().byId("InSiteAssignAdd2").setProperty("editable", true, "required", true);
                        }
                        else if (allowedAssignments.Roles == 'Site Admin') {
                        }

                        if (lRegion == 1 && allowedAssignments.Roles == 'Regional Admin') {
                            this.byId("InRegion2").setSelectedKeys(aRegions);
                            this.getView().byId("InRegion2").setProperty("editable", false);
                            this.getView().byId("InSiteAssignAdd2").setProperty("editable", true);
                        }

                        if (allowedAssignments.Roles == 'Site Admin') {
                            this.byId("InRegion2").setSelectedKeys(aRegions);
                            this.byId("InSiteAssignAdd2").setSelectedKeys(aPlants);
                            this.getView().byId("InCustomerAssign2").setProperty("editable", true);
                            this.getView().byId("InSiteAssignAdd2").setProperty("editable", true);
                            if (lPlant == 1) {
                                this.getView().byId("InSiteAssignAdd2").setProperty("editable", false);
                                this.getView().byId("InCustomerAssign2").setProperty("editable", true);
                            }
                            if (lRegion == 1) {
                                this.getView().byId("InRegion2").setProperty("editable", false);
                            }
                        }

                        var oModelRoles = new JSONModel();
                        oModelRoles.setData(allowedAssignments);
                        that.byId("AddRowRoleAssign2").setModel(oModelRoles);
                        sap.ui.core.BusyIndicator.hide();
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        that.displayErrorMessages(oError);
                    }.bind(this)
                });


            },

            displayErrorMessages: function (oError) {
                if (oError.responseText && JSON.parse(oError.responseText).error
                    && JSON.parse(oError.responseText).error.message && JSON.parse(oError.responseText).error.message.value) {
                    MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                } else {
                    MessageBox.error(this.i18n.getText("operationFailedMsg"));
                }
            },

            closeDialogRoleAssign2: function () {
                var aBlank = [];
                this.byId("InUser2").setValue("");
                this.byId("InUserName2").setValue("");
                this.byId("InRoleNameAssign2").setSelectedItems([]);
                this.byId("InAppType2").setValue("");
                this.byId("InRegion2").setSelectedKeys(aBlank);
                this.byId("InSiteAssignAdd2").setSelectedKeys(aBlank);
                this.byId("InCustomerAssign2").setSelectedKeys(aBlank);
                this.byId("InProCenter2").setSelectedKeys(aBlank);
                this.getView().byId("InUser2").setProperty("editable", true);
                this.getView().byId("InUserName2").setProperty("editable", true);
                this.getView().byId("InSiteAssignAdd2").setProperty("editable", false);
                this.getView().byId("InCustomerAssign2").setProperty("editable", false);
                this.getView().byId("InProCenter2").setProperty("editable", false);
                this.oRoleDialog2.close();
            },

            //Save a new role assignment
            createRoleAssign: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabRoleAssignment").getModel();
                var user = this.getView().byId("InUser2").getValue();
                var userName = this.getView().byId("InUserName2").getValue();
                var roleName = this.getView().byId("InRoleNameAssign2").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");

                var AppType = this.getView().byId("InAppType2").getValue();
                var region = this.getView().byId("InRegion2").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                region = region || "*";

                var site = this.getView().byId("InSiteAssignAdd2").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                site = site || "*";

                var customer = this.getView().byId("InCustomerAssign2").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                customer = customer || "*";

                var profitCenter = this.getView().byId("InProCenter2").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                profitCenter = profitCenter || "*";

                var oItem = {
                    "User": user,
                    "UserName": userName,
                    "RoleName": roleName,
                    "ApprovalType": AppType,
                    "Region": region,
                    "Site": site,
                    "Customer": customer,
                    "ProfitCenter": profitCenter
                };
                oModel.create("/roleAssignment", oItem, {
                    success: function (odata) {
                        that.closeDialogRoleAssign2();
                        that.getView().byId("UITabRoleAssignment").getModel().refresh();
                        MessageToast.show(that.i18n.getText("saved"));
                    },
                    error: function (oError) {
                        // that.closeDialogRoleAssign2();
                        that.getView().byId("UITabRoleAssignment").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                })
            },

            // Calling Value help from Graph API
            onValueHelpChangeLogRequestedUser: function (oEvent) {
                this.parentUserId = oEvent.getSource().getId();
                var graphModel = new JSONModel({
                    'Results': {}
                });
                this.getView().setModel(graphModel, "GraphUser");
                if (!this._oValueHelpDialog) {
                    this._oValueHelpDialog = this.loadFragment({
                        name: "com.jabil.role.cwaroleassign.fragment.UserDialog"
                    });
                }
                this._oValueHelpDialog.then(function (oValueDialog) {
                    this.oValueDialog = oValueDialog;
                    this.oValueDialog.open();
                }.bind(this));
            },
            // After selece from Graph API result
            handleConfirmUser: function (oEvent) {
                var aContexts = oEvent.getParameter("selectedContexts");
                var userMail = oEvent.getParameter("selectedItem").mProperties.key;
                var userName = oEvent.getParameter("selectedItem").mProperties.text;
                if (aContexts && aContexts.length > 0) {
                    var mail = aContexts[0].getObject().mail;
                    // var mail = aContexts[0].getObject().username;
                    this.getView().byId("InUser2").setValue(mail);
                    this.getView().byId("InUserName2").setValue(aContexts[0].getObject().displayName);
                    this.getView().byId("InUser2").setProperty("editable", false)
                    this.getView().byId("InUserName2").setProperty("editable", false)
                }
                else if (userMail) {
                    this.getView().byId("InUser2").setValue(userMail);
                    this.getView().byId("InUserName2").setValue(userName);
                    this.getView().byId("InUser2").setProperty("editable", false)
                    this.getView().byId("InUserName2").setProperty("editable", false)
                }
            },

            // Search in Graph API 
            handleSearchUser: function (oEvent) {
                var that = this;
                const user = oEvent.getParameter("value");
                var oFilterP = [];
                oFilterP.push(new Filter({
                    path: "displayName",
                    operator: FilterOperator.EQ,
                    value1: user
                }));
                if (oFilterP[0].oValue1 === "") { }
                else {
                    this.getView().getModel().read("/User", {
                        urlParameters: {},
                        async: true,
                        filters: oFilterP,
                        success: function (oData, oResponse) {
                            that.getView().getModel("GraphUser").setData(oData.results);
                            that.oValueDialog.setBusy(false);

                        }.bind(this),
                        error: function (oError) {
                            that.oValueDialog.setBusy(false);
                            new sap.m.MessageToast.show(that.i18n.getText("errorUser"));
                        }
                    });
                }
            },
            // To delete the role assignment
            onActionDelete: function (oEvent) {
                var that = this;
                var oModel = this.getOwnerComponent().getModel();
                var oPath = oEvent.getSource().getBindingContext().getPath();
                MessageBox.confirm(that.i18n.getText("DeleteConfirm"), {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === MessageBox.Action.OK) {
                            oModel.remove(oPath, {
                                success: function (data) {
                                    MessageToast.show(that.i18n.getText("deleted"));
                                },
                                error: function (oError) {
                                    that.displayErrorMessages(oError);
                                    that.getView().byId("UITabRoleAssignment").getModel().refresh();
                                }
                            });
                            // MessageToast.show(that.i18n.getText("deleted"));
                        }
                        else {
                            MessageToast.show(that.i18n.getText("actionCancel"));
                        }
                    }
                });
            },
            //Open the Edit Role Assignment Dialog
            onEditRole: function (oEvent) {
                var oPath = oEvent.getSource().getBindingContext().getPath();
                this.oPath = oPath;
                if (!this.oRoleEditDialog) {
                    this.oRoleEditDialog = this.loadFragment({
                        name: "com.jabil.role.cwaroleassign.fragment.EditRowRoleAssign"
                    });
                }
                this.oRoleEditDialog.then(function (oDialogEdit) {
                    if (!this.bInitial) {
                        this.onRowSelect();
                    }
                    this.oDialogEdit = oDialogEdit;
                    this.oDialogEdit.bindElement({ path: oPath });
                    this.oDialogEdit.open();
                }.bind(this));
            },

            // After Edit Row Dialog Open to load the selected row values
            onBeforeOpenEditDialog: function () {
                if (this.bInitial) {
                    this.onRowSelect();
                }
                this.bInitial = false;
            },

            onRowSelect: function () {
                var that = this;
                this.getOwnerComponent().getModel().callFunction("/getAllowedAssignments", {
                    method: "POST",
                    urlParameters: {},
                    success: function (oData) {
                        var allowedAssignments = {};
                        allowedAssignments = oData.getAllowedAssignments;
                        if (allowedAssignments.Roles == 'Global Admin') {
                            this.GAdmin = true;
                        }
                        else if (allowedAssignments.Roles == 'Regional Admin') {
                            this.RAdmin = true;
                            this.getView().byId("InEditSite").setProperty("editable", true);
                        }
                        else if (allowedAssignments.Roles == 'Site Admin') {
                        }

                        if (allowedAssignments.Roles == 'Regional Admin') {
                            this.getView().byId("InEditRegion").setProperty("editable", false);
                            this.getView().byId("InEditSite").setProperty("editable", true);
                        }

                        if (allowedAssignments.Roles == 'Site Admin') {
                            this.getView().byId("InEditCust").setProperty("editable", true);
                            this.getView().byId("InEditSite").setProperty("editable", true);
                            this.getView().byId("InEditProfitCtr").setProperty("editable", true);

                        }
                        var oModelRoles = new JSONModel();
                        oModelRoles.setData(allowedAssignments);
                        that.byId("EditRowRoleAssignForm").setModel(oModelRoles);
                    }.bind(this),
                    error: function (oError) {
                        that.displayErrorMessages(oError);
                    }.bind(this)
                });
            },
            onAfterOpenEditDialog: function () {
                var aRegion = [];
                var aRegion = this.getView().getModel().getProperty(this.oPath).Region.split(',');
                this.byId("InEditRegion").setSelectedKeys(aRegion);
                var aPlants = [];
                var aPlants = this.getView().getModel().getProperty(this.oPath).Site.split(',');
                this.byId("InEditSite").setSelectedKeys(aPlants);
                var aCustomer = [];
                var aCustomer = this.getView().getModel().getProperty(this.oPath).Customer.split(',');
                this.byId("InEditCust").setSelectedKeys(aCustomer);
                var aProCtr = [];
                var aProCtr = this.getView().getModel().getProperty(this.oPath).ProfitCenter.split(',');
                this.byId("InEditProfitCtr").setSelectedKeys(aProCtr);

                var sUser = this.getView().getModel().getProperty(this.oPath).User;
                this.byId("InEditUser").setValue(sUser);

                var sUserName = this.getView().getModel().getProperty(this.oPath).UserName;
                this.byId("InEditUserName").setValue(sUserName);

                var aRoleName = [];
                aRoleName = this.getView().getModel().getProperty(this.oPath).RoleName.split(',');
                this.byId("InEditRoleName").setSelectedKeys(aRoleName);

                this.byId("InEditType").setValue(this.getView().getModel().getProperty(this.oPath).ApprovalType)

            },
            onRegionChangeEdit: function (oEvent) {
                if (this.byId("InEditRegion").getSelectedKeys()[0]) {
                    if (!this.GAdmin) {
                        this.byId("InEditSite").setProperty("editable", true);
                        var selectedItems = oEvent.getSource().getSelectedItems();
                        var aFilters = selectedItems.map((item) => { return new Filter('REGION', FilterOperator.EQ, item.getKey()) });
                        this.byId('InEditSite').getBinding("items").filter(aFilters);
                    }
                }
                else {
                    this.byId("InEditSite").setSelectedItems([]);
                    this.byId("InEditCust").setSelectedItems([]);
                    this.byId("InEditProfitCtr").setSelectedItems([]);
                    this.byId("InEditSite").setProperty("editable", false);
                    this.byId("InEditCust").setProperty("editable", false);
                    this.byId("InEditProfitCtr").setProperty("editable", false);
                }
            },

            onPlantChangeEdit: function (oEvent) {
                if (this.byId("InEditSite").getSelectedKeys()[0]) {
                    if (!this.RAdmin) {
                        this.byId("InEditCust").setProperty("editable", true);
                        var selectedItems = oEvent.getSource().getSelectedItems();
                        var selectedItemsRegion = this.byId("InEditRegion").getSelectedItems();
                        var aFilters = selectedItems.map((item) => { return new Filter('PLANT', FilterOperator.EQ, item.getKey()) });
                        var aFiltersRegion = selectedItemsRegion.map((item) => { return new Filter('REGION', FilterOperator.EQ, item.getKey()) });
                        aFilters.push(...aFiltersRegion);
                        this.byId('InEditCust').getBinding("items").filter(aFilters);
                    }
                }
                else {
                    this.byId("InEditCust").setSelectedItems([]);
                    this.byId("InEditProfitCtr").setSelectedItems([]);
                    this.byId("InEditCust").setProperty("editable", false);
                    this.byId("InEditProfitCtr").setProperty("editable", false);
                }
            },

            onCustChangeEdit: function (oEvent) {
                if (this.byId("InEditCust").getSelectedKeys()[0]) {
                    this.byId("InEditProfitCtr").setProperty("editable", true);
                    var selectedItems = oEvent.getSource().getSelectedItems();
                    var selectedItemsRegion = this.byId("InEditRegion").getSelectedItems();
                    var selectedItemsPlant = this.byId("InEditSite").getSelectedItems();
                    var aFilters = selectedItems.map((item) => { return new Filter('CUSTOMER', FilterOperator.EQ, item.getKey()) });
                    var aFiltersRegion = selectedItemsRegion.map((item) => { return new Filter('REGION', FilterOperator.EQ, item.getKey()) });
                    var aFiltersPlant = selectedItemsPlant.map((item) => { return new Filter('PLANT', FilterOperator.EQ, item.getKey()) });
                    aFilters.push(...aFiltersRegion);
                    aFilters.push(...aFiltersPlant);
                    this.byId('InEditProfitCtr').getBinding("items").filter(aFilters);
                }
                else {
                    this.byId("InEditProfitCtr").setSelectedItems([]);
                    this.byId("InEditProfitCtr").setProperty("editable", false);
                }
            },

            // Close the Edit Role dialog
            closeDialogEditRole: function () {
                var aBlank = [];
                this.byId("InEditUser").setValue("");
                this.byId("InEditUserName").setValue("");
                this.byId("InEditRoleName").setSelectedKeys(aBlank);
                this.byId("InEditType").setValue("");
                this.byId("InEditRegion").setSelectedKeys(aBlank);
                this.byId("InEditSite").setSelectedKeys(aBlank);
                this.byId("InEditCust").setSelectedKeys(aBlank);
                this.byId("InEditProfitCtr").setSelectedKeys(aBlank);
                this.oDialogEdit.close();
            },
            // To save the new role assignment
            EditRoleSave: function (oEvent) {
                var that = this;
                var oModel = this.getView().byId("UITabRoleAssignment").getModel();
                var editedRoleName = this.getView().byId("InEditRoleName").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                var editedRegion = this.getView().byId("InEditRegion").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                editedRegion = editedRegion || "*";
                var editedSite = this.getView().byId("InEditSite").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                editedSite = editedSite || "*";
                var editedCustomer = this.getView().byId("InEditCust").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                editedCustomer = editedCustomer || "*";
                var editedProfCtr = this.getView().byId("InEditProfitCtr").getSelectedItems().map(function (oToken) {
                    return oToken.getKey();
                }).join(",");
                editedProfCtr = editedProfCtr || "*";
                var editedType = this.getView().byId("InEditType").getValue();
                var oItem = {
                    "User": this.getView().byId("InEditUser").getValue(),
                    "UserName": this.getView().byId("InEditUserName").getValue(),
                    "RoleName": editedRoleName,
                    "Region": editedRegion,
                    "Site": editedSite,
                    "Customer": editedCustomer,
                    "ProfitCenter": editedProfCtr,
                    "ApprovalType": editedType
                };
                oModel.update(this.oPath, oItem, {
                    success: function (odata) {
                        that.oDialogEdit.close();
                        MessageToast.show(that.i18n.getText("Updated"));
                        that.getView().byId("UITabRoleAssignment").getModel().refresh();
                    },
                    error: function (oError) {
                        // that.oDialogEdit.close();
                        that.getView().byId("UITabRoleAssignment").getModel().refresh();
                        MessageBox.error(JSON.parse(oError.responseText).error.message.value);
                    }
                }

                )
            }
            // ,
            // checkMandatory: function (oEvent) {
            //     if (this.byId("InUser2")._lastValue == '' ||
            //         this.byId("InUserName2")._lastValue == '' ||
            //         this.byId("InRoleNameAssign2").getSelectedItems().length == 0 ||
            //         this.byId("InAppType2")._lastValue == '') {
            //         this.byId("AcceptRoleAssign2").setEnabled(false);
            //     }
            //     else{
            //         this.byId("AcceptRoleAssign2").setEnabled(true);
            //     }
            // }
        });
    });
