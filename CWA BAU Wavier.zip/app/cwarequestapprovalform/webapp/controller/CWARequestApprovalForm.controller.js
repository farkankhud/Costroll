sap.ui.define(
    [
      "sap/ui/core/mvc/Controller"
    ],
    function (BaseController) {
      "use strict";
  
      return BaseController.extend("com.jabil.cwarequestapprovalform.controller.CWARequestApprovalForm", {
        onInit: async function () {
          // sap.ushell.Container.getServiceAsync("UserInfo").then(function (UserInfo) {
          //   var oFullName = UserInfo.getFullName();
          //   this.oEmail = UserInfo.getEmail();
          //   if (!oFullName) {
          //     oFullName = 'Divye Aggarwal';
          //     this.oFullName = oFullName;
          //   } else {
          //     this.oFullName = oFullName;
          //   }
          //   this.getView().getModel("context").setProperty("/Approver", this.oFullName);
          // }.bind(this));
   
          // var contextData = this.getView().getModel("context").getData();
          // console.log(contextData);
          // const reqId = contextData.CWARequestID;
          // console.log(reqId);
          // if (reqId) {
            // var requestData = await this.getRequestDetails(reqId);
            // var oModel = new sap.ui.model.json.JSONModel(requestData[0]); // Properly creating a JSON model
            //   this.getView().setModel(oModel, "CWACreateRequestModel");
          //}
          // var rejectionReason = await this.getRejectionReason();
          //   var oModel = new sap.ui.model.json.JSONModel(rejectionReason); // Properly creating a JSON model
          //   this.getView().setModel(oModel, "rejectionReasons");
        },
        onSelectRB: function (oEvent) {
          var getSelected = oEvent.getParameters().selectedIndex;
          this.getView().getModel("context").setProperty("/selectedRB",getSelected);
          if(getSelected == 0) {
            var triggerTypeText = "BU Waiver Required";
          } else if(getSelected == 1 || getSelected == 2) {
            var triggerTypeText = "BU Waiver Not Required";
          } 
          this.getOwnerComponent().getModel("context").setProperty("/BUWaiverStatus", triggerTypeText)
        },
        formatMenuButtonText: function (sDocumentName, sDocumentType) {
          return sDocumentName + "." + sDocumentType;
      },
        onBeforeRendering:  function () {
          // this.loadData()
        },
        onAfterRendering:  function () {
          // this.loadData()
        },
        loadData: async function () {
          var contextData = this.getOwnerComponent().getModel("context").getData();
          const reqId = contextData.CWARequestID;
          console.log(reqId);
          if (reqId) {
            var requestData = await this.getRequestDetails(reqId);
            var oModel = new sap.ui.model.json.JSONModel(requestData[0]); // Properly creating a JSON model
              this.getView().setModel(oModel, "CWACreateRequestModel");
          }
        },
        getRequestDetails: function(reqId) {
          return new Promise((resolve, reject) => {
              var urlCap = $.sap.getModulePath("com.jabil.cwaworkflowuimodule") + "/v2/service/CWARequest/CWADashboardWorkflow?$filter=CWAName eq '" + reqId + "'&$expand=FileID,CWAAttachments,Status,CWAItems($expand=FileID,CWAAttachments($expand=FileID)),CWAApprovers,CWAWFHistory,ToBeCWACurrentApproval";
              
              $.ajax({
                  url: urlCap,
                  type: 'GET',
                  contentType: 'application/json',
                  success: function(oData) {
                    console.log(oData);
                      resolve(oData.d.results);
                  },
                  error: function(oError) {
                      reject(oError);
                  }
              });
          });
        },
        getRejectionReason: function(reqId) {
          return new Promise((resolve, reject) => {
              var urlCap = $.sap.getModulePath("com.jabil.cwaworkflowuimodule") + "/v2/odata/v4/cwamaintenance/RejectionReason";
              
              $.ajax({
                  url: urlCap,
                  type: 'GET',
                  contentType: 'application/json',
                  success: function(oData) {
                    console.log(oData);
                      resolve(oData.d.results);
                  },
                  error: function(oError) {
                      reject(oError);
                  }
              });
          });
        },
        OnDownloadExcel:function (oEvent) {
          var iIndex = parseInt(oEvent.getParameters().item.getBindingContext("context").getPath().charAt(oEvent.getParameters().item.getBindingContext("context").getPath().lastIndexOf("/") + 1));
          var docId = this.getView().getModel("context").getProperty("/FileDocuments")[iIndex].DocID
          var oContextData = this.getView().getModel("context").getData();
          var urlCap = $.sap.getModulePath("com.jabil.cwaworkflowuimodule") + "/browser/CWA_REQUEST_REPO/root/" + oContextData.CWAGUID + "?objectId=" + docId;
          window.open(urlCap);
              
        },
        onOpeningFile: function (oEvent) {
          const docId = oEvent.getSource().getUrl();
          var oContextData = this.getView().getModel("context").getData();
          var urlCap = $.sap.getModulePath("com.jabil.cwaworkflowuimodule") + "/browser/CWA_REQUEST_REPO/root/" + oContextData.CWAGUID + "?objectId=" + docId;
          var win = window.open(urlCap, '_blank');
                win.focus();
  
        }
      });
    }
  );
  
