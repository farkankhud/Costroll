const cds = require('@sap/cds');
const CWAMaintenanceHandler = require('./Utils/cwa-maintenanceHandler').CWAMaintenanceHandler;
const axios = require('axios').default;
const FormData = require('form-data');
const { OpenApiRequestBuilder } = require('@sap-cloud-sdk/openapi');
const xlsx = require("xlsx");
const crypto = require('crypto');
const RoleUtility = require("./Utils/roles").RolesUtil;

module.exports = cds.service.impl(srv => {

  // IT Reader Role Check #DELETE A
  srv.before(['DELETE'],'*',async function (req) {
    if(await RoleUtility.userIsReaderOnly(req)){
      req.error({
        message: process.env.ReaderRoleErrorMessage,
        status: 418
    });
      return;
    }
  });

    // IT Reader Role Check #CREATE
    srv.before(['CREATE'],['TM1Hierarchy', 'EscalationMatrix', 'BtpRoleMapping', 'TemplateStore', 'RoleName', 'CWAStatuses'],async function (req) {
      if(await RoleUtility.userIsReaderOnly(req)){
        req.error({
          message: process.env.ReaderRoleErrorMessage,
          status: 418
      });
        return;
      }
    });

        // IT Reader Role Check #UPDATE
    srv.before(['UPDATE'],['TM1Hierarchy', 'EscalationMatrix', 'BtpRoleMapping', 'TemplateStore', 'RoleName', 'CWAStatuses'],async function (req) {
      if(await RoleUtility.userIsReaderOnly(req)){
        req.error({
          message: process.env.ReaderRoleErrorMessage,
          status: 418
      });
        return;
      }
    });

    srv.before(['deleteDMSDocument', 'handleActiveTemplate'], async (req) => {
          if (await RoleUtility.userIsReaderOnly(req)) {
            req.error({
              message: process.env.ReaderRoleErrorMessage,
              status: 418
          });
              return;
          }
      });

  //Get RequestRule
  // srv.after('READ', 'RequestRule', CWAMaintenanceHandler._getRequestRule)
  //Add implementation for TM1Hierarchy
  srv.after(['READ'], 'TM1Hierarchy', CWAMaintenanceHandler._getTM1HierarchyRole);
  // srv.on('READ', 'TM1Hierarchy', CWAMaintenanceHandler._PlantVH);
  //Add implementation for RequestRule
  srv.before(['CREATE', 'UPDATE',], 'RequestRule', CWAMaintenanceHandler._validateProfitCenterProfitCenterRule)
  srv.after(['READ'], 'RequestRule', CWAMaintenanceHandler._getMaintenanceRole)
  //Add implementation for RejectionReason
  srv.before(['CREATE', 'UPDATE',], 'RejectionReason', CWAMaintenanceHandler._RejectionReason);
  srv.after(['READ'], 'RejectionReason', CWAMaintenanceHandler._getRejectionReasonRole);

  //Add implementation for EscalationMatrix
  srv.after(['READ'], 'EscalationMatrix', CWAMaintenanceHandler._getEscalationMatrixRole);

  //Add implementation for EmailNotify
  srv.before(['CREATE', 'UPDATE',], 'EmailNotify', CWAMaintenanceHandler._EmailNotify)
  srv.after(['READ'], 'EmailNotify', CWAMaintenanceHandler._getEmailNotify)
  srv.after(['READ'], 'DeleteEnable', CWAMaintenanceHandler._getDeleteEnableRole);

  srv.on('handleActiveTemplate', async (req) => {
    var id = req.data.ID;

    await UPDATE.entity('CWA_REQUEST.TemplateStore').with({ Active: false, modifiedAt: new Date().toISOString(), modifiedBy: req.user.id }).where({ Active: true })
    await UPDATE.entity('CWA_REQUEST.TemplateStore').with({ Active: true, modifiedAt: new Date().toISOString(), modifiedBy: req.user.id }).where({ ID: id })
  });
  srv.on('getPanelAccess', CWAMaintenanceHandler._getPanelAccess);
  srv.on('getMediaFile', async (req) => {
    var id = req.data.ID;
    try {

      const fileBuffer = await new OpenApiRequestBuilder('GET', '/browser/CWA_REQUEST_REPO/root/c27e0192-9271-4339-8980-5684eaf64d04?objectId=' + id)
        .addCustomRequestConfiguration({ responseType: 'arraybuffer' })
        .execute({ destinationName: 'CWARequestDMS' });
      console.log(fileBuffer);

      const workbook = xlsx.read(fileBuffer, { type: 'buffer' })
      const sheetNames = workbook.SheetNames;
      const firstSheetName = sheetNames[0];
      const sheet = workbook.Sheets[firstSheetName];
      const data = xlsx.utils.sheet_to_json(sheet);
      console.log(data);
      return fileBuffer;

    } catch (error) {
      console.log(error);
    }
    // const url = "https://jabilcfdev.authentication.us10.hana.ondemand.com";
    // const clientid = "sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
    // const clientSecret = "HQJVceIL92Oo9dr8RHrK4L7oP2U=";
    // //
    // var repositoryId = "CWA_REQUEST_REPO";
    // var sRepoId = "CWA_REQUEST_REPO";
    // const connJwtToken = await fetchJwtToken(url, clientid, clientSecret)
    // var folderID = id;
    //   var base64 = "";
    //   var eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
    //   var fileName = "";
    //   var fileId = await getFile(eURL, connJwtToken, repositoryId, "1b1db370001c4f0d3efdb256", folderID, fileName, base64);
    //   var base64 = Buffer.from(fileId).toString('base64');
    //   const workbook = xlsx.read(fileId,{type:'buffer'})
    //   const sheetNames = workbook.SheetNames;
    //   const firstSheetName = sheetNames[0];
    //   const sheet = workbook.Sheets[firstSheetName];
    //   const data = xlsx.utils.sheet_to_json(sheet);
    //   return base64;
    //       // return fileId;
    //       var len = fileId.length;
    // var bytes = new Uint8Array(len);
    // for (var i = 0; i < len; i++) {
    //     bytes[i] = fileId.charCodeAt(i);

    // }
    // // Create a Blob from the bytes
    // var blob = new Blob([bytes.buffer], { type: 'application/pdf' });
    // return blob;
    //   const buffer = Buffer.from(fileId, 'utf8');

    // // Convert the buffer to a binary string
    // const binaryString = buffer.toString('binary');

    // Convert the binary string to an array of binary values
    // const binaryArray = [];
    // for (let i = 0; i < binaryString.length; i++) {
    //     // Convert each character to its binary representation
    //     const binary = binaryString.charCodeAt(i).toString(2).padStart(8, '0');
    //     binaryArray.push(binary);
    // }

    // // Join the array to form a single binary string
    // return binaryArray.join(' ');


    //   // return bytes;
  });
  /**
     * Handler method called before creating data entry
     * for entity Mediafile.
     */
  srv.on('CREATE', 'MediaFile', async (req) => {
    // IT Reader Role Check             
    if(await RoleUtility.userIsReaderOnly(req)){
      req.error({
        message: process.env.ReaderRoleErrorMessage,
        status: 418
    });
      return;
     }
    var base64Data = req.data.content.split(',')[1];
    // var url = sdmCredentials.uaa.url;
    // var clientid = sdmCredentials.uaa.clientid;//"sb-c03ac7d4-a104-4ade-b10f-575f393728c6!b214133|sdm-di-DocumentManagement-sdm_integration!b6332";//"sb-897e0c50-6eca-45ff-b595-a6a47bc78928!b183904|sdm-di-DocumentManagement-sdm_integration!b6332";
    // var clientSecret = sdmCredentials.uaa.clientsecret;//"9v6Hpcq/wof+GJExeMuSiVHL7iA=";//"+MHskjd042Y97kK/GfmNefPusPQ=";
    const url = process.env.dmsURL;//"https://jabilcfdev.authentication.us10.hana.ondemand.com";
    const clientid = process.env.clientid;//"sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
    const clientSecret = process.env.clientSecret;//"HQJVceIL92Oo9dr8RHrK4L7oP2U=";
    //
    var repositoryId = "CWA_REQUEST_REPO";
    var sRepoId = "CWA_REQUEST_REPO";
    const connJwtToken = await fetchJwtToken(url, clientid, clientSecret)
    var folderID = "c27e0192-9271-4339-8980-5684eaf64d04";
    var base64 = base64Data;
    var eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
    var fileName = req.data.fileName;
    var fileId = await createFile(eURL, connJwtToken, repositoryId, "1b1db370001c4f0d3efdb256", folderID, fileName, base64);
    var urlPath = '/browser/' + sRepoId + '/root/' + folderID + '?objectId=' + fileId;
    var guid = crypto.randomUUID();
    var active = false;
    var createdAt = new Date().toISOString();
    var createdBy = req.user.id;
    var docPayload = {
      "ID": guid,
      "CREATEDAT": createdAt,
      "CREATEDBY": createdBy,
      "DmsDocumentId": fileId,
      "DocumentName": fileName,
      "DocumentType": req.data.mediaType,
      "ACTIVE": active,
      "URL": urlPath
    }
    await INSERT.into('CWA_REQUEST.TemplateStore').entries(docPayload);

  });

  srv.on('deleteDMSDocument', async req => {
    const docId = req.data.docId;
    const forlderName = req.data.folderID;
    const url = "https://jabilcfdev.authentication.us10.hana.ondemand.com";
    // var url = sdmCredentials.uaa.url;
    // const clientid = "sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
    // const clientSecret = "HQJVceIL92Oo9dr8RHrK4L7oP2U=";
    const clientid = process.env.clientid;
    const clientSecret = process.env.clientSecret;
    // var clientid = sdmCredentials.uaa.clientid;
    // var clientSecret = sdmCredentials.uaa.clientsecret;
    const repositoryId = "CWA_REQUEST_REPO";
    const connJwtToken = await fetchJwtToken(url, clientid, clientSecret); //Need Error Handling
    const eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
    const response = await deleteFile(eURL, connJwtToken, repositoryId, forlderName, docId); //Need Error Handling
    if (response.status == 200) {
      return "Sucessfully Deleted"
    } else {
      return "Error While Deleting"
    }
  });

  ////////////////case insensitive
  
 // srv.before ('READ', '*' ,async (req)=>{
    srv.before ('READ', ['TM1Hierarchy', 'RejectionReason', 'PlantVH', 'RegionVH', 'CustomerVH', 'ProfitCenterVH', 'SegmentVH', 'DivisionVH', 'CampusNameVH', 'CustomerNameVH',
                         'TypeVH', 'StatusVH', 'EmailNotifyVH', 'BtpRoleMappingRoleNameVH', 'BtpRoleMappingVH', 
                         
    ] ,async (req)=>{
    let conditions =req.query.SELECT.where;
    var newCondition = [];
    if (conditions){
        conditions.forEach((condition,index) => {
            var scol ='';
            var sval = '';
            var sOperator = '';

            if(condition==='and' || condition==='or'||condition==='('||condition===')'
            || condition.func !=undefined
            ){
                newCondition.push(condition);
            }
            if(condition.ref!=undefined){
                scol=condition.ref[0];
                sOperator=conditions[index+1];
                sval=conditions[index+2].val;
                if(sOperator==='='){
                    newCondition.push({ func:'toupper', args:[{ref: [ scol ] }]},'like',{ val: `%${sval.toUpperCase()}%` });
                }else{
                    newCondition.push({ ref: [ scol ] },sOperator,{ val: sval });
                }  
            }
        });
    }
    if(newCondition&& newCondition.length>0){
        req.query.SELECT.where = newCondition;
    }
 })
    
////////////////Case insensitive 

});

const fetchJwtToken = async function (oauthUrl, oauthClient, oauthSecret) {
  // This is to get the oauth token , which is used to create the folder ID
  const tokenUrl = oauthUrl + '/oauth/token?grant_type=client_credentials&response_type=token'
  const config = {
    headers: {
      Authorization: "Basic " + Buffer.from(oauthClient + ':' + oauthSecret).toString("base64")
    }
  };
  let token = await axios.get(tokenUrl, config)
    .then(response => {
      return response.data.access_token;
    })
    .catch(error => {
      return error;
    });

  return token;

}
const createFile = async function (sdmUrl, jwtToken, repositoryId, rootFolderId, forlderName, fileName, base64) {
  return new Promise((resolve, reject) => {
    const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/c27e0192-9271-4339-8980-5684eaf64d04";
    // const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/";

    // var sDecodedFile = window.atob(base64);
    var decodedPdfContent = atob(base64);
    var byteArray = new Uint8Array(decodedPdfContent.length);
    var t = Buffer.from(decodedPdfContent);
    for (var i = 0; i < decodedPdfContent.length; i++) {
      byteArray[i] = decodedPdfContent.charCodeAt(i);
    }
    var blob = new Blob([byteArray.buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
    // var buf = blob;
    //blob = Buffer.from(blob);
    var buf = Buffer.from(base64, "base64");
    const formData = new FormData();
    // formData.append("objectId", forlderName);
    formData.append("cmisaction", "createDocument");
    formData.append("propertyId[0]", "cmis:name");
    formData.append("propertyValue[0]", fileName);
    formData.append("propertyId[1]", "cmis:objectTypeId");
    formData.append("propertyValue[1]", "cmis:document");
    // formData.append("datafile", buf);
    formData.append('content', buf, {
      contentType: blob,
      filename: fileName
    })
    // formData.append("filename", fileName);
    // formData.append("succinct", "true");
    formData.append("_charset", "UTF-8");
    formData.append("includeAllowableActions", "true");
    const headers = {
      ...formData.getHeaders(),
      'Content-Length': formData.getLengthSync()
    }
    // let headers = formData.getHeaders();
    headers["Authorization"] = "Bearer " + jwtToken;
    // headers["cmis:contentStreamMimeType"] = "application/pdf";

    const config = {
      headers: headers
    }

    axios.post(folderCreateURL, formData, config)
      .then(response => {
        resolve(response.data.properties['cmis:objectId'].value)
      })
      .catch(error => {
        reject(error)
      })


  })
}
const deleteFile = async function (sdmUrl, jwtToken, repositoryId, forlderName, docId) {
  const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/" + forlderName
  const formData = new FormData();
  // formData.append("objectId", repositoryId);
  formData.append("cmisaction", "delete");
  formData.append("objectId", docId);


  let headers = formData.getHeaders();
  headers["Authorization"] = "Bearer " + jwtToken;

  const config = {
    headers: headers
  };

  let response = await axios.post(folderCreateURL, formData, config)
    .then(response => {
      return response;
    })
    .catch(error => {
      return error;
    });

  return response;

}