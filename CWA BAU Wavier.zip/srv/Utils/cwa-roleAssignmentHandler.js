const cds = require('@sap/cds');
const RoleUtility = require("./roles").RolesUtil;
const DB = require('./dbOperations').DB;
class CWARoleAssignment {

    static async _getRoleAssignName(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);

        if (userRoles.RoleNames.includes("Global Admin")) {
            for (var i = 0; i < data.length; i++) {
                if (data[i].User == user) {
                    data[i].Action = false;
                }
            }
        }
        else {
            if (userRoles.RoleNames.includes("Regional Admin")) {
                for (var i = 0; i < data.length; i++) {
                    data[i].Action = (await RoleUtility.isValidForUser(req.user.id, data[i].Region, null, null, null, null, null)).allowed;
                    if (data[i].User == user) {
                        data[i].Action = false;
                    }
                }
            }
            else if (userRoles.RoleNames.includes("Site Admin")) {
                for (var i = 0; i < data.length; i++) {
                    data[i].Action = (await RoleUtility.isValidForUser(req.user.id, data[i].Region, data[i].Site, null, null, null, null)).allowed;
                    if (data[i].User == user) {
                        data[i].Action = false;
                    }
                }
            }
            else {
                for (var i = 0; i < data.length; i++) {
                    data[i].Action = false;
                }
            }
        }
    }

    static async _getUserRoles(data) {
        var user = data.User;
        var userRoles = data.Role_Name;
        var UserRoleDetails = await SELECT
            .one
            .from('CWA_REQUEST_ROLEASSIGNMENT')
            .where({ USER: data.user.id });
        // if (userRoles.includes("Global Admin")) {
        return {
            RoleName: UserRoleDetails.ROLENAME,
            Region: UserRoleDetails.REGION,
            Site: UserRoleDetails.SITE,
            Customer: UserRoleDetails.CUSTOMER,
            ProfitCenter: UserRoleDetails.PROFITCENTER
        }
        // } else {
        //     if (userRoles.includes("Site Admin") || userRoles.includes("Regional Admin")) {

        //         return {
        //             RoleName: UserRoleDetails.RoleName,
        //             Region: UserRoleDetails.Region,
        //             Site: UserRoleDetails.Site,
        //             Customer: UserRoleDetails.Customer,
        //             ProfitCenter: UserRoleDetails.ProfitCenter
        //         }
        //     }
        // }
    }
    static async _getAllowedAssignments(req) {
        var userId = req.user.id.toLowerCase();
        /*var userRoles = await SELECT
            .one
            .from('CWA_REQUEST_ROLEASSIGNMENT')
            .where({ USER: userId });*/

        var userRoles = await SELECT
            .one
            .from('CWA_REQUEST_ROLEASSIGNMENT')
            .where([{
                func: 'tolower',
                args: [{ ref: ['USER'] }],
            },
                '=',
            { val: `${userId}` },
            ]);

        if (!userRoles) return;

        return await CWARoleAssignment._getRegionalAdminAssignments(userRoles);

    }

    static async _validateMandatory(req) {
        // IT Reader Role Check             
        if (await RoleUtility.userIsReaderOnly(req)) {
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
            return;
        }

        if (!req.data.User) {
            let err = `User Email can not be blank`
            req.error({
                code: '501',
                message: err,
                status: 418
            });
        }
        if (!req.data.UserName) {
            let err = `User Name can not be blank`
            req.error({
                code: '501',
                message: err,
                status: 418
            });
        }
        if (!req.data.RoleName) {
            let err = `Role Name can not be blank`
            req.error({
                code: '501',
                message: err,
                status: 418
            });
        }
        if (!req.data.ApprovalType) {
            let err = `Type can not be blank`
            req.error({
                code: '501',
                message: err,
                status: 418
            });
        }
        req.data.RoleDesc = await DB._getRoleDescription(req.data.RoleName);
    }

    static async _getRegionalAdminAssignments(userRole) {
        var allowedRegions = userRole.REGION.split(",").map(item => item.trim());
        var allowedSites = userRole.SITE.split(",").map(item => item.trim());
        var allowedPCs = userRole.PROFITCENTER.split(",").map(item => item.trim());
        var allowedCustomers = userRole.CUSTOMER.split(",").map(item => item.trim());

        //Cases
        if (allowedRegions.includes('*')) {
            //return all regions from TM1 Hierarchy
            var regionalData = await SELECT
                .distinct
                .columns(['REGION'])
                .from('CWA_REQUEST_TM1HIERARCHY');
            if (!regionalData) return;
        } else {
            var regionalData = await SELECT
                .distinct
                .columns(['REGION'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ REGION: allowedRegions });
            if (!regionalData) return;
        }


        if (allowedSites.includes('*')) {
            //return all regions from TM1 Hierarchy
            var siteData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ REGION: regionalData.map((region) => region.REGION) });
            if (!siteData) return;
        } else {
            var siteData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ PLANT: allowedSites })
                .and({ REGION: regionalData.map((region) => region.REGION) });
            if (!siteData) return;
        }

        if (allowedCustomers.includes('*')) {
            //return all regions from TM1 Hierarchy
            var customerData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ PLANT: siteData.map((site) => site.PLANT) })
                .and({ REGION: regionalData.map((region) => region.REGION) });

            if (!customerData) return;
        } else {
            var customerData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ CUSTOMER: allowedCustomers })
                .and({ PLANT: siteData.map((site) => site.PLANT) })
                .and({ REGION: regionalData.map((region) => region.REGION) });
            if (!customerData) return;
        }

        if (allowedPCs.includes('*')) {
            //return all regions from TM1 Hierarchy
            var pcData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ PLANT: siteData.map((site) => site.PLANT) })
                .and({ REGION: regionalData.map((region) => region.REGION) })
                .and({ CUSTOMER: customerData.map((customer) => customer.CUSTOMER) });

            if (!pcData) return;
        } else {
            var pcData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ PROFITCENTER: allowedPCs })
                .and({ PLANT: siteData.map((site) => site.PLANT) })
                .and({ REGION: regionalData.map((region) => region.REGION) })
                .and({ CUSTOMER: customerData.map((customer) => customer.CUSTOMER) });
            if (!pcData) return;
        }

        return {
            "Roles": [userRole.ROLENAME],
            "REGION": regionalData,
            "PLANT": siteData,
            "CUSTOMER": customerData,
            "PROFITCENTER": pcData,
        };
    }

    /*static async _getAllowedAssignments(req) {
        var userRoles = await SELECT
            .one
            .from('CWA_REQUEST_ROLEASSIGNMENT')
            .where({ USER: req.user.id });
        if (!userRoles) return;

        if (userRoles.ROLENAME === 'Regional Admin') {
            return await CWARoleAssignment._getRegionalAdminAssignments(userRoles);
        } else {

        }

    }*/

    /*static async _getRegionalAdminAssignments(userRole) {
        var allowedRegions = userRole.REGION.split(",").map(item => item.trim());
        var allowedSites = userRole.SITE.split(",").map(item => item.trim());
        var allowedPCs = userRole.PROFITCENTER.split(",").map(item => item.trim());
        var allowedCustomers = userRole.CUSTOMER.split(",").map(item => item.trim());

        //Cases
        if (allowedRegions.includes('*')) {
            //return all regions from TM1 Hierarchy
            var regionalData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY');
            if (!regionalData) return;
        } else {
            var regionalData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ REGION: allowedRegions });
            if (!regionalData) return;
        }


        if (allowedSites.includes('*')) {
            //return all regions from TM1 Hierarchy
            var siteData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ REGION: regionalData.map((region) => region.REGION) });
            if (!siteData) return;
        } else {
            var siteData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ PLANT: allowedSites })
                .and({ REGION: regionalData.map((region) => region.REGION) });
            if (!siteData) return;
        }

        if (allowedCustomers.includes('*')) {
            //return all regions from TM1 Hierarchy
            var customerData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ PLANT: siteData.map((site) => site.PLANT) })
                .and({ REGION: regionalData.map((region) => region.REGION) });

            if (!customerData) return;
        } else {
            var customerData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ CUSTOMER: allowedCustomers })
                .and({ PLANT: siteData.map((site) => site.PLANT) })
                .and({ REGION: regionalData.map((region) => region.REGION) });
            if (!customerData) return;
        }

        if (allowedPCs.includes('*')) {
            //return all regions from TM1 Hierarchy
            var pcData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ PLANT: siteData.map((site) => site.PLANT) })
                .and({ REGION: regionalData.map((region) => region.REGION) })
                .and({ CUSTOMER: customerData.map((customer) => customer.CUSTOMER) });

            if (!pcData) return;
        } else {
            var pcData = await SELECT
                .distinct
                .columns(['REGION', 'PLANT', 'CUSTOMER', 'PROFITCENTER'])
                .from('CWA_REQUEST_TM1HIERARCHY')
                .where({ PROFITCENTER: allowedPCs })
                .and({ PLANT: siteData.map((site) => site.PLANT) })
                .and({ REGION: regionalData.map((region) => region.REGION) })
                .and({ CUSTOMER: customerData.map((customer) => customer.CUSTOMER) });
            if (!pcData) return;
        }

        return {
            "Roles": [],
            "REGION": regionalData,
            "PLANT": siteData,
            "CUSTOMER": customerData,
            "PROFITCENTER": pcData,
        };
    }*/

}
module.exports = {
    CWARoleAssignmentHandler: CWARoleAssignment
}