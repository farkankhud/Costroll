const { foreach } = require("@sap/cds");
const { request } = require("http");

const DB = require("./dbOperations").DB;
class CWARequestCustomerLevel {
    static async validateExistingCWA(cwa) {
        var saveAllowed, submitAllowed;
        if (cwa.STATUS_ID === 1) {
            saveAllowed = true;
            //Submit allowed is only if all PCs have been saved already
            //Get all active profit centers from TM1
            var activeProfitCenters = await DB.getActivePC(cwa.SITE, cwa.CUSTOMER);
            var cwaExistingFiles = await DB.getCWAItems(cwa);
            var allExistingItemsPC = cwaExistingFiles.flatMap(item => item.PROFITCENTERS.split(",").map(value => value.trim()));

            var remainingProfitCenters = activeProfitCenters.filter(item => !allExistingItemsPC.includes(item));
            submitAllowed = remainingProfitCenters.length === 0 ? true : false;
        } else {
            saveAllowed = submitAllowed = false;
        }

        return {
            "SaveAllowed": saveAllowed,
            "SubmitAllowed": submitAllowed
        }
    }
    static async handleValidation(headerData, itemData) {

        var headerDetails = await DB.getTM1Hierarchy(headerData.Site, headerData.Customer);
        if (!headerDetails) {
            return {
                "validationPassed": false,
                "existingCWA": null,
                "message": "Site and Customer combination does not exist in master hierarchy",
                "action": "NONE",
                "SaveAllowed": false,
                "SubmitAllowed": false
            };
        }

        //Handle all validations of Customer level input
        var cwaExists = await DB.cwaExistsCustomerLevel(headerData.Site, headerData.Customer);

        if (cwaExists) {
            let allowedStatus = new Set([1, 4, 5, 6]);
            let notAllowedStatus = new Set([2, 3, 7]);

            if (notAllowedStatus.has(cwaExists.STATUS_ID)) {
                return {
                    "validationPassed": false,
                    "existingCWA": cwaExists,
                    "message": cwaExists.CWANAME + " already exists for Site " + cwaExists.SITE + " and Customer " + cwaExists.CUSTOMER + " with status " + await DB.getCodeListDescription('CWA_REQUEST_CWASTATUSES', cwaExists.STATUS_ID) + ".",
                    "action": "NONE",
                    "SaveAllowed": true,
                    "SubmitAllowed": false
                };
            } else if (allowedStatus.has(cwaExists.STATUS_ID)) {
                if (cwaExists.STATUS_ID === 1)
                    return await this.checkCustomerLevelFileAllowed(headerData, itemData, cwaExists);
                else return {
                    "validationPassed": true,
                    //"message": "Existing CWA files found with valid status.",
                    "action": "HEADER_CREATE",
                    "SaveAllowed": true
                };
            } else
                return {
                    "validationPassed": false,
                    "message": "CWA# " + cwaExists.CWANAME + " already exists for Site " + cwaExists.SITE + " and Customer " + cwaExists.CUSTOMER + " with status (" + await DB.getCodeListDescription('CWA_REQUEST_CWASTATUSES', cwaExists.STATUS_ID) + ").",
                    "action": "NONE",
                    "SaveAllowed": true,
                    "SubmitAllowed": false
                };
        }
        else {
            //need to validate PC coming from file here 
            var validationResult = await this.validateNewFile(headerData, itemData);

            //Check if PCs in file(s) correspond to multiple customers
            var multipleCustomers = await DB.checkMultiCustomer(itemData.ProfitCenters);
            if (multipleCustomers.length !== 0) {
                return {
                    "ValidationPassed": false,
                    "Message": 'This CWA file contains multiple TM1 customers:' + multipleCustomers.join(", ") + " Please adjust before proceeding.",
                    "Action": 'NONE'
                };
            }

        }

        return {
            "validationPassed": validationResult.validationPassed,
            "message": validationResult.message,
            "action": validationResult.action,
            "SaveAllowed": validationResult.SaveAllowed,
            "SubmitAllowed": validationResult.SubmitAllowed,
        };
    }

    static async validateNewFile(headerData, itemData) {
        //Get all active profit centers from TM1
        var activeProfitCenters = await DB.getActivePC(headerData.Site, headerData.Customer);

        //1. Split CSV first
        var fileProfitCenters = itemData.ProfitCenters.split(",").map(value => value.trim());

        //2. Check if each one in file is valid or not
        var invalidPC = [];
        fileProfitCenters.forEach(profitCenter => { if (!activeProfitCenters.includes(profitCenter)) invalidPC.push(profitCenter); });

        if (invalidPC.length !== 0) {
            //Validation Fails
            return {
                "validationPassed": false,
                "message": "Profit Center(s) " + invalidPC.join(", ") + " do not exist/ are inactive in TM1 Hierarchy",
                "action": "NONE",
                "SaveAllowed": false,
                "SubmitAllowed": false
            }
        }
        else {
            //Validation is passed, check save/ submit allowed
            const arraysAreSame = (arr1, arr2) => arr1.length === arr2.length && arr1.slice().sort().join() === arr2.slice().sort().join();
            return {
                "validationPassed": true,
                //"message": "TBD",
                "action": "HEADER_CREATE",
                "SaveAllowed": true,
                "SubmitAllowed": arraysAreSame(fileProfitCenters, activeProfitCenters)
            }
        }
    }

    static async checkCustomerLevelFileAllowed(headerData, itemData, existingCWA) {
        //Get all active profit centers from TM1
        var activeProfitCenters = await DB.getActivePC(headerData.Site, headerData.Customer);

        //Check PCs in file are valid or not
        //1. Split CSV first
        var fileProfitCenters = itemData.ProfitCenters.split(",").map(value => value.trim());

        //2. Check if each one in file is valid or not
        var invalidPC = [];
        fileProfitCenters.forEach(profitCenter => { if (!activeProfitCenters.includes(profitCenter)) invalidPC.push(profitCenter); });

        if (invalidPC.length !== 0) {
            //Validation Fails
            return {
                "validationPassed": false,
                "message": "Profit Center(s) " + invalidPC.join(", ") + " do not exist/ are inactive in TM1 Hierarchy",
                "action": "NONE"
            }
        } else {
            //Check if PCs in file(s) correspond to multiple customers
            var multipleCustomers = await DB.checkMultiCustomer(itemData.ProfitCenters + ", " + fileProfitCenters);
            if (multipleCustomers.length !== 0) {
                return {
                    "ValidationPassed": false,
                    "Message": cwaExists.cwaExists.CWANAME + " contains multiple TM1 customers:" + multipleCustomers.join(", ") + " Please adjust before proceeding.",
                    "Action": 'NONE'
                };
            }

            //Check this profit center allowed or not
            //1. Get other items for this CWA
            var cwaExistingFiles = await DB.getCWAItems(existingCWA);
            var allExistingItemsPC = cwaExistingFiles.flatMap(item => item.PROFITCENTERS.split(",").map(value => value.trim()));

            var remainingProfitCenters = activeProfitCenters.filter(item => !allExistingItemsPC.includes(item));

            invalidPC = fileProfitCenters.filter(item => !remainingProfitCenters.includes(item));
            if (invalidPC.length !== 0) {
                //Validation Fails
                return {
                    "validationPassed": false,
                    "message": existingCWA.CWANAME + " for Customer "+headerData.Customer+" with the following profit centers already exists: \n\n" + allExistingItemsPC.join(",\n") + ".\n\nPlease adjust before proceeding.",
                    "action": "NONE",
                    "SaveAllowed": false,
                    "SubmitAllowed": false
                }
            } else {
                //Check current file contains all remaining PCs
                const arraysAreSame = (arr1, arr2) => arr1.length === arr2.length && arr1.slice().sort().join() === arr2.slice().sort().join();

                return {
                    "validationPassed": true,
                    "message": "CWA " + existingCWA.CWANAME + " for Customer "+headerData.Customer+" already exists. These are the remaining profit centers: \n\n"+remainingProfitCenters.join(",\n")+".\n\nProceed to submit CWA for one of the profit centers above.",
                    "action": "ITEM_CREATE",
                    "existingCWA": existingCWA,
                    "SaveAllowed": true,
                    "SubmitAllowed": arraysAreSame(fileProfitCenters, remainingProfitCenters)
                }
            }
        }
    }
}

class CWARequestPCLevel {
    static async validateExistingCWA(cwa) {
        var SaveAllowed, SubmitAllowed;
        if (cwa.STATUS_ID == 1) { 
            SaveAllowed = true; 
            SubmitAllowed = true; 
        }else {
            SaveAllowed = false;
            SubmitAllowed = false;
        }

        return {
            "SaveAllowed": SaveAllowed,
            "SubmitAllowed": SubmitAllowed
        }
    }
    static async handleValidation(headerData, itemData) {
        let allFileItemsPC = itemData.ProfitCenters.split(",");
        if (allFileItemsPC.length == 1) {
            var ProfitCenter = await DB.cwaExistsProfitCentreLevel(headerData, itemData);
            if (ProfitCenter.length > 0) {
                var Status = await DB.cwaStatusCheck(headerData, itemData);
                if (Status) {
                    var TM1HierarchyData = await DB.getTM1Hierarchy(headerData.Site, headerData.Customer);
                    var getCWAApprovers = await DB.getCWAApprovers(TM1HierarchyData.REGION, headerData.Site, headerData.Customer, itemData.ProfitCenters);
                    if (Status.STATUS_ID == 1) {
                        //1: In Draft
                        return {
                            validationPassed: false,
                            message: "CWA " + Status.CWANAME + " for Customer "+headerData.Customer+" already exists.",
                            action: "ITEM_CREATE",
                            "existingCWA": {
                                "ID": Status.STATUS_ID,
                                "CWANAME": Status.CWANAME,
                            },
                            "SubmitAllowed": true,
                            "SaveAllowed": true,
                            AdditionalDetails: {
                                existingCWA: Status.STATUS_ID,
                                existingCWA: Status.CWANAME,
                                SubmitAllowed: true,
                                SaveAllowed: true,
                                Division: TM1HierarchyData.DIVISION,
                                Segment: TM1HierarchyData.SEGMENT,
                                Region: TM1HierarchyData.REGION,
                                CWAApprovers: {
                                    WCM: getCWAApprovers.CWAApprovers.WCM,
                                    BUM: getCWAApprovers.CWAApprovers.BUM,
                                    SPM: getCWAApprovers.CWAApprovers.SPM
                                }
                            }
                        }
                    } else if (Status.STATUS_ID == 2) {
                        //2: Pending Approval
                        return {
                            validationPassed: false,
                            message: "CWA " + Status.CWANAME + " for Customer "+headerData.Customer+" already exists.",
                            action: "None",
                            "existingCWA": {
                                "ID": Status.STATUS_ID,
                                "CWANAME": Status.CWANAME,
                            },
                            "SubmitAllowed": false,
                            "SaveAllowed": false,
                            AdditionalDetails: {
                                existingCWA: Status.STATUS_ID,
                                existingCWA: Status.CWANAME,
                                SubmitAllowed: false,
                                SaveAllowed: false,
                                Division: TM1HierarchyData.DIVISION,
                                Segment: TM1HierarchyData.SEGMENT,
                                Region: TM1HierarchyData.REGION,
                                CWAApprovers: {
                                    WCM: getCWAApprovers.CWAApprovers.WCM,
                                    BUM: getCWAApprovers.CWAApprovers.BUM,
                                    SPM: getCWAApprovers.CWAApprovers.SPM
                                }
                            }
                        }
                    } else if (Status.STATUS_ID == 3) {
                        //3: 'Trigger Demand'
                        return {
                            validationPassed: false,
                            message: "CWA " + Status.CWANAME + " for Customer "+headerData.Customer+" already exists.",
                            action: "None",
                            "existingCWA": {
                                "ID": Status.STATUS_ID,
                                "CWANAME": Status.CWANAME,
                            },
                            "SubmitAllowed": false,
                            "SaveAllowed": false,
                            AdditionalDetails: {
                                existingCWA: Status.STATUS_ID,
                                existingCWA: Status.CWANAME,
                                SubmitAllowed: false,
                                SaveAllowed: false,
                                Division: TM1HierarchyData.DIVISION,
                                Segment: TM1HierarchyData.SEGMENT,
                                Region: TM1HierarchyData.REGION,
                                CWAApprovers: {
                                    WCM: getCWAApprovers.CWAApprovers.WCM,
                                    BUM: getCWAApprovers.CWAApprovers.BUM,
                                    SPM: getCWAApprovers.CWAApprovers.SPM
                                }
                            }
                        }
                    } else if (Status.STATUS_ID == 7) {
                        //7: 'Demand Error'
                        return {
                            validationPassed: false,
                            message: Status.CWANAME + " already exists for Site " + Status.SITE + " and Customer " + Status.CUSTOMER + " with status " + await DB.getCodeListDescription('CWA_REQUEST_CWASTATUSES', Status.STATUS_ID) + ".",
                            action: "None",
                            "existingCWA": {
                                "ID": Status.STATUS_ID,
                                "CWANAME": Status.CWANAME,
                            },
                            "SubmitAllowed": false,
                            "SaveAllowed": false,
                            AdditionalDetails: {
                                existingCWA: Status.STATUS_ID,
                                existingCWA: Status.CWANAME,
                                SubmitAllowed: false,
                                SaveAllowed: false,
                                Division: TM1HierarchyData.DIVISION,
                                Segment: TM1HierarchyData.SEGMENT,
                                Region: TM1HierarchyData.REGION,
                                CWAApprovers: {
                                    WCM: getCWAApprovers.CWAApprovers.WCM,
                                    BUM: getCWAApprovers.CWAApprovers.BUM,
                                    SPM: getCWAApprovers.CWAApprovers.SPM
                                }
                            }
                        }
                    }
                    
                } else {
                    return {
                        "validationPassed": true,
                        "existingCWA": "",
                      //  "message": "New CWA Allowed",
                        "action": "HEADER_CREATE"
                    };
                }
            } else {
               var errorMsg;
                //Customer does not exist
                var CustomerCheck = await DB.cwaExistsCustomer(headerData, itemData);
                    if(CustomerCheck.length == 0){
                        errorMsg = `Customer ${headerData.Customer} does not exist in Master Hierarchy Table`;
                    }
                // Profit Centre does not exist
                if(!errorMsg){
                var ProfitCentreCheck = await DB.cwaExistsProfitCentre(headerData, itemData);
                if(ProfitCentreCheck.length == 0){
                    errorMsg = `Profit Centre ${itemData.ProfitCenters} does not exist in Master Hierarchy Table`;
                }
            }
                //Site does not exist
                if(!errorMsg){
                var SiteCheck = await DB.cwaExistsSite(headerData, itemData);
                if(SiteCheck.length == 0){
                    errorMsg = `Site ${headerData.Site} does not exist in Master Hierarchy Table`;
                }
            }

            if(!errorMsg){
                var SiteCustomerPCValidation = await DB.SiteCustomerPCValidation(headerData, itemData);
                if (!SiteCustomerPCValidation || SiteCustomerPCValidation === undefined) {
                    //Site and Customer Validation
                    var SiteCustomerValidation = await DB.SiteCustomerValidation(headerData, itemData);
                    if (!SiteCustomerValidation || SiteCustomerValidation === undefined ) {
                        errorMsg = `Profit Center ${itemData.ProfitCenters} is not valid`;
                    }
                    
                    if(!errorMsg){
                    var CustomerPCValidation = await DB.CustomerPCValidation(headerData, itemData);
                    if (!CustomerPCValidation || CustomerPCValidation === undefined) {
                        errorMsg = `Customer ${headerData.Customer}, Profit Center ${itemData.ProfitCenters} is not found for site ${headerData.Site}`;
                    }
                    }

                    if(!errorMsg){
                    var PCSiteValidation = await DB.PCSiteValidation(headerData, itemData);
                    if (!PCSiteValidation || PCSiteValidation === undefined) {
                        errorMsg = `Customer ${headerData.Customer} not found for site ${headerData.Site}`;
                    }
                }
            }
        }


                return {
                    "validationPassed": false,
                    "existingCWA": "",
                    "message": errorMsg,
                    "action": "NONE"
                };
            }
        } else {
            return {
                "validationPassed": false,
                "existingCWA": "",
                "message": "More than 1 Profit Centre",
                "action": "NONE"
            };
        }
    }
}

module.exports = {
    CWACustomerLevel: CWARequestCustomerLevel,
    CWAPCLevel: CWARequestPCLevel,
}