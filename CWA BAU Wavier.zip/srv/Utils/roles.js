class RoleUtility {

    //Read all roles of the user
    static async getAllRoles(userId) {
        userId = userId.toLowerCase();
        var allowedRegions = new Set(),
            allowedSites = new Set(),
            allowedCustomers = new Set(),
            allowedPCs = new Set(),
            allowedApprovalTypes = new Set(),
            allowedRoleNames = new Set();

        /*var allRoles = await SELECT
            .from('CWA_REQUEST_ROLEASSIGNMENT')
            .where({ USER: userId,  });*/

        var allRoles = await SELECT
            .from('CWA_REQUEST_ROLEASSIGNMENT')
            .where([ { func: 'tolower',
                       args: [{ ref: ['USER'] }],},
                        '=',
                     { val: `${userId}` },
            ]);


        allRoles.forEach(item => {
            if (item.REGION) {
                item.REGION.split(',').forEach(region => allowedRegions.add(region.trim()));
            }
            if (item.SITE) {
                item.SITE.split(',').forEach(site => allowedSites.add(site.trim()));
            }
            if (item.CUSTOMER) {
                item.CUSTOMER.split(',').forEach(customer => allowedCustomers.add(customer.trim()));
            }
            if (item.PROFITCENTER) {
                item.PROFITCENTER.split(',').forEach(pc => allowedPCs.add(pc.trim()));
            }
            if (item.APPROVALTYPE) {
                item.APPROVALTYPE.split(',').forEach(type => allowedApprovalTypes.add(type.trim()));
            }
            if (item.ROLENAME) {
                item.ROLENAME.split(',').forEach(role => allowedRoleNames.add(role.trim()));
            }
        });

        return {
            Regions: allowedRegions.has('*') ? ['*'] : Array.from(allowedRegions),
            Sites: allowedSites.has('*') ? ['*'] : Array.from(allowedSites),
            Customers: allowedCustomers.has('*') ? ['*'] : Array.from(allowedCustomers),
            ProfitCenters: allowedPCs.has('*') ? ['*'] : Array.from(allowedPCs),
            ApprovalTypes: allowedApprovalTypes.has('*') ? ['*'] : Array.from(allowedApprovalTypes),
            RoleNames: allowedRoleNames.has('*') ? ['*'] : Array.from(allowedRoleNames)
        }
    }

    static async getAllowedUsers(region, site, customer, profitCenter, approvalType, roleName) {
        if (!roleName) {
            return 'Please provide the Role.'
        }

        var rolePattern = '%' + roleName + '%'

        var allUsers = await SELECT
            .from('CWA_REQUEST_ROLEASSIGNMENT')
            .where({ ROLENAME: { like: rolePattern } });

        // Helper function to normalize single or CSV string values to an array
        const normalizeInput = (input) => {
            if (!input) return [];
            return input.split(',').map(value => value.trim());
        };

        // Normalize inputs
        const regionsArray = normalizeInput(region);
        const sitesArray = normalizeInput(site);
        const customersArray = normalizeInput(customer);
        const profitCentersArray = normalizeInput(profitCenter);
        const approvalTypesArray = normalizeInput(approvalType);

        // Function to check if a record matches the given parameters
        const matchesFilters = (item) => {
            const matchesRegion = !regionsArray.length || (item.REGION === '*' || regionsArray.some(r => item.REGION.split(',').map(v => v.trim()).includes(r)));
            const matchesSite = !sitesArray.length || (item.SITE === '*' || sitesArray.some(s => item.SITE.split(',').map(v => v.trim()).includes(s)));
            const matchesCustomer = !customersArray.length || (item.CUSTOMER === '*' || customersArray.some(c => item.CUSTOMER.split(',').map(v => v.trim()).includes(c)));
            const matchesProfitCenter = !profitCentersArray.length || (item.PROFITCENTER === '*' || profitCentersArray.some(pc => item.PROFITCENTER.split(',').map(v => v.trim()).includes(pc)));
            const matchesApprovalType = !approvalTypesArray.length || (item.APPROVALTYPE === '*' || approvalTypesArray.some(at => item.APPROVALTYPE.split(',').map(v => v.trim()).includes(at)));

            return matchesRegion && matchesSite && matchesCustomer && matchesProfitCenter && matchesApprovalType;
        };

        // Filter the results based on other parameters
        let filteredResults = allUsers.filter(matchesFilters);

        // Extract unique user IDs from filtered results
        let userIds = new Set();
        filteredResults.forEach(row => userIds.add({ "User": row.USERNAME, "Email": row.USER }));

        // Convert Set to Array for returning
        return Array.from(userIds);
    }

    static async isValidForUser(userId, region, site, customer, profitCenter, approvalType, roleName) {

        // Retrieve allowed values for the user
        var allowedValues = await this.getAllRoles(userId);

        // Helper function to check if a value is allowed
        const isAllowed = (allowedValues, value) => allowedValues.includes('*') || allowedValues.includes(value);

        // Helper function to normalize single or CSV string values to an array
        const normalizeInput = (input) => { if (!input) return []; return input.split(',').map(value => value.trim()); };

        // Object to hold invalid parameters
        let invalidParams = {};

        // Validate region
        if (region && !isAllowed(allowedValues.Regions, region)) {
            invalidParams.Region = region;
        }

        // Validate site
        let Sitearray = [];
        if (site) {
            if (site.includes(',')) {
                Sitearray = site.split(',');
                for (var i = 0; i < Sitearray.length; i++) {
                    if (site && !isAllowed(allowedValues.Sites, Sitearray[i])) {
                        invalidParams.Site = site;
                    }
                }
            }
        }

        // if (site && !isAllowed(allowedValues.Sites, site)) {
        //     invalidParams.Site = site;
        // }

        // Validate customer
        if (customer && !isAllowed(allowedValues.Customers, customer)) {
            invalidParams.Customer = customer;
        }

        // Validate profit centers
        if (profitCenter) {
            let profitCentersArray = normalizeInput(profitCenter);

            const invalidProfitCenters = profitCentersArray.filter(pc => !isAllowed(allowedValues.ProfitCenters, pc));
            if (invalidProfitCenters.length > 0) {
                invalidParams.ProfitCenters = invalidProfitCenters;
            }
        }

        // Validate approval type(s)
        if (approvalType) {
            let approvalTypesArray = normalizeInput(approvalType);

            const invalidApprovalTypes = approvalTypesArray.filter(type => !isAllowed(allowedValues.ApprovalTypes, type));
            if (invalidApprovalTypes.length > 0) {
                invalidParams.approvalType = invalidApprovalTypes;
            }
        }

        // Validate role name(s)
        if (roleName) {
            let roleNamesArray = normalizeInput(roleName);

            const invalidRoleNames = roleNamesArray.filter(role => !isAllowed(allowedValues.RoleNames, role));
            if (invalidRoleNames.length > 0) {
                invalidParams.roleName = invalidRoleNames;
            }
        }

        // Return validation result
        return Object.keys(invalidParams).length === 0 ? { "allowed": true } : { "allowed": false, "invalidParams": invalidParams };

    }

    static getValidationMessage(validationResult) {
        if (validationResult.allowed) {
            return 'User has roles to perform this action.';
        } else {
            const { invalidParams } = validationResult;
            let messages = [];

            // Helper function to format invalid parameters
            const formatInvalidParams = (key, value) => {
                if (Array.isArray(value)) {
                    return `${key}: ${value.join(', ')}`;
                }
                return `${key}: ${value}`;
            };

            // Format each invalid parameter
            if (invalidParams.Region) {
                messages.push(formatInvalidParams('Invalid region', invalidParams.Region));
            }
            if (invalidParams.Site) {
                messages.push(formatInvalidParams('Invalid site', invalidParams.Site));
            }
            if (invalidParams.Customer) {
                messages.push(formatInvalidParams('Invalid customer', invalidParams.Customer));
            }
            if (invalidParams.ProfitCenters) {
                messages.push(formatInvalidParams('Invalid profit center(s)', invalidParams.ProfitCenters));
            }
            if (invalidParams.approvalType) {
                messages.push(formatInvalidParams('Invalid approval type(s)', invalidParams.approvalType));
            }
            if (invalidParams.roleName) {
                messages.push(formatInvalidParams('Invalid role name(s)', invalidParams.roleName));
            }

            return `Insufficient Roles: ${messages.join('; ')}`;
        }
    }

    static async userIsReaderOnly(req) {
        console.log("Inside userIsReaderOnly Method");
        var userId = req.user.id;
        //get all BTP roles assigned to user
        var userRoles = await this.getAllRoles(userId);
        console.log("User Roles: " + userRoles.RoleNames);

        //get which role to check from env file
        var readerRole = process.env.ITReaderBTPRole
        console.log("Reader Role " + userRoles.RoleNames.includes(readerRole));
        //check if userRoles have readerRole
        if (userRoles.RoleNames.includes(readerRole)) return true;
        else return false;
    }
}


module.exports = {
    RolesUtil: RoleUtility
}