const axios = require("axios");
const xsenv = require('@sap/xsenv');
const cds = require("@sap/cds/libx/_runtime/cds");
const xlsx = require("xlsx");
const dbOperations = require("./dbOperations");
const FormData = require('form-data');
const { OpenApiRequestBuilder } = require('@sap-cloud-sdk/openapi');
const { select } = require("@sap/cds/libx/_runtime/hana/execute");
const { RolesUtil } = require("./roles");
const { mailUtility } = require("./triggerEmail");
const crypto = require('crypto');

class CommonUtilities {
    static async getDestinations(destinationName) {
        const dest_service = xsenv.readServices();
    }

    static async callWorkFlow(data, req, invoker, wfPayload) {
        var cwaID = invoker == 1 ? data.ID : data.Parent_ID;
        var cwaRequestRule = await dbOperations.DB.getCWARule(cwaID);
        var cwa = cwaRequestRule[0];

        // const payload = {
        //     "definitionId": "us10.jabilcfdev.cwarequest.cWARequestProcess",
        //     "context": {
        //         "cwarequestvariable": {
        //             "CWARequestID": cwa.CWANAME,
        //             "CWAGUID": cwaID,
        //             "Counter": 0,
        //             "ApprovedStatus": "Approved",
        //             "RejectStatus": "Rejected"
        //         }
        //     }
        // };

        var wfService = await cds.connect.to("Workflow");
        const response = await wfService.tx(req).post("/workflow-instances", wfPayload);
        console.log('Deepak:' + response.toString());
        return response;
    }

    static async readFileContents(folderID, fileID) {
        try {
            console.log("Start reading file from DMS");
            var fileLocation = folderID + '?objectId=' + fileID;
            const fileBuffer = await new OpenApiRequestBuilder('GET', '/browser/CWA_REQUEST_REPO/root/' + fileLocation)
                .addCustomRequestConfiguration({ responseType: 'arraybuffer' })
                .execute({ destinationName: 'CWARequestDMS' });
            console.log("File from DMS read to buffer");
            const workbook = xlsx.read(fileBuffer, { type: 'buffer' })
            const data = xlsx.utils.sheet_to_json(workbook.Sheets['Export Propose MS']);

            return data;
        } catch (error) {
            throw new Error('Error while reading files');
            console.log("Error reading file from DMS");
            console.log(error);
        }
    }

    static async readDMSFiles(cwaID, splitDemand, splitLimit) {
        console.log("Read DMS Files");

        //based on CWA ID get all items and their corresponding files from DMS
        //Read the above files and populate th demand structure for BAPI
        var cwaHeader = await SELECT
            .one
            .from('CWA_REQUEST_CWAHEADER')
            .where({ ID: cwaID });

        var cwafiles = await dbOperations.DB.getCWAItems(cwaHeader);
        var fileContents = [];
        // var result=[];
        for (let index = 0; index < cwafiles.length; index++) {
            const element = cwafiles[index];
            var cwaDocument = await SELECT
                .one
                .from('CWA_REQUEST_DOCUMENTMETADATA')
                .where({ ID: element.FILEID_ID });
            if (cwaDocument) {
                // Commented the spread operator to replace with .concat 12/11/2024
                // fileContents.push(...(await this.readFileContents(cwaHeader.DMSFOLDERID, cwaDocument.DMSDOCUMENTID))); 
                fileContents = fileContents.concat(
                    await this.readFileContents(cwaHeader.DMSFOLDERID, cwaDocument.DMSDOCUMENTID)
                );
            }
        }
        /*debugger;
        var XLSX = require('xlsx');
        var workbook = XLSX.readFile('./srv/external/Summary for BTP_KeySight_101124 (1).xlsx');
        var xlData = XLSX.utils.sheet_to_json(workbook.Sheets['Export Propose MS']); 
        fileContents.push(...xlData);*/

        var demandStructure = fileContents.map((item, index) => ({
            "LINENUM": (index + 1).toString().padStart(6, '0'),
            "CWA_ID": cwaID,
            "PLANT": item.Site,
            "MATERIAL": item.Part,
            "PLAN_IND_REQ_DATE": this.convertExcelDateToJSDate(item.Date),
            "PLAN_IND_REQ_QTY": item.Qty.toString(),
            "REF_DATE": this.convertExcelDateToJSDate(item["MRP Date"]),
            "REF_TIME": item["MRP Time"].toString()
        }));

        /*fileContents.forEach((item) => {
            console.log(`"PLAN_IND_REQ_DATE": ${this.convertExcelDateToJSDate(item.Date)}`);
            console.log(`"REF_DATE": ${this.convertExcelDateToJSDate(item.Date)}`)
        })*/


        if (splitDemand)
            if (splitLimit)
                return this.splitArrayWithLimit(demandStructure, splitLimit);
        if (!splitDemand)
            return [demandStructure]

    }

    static convertExcelDateToJSDate(sExcelDate) {
        var unixTimestamp = (sExcelDate - 25569) * 86400000 - (new Date().getTimezoneOffset() * 60000);
        return this.formatDate(new Date(unixTimestamp));
    }

    static formatDate(dDate) {
        //console.log(`dDate: ${dDate.getFullYear}`);
        return [dDate.getFullYear(),
        ((dDate.getMonth() + 1) > 9 ? '' : '0') + (dDate.getMonth() + 1),
        (dDate.getDate() > 9 ? '' : '0') + dDate.getDate()
        ].join('');
    }

    static splitArrayWithLimit(arr, limit) {
        let result = [];
        let currentIndex = 1;

        // Helper function to create a new chunk with updated LINENUM
        function createChunk(startIndex, endIndex) {
            return arr.slice(startIndex, endIndex).map(item => ({
                ...item,
                LINENUM: (currentIndex++).toString().padStart(6, '0')
            }));
        }

        // Iterate and split the array into chunks
        for (let i = 0; i < arr.length; i += limit) {
            result.push(createChunk(i, i + limit));
        }
        return result;
    }

    static async getRequirementsFromFiles(cwaID) {
        var cwaRule = await dbOperations.DB.getCWARule(cwaID);
        var cwa = cwaRule[0];
        var payload = {
            "CONV_UTC": (cwa.SAPUTCCONVERT ? 'X' : ''),
            "TIMEZONE": cwa.SAPLOCALTIME,
            "VERSION": cwa.SAPREQPLAN
        };
        return payload;
    }

    static async simulateDemandCreation(data, req, invoker) {
        console.log("Simulate Demand");
        var cwaID = invoker == 1 ? data.ID : data.Parent_ID;
        var onPremS4API = await cds.connect.to("ZOD_CWA_REQ_ZUPL_INTERG_SRV");
        var splitValue = parseInt(process.env.ODataBatchSplit) || 21000;
        console.log("Before reading DMS files");
        var demandItemStructure = await this.readDMSFiles(cwaID, true, splitValue);
        console.log("After reading DMS files success");
        var demandHeaderStructure = await this.getRequirementsFromFiles(cwaID);

        var demandResults = [];
        var promises = [];
        for (let index = 0; index < demandItemStructure.length; index++) {
            const element = demandItemStructure[index];

            let payload = {};
            payload.CONV_UTC = demandHeaderStructure.CONV_UTC;
            payload.TIMEZONE = demandHeaderStructure.TIMEZONE;
            payload.VERSION = demandHeaderStructure.VERSION;
            payload.SIMULATIONMODE = 'X';
            payload.ToResults = element;
            payload.ToReturn = [];
            payload.ToJobDetails = [];
            promises.push(onPremS4API.tx(req).post("/ZUPLSelectionSet", payload)
                .then(function (results) {
                    demandResults.push(...results.ToReturn);
                    return results.ToReturn;
                }.bind(this), function (error) {
                    debugger;
                    demandResults.push(error);
                    return error;
                }));
        }

        const promiseAll = await Promise.allSettled(promises);

        //console.log("allResults");
        //console.log(demandResults);
        return demandResults;
    }

    //Method for calling actual BAPI
    static async DemandCreation(data, req, invoker) {
        console.log("Simulate Demand");
        var cwaID = invoker == 1 ? data.ID : data.Parent_ID;
        var onPremS4API = await cds.connect.to("ZOD_CWA_REQ_ZUPL_INTERG_SRV");
        var demandItemStructure = await this.readDMSFiles(cwaID, false, null);
        var demandHeaderStructure = await this.getRequirementsFromFiles(cwaID);

        let apiPromises = demandItemStructure.map((items) => {
            demandHeaderStructure.SIMULATIONMODE = ' '; //For Demand creation without in simulation mode
            demandHeaderStructure.ToResults = items;
            demandHeaderStructure.ToReturn = [];
            demandHeaderStructure.ToJobDetails = [];

            return onPremS4API.tx(req).post("/ZUPLSelectionSet", demandHeaderStructure)
                .then(function (results) {
                    return results.ToJobDetails;
                }.bind(this), function (error) {
                    return error;
                });
        });

        // debugger;
        // Wait for all API calls to succeed
        let results = await Promise.allSettled(apiPromises);
        // debugger;
        // Process results
        var allResults = [];
        results.forEach(result => {
            if (result.status === 'fulfilled') {
                if (result.value.constructor === Array)
                    allResults.push(...(result.value));
                else
                    allResults.push(result.value);
            } else {
                console.error('Error:', result.reason);
            }
        });
        console.log("allResults");
        console.log(allResults);
        return allResults;
    }


    //Fetching the status of DemandCreation 
    static async DemandCreationStatus(data, req, invoker) {
        console.log("Demand Creation Status");
        var cwaID = invoker == 1 ? data.ID : data.Parent_ID;
        var onPremS4API = await cds.connect.to("ZOD_CWA_REQ_ZUPL_INTERG_SRV");
        var demandItemStructure = await this.readDMSFiles(cwaID, false, 100);
        var demandHeaderStructure = await this.getRequirementsFromFiles(cwaID);

        let apiPromises = demandItemStructure.map((items) => {
            demandHeaderStructure.SIMULATIONMODE = ' '; //For Demand creation without in simulation mode
            demandHeaderStructure.ToResults = items;
            demandHeaderStructure.ToReturn = [];

            return onPremS4API.tx(req).post("/JobDetailsSet", demandHeaderStructure)
                .then(function (results) {
                    return results.ToReturn;
                }.bind(this), function (error) {
                    return error;
                });
        });

        // debugger;
        // Wait for all API calls to succeed
        let results = await Promise.allSettled(apiPromises);
        // debugger;
        // Process results
        var allResults = [];
        results.forEach(result => {
            if (result.status === 'fulfilled') {
                if (result.value.constructor === Array)
                    allResults.push(...(result.value));
                else
                    allResults.push(result.value);
            } else {
                console.error('Error:', result.reason);
            }
        });
        console.log("allResults");
        console.log(allResults);
        return allResults;
    }

    static async getAllJobStatus(allJobs, req) {
        var answer = {};
        var onPremS4API = await cds.connect.to("ZOD_CWA_REQ_ZUPL_INTERG_SRV");
        var payload = {};
        payload.ToJobLogDetails =
            allJobs.map((job) => {
                return {
                    "jobname": job.JobID,
                    "cwanum": job.CWAID
                }
            });
        payload.ToJobFlag = [];
        var allJobStatuses = await onPremS4API.tx(req).post("/JobLogDetailsSet", payload)
            .then(function (results) {
                return results.ToJobFlag;
            }.bind(this), function (error) {
                return error;
            });

        allJobStatuses.forEach((item) => {
            answer[item.jobname] = item;
        });

        return answer;

    }

    static async GetSAPJOBIDErrors(sapJob, req) {

        var onPremS4API = await cds.connect.to("ZOD_CWA_REQ_ZUPL_INTERG_SRV");
        var payload = {};
        payload.jobname = sapJob.jobname;
        payload.cwanum = sapJob.cwanum;
        //  payload.status = " ";
        //  payload.Type = " ";
        //  payload.Number = " ";
        //  payload.Message = " ";


        payload.ToReturn = [];


        var JobIDError = await onPremS4API.tx(req).post("/JobDetailsSet", payload)
            .then(function (results) {
                return results.ToReturn;
            }.bind(this), function (error) {
                debugger;
                return error;
            });

        return JobIDError;

    }

    static async createFile(sdmUrl, jwtToken, repositoryId, rootFolderId, fileName, base64) {
        return new Promise((resolve, reject) => {
            const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/" + rootFolderId;
            var decodedPdfContent = atob(base64);
            var byteArray = new Uint8Array(decodedPdfContent.length);
            var t = Buffer.from(decodedPdfContent);
            for (var i = 0; i < decodedPdfContent.length; i++) {
                byteArray[i] = decodedPdfContent.charCodeAt(i);
            }
            var blob = new Blob([byteArray.buffer], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            });
            var buf = Buffer.from(base64, "base64");
            const formData = new FormData();
            // formData.append("objectId", forlderName);
            formData.append("cmisaction", "createDocument");
            formData.append("propertyId[0]", "cmis:name");
            formData.append("propertyValue[0]", fileName);
            formData.append("propertyId[1]", "cmis:objectTypeId");
            formData.append("propertyValue[1]", "cmis:document");
            // formData.append("datafile", buf);
            formData.append('content', buf, {
                contentType: blob,
                filename: fileName
            })
            // formData.append("filename", fileName);
            // formData.append("succinct", "true");
            formData.append("_charset", "UTF-8");
            formData.append("includeAllowableActions", "true");
            const headers = {
                ...formData.getHeaders(),
                'Content-Length': formData.getLengthSync()
            }
            // let headers = formData.getHeaders();
            headers["Authorization"] = "Bearer " + jwtToken;
            // headers["cmis:contentStreamMimeType"] = "application/pdf";

            const config = {
                headers: headers
            }

            axios.post(folderCreateURL, formData, config)
                .then(response => {
                    resolve(response.data.properties['cmis:objectId'].value)
                })
                .catch(error => {
                    reject(error)
                })


        })
    }

    static async sendCancellationMail(cwaID, req) {
        console.log("Sending Cancellation email");
        var [cwaHeader] = await SELECT.from("CWA_REQUEST.CWAHeader").where({ ID: cwaID });

        var mailReceiverRoles = await SELECT.from("CWA_REQUEST.EmailNotify").where({ Status: "Cancelled" }).and({ Type: "CWA" }).columns('EmailNotify');
        var mailReceivers = [];
        if (mailReceiverRoles.length !== 0)
            mailReceiverRoles = mailReceiverRoles[0].EmailNotify.split(",").map(s => s.trim());
        for (let index = 0; index < mailReceiverRoles.length; index++) {
            const element = mailReceiverRoles[index];
            switch (element) {
                case 'Global Admin':
                    let receivers = await RolesUtil.getAllowedUsers(null, null, null, null, 'CWA', element);
                    mailReceivers.push(...receivers);
                    break;
                case 'Regional Admin':
                    mailReceivers.push(...(await RolesUtil.getAllowedUsers(cwaHeader.REGION, null, null, null, 'CWA', element)));
                    break;
                case 'Site Admin':
                    mailReceivers.push(...(await RolesUtil.getAllowedUsers(null, cwaHeader.SITE, null, null, 'CWA', element)));
                    break;
                default:
                    let receivers1 = await RolesUtil.getAllowedUsers(null, null, null, null, 'CWA', element);
                    mailReceivers.push(...receivers1);
                    break;
            }
        }

        const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site?siteId=24a954a1-987b-464e-80ae-efd3687823c8";
        var from = process.env.FromEmail;
        var to = cwaHeader.CREATEDBY;
        mailReceivers.push(cwaHeader.CURRENTAPPROVER);

        const cwaItem = await SELECT.from("CWA_REQUEST.CWAItem").where({ Parent_ID: cwaHeader.ID });
        var Propose_MS = 0, Current_MS = 0, CurrentMonthShipment = 0, BalanceMonth = 0,
            MonthTM1 = 0, BalanceMonth = 0, CurrentMonthShipment = 0, ApprovedWaiver = 0;

        for (var j = 0; j < cwaItem.length; j++) {
            Propose_MS = Propose_MS + parseFloat(cwaItem[j].PROPOSEDMS);
            Current_MS = Current_MS + parseFloat(cwaItem[j].CURRENTMS);
            CurrentMonthShipment = CurrentMonthShipment + parseFloat(cwaItem[j].CURRENTMONTHSHIPMENT);
            BalanceMonth = BalanceMonth + parseFloat(cwaItem[j].BALANCEMONTH);
            MonthTM1 = MonthTM1 + parseFloat(cwaItem[j].MONTHTM1);
            ApprovedWaiver = ApprovedWaiver + parseFloat(cwaItem[j].APPROVEDWAIVER);
        }
        let profitCentersArray = cwaItem.map(item => item.PROFITCENTERS);
        let profitCentersString = profitCentersArray.join(',');

        // Fetch data from the database
        const cwaApproverHistory = await SELECT.from("CWA_REQUEST.CWAWFHistory").where({ Parent_ID: cwaHeader.ID });
        const cwaApprover = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: cwaHeader.ID });

        // Initialize variables for approvers, statuses, and comments
        let approver1 = "", status1 = "", comment1 = "";
        let approver2 = "", status2 = "", comment2 = "";
        let approver3 = "", status3 = "", comment3 = "";

        // Iterate over cwaApprover to set the approvers
        cwaApprover.forEach(entry => {
            switch (entry.APPROVERLEVEL) {
                case "WCM":
                    approver1 = entry.APPROVERNAME || "";
                    status1 = entry.STATUS || "Pending Approval";
                    comment1 = entry.COMMENTS || "No Comments";
                    break;
                case "BUM":
                    approver2 = entry.APPROVERNAME || "";
                    status2 = entry.STATUS || "Pending Approval";
                    comment2 = entry.COMMENTS || "No Comments";
                    break;
                case "SPM":
                    approver3 = entry.APPROVERNAME || "";
                    status3 = entry.STATUS || "Pending Approval";
                    comment3 = entry.COMMENTS || "No Comments";
                    break;
                default:
                    break;
            }
        });

        // Iterate over cwaApproverHistory to set statuses and comments
        cwaApproverHistory.forEach(entry => {
            switch (entry.APPROVERLEVEL) {
                case "WCM":
                    approver1 = entry.APPROVERNAME || approver1; // Keep existing value if not set
                    status1 = entry.STATUS || status1 || "Pending Approval";
                    comment1 = entry.COMMENTS || comment1 || "No Comments";
                    break;
                case "BUM":
                    approver2 = entry.APPROVERNAME || approver2; // Keep existing value if not set
                    status2 = entry.STATUS || status2 || "Pending Approval";
                    comment2 = entry.COMMENTS || comment2 || "No Comments";
                    break;
                case "SPM":
                    approver3 = entry.APPROVERNAME || approver3; // Keep existing value if not set
                    status3 = entry.STATUS || status3 || "Pending Approval";
                    comment3 = entry.COMMENTS || comment3 || "No Comments";
                    break;
                default:
                    break;
            }
        });

        const mailData = {
            cwaNumber: cwaHeader.CWANAME,
            customer: cwaHeader.CUSTOMER,
            site: cwaHeader.SITE,
            region: cwaHeader.REGION,
            segment: cwaHeader.SEGMENT,
            division: cwaHeader.DIVISION,
            profitCenter: profitCentersString,
            CurrentMS: Current_MS ? Number(Current_MS).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
            ProposedMS: Propose_MS ? Number(Propose_MS).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
            ApprovedWaiver: ApprovedWaiver ? Number(ApprovedWaiver).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
            MPSAlignment: (100 * (MonthTM1 / (BalanceMonth + CurrentMonthShipment))).toFixed(2).toLocaleString(),
            MPSAlignment3MonthIncWaiver: (100 * ((MonthTM1 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment))).toFixed(2).toLocaleString(),
            Approver1: approver1,
            Status1: status1,
            comment1: comment1,
            Approver2: approver2,
            Status2: status2,
            comment2: comment2,
            Approver3: approver3,
            Status3: status3,
            comment3: comment3,
            comment: cwaHeader.COMMENT,
            cwaDBUrl: apiUrl + "#cwadashboard-manage?CWAName=" + cwaHeader.CWANAME
        };

        //abhishek
        var subject = "Cancelled " + cwaHeader.CWANAME;
        var ccList = this.getUniqueUsers(mailReceivers).map(user => user.Email).join(', ');
        console.log("sending email: from/ to/ cc: " + from + to + ccList);
        var responseMailStatus = await mailUtility.sendEmail("CWACancelled", mailData, from, to, subject, ccList, req);
        console.log("responseMailStatus: " + responseMailStatus);
        if (responseMailStatus == "Success") {
            return { "Success": true }
        } else {
            return { "Success": false }
        }

    }
    static getUniqueUsers(originalArray) {
        const uniqueSet = new Set();
        const uniqueArray = [];

        originalArray.forEach(item => {
            const identifier = `${item.User}:${item.Email}`; // Create a unique identifier
            if (!uniqueSet.has(identifier)) {
                uniqueSet.add(identifier);
                uniqueArray.push(item);
            }
        });

        return uniqueArray;
    }

    static async sendReminderMail(cwa, receiverRoles, req) {
        var from = process.env.FromEmail || "cwa_waiver_dev@jabil.com";
        // var to = cwa.CREATEDBY;
        //start of change Sharique Ali 19/02/
        // var to = cwa.CURRENTAPPROVER;
        var to;
        if (cwa.CURRENTAPPROVER.includes("@")) {
            to = cwa.CURRENTAPPROVER;
        } else {
            var user = await SELECT.one.from("CWA_REQUEST_ROLEASSIGNMENT")
                .columns('USER')
                .where({ "USERNAME": `${cwa.CURRENTAPPROVER}` });
            if (user) {
                to = user.USER;
            }
        }
        // End of change Sharique Ali 19/02/2024

        console.log("Sending reminder email to " + to);
        var mailReceivers = [];

        //get cc list
        //start of change Sharique Ali 19/02/
        // Add requester in the CClist
        let requester = await SELECT.from("CWA_REQUEST_ROLEASSIGNMENT")
            .columns('USER', 'USERNAME')
            .where({ "USER": `${cwa.CREATEDBY}` });
        if (requester) {
            const mappedReceivers = requester.map(receiver => ({
                User: receiver.USERNAME,
                Email: receiver.USER
            }));
            mailReceivers.push(...mappedReceivers);
        }

        // End of change Sharique Ali 19/02/2024
        for (let index = 0; index < receiverRoles.length; index++) {
            const element = receiverRoles[index];
            switch (element) {
                case 'Global Admin':
                    let receivers = await RolesUtil.getAllowedUsers(null, null, null, null, 'CWA', element);
                    mailReceivers.push(...receivers);
                    break;
                case 'Regional Admin':
                    mailReceivers.push(...(await RolesUtil.getAllowedUsers(cwa.REGION, null, null, null, 'CWA', element)));
                    break;
                case 'Site Admin':
                    mailReceivers.push(...(await RolesUtil.getAllowedUsers(null, cwa.SITE, null, null, 'CWA', element)));
                    break;
                default:
                    let receivers1 = await RolesUtil.getAllowedUsers(null, null, null, null, 'CWA', element);
                    mailReceivers.push(...receivers1);
                    break;
            }
        }

        //Get Mail Data
        const cwaItem = await SELECT.from("CWA_REQUEST.CWAItem").where({ Parent_ID: cwa.ID });
        var Propose_MS = 0, Current_MS = 0, CurrentMonthShipment = 0, BalanceMonth = 0,
            MonthTM1 = 0, BalanceMonth = 0, CurrentMonthShipment = 0, ApprovedWaiver = 0;

        for (var j = 0; j < cwaItem.length; j++) {
            Propose_MS = Propose_MS + parseFloat(cwaItem[j].PROPOSEDMS);
            Current_MS = Current_MS + parseFloat(cwaItem[j].CURRENTMS);
            CurrentMonthShipment = CurrentMonthShipment + parseFloat(cwaItem[j].CURRENTMONTHSHIPMENT);
            BalanceMonth = BalanceMonth + parseFloat(cwaItem[j].BALANCEMONTH);
            MonthTM1 = MonthTM1 + parseFloat(cwaItem[j].MONTHTM1);
            ApprovedWaiver = ApprovedWaiver + parseFloat(cwaItem[j].APPROVEDWAIVER);
        }
        let profitCentersArray = cwaItem.map(item => item.PROFITCENTERS);
        let profitCentersString = profitCentersArray.join(',');

        // Fetch data from the database
        const cwaApproverHistory = await SELECT.from("CWA_REQUEST.CWAWFHistory").where({ Parent_ID: cwa.ID });
        const cwaApprover = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: cwa.ID });

        // Initialize variables for approvers, statuses, and comments
        let approver1 = "", status1 = "", comment1 = "";
        let approver2 = "", status2 = "", comment2 = "";
        let approver3 = "", status3 = "", comment3 = "";

        // Iterate over cwaApprover to set the approvers
        cwaApprover.forEach(entry => {
            switch (entry.APPROVERLEVEL) {
                case "WCM":
                    approver1 = entry.APPROVERNAME || "";
                    status1 = entry.STATUS || "Pending Approval";
                    comment1 = entry.COMMENTS || "No Comments";
                    break;
                case "BUM":
                    approver2 = entry.APPROVERNAME || "";
                    status2 = entry.STATUS || "Pending Approval";
                    comment2 = entry.COMMENTS || "No Comments";
                    break;
                case "SPM":
                    approver3 = entry.APPROVERNAME || "";
                    status3 = entry.STATUS || "Pending Approval";
                    comment3 = entry.COMMENTS || "No Comments";
                    break;
                default:
                    break;
            }
        });


        // Iterate over cwaApproverHistory to set statuses and comments
        let approverLevel;
        cwaApproverHistory.forEach(entry => {
            switch (entry.APPROVERLEVEL) {
                case "WCM":
                    approver1 = entry.APPROVERNAME || approver1; // Keep existing value if not set
                    status1 = entry.STATUS || status1 || "Pending Approval";
                    comment1 = entry.COMMENTS || comment1 || "No Comments";
                    approverLevel = entry.APPROVERLEVEL;
                    break;
                case "BUM":
                    approver2 = entry.APPROVERNAME || approver2; // Keep existing value if not set
                    status2 = entry.STATUS || status2 || "Pending Approval";
                    comment2 = entry.COMMENTS || comment2 || "No Comments";
                    approverLevel = entry.APPROVERLEVEL;
                    break;
                case "SPM":
                    approver3 = entry.APPROVERNAME || approver3; // Keep existing value if not set
                    status3 = entry.STATUS || status3 || "Pending Approval";
                    comment3 = entry.COMMENTS || comment3 || "No Comments";
                    approverLevel = entry.APPROVERLEVEL;
                    break;
                default:
                    break;
            }
        });
        const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site?siteId=24a954a1-987b-464e-80ae-efd3687823c8";
        const mailData = {
            approverName: cwa.CURRENTAPPROVER,
            cwaNumber: cwa.CWANAME,
            site: cwa.SITE,
            region: cwa.REGION,
            segment: cwa.SEGMENT,
            division: cwa.DIVISION,
            profitCenter: profitCentersString,
            CurrentMS: String(Current_MS),
            ProposedMS: String(Propose_MS),
            ApprovedWaiver: String(ApprovedWaiver),
            MPSAlignment: String((100 * (MonthTM1 / (BalanceMonth + CurrentMonthShipment))).toFixed(2)),
            MPSAlignment3MonthIncWaiver: String((100 * ((MonthTM1 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment))).toFixed(2)),
            Approver1: approver1,
            Status1: status1,
            comment1: comment1,
            Approver2: approver2,
            Status2: status2,
            comment2: comment2,
            Approver3: approver3,
            Status3: status3,
            comment3: comment3,
            comment: cwa.COMMENT,
            inboxUrl: apiUrl + "#WorkflowTask-DisplayMyInbox?sap-ui-app-id-hint=saas_approuter_com.sap.spa.inbox",
            cwadbUrl: apiUrl + "#cwadashboard-manage?CWAName=" + cwa.CWANAME
        };

        // var subject = "[REMINDER] CWA ACTION REQUIRED: WCM Approval" + cwa.CWANAME;
        //  approverLevel = await SELECT.one.from()
// Get the approver level from workflow history
        var subject = "[REMINDER] CWA ACTION REQUIRED:" + " " + cwa.CURRENTAPPROVERLEVEL + " " + cwa.CWANAME;
        console.log("Sending reminder email for " + mailData.cwaNumber);
        try {
            var responseMailStatus = await mailUtility.sendEmail("CWAReminder", mailData, from, to, subject, this.getUniqueUsers(mailReceivers).map(user => user.Email).join(', '), req);
            console.log("Reminder email SENT");
        } catch (error) {
            console.log("Error while Sending reminder email ");
            console.log(error);
        }
    }

    static getUniqueUsers(originalArray) {
        const uniqueSet = new Set();
        const uniqueArray = [];

        originalArray.forEach(item => {
            const identifier = `${item.User}:${item.Email}`; // Create a unique identifier
            if (!uniqueSet.has(identifier)) {
                uniqueSet.add(identifier);
                uniqueArray.push(item);
            }
        });

        return uniqueArray;
    }
    static async calculateAging(maxDate, LeastDate) {
        var fromDate = new Date((new Date(maxDate).toISOString()).split('T')[0]);
        var toDate = new Date((LeastDate).split('T')[0]);
        var timeDifference = Math.abs(fromDate.getTime() - toDate.getTime());
        return Math.ceil(timeDifference / (1000 * 3600 * 24));
    }

    static async processCWAForReminder(cwa, req) {
        var mailReceiverRoles = await SELECT.from("CWA_REQUEST.EmailNotify")
            .where({ Status: "Pending Approval" })
            .and({ Type: "CWA" })
            .columns('EmailNotify');
        if (mailReceiverRoles.length === 0) {
            console.log("Email Notify Table entries missing");
        }
        else
            mailReceiverRoles = mailReceiverRoles[0].EmailNotify.split(",").map(s => s.trim());

        const hoursBetween = (t1, t2) => (new Date(t2) - new Date(t1)) / (1000 * 60 * 60);

        //1. Check if reminder really needed for this Site and Customer
        var escalationMatrix = await SELECT
            .one
            .from("CWA_REQUEST.EscalationMatrix")
            .where({ Customer: cwa.CUSTOMER, Site: cwa.SITE, Active: true });
        //-> no entry found in matrix means no reminder emails                             
        if (!escalationMatrix) {
            console.log("No escalation matrix found for CWA: " + cwa.CWANAME + ". No reminder will be sent.");
            return;
        }

        //2. Check if cyclic reminders needed from 1
        if (escalationMatrix.CYCLEINDICATOR) {
            console.log("Cyclic Reminder to be sent for CWA: " + cwa.CWANAME);
            var wfLogs = await SELECT
                .from("CWA_REQUEST.CWAWFHistory")
                .where({ Parent_ID: cwa.ID })
                .orderBy("createdAt desc");

            if (hoursBetween(wfLogs[0].CREATEDAT, new Date()) > escalationMatrix.BYHOUR) {
                //send email
                console.log("Sending Reminder Email for CWA " + cwa.CWANAME);
                this.sendReminderMail(cwa, mailReceiverRoles, req);
                //append wfhistory table
                var payload = {
                    ID: crypto.randomUUID(),
                    Parent_ID: cwa.ID,
                    WorkflowID: wfLogs[0].WORKFLOWID,
                    createdAt: new Date().toISOString(),
                    createdBy: 'System',
                    Status: "Reminded"
                }
                await INSERT.into("CWA_REQUEST.CWAWFHistory").entries(payload);
            }

        } else {
            //Check if a reminder already sent before
            var wfLogs = await SELECT
                .from("CWA_REQUEST.CWAWFHistory")
                .where({ Parent_ID: cwa.ID })
                .orderBy("createdAt desc");
            if (wfLogs[0].Status !== 'Reminded') {
                if (hoursBetween(wfLogs[0].CREATEDAT, new Date()) > escalationMatrix.BYHOUR) {
                    //send email
                    this.sendReminderMail(cwa, mailReceiverRoles, req);
                    //append wfhistory table
                    var payload = {
                        ID: crypto.randomUUID(),
                        Parent_ID: cwa.ID,
                        WorkflowID: wfLogs[0].WORKFLOWID,
                        createdAt: new Date().toISOString(),
                        createdBy: 'System',
                        Status: "Reminded"
                    }
                    await INSERT.into("CWA_REQUEST.CWAWFHistory").entries(payload);
                }
            }
        }

        //3. Check if a reminder already sent in logs table
        //if cyclic not needed then return else increase count by 1

        //4. send reminder email        
    }

}

module.exports = {
    CommonUtilities: CommonUtilities
}