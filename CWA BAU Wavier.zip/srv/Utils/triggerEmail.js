const fs = require('fs');
const path = require('path');
class mailUtility {

    //Read all roles of the user
    static async sendEmail(templateName,data,from,to,subject,cc,req) {
        // const templateName = 'workflowNotification'; // Template file name (without extension)
        var environment = process.env.Environment || ' ';
        if(environment !== ' '){
            environment = "("+environment+") ";
        }
        const template = await getTemplate(templateName);
        const emailContent = await fillTemplate(template, data);
        let content;content = '';
        var mailPayload = 
        {
            "mail_details": {
                "from": from,
                "to": to,
                "subject": environment+subject,
                "cc": cc,
                "bcc": "",
                "body": emailContent,
                "attachment": "",
                "attachmentName": ""
            }
        }
        const mailService = await cds.connect.to('CPI');
        try {
            await mailService.tx(req).post('/send/mail/bp', mailPayload);
            return "Success";
        } catch (error) {
            console.log("Error during email sending");
            console.log(error);
            return "Error";
        }

        
        
    }
  
}


module.exports = {
    mailUtility: mailUtility
}

async function getTemplate(templateName) {
    const templatePath = path.resolve(__dirname, '../templates', `${templateName}.html`);
    return new Promise((resolve, reject) => {
        fs.readFile(templatePath, 'utf8', (err, data) => {
            if (err) return reject(err);
            resolve(data);
        });
    });
}
async function fillTemplate(template, data) {
    return template.replace(/{{(.*?)}}/g, (_, key) => data[key.trim()] || '');
}