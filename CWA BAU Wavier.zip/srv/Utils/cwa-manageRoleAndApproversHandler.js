const cds = require('@sap/cds');
const RoleUtility = require("./roles").RolesUtil;
const DB = require('./dbOperations').DB;
class CWAManageRoleAndApprovers {

    static async _getRoleNameRoleReader(req){
        // IT Reader Role Check             
        if(await RoleUtility.userIsReaderOnly(req)){
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
           return;
           }
    }
    static async _getRoleNameRole(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);
        if (userRoles.RoleNames.includes("Global Admin")) {
        }
        else {
            for (var i = 0; i < data.length; i++) {
                data[i].Action = false;
            }
        }
    }

    static async _getApprovalRole(data, req) {
        // for (var i = 0; i < data.length; i++) {
        //     data[i].Action = (await RoleUtility.isValidForUser(req.user.id, null, data[i].Site, null, null, data[i].ApprovalType, data[i].RoleName)).allowed;
        // }
    }

    static async _getMPSBUWaiverThresholdRoleReader(req){
        // IT Reader Role Check             
        if(await RoleUtility.userIsReaderOnly(req)){
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
           return;
           }
    }
    static async _getMPSBUWaiverThresholdRole(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);
        if (userRoles.RoleNames.includes("Global Admin")) {
        }
        else {
            for (var i = 0; i < data.length; i++) {
                data[i].Action = false;
            }
        }
    }

    static async _getBUWaiverRuleClosureRoleReader(req){
    // IT Reader Role Check             
        if(await RoleUtility.userIsReaderOnly(req)){
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
            return;
       }
    }
    static async _getBUWaiverRuleClosureRole(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);
        if (userRoles.RoleNames.includes("Global Admin")) {
        }
        else {
            if (userRoles.RoleNames.includes("Site Admin") || userRoles.RoleNames.includes("Regional Admin")) {
                for (var i = 0; i < data.length; i++) {
                    data[i].Action = (await RoleUtility.isValidForUser(req.user.id, null, data[i].Site, data[i].Customer, null, null, null)).allowed;
                }
            }
            else {
                for (var i = 0; i < data.length; i++) {
                    data[i].Action = false;
                }
            }
        }

    }

    static async _updateApprovalRole(req) {
        // IT Reader Role Check             
        if(await RoleUtility.userIsReaderOnly(req)){
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
               return;
       }
        req.data.RoleDesc = await DB._getRoleDescription(req.data.RoleName);
    }
}

module.exports = {
    CWAManageRoleAndApproversHandler: CWAManageRoleAndApprovers
}