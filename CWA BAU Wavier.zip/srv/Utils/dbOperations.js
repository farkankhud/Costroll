const {
    RolesUtil
} = require(
    "./roles"
);
class DBOperations {
    static async getCustomerRule(customerName, site) {
        const db = await cds.connect.to("db");
        var result = await SELECT
            .one
            .from('CWA_REQUEST_REQUESTRULE')
            .where({ CUSTOMERNAME: customerName, SITE: site });
        return result;
    }
    static async getCWARule(cwaID) {
        const db = await cds.connect.to("db");
        var cwa = await SELECT
            .one
            .from('CWA_REQUEST_CWAHEADER')
            .where({ ID: cwaID });
        if (cwa) {
            var result = await this.getCustomerRule(cwa.CUSTOMER, cwa.SITE);
        }
        return [cwa, result];
    }


    static async cwaExistsCustomerLevel(siteName, customerName) {
        //Need to write more logic for this method to currently identify 
        //active CWA
        var allExistingCWA = await SELECT
            .from('CWA_REQUEST_CWAHEADER')
            .where({ SITE: siteName, CUSTOMER: customerName });

        if (allExistingCWA.length == 0) return false;

        //out of all existing CWAs we need to check if anyone is currently active
        const statusPriority = [1, 2, 3, 7];
        let existingCWA = null;

        for (const status of statusPriority) {
            existingCWA = allExistingCWA.find(item => item.STATUS_ID === status);
            if (existingCWA) break;
        }
        return existingCWA == null ? false : existingCWA;

    }

    static async getCWAItems(cwaHeader) {
        var cwaFiles = await SELECT
            .from('CWA_REQUEST_CWAITEM')
            .where({ PARENT_ID: cwaHeader.ID });

        if (!cwaFiles) {
            return [];
        } else {
            return !Array.isArray(cwaFiles) ? [cwaFiles] : cwaFiles;
        }
    }

    static async getCodeListDescription(codeList, id) {
        var codeListDescr = await SELECT
            .one
            .from(codeList)
            .where({ ID: id });

        return codeListDescr.DESCR;
    }

    static async getActivePC(siteName, customerName) {
        var validProfitCenters = await SELECT
            .from('CWA_REQUEST_TM1HIERARCHY')
            .where({ PLANT: siteName, CUSTOMER: customerName, ACTIVE: true });
        return validProfitCenters.map(item => item.PROFITCENTER);
    }

    static async getTM1Hierarchy(siteName, customerName) {
        var tm1HierarchyLine = await SELECT
            .one
            .from('CWA_REQUEST_TM1HIERARCHY')
            .where({ PLANT: siteName, CUSTOMER: customerName, ACTIVE: true });
        return tm1HierarchyLine;
    }

    static async getCWAApprovers(region, siteName, customerName, profitCenters) {
        //get from role utility
        var wcmApprovers = await RolesUtil.getAllowedUsers(region, siteName, customerName, profitCenters, 'CWA', 'WCM');
        var bumApprovers = await RolesUtil.getAllowedUsers(region, siteName, customerName, profitCenters, 'CWA', 'BUM');
        var spmApprovers = await RolesUtil.getAllowedUsers(region, siteName, customerName, profitCenters, 'CWA', 'SPM');

        return {
            "CWAApprovers": {
                "WCM": wcmApprovers,
                "BUM": bumApprovers,
                "SPM": spmApprovers
            }
        };
    }


    static async getNextNumberForSite(siteName) {
        const db = await cds.connect.to("db");
        var nextNumber = await db.run(`SELECT MAX("NUMBER") FROM "CWA_REQUEST_CWAHEADER" WHERE SITE = '${siteName}'`)
            .then((result) => {
                if (result.length == 0 || result[0]["MAX(NUMBER)"] == null) {
                    return 1;
                } else if (result.length != 0) return result[0]["MAX(NUMBER)"] + 1;
            })
            .catch((error) => {
                return error;
            });
        return nextNumber;
    }

    static async cwaExistsProfitCentreLevel(headerData, itemData) {
        var validProfitCenter = await SELECT
            .from('CWA_REQUEST_TM1HIERARCHY')
            .where({ PLANT: headerData.Site, CUSTOMER: headerData.Customer, PROFITCENTER: itemData.ProfitCenters, ACTIVE: true });
        if (validProfitCenter) {
            return validProfitCenter;
        } else {
            return false;
        }
    }

    static async cwaExistsCustomer(headerData, itemData){
        var validCustomer = await SELECT
        .from('CWA_REQUEST_TM1HIERARCHY')
        .where({ CUSTOMER: headerData.Customer, ACTIVE: true });
        //.where({ PLANT: headerData.Site, PROFITCENTER: itemData.ProfitCenters, ACTIVE: true });
        if(validCustomer){
            return validCustomer;
        }else {
            return false;
        }
    }

    static async cwaExistsProfitCentre(headerData, itemData){
        var validPC = await SELECT
        .from('CWA_REQUEST_TM1HIERARCHY')
        .where({ PROFITCENTER: itemData.ProfitCenters, ACTIVE: true });
        //.where({ PLANT: headerData.Site, CUSTOMER: headerData.Customer, ACTIVE: true });
        if(validPC){
            return validPC;
        }else {
            return false;
        } 
    }
    static async cwaExistsSite(headerData, itemData){
        var validSite = await SELECT
        .from('CWA_REQUEST_TM1HIERARCHY')
        .where({ PLANT: headerData.Site, ACTIVE: true });
        //.where({ CUSTOMER: headerData.Customer, PROFITCENTER: itemData.ProfitCenters, ACTIVE: true });
        if(validSite){
            return validSite;
        }else {
            return false;
        }   
    }

    static async SiteCustomerPCValidation(headerData, itemData){
        var check = await SELECT 
                          .one
                          .from('CWA_REQUEST_TM1HIERARCHY')
                          .where({ CUSTOMER: headerData.Customer, PLANT: headerData.Site, PROFITCENTER: itemData.ProfitCenters, ACTIVE: true });
            if (check) {
                return check;
            }
    }

    static async SiteCustomerValidation(headerData, itemData){
        var check = await SELECT 
        .one
        .from('CWA_REQUEST_TM1HIERARCHY')
        .where({ CUSTOMER: headerData.Customer, PLANT: headerData.Site, ACTIVE: true });

            if (check) {
                return check;
            }
    }

    static async CustomerPCValidation(headerData, itemData){
        var check = await SELECT 
                         .one
                         .from('CWA_REQUEST_TM1HIERARCHY')
                         .where({ CUSTOMER: headerData.Customer, PROFITCENTER: itemData.ProfitCenters, ACTIVE: true });
            if (check) {
                return check;
            }
    }

    static async PCSiteValidation(headerData, itemData){
        var check = await SELECT 
        .one
        .from('CWA_REQUEST_TM1HIERARCHY')
        .where({ PLANT: headerData.Site, PROFITCENTER: itemData.ProfitCenters, ACTIVE: true });

        if (!check) {
            return check;
        }

    }

    static async cwaStatusCheck(headerData, itemData) {
        /* var status = await SELECT
             .from('CWA_REQUEST_CWAHEADER')
             .join('CWA_REQUEST_CWAITEM')
             .on('CWA_REQUEST_CWAHEADER.ID', '=', 'CWA_REQUEST_CWAITEM.PARENT_ID')
             .where({ CUSTOMER: headerData.Customer, SITE: headerData.Site, PROFITCENTERS: itemData.ProfitCenters });
 */
        var status = await SELECT.one.from('CWAMAINTENANCE_HEADERTOITEM')
            .where({ CUSTOMER: headerData.Customer, SITE: headerData.Site, PROFITCENTERS: itemData.ProfitCenters, STATUS_ID: [1, 2, 3, 7] });
        // .where({ CUSTOMER: 'A123', SITE: 'SG03', PROFITCENTERS: '0112A123', STATUS_ID: [1, 2, 3, 4] });

        if (status) {
            return status;
        }
    }

    static async _getRoleDescription(role) {
        var RoleDesc = await SELECT.one
            .from('CWA_REQUEST_ROLENAME')
            .where({ ROLENAM: role });
        if (RoleDesc) {
            return RoleDesc.ROLEDESC;
        } else {
            return "No Role Found";
        }
    }

    static async getPlants() {
        var Plants = await SELECT.distinct
            .Plant
            .from('CWA_REQUEST_TM1HIERARCHY');
        if (Plants) {
            return Plants;
        } else {
            return "No Plant Found";
        }
    }

    static async _updateHeader(cwaID, SAPJOBID, status, spoolError, cwaStatus, userId) {
        if (cwaID && SAPJOBID) {
            return await cds.update('CWA_REQUEST_CWAHEADER', cwaID).set({ SAPJOBDETAILS_ID: SAPJOBID, SAPJOBDETAILS_STATUS: status, SAPJOBDETAILS_SPOOLERROR: spoolError, STATUS_ID: cwaStatus, MODIFIEDAT: new Date().toISOString(), MODIFIEDBY: userId }).then(function () {
                return true;
            }, function (error) {
                return false;
            });
        }
    }
    static async updateHeaderStatus(cwaID, statusID, userId) {
        if (cwaID && statusID) {
            return await cds.update('CWA_REQUEST_CWAHEADER', cwaID).set({ STATUS_ID: statusID, MODIFIEDAT: new Date().toISOString(), MODIFIEDBY: userId }).then(function () {
                return true;
            }, function (error) {
                return false;
            });
        }
    }

    static async checkMultiCustomer(profitCenters) {
        var tm1Hierarchy = await SELECT
            .distinct
            .from('CWA_REQUEST_TM1HIERARCHY')
            .where({ PROFITCENTER: profitCenters.split(",").map(item => item.trim()) })
            .columns(['CUSTOMER']);
        if (!tm1Hierarchy) return;
        return tm1Hierarchy.length > 1 ? tm1Hierarchy : [];
    }

    static async _getSAPJobID(cwaID) {
        var SAPJOBID = await SELECT.one
            .from('CWA_REQUEST_CWAHEADER')
            .where({ ID: cwaID });
        if (SAPJOBID) {
            return SAPJOBID.SAPJOBID;
        } else {
            return "No SAPJOBID found";
        }
    }

    static async getCampusName(site, customer){
        var CampusName = await SELECT .one 
                                      .from('CWA_REQUEST_TM1HIERARCHY')
                                      .where({ PLANT : site, CUSTOMER : customer })
                                      .columns(['CAMPUSNAME']);
        if(CampusName) {
            return CampusName;
        }  else {
            return "";
        }                                   
    }

    static async _getRegion(data){
        var Region = await SELECT .one 
        .from('CWA_REQUEST_TM1HIERARCHY')
        .where({ PLANT : data.Site, CUSTOMER : data.CustomerName })
        .columns(['Region']);
        if(Region) {
            return Region.Region;
    }  else {
            return "";
}                
    }
}

module.exports = {
    DB: DBOperations
}