const cds = require('@sap/cds');
//const { select } = require('@sap/cds/libx/_runtime/hana/execute');
const RoleUtility = require("./roles").RolesUtil;
const DB = require("./dbOperations").DB;

class CWAmaintenance {
    /*  static async _getRequestRule(req) {
          if (!req[0].CustomerName) {
              err = `Please provide Customer`
              req.error({
                  code: '501',
                  message: err,
                  target: 'some_field',
                  status: 418
              });
          }
      } */

    static async _validateProfitCenterProfitCenterRule(req) {
          // IT Reader Role Check             
                if(await RoleUtility.userIsReaderOnly(req)){
                    req.error({"message" : process.env.ReaderRoleErrorMessage,
                        "status" : 418
                    });
                        return;
                }

        if (!req.data.CustomerName) {
            let err = `Please provide Customer`
            req.error({
                code: '501',
                message: err,
                //  target: 'some_field',
                status: 418
            });
        }
        
        if(req){
            var region = await DB._getRegion(req.data);
            if(region == ""){
                let err = `No Region found for Site ${req.data.Site} and Customer ${req.data.CustomerName}`;
                req.error({
                    code: '501',
                    message: err,
                    status: 418
                }); 
            }else{
                req.data.Region = region;
            }
        }
 /*        if (req.data.ProfitCenterRule === true && req.data.CustomerRule === true) {
            let err = `${req.data.CustomerName} has both Rule selected, please remove one Rule`;
            req.error({
                code: '501',
                message: err,
                //  target: 'some_field',
                status: 418
            });
        }
            */

    }

    static async _RejectionReason(req) {
        // IT Reader Role Check             
        if(await RoleUtility.userIsReaderOnly(req)){
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
            return;
           }

        if (!req.data.Description) {
            let err = `Description can not be blank`
            req.error({
                code: '501',
                message: err,
                //  target: 'Description',
                status: 418
            });
        }
    }

    static async _EmailNotify(req) {
        // IT Reader Role Check             
        if(await RoleUtility.userIsReaderOnly(req)){
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
            return;
           }

        if (!req.data.Type) {
            let err = `Type can not be blank`
            req.error({
                code: '501',
                message: err,
                //  target: 'some_field',
                status: 418
            });
        }
        if (!req.data.Status) {
            let err = `Status can not be blank`
            req.error({
                code: '501',
                message: err,
                //   target: 'some_field',
                status: 418
            });
        }
        // if (!req.data.Recipients) {
        //     let err = `Recipient can not be blank`
        //     req.error({
        //         code: '501',
        //         message: err,
        //         //  target: 'some_field',
        //         status: 418
        //     });
        // }
    }

    static async _EscalationMatrix(req) {
        if (!req.data.Customer) {
            let err = `Customer can not be blank`
            req.error({
                code: '501',
                message: err,
                //   target: 'some_field',
                status: 418
            });
        }
        if (!req.data.Site) {
            let err = `Site can not be blank`
            req.error({
                code: '501',
                message: err,
                //   target: 'some_field',
                status: 418
            });
        }
    }

    static async _getTM1HierarchyRole(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);

        if (userRoles.RoleNames.includes("Global Admin")) {
        }
        else {
            if (userRoles.RoleNames.includes("Site Admin") || userRoles.RoleNames.includes("Regional Admin")) {
                for (var i = 0; i < data.length; i++) {
                    data[i].FlagEnable = (await RoleUtility.isValidForUser(req.user.id, data[i].Region, data[i].Plant, data[i].Customer, data[i].ProfitCenter, null, null)).allowed;
                }
            }
            else {
                for (var i = 0; i < data.length; i++) {
                    data[i].FlagEnable = false;
                }
            }
        }

    }

    static async _getMaintenanceRole(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);
        if (userRoles.RoleNames.includes("Global Admin")) {
        }
        else {
            if (userRoles.RoleNames.includes("Site Admin") || userRoles.RoleNames.includes("Regional Admin")) {
                for (var i = 0; i < data.length; i++) {
                    data[i].DeleteEnable = (await RoleUtility.isValidForUser(req.user.id, null, null, data[i].CustomerName, null, null, null)).allowed;
                }
            }
            else {
                for (var i = 0; i < data.length; i++) {
                    data[i].DeleteEnable = false;
                }
            }
        }
    }

    static async _getRejectionReasonRole(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);
        if (userRoles.RoleNames.includes("Global Admin")) {
            for (var i = 0; i < data.length; i++) {
                data[i].EditEnable = true;
                // data[i].EditEnable = (await RoleUtility.isValidForUser(req.user.id, null, null, null, null, null, null)).allowed;
            }
        }
        else {
            for (var i = 0; i < data.length; i++) {
                data[i].EditEnable = false;
            }
        }
    }

    static async _getEscalationMatrixRole(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);
        if (userRoles.RoleNames.includes("Global Admin")) {
        }
        else {
            if (userRoles.RoleNames.includes("Site Admin") || userRoles.RoleNames.includes("Regional Admin")) {
                for (var i = 0; i < data.length; i++) {
                    data[i].DeleteEnable = (await RoleUtility.isValidForUser(req.user.id, null, data[i].Site, data[i].Customer, null, null, null)).allowed;
                }
            }
            else {
                for (var i = 0; i < data.length; i++) {
                    data[i].DeleteEnable = false;
                }
            }
        }
    }

    static async _getDeleteEnableRole(data, req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);
        if (userRoles.RoleNames.includes("Global Admin")) {
        }
        else {
            for (var i = 0; i < data.length; i++) {
                data[i].DeleteEnable = false;
            }
        }
    }
    
    static async _getPanelAccess(req) {
        var user = req.user.id;
        var userRoles = await RoleUtility.getAllRoles(user);

        if (userRoles.RoleNames.includes("Global Admin")) {
            return {
                TM1Hierarchy: true,
                RequestRule: true,
                RejectionReason: true,
                EscalationMatrix: true,
                EmailNotify: true,
                BtpRoleMapping: true,
                TemplateStore: true
            }
        } else {
            if (userRoles.RoleNames.includes("Site Admin") || userRoles.RoleNames.includes("Regional Admin")) {

                return {
                    TM1Hierarchy: true,
                    RequestRule: true,
                    RejectionReason: false,
                    EscalationMatrix: true,
                    EmailNotify: false,
                    BtpRoleMapping: false,
                    TemplateStore: false
                }
            }
        }
    }

    static async _PlantVH(data, req) {
        var Plants = DB.getPlants();
    }

    static async _getEmailNotify(data, req) {

    }


}

module.exports = {
    CWAMaintenanceHandler: CWAmaintenance
}