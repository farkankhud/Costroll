const cds = require("@sap/cds/libx/_runtime/cds");
const { RolesUtil } = require("./Utils/roles");
const { mailUtility } = require("./Utils/triggerEmail");
const mailUtil = require("./Utils/triggerEmail").mailUtility;
const { CommonUtilities } = require("./Utils/common");

module.exports = function () {
    this.on('ApprovalReminder', async function (req) {
        console.log("Approval Reminder action called");
        var pendingCWA = await SELECT.from("CWA_REQUEST.CWAHeader")
            .where({ Status_ID: 2 });
        console.log("Total pending CWA found = " + pendingCWA.length);
        for (let index = 0; index < pendingCWA.length; index++) {
            const element = pendingCWA[index];
            console.log("Processing CWA: " + element.CWANAME);
            await CommonUtilities.processCWAForReminder(element, req);
        }
    });

    this.before(['UpdateDBData','ApprovalReminder'], async (req) => {
        if(await RolesUtil.userIsReaderOnly(req)){
            req.error({"message" : process.env.ReaderRoleErrorMessage,
                "status" : 418
            });
            return;
        }
    });

    this.on('UpdateDBData', async function (req) {
        req.res.status(202).send('Accepted Async Job');

        console.log("Update DB data action called");
        var oldTM1Source = await cds.run(`SELECT * FROM "CUSTOM"."CWA_SYSTEM_V_TM1"`);
        console.log("Old Data Fetched");
        console.log("Old Data Number of Records = "+oldTM1Source.length);
        var oldTm1 = oldTM1Source.map(item => ({
            Plant: item.SiteCode,
            Customer: item.customerName,
            ProfitCenter: item.ProfitCenter,
            Segment: item.SegmentName,
            Division: item.DevisionName,
            CampusName: item.CampusName,
            Region: item.RegionName,
        }));

        const query = `CALL "CUSTOM"."SP_REFRESH_TM1"()`;
        const response = await cds.run(query);
        console.log("Refresh Procedure called");
        var newTM1Source = await cds.run(`SELECT * FROM "CUSTOM"."CWA_SYSTEM_V_TM1"`);
        console.log("New Data Fetched");
        console.log("New Data Number of Records = "+newTM1Source.length);
        var newTm1 = newTM1Source.map(item => ({
            Plant: item.SiteCode,
            Customer: item.customerName,
            ProfitCenter: item.ProfitCenter,
            Segment: item.SegmentName,
            Division: item.DevisionName,
            CampusName: item.CampusName,
            Region: item.RegionName,
        }));

        //Detect changes in the old and new TM1 Hierarchy Data
        var changesDetected = detectChanges(oldTm1, newTm1);

        if (changesDetected.deletedLines.length == 0 &&
            changesDetected.addedLines.length == 0 &&
            changesDetected.changedLines.length == 0
        ){
            console.log("No changes in data detected, returning");
            return;
        } 

        //Update changes to cwa tm1 hierarchy table
        //Delete records from CWA TM1 table
        if (changesDetected.deletedLines.length !== 0)
            await deleteCWATM1Hierarchy(changesDetected.deletedLines);
        if (changesDetected.addedLines.length !== 0)
            await addCWATM1Hierarchy(changesDetected.addedLines);
        if (changesDetected.changedLines.length !== 0)
            await updateCWATM1Hierarchy(changesDetected.changedLines);

        console.log("Changes are detected!");
        //Send changes as emails to the people maintained in EmailNotify table
        var mailData = {
            text: "Hi Admins, \n The following are the changes detected in TM1 Hierarchy Data:",
            added: changesDetected.addedLines,
            changed: changesDetected.changedLines,
            deleted: changesDetected.deletedLines
        };
        var mailReceiverRoles = await SELECT.from("CWA_REQUEST.EmailNotify").where({ Status: "Change" }).and({ Type: "Master Hierarchy" }).columns('EmailNotify');
        var mailReceivers = [];
        if (mailReceiverRoles.length !== 0)
            mailReceiverRoles = mailReceiverRoles[0].EmailNotify.split(",").map(s => s.trim());
        else return;


        for (let index = 0; index < mailReceiverRoles.length; index++) {
            const element = mailReceiverRoles[index];
            switch (element) {
                case 'Global Admin':
                    let receivers = await RolesUtil.getAllowedUsers(null, null, null, null, 'CWA', element);
                    mailReceivers.push(...receivers);
                    break;
                case 'Regional Admin':
                    for (let region of changesDetected.regions) {
                        let receivers1 = await RolesUtil.getAllowedUsers(region, null, null, null, 'CWA', element);
                        mailReceivers.push(...receivers1);
                    }
                    break;
                case 'Site Admin':
                    for (let site of changesDetected.sites) {
                        let receivers1 = await RolesUtil.getAllowedUsers(null, site, null, null, 'CWA', element);
                        mailReceivers.push(...receivers1);
                    }
                    break;
                default:
                    let receivers1 = await RolesUtil.getAllowedUsers(null, null, null, null, 'CWA', element);
                    mailReceivers.push(...receivers1);
                    break;
            }
        }
        
        var from = process.env.FromEmail || "cwa_waiver_dev@jabil.com";
        var to = from;
        console.log(`Sending Email: from ${from} to ${to}`);
        var responseMailStatus = await sendEmail(mailData, from, to, "TM1 Hierarchy Data Changes", getUniqueUsers(mailReceivers).map(user => user.Email).join(', '), req);
        console.log(responseMailStatus);
        if (responseMailStatus == "Success") {
            console.log("successful mail");
            return { "Success": true }
        } else {
            console.log("fail mail");
            return { "Success": false }
        }
    });
}

async function sendEmail(data, from, to, subject, cc, req) {
    const emailContent = createHtmlPayload(data);
    var mailPayload =
    {
        "mail_details": {
            "from": from,
            "to": to,
            "subject": subject,
            "cc": cc,
            "bcc": "",
            "body": emailContent,
            "attachment": "",
            "attachmentName": ""
        }
    }
    const mailService = await cds.connect.to('CPI');
    try {
        await mailService.tx(req).post('/send/mail/bp', mailPayload);
        return "Success";
    } catch (error) {
        return "Error";
    }
}

function createHtmlPayload(data) {
    const { text, added, changed, deleted } = data;

    const createTable = (array) => {
        if (array.length === 0) return '<p>No items</p>';

        let keys = [];
        const rows = array.map(item => {
            if (item.oldItem && item.newItem) {
                // Get keys from oldItem (or newItem, since they are the same)
                if (keys.length === 0) {
                    keys = Object.keys(item.oldItem);
                }

                const oldRow = keys.map(key => {
                    const oldValue = item.oldItem[key];
                    const newValue = item.newItem[key];
                    const cellStyle = oldValue !== newValue ? 'color: red;' : '';
                    return `<td style="${cellStyle}">${oldValue !== undefined ? oldValue : ''}</td>`;
                }).join('');

                const newRow = keys.map(key => {
                    const newValue = item.newItem[key];
                    const oldValue = item.oldItem[key];
                    const cellStyle = oldValue !== newValue ? 'color: blue;' : '';
                    return `<td style="${cellStyle}">${newValue !== undefined ? newValue : ''}</td>`;
                }).join('');

                return `<tr>${oldRow}</tr><tr>${newRow}</tr>`;
            } else {
                // Handle direct JSON objects
                if (keys.length === 0) {
                    keys = Object.keys(item); // Get keys for the header if not set
                }
                return `<tr>${keys.map(key => `<td>${item[key] !== undefined ? item[key] : ''}</td>`).join('')}</tr>`;
            }
        }).join('');

        // Create the header row
        const headerRow = keys.map(key => `<th>${key}</th>`).join('');

        return `<table border="1"><tr>${headerRow}</tr>${rows}</table>`;
    };

    return `
        <div>
            <h1>${text}</h1>
            <h2>Added</h2>
            ${createTable(added)}
            <h2>Changed</h2>
            ${createTable(changed)}
            <h2>Deleted</h2>
            ${createTable(deleted)}
        </div>
    `;
}

function isEqual(obj1, obj2) {
    return JSON.stringify(obj1) === JSON.stringify(obj2);
}

function getUniqueUsers(originalArray) {
    const uniqueSet = new Set();
    const uniqueArray = [];

    originalArray.forEach(item => {
        const identifier = `${item.User}:${item.Email}`; // Create a unique identifier
        if (!uniqueSet.has(identifier)) {
            uniqueSet.add(identifier);
            uniqueArray.push(item);
        }
    });

    return uniqueArray;
}

// Function to detect changes between oldData and newData
function detectChanges(oldData, newData) {
    // Initialize result arrays
    const addedLines = [];
    const deletedLines = [];
    const changedLines = [];
    const sites = new Set();
    const regions = new Set();


    // Create a map from oldData and newData for easy lookup (Need to get keys)
    const oldDataMap = new Map(oldData.map(item => [item.Plant + item.Customer + item.ProfitCenter, item]));
    const newDataMap = new Map(newData.map(item => [item.Plant + item.Customer + item.ProfitCenter, item]));

    // Detect added and changed lines
    newData.forEach(newItem => {
        const oldItem = oldDataMap.get(newItem.Plant + newItem.Customer + newItem.ProfitCenter);
        if (!oldItem) {
            addedLines.push(newItem);
            sites.add(newItem.Plant);
            regions.add(newItem.Region);
        } else if (!isEqual(oldItem, newItem)) {
            changedLines.push({ oldItem, newItem });
            sites.add(newItem.Plant);
            regions.add(newItem.Region);
        }
    });

    // Detect deleted lines
    oldData.forEach(oldItem => {
        if (!newDataMap.has(oldItem.Plant + oldItem.Customer + oldItem.ProfitCenter)) {
            deletedLines.push(oldItem);
            sites.add(oldItem.Plant);
            regions.add(oldItem.Region);
        }
    });

    return { addedLines, deletedLines, changedLines, sites, regions };
}

async function deleteCWATM1Hierarchy(lines) {
    lines.forEach(async element => {
        await DELETE.from("CWA_REQUEST.TM1Hierarchy")
            .where({ Plant: element.Plant })
            .and({ Customer: element.Customer })
            .and({ ProfitCenter: element.ProfitCenter });
    });
}
async function addCWATM1Hierarchy(lines) {
    var newLines = lines.map(item => ({
        ...item,
        Active: true
    }));
    await INSERT.into("CWA_REQUEST.TM1Hierarchy").entries(newLines);
}
async function updateCWATM1Hierarchy(lines) {
    lines.forEach(async element => {
        await UPDATE.entity("CWA_REQUEST.TM1Hierarchy")
            .with(element)
            .where({ Plant: element.Plant })
            .and({ Customer: element.Customer })
            .and({ ProfitCenter: element.ProfitCenter });
    });
}
