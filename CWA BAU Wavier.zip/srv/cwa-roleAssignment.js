const cds = require('@sap/cds');
const user = require('@sap/cds/lib/req/user');
const CWARoleAssignmentHandler = require('./Utils/cwa-roleAssignmentHandler').CWARoleAssignmentHandler;
const DB = require('../srv/Utils/dbOperations').DB;
const { RolesUtil } = require('./Utils/roles');
const axios = require("axios");
const sdk = require("@sap-cloud-sdk/connectivity");
const { getDestinationFromDestinationService } = require("@sap-cloud-sdk/connectivity");

module.exports = cds.service.impl(srv => {
    srv.on('READ', 'User', async req => {
        const service = await cds.connect.to('MicrosoftGraph');
        // var query = "/users?$filter=" + req._query.$filter;//+"&$expand=manager($select=displayName,mail)";  change on 11 Feb 2025
        // const graphUser = await service.tx(req).get(query);
        // const email = req.user.id;

        // Change on 11 Feb 2025
        const email = req.query.SELECT.where[2].val;
        let response1 = [];
        // const baseURL = "/users/?$filter=startswith(displayName,'"
        // const endURL = "')"
        // const url = baseURL.concat(email, endURL);

        const destinationName = "OKTA_INTEGRATION_COSTROLL";
        const destination = await getDestinationFromDestinationService({ destinationName: destinationName });
        // const graphUser = await service.tx(req).get(url);

        if (!destination) {
            return { error: `Destination '${destinationName}' not found` };
            // }
        }
        const apiKey = destination.originalProperties?.SSWSKey;
        const fullUrl = destination.originalProperties.URL + "/api/v1/users";
        // const apiKey = "00aFAnwMm8RGw2hCUTvjru_4vq2Um4euV7Coq4j3uC";
        // SEnd of Change of Change Shariue 03/02/2025
        console.log("apikey", process.env.oktaAPIkey);
        // Start of change Sharique 13/03/2025
        try {
            response1 = await axios.get(fullUrl, {
                headers: {
                    Authorization: `SSWS ${apiKey}`,
                    Accept: "application/json"
                },
                params: {
                    // q: email,//this property searches against 3 properites(mail,name...)
                    search: `profile.firstName sw "${email}" or profile.lastName sw "${email}"`,
                    limit: 60
                }
            });
        } catch (error) {
            console.error("First API call failed:", error.message);
            response1 = null;

        }
        if (!response1 || !response1.data || (Array.isArray(response1.data) && response1.data.length === 0)) {
            console.log("Trying another time with Capital P....");
            response1 = await axios.get(fullUrl, {
                headers: {
                    Authorization: `SSWS ${apiKey}`,
                    Accept: "application/json"
                },
                params: {
                    search: `Profile.firstName sw "${email}" or Profile.lastName sw "${email}"`,
                    limit: 60
                }
            });
        }
        // End of   change  Sharique 13/03/2025

        let users = response1.data.map(graph_user => {
            var user = {}
            user.aad_id = graph_user.profile.employeeNumber;
            user.username = graph_user.profile.email;
            user.displayName = graph_user.profile.displayName;
            user.givenName = graph_user.profile.firstName;
            user.surname = graph_user.profile.lastName;
            user.mail = graph_user.profile.email;
            return user
        })
        return users
        // Change on 11 Feb 2025
    });

    // IT Reader Role Check #DELETE
    srv.before(['DELETE'], '*', async function (req) {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
            return;
        }
    });

    // IT Reader Role Check #CREATE
    srv.before(['CREATE'], ['RoleName'], async function (req) {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
            return;
        }
    });

    // IT Reader Role Check #UPDATE
    srv.before(['UPDATE'], ['RoleName'], async function (req) {
        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                message: process.env.ReaderRoleErrorMessage,
                status: 418
            });
            return;
        }
    });

    srv.after(['READ'], 'roleAssignment', CWARoleAssignmentHandler._getRoleAssignName);
    srv.on('getUserRoles', CWARoleAssignmentHandler._getUserRoles);

    srv.on('getAllowedAssignments', CWARoleAssignmentHandler._getAllowedAssignments);

    srv.before(['CREATE', 'UPDATE',], 'roleAssignment', CWARoleAssignmentHandler._validateMandatory)

    // srv.before('CREATE', 'roleAssignment', async req => {
    //     req.data.RoleDesc = await DB._getRoleDescription(req.data.RoleName);
    // });

    // srv.after('UPDATE', 'roleAssignment', async req => {
    //     const userEmail = req.User;
    //     const roleNames = req.RoleName.split(',').map(role => role.trim());

    //     try {
    //         const cwaBTPRoles = await SELECT.from("CWA_REQUEST.BtpRoleMapping");
    //         const existingRoles = new Set(cwaBTPRoles.map(role => role.ROLENAME));
    //         const roleMappings = new Map(cwaBTPRoles.map(role => [role.ROLENAME, role.BTPROLENAME]));

    //         // Separate matching and non-matching roles
    //         const matchingRoles = roleNames.filter(role => existingRoles.has(role));
    //         const nonMatchingRoles = [...existingRoles].filter(role => !roleNames.includes(role));

    //         const xsuaa = await cds.connect.to("xsuaa");

    //         // Fetch or create user
    //         const user = await getOrCreateUser(xsuaa, userEmail,req);

    //         // Process role updates
    //         await Promise.all([
    //             ...matchingRoles.map(roleName => updateRole(xsuaa, roleMappings.get(roleName), user.id, 'create')),
    //             ...nonMatchingRoles.map(roleName => updateRole(xsuaa, roleMappings.get(roleName), user.id, 'delete'))
    //         ]);

    //     } catch (error) {
    //         console.error("Error handling role assignment:", error);
    //         // Handle error as needed
    //     }
    // });
    srv.after('UPDATE', 'roleAssignment', async req => {
        const userEmail = req.User;
        const roleNames = req.RoleName.split(',').map(role => role.trim());

        try {
            const OktaFlag = true;
            const cwaBTPRoles = await SELECT.from("CWA_REQUEST.BtpRoleMapping");
            const existingRoles = new Set(cwaBTPRoles.map(role => role.ROLENAME));
            const roleMappings = new Map(cwaBTPRoles.map(role => [role.ROLENAME, role.BTPROLENAME]));

            // Separate matching and non-matching roles
            const matchingRoles = roleNames.filter(role => existingRoles.has(role));

            // Calculate the non-matching roles
            const nonMatchingRoles = [...existingRoles].filter(role => !roleNames.includes(role));

            const xsuaa = await cds.connect.to("xsuaa");

            // Fetch or create user
            const user = await getOrCreateUser(xsuaa, userEmail, req, OktaFlag);

            // Map non-matching roles to their BTP role names
            const nonMatchingBtpRoles = new Set(nonMatchingRoles.map(role => roleMappings.get(role)));

            // Check if any matching roles still map to the BTP roles of non-matching ones
            const rolesToRemove = new Set(
                [...nonMatchingBtpRoles].filter(btpRole => {
                    // Check if there are any remaining roles that map to this BTP role
                    return !matchingRoles.some(role => roleMappings.get(role) === btpRole);
                })
            );

            // Process role updates
            await Promise.all([
                // Add matching roles (create)
                ...matchingRoles.map(roleName => updateRole(xsuaa, roleMappings.get(roleName), user.id, 'create')),

                // Only remove BTP roles that are no longer referenced by any remaining roles
                ...[...rolesToRemove].map(btpRole => updateRole(xsuaa, btpRole, user.id, 'delete'))
            ]);

        } catch (error) {
            console.error("Error handling role assignment:", error);
            // Handle error as needed
        }
    });

    srv.after('DELETE', 'roleAssignment', async (req, res) => {
        const userEmail = res.data.User;
        console.log(userEmail)

        try {
            // Fetch all role mappings
            const cwaBTPRoles = await SELECT.from("CWA_REQUEST.BtpRoleMapping");
            const OktaFlag = false;
            // Connect to xsuaa
            const xsuaa = await cds.connect.to("xsuaa");
            // Fetch or create user
            const user = await getOrCreateUser(xsuaa, userEmail, res, OktaFlag);
            console.log(user)

            // Process each role in the fetched role mappings
            for (const roleMapping of cwaBTPRoles) {
                const btpRole = roleMapping.BTPROLENAME; // Get the BTP role name
                console.log(btpRole)
                // Prepare role payload
                const rolePayload = {
                    "members": [{
                        "origin": user.origin,
                        "type": "USER",
                        "value": user.id, // Assuming you need the email for the user
                        "operation": "delete"
                    }]
                };
                console.log(rolePayload)
                // Update group with new role
                await xsuaa.send({
                    method: 'PATCH',
                    path: `/Groups/${btpRole}`,
                    data: rolePayload,
                    headers: { 'If-Match': '0' }
                });
            }

        } catch (error) {
            console.error("Error handling role assignment:", error);
            // Handle error as needed
        }
    });
    srv.before('CREATE', 'roleAssignment', async req => {
        const userEmail = req.data.User;
        const roleNames = req.data.RoleName.split(',').map(role => role.trim());

        try {
            const xsuaa = await cds.connect.to("xsuaa");
            const OktaFlag = true;
            // Fetch or create user
            const user = await getOrCreateUser(xsuaa, userEmail, req, OktaFlag);

            //Update DB with User from API
            req.data.User = user.userEmail;

            // Fetch role mappings once for all role names
            const cwaBTPRoles = await SELECT.from("CWA_REQUEST.BtpRoleMapping");
            const roleMappings = new Map(cwaBTPRoles.map(role => [role.ROLENAME, role.BTPROLENAME]));

            // Process each role
            await Promise.all(roleNames.map(roleName => {
                const btpRole = roleMappings.get(roleName);
                if (btpRole) {
                    return updateRole(xsuaa, btpRole, user.id, 'create', user.origin);
                }
            }));

        } catch (error) {
            console.error("Error handling role assignment:", error);
            // Handle error as needed
        }
    });


    ////////////////case insenstive 
    srv.before('READ', ['roleAssignment_UserVH', 'roleAssignment_UserNameVH', 'roleAssignment_RoleNameVH',
        'roleAssignment_RegionVH', 'roleAssignment',
        'roleAssignment_SiteVH', 'roleAssignment_CustomereVH', 'roleAssignment_ProfitCenterVH'
    ], async (req) => {
        let conditions = req.query.SELECT.where;
        var newCondition = [];
        if (conditions) {
            conditions.forEach((condition, index) => {
                var scol = '';
                var sval = '';
                var sOperator = '';

                if (condition === 'and' || condition === 'or' || condition === '(' || condition === ')'
                    || condition.func != undefined
                ) {
                    newCondition.push(condition);
                }
                if (condition.ref != undefined) {
                    scol = condition.ref[0];
                    sOperator = conditions[index + 1];
                    sval = conditions[index + 2].val;
                    if (sOperator === '=') {
                        newCondition.push({ func: 'toupper', args: [{ ref: [scol] }] }, 'like', { val: `%${sval.toUpperCase()}%` });
                    } else {
                        newCondition.push({ ref: [scol] }, sOperator, { val: sval });
                    }
                }
            });
        }
        if (newCondition && newCondition.length > 0) {
            req.query.SELECT.where = newCondition;
        }
    })
    ////////////////Case insensitive 

});

async function getOrCreateUser(xsuaa, userEmail, req, OktaFlag) {
    if (OktaFlag) {
        let response1 = [];
        const destinationName = "OKTA_INTEGRATION_COSTROLL";
        const destination = await getDestinationFromDestinationService({ destinationName: destinationName });
        // const graphUser = await service.tx(req).get(url);

        if (!destination) {
            return { error: `Destination '${destinationName}' not found` };
            // }
        }
        const apiKey = destination.originalProperties?.SSWSKey;
        const fullUrl = destination.originalProperties.URL + "/api/v1/users";
        // const apiKey = "00aFAnwMm8RGw2hCUTvjru_4vq2Um4euV7Coq4j3uC";
        // SEnd of Change of Change Shariue 03/02/2025
        console.log("apikey", process.env.oktaAPIkey);
        response1 = await axios.get(fullUrl, {
            headers: {
                Authorization: `SSWS ${apiKey}`,
                Accept: "application/json"
            },
            // params: { filter: filterQuery }
            params: {
                // q: userEmail
                search: `profile.email eq "${userEmail}"`,
                limit: 60

            }
        });

        // if (response1.data != undefined || response1.data != '') {
        if (!response1.data || !Array.isArray(response1.data) || response1.data.length === 0) {
            userEmail = "";
            req.error({
                message: "User email is not valid",
                status: 418
            });
            return;
        }
        else {
            console.log("After Okta API 1", response1.data);
            console.log("After Okta API 1", response1.data[0].profile.email);
            response1.data.map(graph_user => {
                userEmail = graph_user.profile.email;
            });
        }
    }
    console.log("After Okta API", userEmail);
    const userFilterUrl = `/Users?filter=email eq '${userEmail}'`;
    const response = await xsuaa.tx(req).get(userFilterUrl);

    // Check if the user already exists
    if (response.resources.length > 0) {
        // Loop through the resources to find the matching origin
        const userWithMatchingOrigin = response.resources.find(user =>
            user.origin.includes("okta")
        );

        if (userWithMatchingOrigin) {
            var returnPayload = {
                id: userWithMatchingOrigin.id,
                origin: userWithMatchingOrigin.origin,
                // userEmail: userWithMatchingOrigin.userName
                userEmail: userWithMatchingOrigin.emails[0].value
            }
            return returnPayload;
            // return userWithMatchingOrigin.id; // Return the ID if found
        }
    }

    // If not found, create a new user
    const userFilterUrls = `/Users`;
    const responseUser = await xsuaa.tx(req).get(userFilterUrls);
    // var originUser;
    // if (response.resources.length > 0) {
    //     // Loop through the resources to find the matching origin
    //     const userWithMatching = responseUser.resources.find(user => 
    //         user.origin.includes("okta")
    //     );
    //     originUser = userWithMatching.origin;
    // }
    var originUser = process.env.origin;
    const [localPart] = userEmail.split('@');
    const [firstName, lastName] = localPart.split('_').map(part => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase());
    const userPayload = {
        userName: userEmail,
        name: {
            familyName: lastName,
            givenName: firstName
        },
        emails: [{ value: userEmail, primary: false }],
        active: true,
        verified: true,
        origin: originUser
    };

    const userCreationResponse = await xsuaa.send({
        method: 'POST',
        path: '/Users',
        data: userPayload,
        headers: { 'If-Match': '0' }
    });

    var returnPayload = {
        id: userCreationResponse.id,
        origin: userCreationResponse.origin,
        // userEmail: userCreationResponse.userName
        userEmail: userCreationResponse.emails[0].value
    }
    return returnPayload;
    // return userCreationResponse.id; // Return the newly created user's ID
}


async function updateRole(xsuaa, btpRole, userId, operation, origin) {
    const rolePayload = {
        members: [{
            origin: origin,
            type: "USER",
            value: userId,
            operation: operation
        }]
    };

    await xsuaa.send({
        method: 'PATCH',
        path: `/Groups/${btpRole}`,
        data: rolePayload,
        headers: { 'If-Match': '0' }
    });
}
