const cds = require('@sap/cds');
const CWAManageRoleAndApproversHandler = require('./Utils/cwa-manageRoleAndApproversHandler').CWAManageRoleAndApproversHandler;
const RoleUtility = require("./Utils/roles").RolesUtil;
module.exports = cds.service.impl(srv => {
 
    // IT Reader Role Check
  srv.before(['DELETE'],'*',async function (req) {
    if(await RoleUtility.userIsReaderOnly(req)){
        req.error({
            message: process.env.ReaderRoleErrorMessage,
            status: 418
        });
      return;
    }
  });

////////////////case insenstive
  srv.before ('READ', ['RoleName', 'ManageRoleAndApprovers_RoleTypeVH', 'ManageRoleAndApprovers_RoleNameVH',
                        'ManageRoleAndApprovers_RoleDescVH', 'ManageRoleAndApprovers_SiteVH', 
                        'ManageRoleAndApprovers_ApprovalLevelVH', 'SegmentVH', 'DivisionVH', 'MPSBUWaiverThreshold_LevelVH',
                        'MPSBUWaiverThreshold_WaiverTypeVH', 'MPSBUWaiverThreshold_ThresholdPercVH',
                        'MPSBUWaiverThreshold_ThresholdVH', 'CustomerVH', 'PlantVH', 'BUWaiverRuleClosure_BUWaiverActiveVH',
                        'BUWaiverRuleClosure_BUWaiverStatusVH'
  ] ,async (req)=>{
    let conditions =req.query.SELECT.where;
    var newCondition = [];
    if (conditions){
        conditions.forEach((condition,index) => {
            var scol ='';
            var sval = '';
            var sOperator = '';

            if(condition==='and' || condition==='or'||condition==='('||condition===')'
            || condition.func !=undefined
            ){
                newCondition.push(condition);
            }
            if(condition.ref!=undefined){
                scol=condition.ref[0];
                sOperator=conditions[index+1];
                sval=conditions[index+2].val;
                if(sOperator==='='){
                    newCondition.push({ func:'toupper', args:[{ref: [ scol ] }]},'like',{ val: `%${sval.toUpperCase()}%` });
                }else{
                    newCondition.push({ ref: [ scol ] },sOperator,{ val: sval });
                }  
            }
        });
    }
    if(newCondition&& newCondition.length>0){
        req.query.SELECT.where = newCondition;
    }
 });
////////////////Case insensitive 

    //Add implementation for TM1Hierarchy
    srv.after(['READ'], 'RoleName', CWAManageRoleAndApproversHandler._getRoleNameRole);
    srv.before(['CREATE', 'UPDATE'], 'RoleName', CWAManageRoleAndApproversHandler._getRoleNameRoleReader);
    //Add implementation for ApprovalRole
    srv.after(['READ'], 'ApprovalRole', CWAManageRoleAndApproversHandler._getApprovalRole);
    srv.before(['CREATE', 'UPDATE'], 'ApprovalRole', CWAManageRoleAndApproversHandler._updateApprovalRole);

    //Add implementation for MPSBUWaiverThreshold
    srv.after(['READ'], 'MPSBUWaiverThreshold', CWAManageRoleAndApproversHandler._getMPSBUWaiverThresholdRole);
    srv.before(['CREATE','UPDATE'], 'MPSBUWaiverThreshold', CWAManageRoleAndApproversHandler._getMPSBUWaiverThresholdRoleReader);

    //Add implementation for BUWaiverRuleClosure
    srv.after(['READ'], 'BUWaiverRuleClosure', CWAManageRoleAndApproversHandler._getBUWaiverRuleClosureRole);
    srv.before(['CREATE','UPDATE'], 'BUWaiverRuleClosure', CWAManageRoleAndApproversHandler._getBUWaiverRuleClosureRoleReader)
});