const cds = require('@sap/cds');
const CommonUtilities = require("./Utils/common").CommonUtilities;
const DB = require("./Utils/dbOperations").DB;
const CWACustomerLevel = require("./Utils/cwa-request").CWACustomerLevel;
const CWAPCLevel = require("./Utils/cwa-request").CWAPCLevel;
const xsenv = require('@sap/xsenv');
const axios = require('axios').default;
const FormData = require('form-data');
const { util } = require('hdb/lib');
const { RolesUtil } = require('./Utils/roles');
const RoleUtility = require("./Utils/roles").RolesUtil;
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { triggerAsyncId } = require('async_hooks');
const { db } = require('@sap/cds/lib');
const { mailUtility } = require('./Utils/triggerEmail');
const common = require('./Utils/common');
const mailUtil = require("./Utils/triggerEmail").mailUtility;


module.exports = function () {
    this.on('READ', ['Versions', 'TimeZones'], async function (req) {
        var onPremS4API = await cds.connect.to("ZOD_CWA_REQ_ZUPL_INTERG_SRV");
        return onPremS4API.run(req.query);
    });

    this.before('CREATE', ['Items', 'Attachments', 'Approvers', 'CWAWFHistory', 'CWAStatuses', 'Documents',
        'TimeZones', 'Versions', 'TemplateStore', 'MediaFile'], async req => {
            if (await RolesUtil.userIsReaderOnly(req)) {
                req.error({
                    "message": process.env.ReaderRoleErrorMessage,
                    "status": 418
                });
                return;
            }
        });

    this.before('DELETE', ['Header', 'Items', 'Attachments', 'Approvers', 'CWAWFHistory', 'CWAStatuses', 'Documents',
        'TimeZones', 'Versions', 'TemplateStore', 'MediaFile'], async req => {
            if (await RolesUtil.userIsReaderOnly(req)) {
                req.error({
                    "message": process.env.ReaderRoleErrorMessage,
                    "status": 418
                });
                return;
            }
        });

    this.before('UPDATE', ['Header', 'Items', 'Attachments', 'Approvers', 'CWAWFHistory', 'CWAStatuses', 'Documents',
        'TimeZones', 'Versions', 'TemplateStore', 'MediaFile'], async req => {
            if (await RolesUtil.userIsReaderOnly(req)) {
                req.error({
                    "target": "ReadOnly",
                    "message": process.env.ReaderRoleErrorMessage,
                    "status": 418
                });
                return;
            }
        });

    this.before(['SubmitCWA', 'UploadDemand', 'forwardWorkflow', 'CancelCWA',
        'createDMSFolder', 'updateWorkflow', 'updateRequestFromWF',
        'CreateMediaFile', 'deleteDMSDocument'], async (req) => {
            if (await RolesUtil.userIsReaderOnly(req)) {
                req.error({
                    "message": process.env.ReaderRoleErrorMessage,
                    "status": 418
                });
                return;
            }
        });

    this.on('CreateMediaFile', async (req) => {
        // debugger;
        req.data = req.data.FileData;
        var base64Data = req.data.content.split(',')[1];
        const url = process.env.dmsURL;//"https://jabilcfdev.authentication.us10.hana.ondemand.com";
        // const clientid = "sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
        // const clientSecret = "HQJVceIL92Oo9dr8RHrK4L7oP2U=";
        const clientid = process.env.clientid;//"sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
        const clientSecret = process.env.clientSecret;
        var repositoryId = "CWA_REQUEST_REPO";
        const connJwtToken = await fetchJwtToken(url, clientid, clientSecret);
        var folderID = req.data.folderID;
        var base64 = base64Data;
        var eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
        var fileName = req.data.fileName;
        try {
            req.data.fileID = await CommonUtilities.createFile(eURL, connJwtToken, repositoryId, folderID, fileName, base64);
        } catch (error) {
            //do nothing for now => to be handled
        }
        // debugger;
        return { "folderID": req.data.fileID };

    });

    this.on('ValidateFileData', async req => {
        console.log("Validate File Data called");
        //get the inputs from UI
        var headerData = req.data.Header;
        var itemData = req.data.Item;

        console.log("User Id for roles = " + req.req.user.id);
        console.log("Changed User Id for roles1 = " + req.req.user.id.toLowerCase());

        //Check if the user has access to the Site etc mentioned in file
        var fileDataAllowed = await RoleUtility.isValidForUser(req.req.user.id, itemData.Region, headerData.Site, headerData.Customer, itemData.ProfitCenters, 'CWA', 'PL');

        if (!fileDataAllowed.allowed) {
            return {
                "ValidationPassed": false,
                "Message": RoleUtility.getValidationMessage(fileDataAllowed),
                "Action": 'NONE'
            };
        }


        //Check if Customer level / PC level scenario
        var customerRule = await DB.getCustomerRule(headerData.Customer, headerData.Site);
        var validationResult;

        if (customerRule == null) {
            //If no customer rule found then automatically set profit center rule
            customerRule = { "PROFITCENTERRULE": true, "CUSTOMERRULE": false }
        }
        if (customerRule.CUSTOMERRULE) {
            validationResult = await CWACustomerLevel.handleValidation(headerData, itemData);
        } else {
            //else if (customerRule.PROFITCENTERRULE) {
            validationResult = await CWAPCLevel.handleValidation(headerData, itemData);
        }

        if (validationResult.validationPassed) {
            //Get Segment, Division and Region values for Header
            var headerDetails = await DB.getTM1Hierarchy(headerData.Site, headerData.Customer);
            //Get CWA approvers for header based on Site and custommer
            var cwaApprovers = (await DB.getCWAApprovers(headerDetails.REGION, headerData.Site, headerData.Customer, itemData.ProfitCenters)).CWAApprovers;
        }
        console.log("Validate File Data Returning successfully");
        return {
            "ValidationPassed": validationResult.validationPassed,
            "Message": validationResult.message,
            "Action": validationResult.action,
            "AdditionalDetails": {
                "ExistingCWAID": validationResult.existingCWA?.ID,
                "ExistingCWAName": validationResult.existingCWA?.CWANAME,
                "SubmitAllowed": validationResult.SubmitAllowed,
                "SaveAllowed": validationResult.SaveAllowed,
                "Division": headerDetails?.DIVISION,
                "Segment": headerDetails?.SEGMENT,
                "Region": headerDetails?.REGION,
                "CWAApprovers": cwaApprovers
            }
        };
    });



    this.before('CREATE', 'Header', async req => {

        if (await RolesUtil.userIsReaderOnly(req)) {
            req.error({
                "message": process.env.ReaderRoleErrorMessage,
                "status": 418
            });
            return;
        }

        req.data.Number = await DB.getNextNumberForSite(req.data.Site); //Need error handling
        const currentDate = new Date();
        const day = String(currentDate.getDate()).padStart(2, '0');
        const month = String(currentDate.getMonth() + 1).padStart(2, '0');
        const year = String(currentDate.getFullYear()).slice(-2);
        const formattedDate = day + month + year;

        // Define the plant code, customer code, and running number
        const plantCode = req.data.Site;
        const customerCode = req.data.Customer.slice(0, 3).trim();
        const runningNumber = String(req.data.Number).padStart(4, '0');

        // Construct the final CWA name
        req.data.CWAName = `CWA-${plantCode}-${customerCode}-${formattedDate}-${runningNumber}`;
        req.data.Status_ID = 1; //In Draft

        //Create Folder in DMS for keeping documents + attachments
        console.log("Going to create DMS folder");
        try {
            var folderID = await createDMSFolder(req.data.ID); //Need Error Handling
        } catch (error) {
            console.log("Error while folder creation in DMS.");
            console.log(error);
        }
        console.log("DMS folder creation fine: " + folderID.folderID);
        req.data.DmsFolderId = folderID.folderID;
        req.data.DmsFolderName = 'Folder_' + req.data.CWAName;
    });
    ////////////////case insenstive
    this.before('READ', ['PlantVH', 'CWANameVH', 'ProfitCentersVH', 'CustomerVH', 'RegionVH', 'SegmentVH',
        'DivisionVH', 'StatusIDVH', 'CurrentApproverVH', 'CurrentApproverLevelVH', 'BUWaiverStatusVH',
        'IDVH'
    ], async (req) => {
        let conditions = req.query.SELECT.where;
        var newCondition = [];
        if (conditions) {
            conditions.forEach((condition, index) => {
                var scol = '';
                var sval = '';
                var sOperator = '';

                if (condition === 'and' || condition === 'or' || condition === '(' || condition === ')'
                    || condition.func != undefined
                ) {
                    newCondition.push(condition);
                }
                if (condition.ref != undefined) {
                    scol = condition.ref[0];
                    sOperator = conditions[index + 1];
                    sval = conditions[index + 2].val;
                    if (sOperator === '=') {
                        newCondition.push({ func: 'toupper', args: [{ ref: [scol] }] }, 'like', { val: `%${sval.toUpperCase()}%` });
                    } else {
                        newCondition.push({ ref: [scol] }, sOperator, { val: sval });
                    }
                }
            });
        }
        if (newCondition && newCondition.length > 0) {
            req.query.SELECT.where = newCondition;
        }
    })

    // handled ref, xpr for DashboardNew entity set
    // this.before('READ', ['DashboardNew'], async (req) => {
    //     let conditions = req.query.SELECT.where;
    //     var newCondition = [];
    //     var xprNewCondition = [];
    //     if (conditions) {
    //         conditions.forEach((condition, index) => {
    //             var scol = '';
    //             var sval = '';
    //             var sOperator = '';
    //             if (condition === 'and' || condition === 'or' || condition === '(' || condition === ')'
    //                 || condition.func != undefined
    //             ) {
    //                 newCondition.push(condition);
    //             }
    //             if (condition.ref != undefined) {
    //                 scol = condition.ref[0];
    //                 sOperator = conditions[index + 1];
    //                 sval = conditions[index + 2].val;
    //                 if (sOperator === '=') {
    //                     newCondition.push({ func: 'toupper', args: [{ ref: [scol] }] }, 'like', { val: `%${sval.toUpperCase()}%` });
    //                 } else {
    //                     newCondition.push({ ref: [scol] }, sOperator, { val: sval });
    //                 }
    //             }
    //             if (condition.xpr) {
    //                 xprNewCondition = [];
    //                 // condition.xpr.forEach((xprCondition, xprIndex) => {
    //                 //     var scol = '';
    //                 //     var sval = '';
    //                 //     var sOperator = '';
    //                 //     if (xprCondition === 'and' || xprCondition === 'or' || xprCondition === '(' || xprCondition === ')'
    //                 //         || xprCondition.func != undefined
    //                 //     ) {
    //                 //         xprNewCondition.push(xprCondition);
    //                 //     }
    //                 //     if (xprCondition.ref != undefined) {
    //                 //         scol = xprCondition.ref[0];
    //                 //         sOperator = condition.xpr[xprIndex + 1];
    //                 //         sval = condition.xpr[xprIndex + 2].val;
    //                 //         if (sOperator === '=') {
    //                 //             xprNewCondition.push({ func: 'toupper', args: [{ ref: [scol] }] }, 'like', { val: `%${sval.toUpperCase()}%` });
    //                 //         } else {
    //                 //             xprNewCondition.push({ ref: [scol] }, sOperator, { val: sval });
    //                 //         }
    //                 //     }
    //                 // });
    //                 // newCondition.push({ xpr: xprNewCondition });
    //                 newCondition.push({ xpr: condition.xpr });
    //             }

    //         });
    //     }
    //     if (newCondition && newCondition.length > 0) {
    //         req.query.SELECT.where = newCondition;
    //     }
    // })

    ////////////////Case insensitive 
    // this.before('READ', 'Dashboard', async function (req) {
    //     // Remove the Profit Center from Query

    //     // Store the removed PC in Local Var
    //     }),
    //Dashboard
    // this.after('READ', 'Dashboard', async function (data, req) {

    //     var allJobs = data.map(x => { if (!(x.SAPJobDetails_Status === 'F' || x.SAPJobDetails_Status === null || x.SAPJobDetails_ID === null)) return { "CWAID": x.ID, "JobID": x.SAPJobDetails_ID, "JobStatus": x.SAPJobDetails_Status } })
    //     var _allJobs = allJobs.filter(item => item !== undefined);
    //     var allJobsStatus = await CommonUtilities.getAllJobStatus(_allJobs, req);

    //     var Propose_MS, Current_MS, CurrentMonthShipment, BalanceMonth,
    //         ExcessTotalProposed, ExcessTotalCurrent, ObsoleteTotalProposed, ObsoleteTotalCurrent,
    //         MonthTM1, BalanceMonth, CurrentMonthShipment, ApprovedWaiver,
    //         ProfitCenters,
    //         CWAAttachments, FileID;
    //     var CampusName, CurrentDate, timeDifference, fromDate, toDate;
    //     for (var i = 0; i < data.length; i++) {
    //         Propose_MS = 0, Current_MS = 0, CurrentMonthShipment = 0, BalanceMonth = 0,
    //             ExcessTotalProposed = 0, ExcessTotalCurrent = 0, ObsoleteTotalProposed = 0, ObsoleteTotalCurrent = 0,
    //             MonthTM1 = 0, BalanceMonth = 0, CurrentMonthShipment = 0, ApprovedWaiver = 0, ProfitCenters = [],
    //             CWAAttachments = [], FileID = [];

    //         CurrentDate = new Date();
    //         fromDate = new Date((new Date(CurrentDate).toISOString()).split('T')[0]);
    //         if (data[i].createdAt) {
    //             toDate = new Date((data[i].createdAt).split('T')[0]);
    //             timeDifference = Math.abs(fromDate.getTime() - toDate.getTime());
    //             data[i].Aging = Math.ceil(timeDifference / (1000 * 3600 * 24));
    //         }
    //         // data[i].Aging = (new Date(CurrentDate).toISOString()).split('T')[0] - (data[i].createdAt).split('T')[0];
    //         // data[i].Aging = differentDays;
    //         data[i].FileFromRR = true;
    //         //  data[i].CampusName = data[i].Region;
    //         if (data[i].Site && data[i].Customer) {
    //             CampusName = await DB.getCampusName(data[i].Site, data[i].Customer);
    //             data[i].CampusName = CampusName.CAMPUSNAME;
    //         }
    //         if (data[i].SAPJobDetails_ID !== null) {
    //             if (allJobsStatus[jobname = data[i].SAPJobDetails_ID] !== undefined) {
    //                 var spoolError;
    //                 if (allJobsStatus[jobname = data[i].SAPJobDetails_ID].status === 'F') { //data[i].SAPJobDetails_Status) {
    //                     if (allJobsStatus[jobname = data[i].SAPJobDetails_ID].Error == 'X') {
    //                         spoolError = true;
    //                         var cwaStatus = 7; //Demand Error
    //                         await sendEmail(data[i], 7, req);
    //                     } else {
    //                         spoolError = false;
    //                         cwaStatus = 4; //Closed
    //                         await sendEmail(data[i], 4, req);
    //                     }
    //                     await DB._updateHeader(data[i].ID, data[i].SAPJobDetails_ID, allJobsStatus[data[i].SAPJobDetails_ID].status, spoolError, cwaStatus);
    //                     data[i].SAPJobDetails_SpoolError = spoolError;
    //                     data[i].Status_ID = cwaStatus;
    //                 }
    //                 data[i].SAPJobDetails_Status = allJobsStatus[jobname = data[i].SAPJobDetails_ID].status;
    //             }
    //         }
    //         if (data[i].CWAItems) {
    //             for (var j = 0; j < data[i].CWAItems.length; j++) {

    //                 ProfitCenters.push(data[i].CWAItems[j].ProfitCenters);

    //                 for (var k = 0; k < data[i].CWAItems[j].CWAAttachments.length; k++) {
    //                     CWAAttachments.push(data[i].CWAItems[j].CWAAttachments[k]);
    //                 }

    //                 if (data[i].CWAItems[j].FileID) {
    //                     FileID.push(data[i].CWAItems[j].FileID);
    //                 }

    //                 if (data[i].CWAItems[j].FileFromRR === false) {
    //                     data[i].FileFromRR = false;
    //                 }

    //                 Propose_MS = Propose_MS + parseFloat(data[i].CWAItems[j].ProposedMS);
    //                 Current_MS = Current_MS + parseFloat(data[i].CWAItems[j].CurrentMS);

    //                 CurrentMonthShipment = CurrentMonthShipment + parseFloat(data[i].CWAItems[j].CurrentMonthShipment);
    //                 BalanceMonth = BalanceMonth + parseFloat(data[i].CWAItems[j].BalanceMonth);

    //                 ExcessTotalProposed = ExcessTotalProposed + parseFloat(data[i].CWAItems[j].ExcessTotalProposed);
    //                 ExcessTotalCurrent = ExcessTotalCurrent + parseFloat(data[i].CWAItems[j].ExcessTotalCurrent);

    //                 ObsoleteTotalProposed = ObsoleteTotalProposed + parseFloat(data[i].CWAItems[j].ObsoleteTotalProposed);
    //                 ObsoleteTotalCurrent = ObsoleteTotalCurrent + parseFloat(data[i].CWAItems[j].ObsoleteTotalCurrent);

    //                 MonthTM1 = MonthTM1 + parseFloat(data[i].CWAItems[j].MonthTM1);
    //                 ApprovedWaiver = ApprovedWaiver + parseFloat(data[i].CWAItems[j].ApprovedWaiver);
    //             }
    //         }

    //         data[i].ProfitCenters = ProfitCenters.toString();
    //         data[i].CWAAttachments = CWAAttachments;
    //         data[i].FileID = FileID;
    //         data[i].CurrentMS = Current_MS;
    //         data[i].ProposedMS = Propose_MS;

    //         data[i].VarianceMS = Propose_MS - Current_MS;
    //         data[i].CurrentMonthShipment = CurrentMonthShipment;
    //         data[i].BalanceMonth = BalanceMonth;
    //         data[i].MS = CurrentMonthShipment + BalanceMonth;

    //         //MPS
    //         data[i].TM1M13 = MonthTM1;
    //         data[i].MPSAlignmentPerc3Mon = 100 * (data[i].TM1M13 / (BalanceMonth + CurrentMonthShipment));
    //         data[i].MPSVariance3Mon = data[i].TM1M13 - BalanceMonth - CurrentMonthShipment;
    //         data[i].MPSAlignmentPerc3MonIncldWaiver = 100 * ((data[i].TM1M13 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment));
    //         //  data[i].MPSVariance3MonIncldWaiver = ((data[i].TM1M13 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment));
    //         data[i].MPSVariance3MonIncldWaiver = data[i].TM1M13 - BalanceMonth - CurrentMonthShipment + parseFloat(ApprovedWaiver);

    //         data[i].ApprovedWaiver = ApprovedWaiver;
    //         data[i].ExcessTotalProposed = ExcessTotalProposed;
    //         data[i].ExcessTotalCurrent = ExcessTotalCurrent;
    //         data[i].excessPercDifference = ((ExcessTotalProposed - ExcessTotalCurrent) / ExcessTotalCurrent);
    //         data[i].ObsoleteTotalProposed = ObsoleteTotalProposed;
    //         data[i].ObsoleteTotalCurrent = ObsoleteTotalCurrent;
    //         data[i].ObsoletePercDifference = ((ObsoleteTotalProposed - ObsoleteTotalCurrent) / ObsoleteTotalCurrent);

    //         if (data[i].CurrentApprover) {
    //             data[i].CWACurrentApproval = data[i].CurrentApprover;
    //         }
    //         data[i].BUWaiverCurrentApproval = '-';
    //         // data[i].BUWaiverStatus = BUWaiverStatus;
    //         if (data[i].CurrentApproverLevel == "WCM") {
    //             data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'WCM');
    //         } else if (data[i].CurrentApproverLevel == "BUM") {
    //             data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'BUM');
    //         } else if (data[i].CurrentApproverLevel == "SPM") {
    //             data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'SPM');
    //         }

    //         // data[i].UploadDemand = 
    //         // data[i].CWAStatus = data[i].Status;
    //     }
    // });


    // DashboardNew entity set AFTER event handler for event READ
    this.after('READ', 'DashboardNew', async function (data, req) {
        var allJobs = data.map(x => { if (!(x.SAPJobDetails_Status === 'F' || x.SAPJobDetails_Status === null || x.SAPJobDetails_ID === null)) return { "CWAID": x.ID, "JobID": x.SAPJobDetails_ID, "JobStatus": x.SAPJobDetails_Status } })
        var _allJobs = allJobs.filter(item => item !== undefined);
        var allJobsStatus = await CommonUtilities.getAllJobStatus(_allJobs, req);
        var CWAAttachments = [];
        var FileID = [];
        var CampusName, CurrentDate, timeDifference, fromDate, toDate, aging = 0, sortedCWAWFHistory, least, max;
        for (var i = 0; i < data.length; i++) {
            CWAAttachments = [];
            FileID = [];
            data[i].FileFromRR = true;
            // Campus
            if (data[i].Site && data[i].Customer) {
                CampusName = await DB.getCampusName(data[i].Site, data[i].Customer);
                data[i].CampusName = CampusName.CAMPUSNAME;
            }

            // Aging
            if (data[i].CWAWFHistory.length > 0) {
                sortedCWAWFHistory = data[i].CWAWFHistory.sort((a, b) => a.createdAt - b.createdAt); //Sorting the WF History Array on the basis of CreatedAt
                least = sortedCWAWFHistory[0];  //Fetching the first entry
                max = sortedCWAWFHistory[sortedCWAWFHistory.length - 1]; //Fetching the last entry
                if (data[i].Status_ID == '5' || data[i].Status_ID == '6') { //If CWA status = Cancelled OR Rejected
                    if (max.createdAt && least.createdAt) {
                        aging = await CommonUtilities.calculateAging(max.createdAt, least.createdAt);
                    }
                } else if (data[i].Status_ID == '4') { //If CWA status = Closed
                    if (data[i].modifiedAt && least.createdAt) {
                        aging = await CommonUtilities.calculateAging(data[i].modifiedAt, least.createdAt);
                    }
                } else {
                    CurrentDate = new Date();
                    fromDate = new Date((new Date(CurrentDate).toISOString()).split('T')[0]);
                    if (least.createdAt) {
                        toDate = new Date((least.createdAt).split('T')[0]);
                        timeDifference = Math.abs(fromDate.getTime() - toDate.getTime());
                        aging = Math.ceil(timeDifference / (1000 * 3600 * 24));
                    }
                }
            }
            if (aging) {
                data[i].Aging = aging;
                aging = 0;
            }
            // SAP Job details
            if (data[i].SAPJobDetails_ID !== null) {
                if (allJobsStatus[jobname = data[i].SAPJobDetails_ID] !== undefined) {
                    var spoolError;
                    if (allJobsStatus[jobname = data[i].SAPJobDetails_ID].status === 'F') { //data[i].SAPJobDetails_Status) {
                        if (allJobsStatus[jobname = data[i].SAPJobDetails_ID].Error == 'X') {
                            spoolError = true;
                            var cwaStatus = 7; //Demand Error
                            await sendEmail(data[i], 7, req);
                        } else {
                            spoolError = false;
                            cwaStatus = 4; //Closed
                            await sendEmail(data[i], 4, req);
                        }
                        await DB._updateHeader(data[i].ID, data[i].SAPJobDetails_ID, allJobsStatus[data[i].SAPJobDetails_ID].status, spoolError, cwaStatus, req.user.id);
                        data[i].SAPJobDetails_SpoolError = spoolError;
                        data[i].Status_ID = cwaStatus;
                    }
                    data[i].SAPJobDetails_Status = allJobsStatus[jobname = data[i].SAPJobDetails_ID].status;
                }
            }

            // Reading Items
            if (data[i].CWAItems) {
                for (var j = 0; j < data[i].CWAItems.length; j++) {
                    // Reading Attachments for each item
                    for (var k = 0; k < data[i].CWAItems[j].CWAAttachments.length; k++) {
                        CWAAttachments.push(data[i].CWAItems[j].CWAAttachments[k]);
                    }

                    if (data[i].CWAItems[j].FileID) {
                        FileID.push(data[i].CWAItems[j].FileID);
                    }

                    //FileFromRR
                    if (data[i].CWAItems[j].FileFromRR === false) {
                        data[i].FileFromRR = false;
                    }
                }
            }
            data[i].CWAAttachments = CWAAttachments;
            data[i].FileID = FileID;
            if (data[i].CurrentApproverLevel == "WCM") {
                data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'WCM');
            } else if (data[i].CurrentApproverLevel == "BUM") {
                data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'BUM');
            } else if (data[i].CurrentApproverLevel == "SPM") {
                data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'SPM');
            }
        }

    });

    ////////////////case insenstive
    /*    
        this.before ('READ', 'DashboardNew' ,async (req)=>{
            console.log(req.query.SELECT.where);
    
            let conditions =req.query.SELECT.where;
            var newCondition = [];
    
            if (conditions){
    
                conditions.forEach((condition,index) => {
                
                    var scol ='';
                    var sval = '';
                    var sOperator = '';
        
                    if(condition==='and' || condition==='or'||condition==='('||condition===')'
                    || condition.func !=undefined
                    ){
                        newCondition.push(condition);
                    }
        
                    if(condition.ref!=undefined){
                        
                        scol=condition.ref[0];
                        sOperator=conditions[index+1];
                        sval=conditions[index+2].val;
    
                        if(sOperator==='='){
                            newCondition.push({ func:'toupper', args:[{ref: [ scol ] }]},'like',{ val: `%${sval.toUpperCase()}%` });
                        }else{
                            newCondition.push({ ref: [ scol ] },sOperator,{ val: sval });
                        }  
                    }
                });
            }
    
            if(newCondition&& newCondition.length>0){
                req.query.SELECT.where = newCondition;
            }
            console.log(req.query.SELECT.where);
         })
    */
    ////////////////Case insensitive 
    /*
        //Dashboard workflow
        this.after('READ', 'CWADashboardWorkflow', async function (data, req) {
    
            // var allJobs = data.map(x => { if (!(x.SAPJobDetails_Status === 'F' || x.SAPJobDetails_Status === null)) return { "CWAID": x.ID, "JobID": x.SAPJobDetails_ID, "JobStatus": x.SAPJobDetails_Status } })
            // var _allJobs = allJobs.filter(item => item !== undefined);
            //  var allJobsStatus = await CommonUtilities.getAllJobStatus(_allJobs, req);
    
            var Propose_MS, Current_MS, CurrentMonthShipment, BalanceMonth,
                ExcessTotalProposed, ExcessTotalCurrent, ObsoleteTotalProposed, ObsoleteTotalCurrent,
                MonthTM1, BalanceMonth, CurrentMonthShipment, ApprovedWaiver,
                ProfitCenters,
                CWAAttachments, FileID;
            for (var i = 0; i < data.length; i++) {
                Propose_MS = 0, Current_MS = 0, CurrentMonthShipment = 0, BalanceMonth = 0,
                    ExcessTotalProposed = 0, ExcessTotalCurrent = 0, ObsoleteTotalProposed = 0, ObsoleteTotalCurrent = 0,
                    MonthTM1 = 0, BalanceMonth = 0, CurrentMonthShipment = 0, ApprovedWaiver = 0, ProfitCenters = [],
                    CWAAttachments = [], FileID = [];
                data[i].Aging = new Date() - data[i].createdAt;
                data[i].FileFromRR = true;
                data[i].CampusName = data[i].Region;
    
                
                        if (data[i].SAPJobDetails_ID !== null) {
                            if (allJobsStatus[jobname = data[i].SAPJobDetails_ID] !== undefined) {
                                var spoolError;
                                if (allJobsStatus[jobname = data[i].SAPJobDetails_ID].status !== data[i].SAPJobDetails_Status) {
                                    if (allJobsStatus[jobname = data[i].SAPJobDetails_ID].Error == 'X') {
                                        spoolError = true;
                                    } else {
                                        spoolError = false;
                                    }
                                    data[i].SAPJobDetails_SpoolError = spoolError;
                                    await DB._updateHeader(data[i].ID, data[i].SAPJobDetails_ID, allJobsStatus[data[i].SAPJobDetails_ID].status, spoolError)
                                }
                                data[i].SAPJobDetails_Status = allJobsStatus[jobname = data[i].SAPJobDetails_ID].status;
                            }
                        }
              
                for (var j = 0; j < data[i].CWAItems.length; j++) {
    
                    ProfitCenters.push(data[i].CWAItems[j].ProfitCenters);
    
                    for (var k = 0; k < data[i].CWAItems[j].CWAAttachments.length; k++) {
                        CWAAttachments.push(data[i].CWAItems[j].CWAAttachments[k]);
                    }
    
                    if (data[i].CWAItems[j].FileID) {
                        FileID.push(data[i].CWAItems[j].FileID);
                    }
    
                    if (data[i].CWAItems[j].FileFromRR === false) {
                        data[i].FileFromRR = false;
                    }
    
                    Propose_MS = Propose_MS + parseFloat(data[i].CWAItems[j].ProposedMS);
                    Current_MS = Current_MS + parseFloat(data[i].CWAItems[j].CurrentMS);
    
                    CurrentMonthShipment = CurrentMonthShipment + parseFloat(data[i].CWAItems[j].CurrentMonthShipment);
                    BalanceMonth = BalanceMonth + parseFloat(data[i].CWAItems[j].BalanceMonth);
    
                    ExcessTotalProposed = ExcessTotalProposed + parseFloat(data[i].CWAItems[j].ExcessTotalProposed);
                    ExcessTotalCurrent = ExcessTotalCurrent + parseFloat(data[i].CWAItems[j].ExcessTotalCurrent);
    
                    ObsoleteTotalProposed = ObsoleteTotalProposed + parseFloat(data[i].CWAItems[j].ObsoleteTotalProposed);
                    ObsoleteTotalCurrent = ObsoleteTotalCurrent + parseFloat(data[i].CWAItems[j].ObsoleteTotalCurrent);
    
                    MonthTM1 = MonthTM1 + parseFloat(data[i].CWAItems[j].MonthTM1);
                    ApprovedWaiver = ApprovedWaiver + parseFloat(data[i].CWAItems[j].ApprovedWaiver);
                }
    
                data[i].ProfitCenters = ProfitCenters.toString();
                data[i].CWAAttachments = CWAAttachments;
                data[i].FileID = FileID;
                data[i].CurrentMS = Current_MS;
                data[i].ProposedMS = Propose_MS;
    
                data[i].VarianceMS = Propose_MS - Current_MS;
                data[i].CurrentMonthShipment = CurrentMonthShipment;
                data[i].BalanceMonth = BalanceMonth;
                data[i].MS = CurrentMonthShipment + BalanceMonth;
    
                //MPS
                data[i].TM1M13 = MonthTM1;
                data[i].MPSAlignmentPerc3Mon = 100 * (data[i].TM1M13 / (BalanceMonth + CurrentMonthShipment));
                data[i].MPSVariance3Mon = data[i].TM1M13 - BalanceMonth - CurrentMonthShipment;
                data[i].MPSAlignmentPerc3MonIncldWaiver = 100 * ((data[i].TM1M13 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment));
                data[i].MPSVariance3MonIncldWaiver = ((data[i].TM1M13 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment));
    
                data[i].ApprovedWaiver = ApprovedWaiver;
                data[i].ExcessTotalProposed = ExcessTotalProposed;
                data[i].ExcessTotalCurrent = ExcessTotalCurrent;
                data[i].excessPercDifference = ((ExcessTotalProposed - ExcessTotalCurrent) / ExcessTotalCurrent);
                data[i].ObsoleteTotalProposed = ObsoleteTotalProposed;
                data[i].ObsoleteTotalCurrent = ObsoleteTotalCurrent;
                data[i].ObsoletePercDifference = ((ObsoleteTotalProposed - ObsoleteTotalCurrent) / ObsoleteTotalCurrent);
    
                if (data[i].CurrentApprover) {
                    data[i].CWACurrentApproval = data[i].CurrentApprover;
                }
                data[i].BUWaiverCurrentApproval = '-';
                // data[i].BUWaiverStatus = BUWaiverStatus;
                if (data[i].CurrentApproverLevel == "WCM") {
                    data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'WCM');
                } else if (data[i].CurrentApproverLevel == "BUM") {
                    data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'BUM');
                } else if (data[i].CurrentApproverLevel == "SPM") {
                    data[i].ToBeCWACurrentApproval = await RolesUtil.getAllowedUsers(data[i].Region, data[i].Site, data[i].Customer, data[i].ProfitCenters, 'CWA', 'SPM');
                }
    
                // data[i].UploadDemand = 
                data[i].CWAStatus = data[i].Status;
            }
        });
    */
    this.on('ValidateCWA', async (req) => {
        var cwaID = req.data.ID;
        //check CWA level
        var cwaRule = await DB.getCWARule(cwaID);
        var cwaApprovers = (await DB.getCWAApprovers(cwaRule[0].REGION, cwaRule[0].SITE, cwaRule[0].CUSTOMER)).CWAApprovers;

        var validationResult;
        if (!cwaRule[1]) {
            //If no customer rule found then automatically set profit center rule
            cwaRule[1] = { "PROFITCENTERRULE": true, "CUSTOMERRULE": false }
        }
        if (cwaRule[1].CUSTOMERRULE) {
            validationResult = await CWACustomerLevel.validateExistingCWA(cwaRule[0]);
        } else {
            validationResult = await CWAPCLevel.validateExistingCWA(cwaRule[0]);
        }

        return {
            "SaveAllowed": validationResult.SaveAllowed,
            "SubmitAllowed": validationResult.SubmitAllowed,
            "CWAApprovers": {
                "WCM": cwaApprovers.WCM,
                "BUM": cwaApprovers.BUM,
                "SPM": cwaApprovers.SPM,
            }
        };
    });

    this.on('DownloadDocument', async (req) => {
        let { dmsDocumentId } = req.data.dmsDocumentID;
        let destination_details = await CommonUtilities.getDestinations("DMS");
        const connJwtToken = await _fetchJwtToken(destination_details?.tokenServiceURL, destination_details?.clientId, destination_details?.clientSecret)
        let result = await _downloadFile(destination_details.URL, connJwtToken, SDM_REPOSTITOR_ID, dmsDocumentId);
        return result;
    });

    this.on('CancelCWA', async (req) => {
        //check CWA current status
        var cwa = await DB.getCWARule(req.data.ID);
        return await cds.update('CWA_REQUEST_CWAHEADER', req.data.ID)
            .set({ STATUS_ID: 6, MODIFIEDAT: new Date().toISOString(), MODIFIEDBY: req.user.id })
            .then(async function () {
                console.log("CWA Header Status changed.");
                var payload = {
                    ID: crypto.randomUUID(),
                    Parent_ID: req.data.ID,
                    WorkflowID: req.data.WFID,
                    createdAt: new Date().toISOString(),
                    createdBy: req.user.id,
                    modifiedAt: new Date().toISOString(),
                    modifiedBy: req.user.id,
                    Status: "Cancelled"
                }
                await INSERT.into("CWA_REQUEST.CWAWFHistory").entries(payload);
                console.log("WFHistory Updated");
                await common.CommonUtilities.sendCancellationMail(req.data.ID, req);
                if (cwa[0].STATUS_ID !== 1 && cwa[0].STATUS_ID !== 7) {
                    var workflowPayload = {
                        "status": "CANCELED",
                        "cascade": false
                    }
                    try {
                        const workflowService = await cds.connect.to('Workflow');
                        await workflowService.tx(req).patch('/workflow-instances/' + req.data.WFID, workflowPayload);
                        return 'CWA Cancelled Successfully';
                    } catch (error) {
                        console.log(error);
                        return 'CWA Cancelled Successfully but approval workflow cannot be terminated.';
                    }
                } else return 'CWA Cancelled Successfully';
            }, function (error) {
                console.log(error);
                return 'Technical Error in cancelling CWA.';
            });
    });

    this.on('SubmitCWA', async (req) => {
        try {
            //Simulate Demand Create from sap => comment
            var demandCreateSimulationResults = await CommonUtilities.simulateDemandCreation(req.data, req, 1);
            if (demandCreateSimulationResults.some(item => item.Type === 'E')) {
                return {
                    "SimulationResults": demandCreateSimulationResults,
                    "DisplayMessage": "Demand simulation ended in errors. Please correct your file data.",
                    "BackendError": true,
                    "BackendErrorObject": null,
                }
            }
            else if (demandCreateSimulationResults.some(item => item.constructor === Error)) {
                return {
                    "SimulationResults": demandCreateSimulationResults.filter(item => !(item instanceof Error)),
                    "DisplayMessage": "Technical Error while demand simulation.",
                    "BackendError": true,
                    "BackendErrorObject": demandCreateSimulationResults.find(item => item.constructor === Error).toString(),
                }
            }
            else {
                try {
                    //call the workflow if the demand simulation does not have any errors
                    console.log("call the workflow if the demand simulation does not have any errors");
                    const [cwaHeader] = await SELECT.from("CWA_REQUEST.CWAHeader").where({ ID: req.data.ID });
                    const cwaItem = await SELECT.from("CWA_REQUEST.CWAItem").where({ Parent_ID: req.data.ID });
                    const cwaApprover = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: req.data.ID });

                    var Propose_MS = 0, Current_MS = 0, CurrentMonthShipment = 0, BalanceMonth = 0,
                        ExcessTotalProposed = 0, ExcessTotalCurrent = 0, ObsoleteTotalProposed = 0, ObsoleteTotalCurrent = 0,
                        MonthTM1 = 0, BalanceMonth = 0, CurrentMonthShipment = 0, ApprovedWaiver = 0;

                    for (var j = 0; j < cwaItem.length; j++) {
                        Propose_MS = Propose_MS + parseFloat(cwaItem[j].PROPOSEDMS);
                        Current_MS = Current_MS + parseFloat(cwaItem[j].CURRENTMS);
                        CurrentMonthShipment = CurrentMonthShipment + parseFloat(cwaItem[j].CURRENTMONTHSHIPMENT);
                        BalanceMonth = BalanceMonth + parseFloat(cwaItem[j].BALANCEMONTH);
                        MonthTM1 = MonthTM1 + parseFloat(cwaItem[j].MONTHTM1);
                        ApprovedWaiver = ApprovedWaiver + parseFloat(cwaItem[j].APPROVEDWAIVER);
                    }
                    let profitCentersArray = cwaItem.map(item => item.PROFITCENTERS);
                    let profitCentersString = profitCentersArray.join(',');

                    let allFileFromRRTrue = cwaItem.every(item => item.FILEFROMRR === 1);
                    let allFileFromRRString = allFileFromRRTrue.toString();
                    var HeaderData = {
                        "Site": cwaHeader.SITE ? cwaHeader.SITE : "",
                        "Customer": cwaHeader.CUSTOMER ? cwaHeader.CUSTOMER : "",
                        "ProfitCenter": profitCentersString ? profitCentersString : "",
                        "Region": cwaHeader.REGION ? cwaHeader.REGION : "",
                        "Segment": cwaHeader.SEGMENT ? cwaHeader.SEGMENT : "",
                        "Division": cwaHeader.DIVISION ? cwaHeader.DIVISION : "",
                        "DataGeneratedRR": allFileFromRRString ? allFileFromRRString : ""
                    }
                    const MPSInfo = {
                        "CurrentMS": Current_MS ? Number(Current_MS).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
                        "ProposedMS": Propose_MS ? Number(Propose_MS).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
                        "CurrentMonthShipment": CurrentMonthShipment ? Number(CurrentMonthShipment).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
                        "BalanceMonth1Month3MS": BalanceMonth ? Number(BalanceMonth).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
                        "Month1Month3MS": MonthTM1 ? Number(MonthTM1).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
                        "ApproverWaiver": ApprovedWaiver ? Number(ApprovedWaiver).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
                        // "ProposedMS": Propose_MS ? Number(Propose_MS.toFixed(2)).toLocaleString() : "",
                        // "CurrentMonthShipment": CurrentMonthShipment ? Number(CurrentMonthShipment.toFixed(2)).toLocaleString() : "",
                        // "BalanceMonth1Month3MS": BalanceMonth ? Number(BalanceMonth.toFixed(2)).toLocaleString() : "",
                        // "Month1Month3MS": MonthTM1 ? Number(MonthTM1.toFixed(2)).toLocaleString() : "",
                        // "ApproverWaiver": ApprovedWaiver ? ApprovedWaiver.toLocaleString() : "",
                        // "MPSAlignment3Months": String((100 * (MonthTM1 / (BalanceMonth + CurrentMonthShipment))).toFixed(2)),
                        // "MPSVariance3Months": String((MonthTM1 - BalanceMonth - CurrentMonthShipment).toFixed(2)),
                        // "MPSAlignment3MonthsInclWaiver": String((100 * ((MonthTM1 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment))).toFixed(2)),
                        // "MPSVarianceInclWaiver": String(((MonthTM1 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment)).toFixed(2))
                        "MPSAlignment3Months": (100 * (MonthTM1 / (BalanceMonth + CurrentMonthShipment)))
                            .toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
                        "MPSVariance3Months": (MonthTM1 - BalanceMonth - CurrentMonthShipment)
                            .toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
                        "MPSAlignment3MonthsInclWaiver": (100 * ((MonthTM1 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment)))
                            .toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
                        "MPSVarianceInclWaiver": (MonthTM1 - BalanceMonth - CurrentMonthShipment + parseFloat(ApprovedWaiver))
                            .toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })

                    };

                    const CWAApprover = cwaApprover.map(record => ({
                        Name: record.APPROVERNAME,
                        Level: record.APPROVERLEVEL
                    }))
                    // Initialize GeneralEO array
                    const GeneralEO = [
                        { Name: "Excess Total STD (Jabil internal - general)", Proposed: 0, Current: 0 },
                        { Name: "Obsolete Total STD (Jabil internal - general)", Proposed: 0, Current: 0 }
                    ];

                    // Process the cwaItem array and update GeneralEO
                    cwaItem.forEach(item => {
                        GeneralEO[0].Proposed = (parseFloat(GeneralEO[0].Proposed) + parseFloat(item.EXCESSTOTALPROPOSED)).toFixed(2);
                        GeneralEO[0].Current = (parseFloat(GeneralEO[0].Current) + parseFloat(item.EXCESSTOTALCURRENT)).toFixed(2);
                        GeneralEO[1].Proposed = (parseFloat(GeneralEO[1].Proposed) + parseFloat(item.OBSOLETETOTALPROPOSED)).toFixed(2);
                        GeneralEO[1].Current = (parseFloat(GeneralEO[1].Current) + parseFloat(item.OBSOLETETOTALCURRENT)).toFixed(2);
                    });
                    GeneralEO[0].Proposed = Number(GeneralEO[0].Proposed).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                    GeneralEO[0].Current = Number(GeneralEO[0].Current).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                    GeneralEO[1].Proposed = Number(GeneralEO[1].Proposed).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                    GeneralEO[1].Current = Number(GeneralEO[1].Current).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                    const cwaAttachmentIds = [];

                    // Collect all attachment IDs and associated cwaItem IDs in one pass
                    for (const item of cwaItem) {
                        const attachments = await SELECT.from("CWA_REQUEST.CWAAttachments").where({ Parent_ID: item.ID });
                        for (const attachment of attachments) {
                            cwaAttachmentIds.push(attachment.FILEID_ID);
                        }
                    }
                    const cwaDocData = [];
                    if (cwaAttachmentIds.length > 0) {
                        // Fetch all document metadata in one go based on collected FileIDs
                        const cwaDocuments = await SELECT.from("CWA_REQUEST.DocumentMetadata").where({ ID: { in: cwaAttachmentIds } });

                        // Create a lookup for easy access to document details by FileID
                        const documentLookup = cwaDocuments.reduce((acc, doc) => {
                            acc[doc.ID] = {
                                DocName: doc.DOCUMENTNAME ? doc.DOCUMENTNAME : "",
                                DocID: doc.DMSDOCUMENTID ? doc.DMSDOCUMENTID : "",
                                DocType: doc.DOCUMENTTYPE ? doc.DOCUMENTTYPE : ""
                            };
                            return acc;
                        }, {});

                        // Process each cwaItem and build the cwaDocData array
                        // const cwaDocData = [];

                        for (const item of cwaItem) {
                            const attachments = await SELECT.from("CWA_REQUEST.CWAAttachments").where({ Parent_ID: item.ID });
                            for (const attachment of attachments) {
                                const docDetails = documentLookup[attachment.FILEID_ID];
                                if (docDetails) {
                                    cwaDocData.push(docDetails);
                                }
                            }
                        }
                    }
                    const cwaFileIds = [];

                    // Collect all attachment IDs and associated cwaItem IDs in one pass
                    for (const item of cwaItem) {
                        cwaFileIds.push(item.FILEID_ID);
                    }
                    const cwaFileDocuments = await SELECT.from("CWA_REQUEST.DocumentMetadata").where({ ID: { in: cwaFileIds } });
                    // Create a map for quick lookup of document details by ID
                    const documentMap = new Map(cwaFileDocuments.map(doc => [doc.ID, doc]));

                    // Build the fileDocArray with document details
                    const fileDocArray = cwaFileIds.map(fileId => {
                        const doc = documentMap.get(fileId);
                        return {
                            DocID: doc ? doc.DMSDOCUMENTID || "" : "",
                            DocName: doc ? doc.DOCUMENTNAME || "" : "",
                            DocType: doc ? doc.DOCUMENTTYPE || "" : ""
                        };
                    });

                    var wfPayload = {
                        "definitionId": "us10.jabilcfdev.cwarequest.cWARequestProcess",
                        "context": {
                            "cwarequestvariable": {
                                "CWARequestID": cwaHeader.CWANAME,
                                "CWAGUID": cwaHeader.ID,
                                "Counter": 0,
                                "ApprovedStatus": "Approved",
                                "RejectStatus": "Rejected",
                                "HeaderData": HeaderData,
                                "MPSInfo": MPSInfo,
                                "CWAApprover": CWAApprover,
                                "GeneralEO": GeneralEO,
                                "Documents": cwaDocData,
                                "Comments": cwaHeader.COMMENT,
                                "CWAStatus": "Pending Approval",
                                "FileDocuments": fileDocArray
                            }
                        }
                    }
                    var wfResults = await CommonUtilities.callWorkFlow(req.data, req, 1, wfPayload);
                    await DB.updateHeaderStatus(req.data.ID, 2, req.user.id);
                    var wfHistoryPayload = {
                        ID: crypto.randomUUID(),
                        Parent_ID: req.data.ID,
                        WorkflowID: wfResults.id,
                        createdAt: new Date().toISOString(),
                        createdBy: req.user.id,
                        modifiedAt: new Date().toISOString(),
                        modifiedBy: req.user.id,
                        Status: "Started",
                        Comments: "Approval Process Initiated"
                    }
                    await INSERT.into("CWA_REQUEST.CWAWFHistory").entries(wfHistoryPayload);
                    return {
                        "SimulationResults": demandCreateSimulationResults,
                        "DisplayMessage": "Demand Simulation was successful. Approval process initiated.",
                        "BackendError": false,
                        "BackendErrorObject": null,
                    }
                } catch (error) {
                    //If any error occured during Simulation, reject to FE stating errors
                    console.log(error);
                    console.log(error.message);

                    console.log("Workflow trigger failed");
                    return {
                        "SimulationResults": demandCreateSimulationResults,
                        "DisplayMessage": "Demand Simulation was successful but technical error occurred while initiating approval process.",
                        "BackendError": true,
                        "BackendErrorObject": error.toString(),
                    }
                }
            }

        } catch (error) {
            //If any error occured during Simulation, reject to FE stating errors
            console.log("Some error has occurred during Simulation");
            console.log(error);
            console.log(error.message);
            return {
                "SimulationResults": null,
                "DisplayMessage": "Technical Error while demand simulation.",
                "BackendError": true,
                "BackendErrorObject": error.toString(),
            }
        }
    });

    this.on('UploadDemand', async req => {
        //SimulationMode === true means Call the BAPI in Simulation mode
        debugger;
        try {
            //Simulate Demand Create from sap
            var demandCreateSimulationResults = await CommonUtilities.simulateDemandCreation(req.data, req, 1);
            if (demandCreateSimulationResults.some(item => item.Type === 'E')) {
                return {
                    "SimulationResults": demandCreateSimulationResults,
                    "DisplayMessage": "Demand simulation ended in errors. Please correct your file data.",
                    "BackendError": true,
                    "BackendErrorObject": null,
                }
            }
            else if (demandCreateSimulationResults.some(item => item.constructor === Error)) {
                return {
                    "SimulationResults": demandCreateSimulationResults.filter(item => !(item instanceof Error)),
                    "DisplayMessage": "Technical Error while demand simulation.",
                    "BackendError": true,
                    "BackendErrorObject": demandCreateSimulationResults.find(item => item.constructor === Error).toString(),
                }
            }
            else {
                //Add code for Actual BAPI call
                //Store Job ID in Table if no errors
                var demandCreationResults = await CommonUtilities.DemandCreation(req.data, req, 1);
                if (demandCreationResults.some(item => item.Type === 'E')) {
                    return {
                        "SimulationResults": demandCreationResults,
                        "DisplayMessage": "Demand creation ended in errors. Please correct your file data.",
                        "BackendError": true,
                        "BackendErrorObject": demandCreationResults.find(item => item.constructor === Error).toString(),
                    }
                } else {
                    //Store the Job ID in Table as there is no errors
                    try {
                        var demandCreationStatus = await DB._updateHeader(req.data.ID, demandCreationResults[0].jobname, demandCreationResults[0].status, false, 8, req.user.id);
                        return {
                            "SimulationResults": null, //demandCreationStatus,
                            "DisplayMessage": "Demand triggered to SAP",
                            "BackendError": false,
                            "BackendErrorObject": null,
                        }
                    } catch { error }
                }
            }
        }
        catch (error) {
            //If any error occured during Simulation, reject to FE stating errors
            return {
                "SimulationResults": null,
                "DisplayMessage": "Technical Error while demand simulation.",
                "BackendError": true,
                "BackendErrorObject": error.toString(),
            }
        }
    });

    this.on('GetSAPJOBIDError', async req => {
        try {
            var results = await CommonUtilities.GetSAPJOBIDErrors(req.data, req);
        } catch (error) {
            return {
                "SimulationResults": null,
                "DisplayMessage": "Technical Error occurred while fetching data, please try again later.",
                "BackendError": true,
                "BackendErrorObject": error,
            }
        }
        if (results.some(item => item.constructor === Error)) {
            return {
                "SimulationResults": results,
                "DisplayMessage": "Error occurred while fetching data, please try again later.",
                "BackendError": true,
                "BackendErrorObject": results.find(item => item.constructor === Error).toString(),
            }
        } else {
            return {
                "SimulationResults": results,
                "DisplayMessage": "Demand errors fetched successfully.",
                "BackendError": false,
                "BackendErrorObject": null
            }

        }
    });

    this.on('createDMSFolder', async req => {
        const forlderName = req.data.repoId;
        const url = process.env.dmsURL;//"https://jabilcfdev.authentication.us10.hana.ondemand.com";
        // var url = sdmCredentials.uaa.url;
        // const clientid = "sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
        // const clientSecret = "HQJVceIL92Oo9dr8RHrK4L7oP2U=";
        const clientid = process.env.clientid;//"sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
        const clientSecret = process.env.clientSecret;
        // var clientid = sdmCredentials.uaa.clientid;
        // var clientSecret = sdmCredentials.uaa.clientsecret;
        const repositoryId = "CWA_REQUEST_REPO";
        const connJwtToken = await fetchJwtToken(url, clientid, clientSecret); //Need Error Handling
        const eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
        const folderId = await createFolder(eURL, connJwtToken, repositoryId, forlderName); //Need Error Handling
        return { 'folderID': folderId };
    });
    this.on('deleteDMSDocument', async req => {
        const docId = req.data.docId;
        const forlderName = req.data.folderID;
        const url = process.env.dmsURL;//"https://jabilcfdev.authentication.us10.hana.ondemand.com";
        // var url = sdmCredentials.uaa.url;
        // const clientid = "sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
        // const clientSecret = "HQJVceIL92Oo9dr8RHrK4L7oP2U=";
        const clientid = process.env.clientid;//"sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
        const clientSecret = process.env.clientSecret;
        // var clientid = sdmCredentials.uaa.clientid;
        // var clientSecret = sdmCredentials.uaa.clientsecret;
        const repositoryId = "CWA_REQUEST_REPO";
        const connJwtToken = await fetchJwtToken(url, clientid, clientSecret); //Need Error Handling
        const eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
        const response = await deleteFile(eURL, connJwtToken, repositoryId, forlderName, docId); //Need Error Handling
        if (response.status == 200) {
            return "Sucessfully Deleted"
        } else {
            return "Error While Deleting"
        }
    });

    this.on('getApproverList', async req => {
        const requestGuid = req.data.RequestID;
        const index = req.data.Counter;
        const nextIndex = index + 1;
        var level;
        if (index == 0) {
            level = "WCM"
        } else if (index == 1) {
            level = "BUM"
        } else if (index == 2) {
            level = "SPM"
        }
        const approver = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: requestGuid });
        const approverIndex = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: requestGuid, ApproverLevel: level });
        // const Approvers = approverList.map(approver => ({
        //     Parent: approver.PARENT_ID,
        //     ApproverLevel: approver.APPROVERLEVEL,
        //     ApproverName: approver.APPROVERNAME,
        //     ApproverEmail: approver.APPROVEREMAIL
        // }));
        if (index < approver.length) {
            // start of change Sharique 25/02/2025
            // verify and use BTP cockpit email for the determined approvers
            btpCockpitEmail = await get_verified_email(approverIndex[0].APPROVEREMAIL, req);
            console.log("BTP CockpitEmail", btpCockpitEmail);
            if (btpCockpitEmail) {
                
            } else {
                btpCockpitEmail = approverIndex[0].APPROVEREMAIL;
                
            }
            console.log
            // end of change   Sharique 25/02/2025
            var Approvers = {
                "Parent": approverIndex[0].PARENT_ID,
                "ApproverLevel": approverIndex[0].APPROVERLEVEL,
                "ApproverName": approverIndex[0].APPROVERNAME,
                "ApproverEmail": btpCockpitEmail//approverIndex[0].APPROVEREMAIL
            }

            // Create the final response object
            const CWAApproverResponse = {
                totalCount: approver.length,
                indexCount: nextIndex,
                Approvers: Approvers
            };
            return CWAApproverResponse;
        } else {
            var Approvers = {
                "Parent": "02d98bf9-d14f-49f2-98af-2924a543d5aa",
                "ApproverLevel": "",
                "ApproverName": "",
                "ApproverEmail": ""
            }
            const CWAApproverResponse = {
                totalCount: approver.length,
                indexCount: nextIndex,
                Approvers: Approvers
            };
            return CWAApproverResponse;
        }

    });
    this.on('forwardWorkflow', async (req) => {
        var guid = crypto.randomUUID();
        const id = req.data.ID;
        const WFID = req.data.WFID;
        const email = req.data.EMAIL;
        const name = req.data.NAME;

        var workflowPayload = {
            "recipientUsers": email
        }
        try {
            const workflowService = await cds.connect.to('Workflow');
            const wfdetails = await workflowService.tx(req).get('/workflow-instances/' + WFID + '/execution-logs');
            const userTaskCreatedLogs = wfdetails.filter(log => log.type === "USERTASK_CREATED");
            const lastLogIndex = userTaskCreatedLogs.length - 1;
            const taskId = userTaskCreatedLogs[lastLogIndex]?.taskId;
            console.log(taskId);
            await workflowService.tx(req).patch('/task-instances/' + taskId, workflowPayload);

            const [cwaData] = await SELECT.from("CWA_REQUEST.CWAHeader").where({ ID: id });
            const CurrentApproverLevel = cwaData.CURRENTAPPROVERLEVEL;
            const [cwaApprover] = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: id, ApproverLevel: CurrentApproverLevel });
            await UPDATE.entity("CWA_REQUEST.CWAHeader").with({ CurrentApprover: name }).where({ ID: id });
            await UPDATE.entity("CWA_REQUEST.CWAApprovers").with({ ApproverEmail: email, ApproverName: name }).where({ ID: cwaApprover.ID });

            var payload = {
                ID: guid,
                Parent_ID: id,
                WorkflowID: WFID,
                ApproverEmail: email,
                ApproverLevel: cwaApprover.APPROVERLEVEL,
                ApproverName: name,
                Status: "Forwarded",
                Comments: "",
                createdAt: new Date().toISOString(),
                createdBy: req.user.id,
                modifiedAt: new Date().toISOString(),
                modifiedBy: req.user.id,
            }
            await INSERT.into("CWA_REQUEST.CWAWFHistory").entries(payload);
            //Email Functionality
            const emailData = await getEmailData(id, "Pending Approval", email, cwaApprover.APPROVERLEVEL)
            const responseMailStatus = await mailUtil.sendEmail("workflowNotification", emailData.data, emailData.from, email, emailData.subject, emailData.ccEmails, req);
            if (responseMailStatus == "Success") {
                return { "RequestID": WFID, "MSGType": "S", "MSG": "CWA Request Sucessfully Forwared" }
            } else {
                return { "RequestID": WFID, "MSGType": "E", "MSG": "Error" }
            }
            // var returnPayload = {
            //     RequestID: WFID,
            //     MSGType: "S",
            //     MSG: 'CWA Request Sucessfully Forwared'
            // };
            // return returnPayload;

        } catch (error) {
            var returnPayload = {
                RequestID: WFID,
                MSGType: "E",
                MSG: error
            };
            return returnPayload;
        }
    })
    this.on('updateWorkflow', async req => {
        var guid = crypto.randomUUID();
        var { RequestID: requestGuid, ApproverLevel: ApproverLevel, STATUS: status, ApproverName: ApproverName, ApproverEmail: ApproverEmail, Comments: Comments, BUWaiverStatus: BUWaiverStatus } = req.data;
        let statusId;
        const cwaApproversList = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: requestGuid, ApproverLevel: ApproverLevel });
        ApproverName = cwaApproversList[0].APPROVERNAME;
        ApproverEmail = cwaApproversList[0].APPROVEREMAIL;
        try {

            if (status === "Approved") {
                statusId = 2;
                var payload = {
                    ID: guid,
                    Parent_ID: requestGuid,
                    WorkflowID: req.data.WFID,
                    ApproverEmail: ApproverEmail,
                    ApproverLevel: ApproverLevel,
                    ApproverName: ApproverName,
                    Status: "Approved",
                    Comments: Comments,
                    createdAt: new Date().toISOString(),
                    createdBy: req.user.id,
                    modifiedAt: new Date().toISOString(),
                    modifiedBy: req.user.id,
                }
                await INSERT.into("CWA_REQUEST.CWAWFHistory").entries(payload);
            } else if (status === "Rejected") {
                statusId = 5;
                var payload = {
                    ID: guid,
                    Parent_ID: requestGuid,
                    WorkflowID: req.data.WFID,
                    ApproverEmail: ApproverEmail,
                    ApproverLevel: ApproverLevel,
                    ApproverName: ApproverName,
                    Status: "Rejected",
                    Comments: Comments,
                    createdAt: new Date().toISOString(),
                    createdBy: req.user.id,
                    modifiedAt: new Date().toISOString(),
                    modifiedBy: req.user.id,
                }
                await INSERT.into("CWA_REQUEST.CWAWFHistory").entries(payload);
            }
            if (statusId) {
                const cwaApprovers = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: requestGuid });
                const order = {
                    "WCM": 0,
                    "BUM": 1,
                    "SPM": 2
                };

                // Sort the array based on the APPROVERLEVEL
                const sortedApprovers = cwaApprovers.sort((a, b) => {
                    const aLevel = order[a.APPROVERLEVEL] !== undefined ? order[a.APPROVERLEVEL] : Infinity;
                    const bLevel = order[b.APPROVERLEVEL] !== undefined ? order[b.APPROVERLEVEL] : Infinity;
                    return aLevel - bLevel;
                });
                const currentIndex = sortedApprovers.findIndex(
                    approver => approver.APPROVERNAME === ApproverName && approver.APPROVERLEVEL === ApproverLevel
                );
                let currentApproverName = "";
                let currentApproverLevel = "";
                if (currentIndex !== -1) {
                    const nextApprover = sortedApprovers[currentIndex + 1];
                    if (nextApprover) {

                        currentApproverName = nextApprover.APPROVERNAME;
                        currentApproverLevel = nextApprover.APPROVERLEVEL;
                    }
                }
                const buWaiverStatus = BUWaiverStatus ? BUWaiverStatus : "";
                await UPDATE.entity("CWA_REQUEST.CWAHeader").with({ Status_ID: statusId, CurrentApprover: currentApproverName, CurrentApproverLevel: currentApproverLevel, BUWaiverStatus: buWaiverStatus }).where({ ID: requestGuid });
            }
            return { "CWARequestID": requestGuid, "MessageType": "S", "Message": "Success" }

        } catch (error) {
            return { "CWARequestID": requestGuid, "MessageType": "E", "Message": error }
        }
    });
    this.on('testMail', async (req) => {
        const service = await cds.connect.to('MicrosoftGraph_CLONING');
        try {
            await service.tx(req).post("/workflows/0dbc61c1822e467eb5e9fcc8b581b4c6/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=O_HQhZ9zXKcr_1zr_Q2o_OqTOUlUXApJKwdQsu7oFVQ");
            return "Success";
        } catch (error) {
            console.log(error)
            return "error"
        }

    });
    this.on('updateRequestFromWF', async req => {
        const { RequestID: requestGuid } = req.data;
        try {
            if (requestGuid) {
                await UPDATE.entity("CWA_REQUEST.CWAHeader").with({ Status_ID: 3 }).where({ ID: requestGuid });
            }
            return { "CWARequestID": requestGuid, "MessageType": "S", "Message": "Success" }
        } catch (error) {
            return { "CWARequestID": requestGuid, "MessageType": "E", "Message": error }
        }
    });


    this.on('triggerEmail', async (req) => {
        console.log(req.data);
        var { RequestID: requestGuid, ApproverLevel: ApproverLevel, STATUS: status, ApproverName: ApproverName, ApproverEmail: ApproverEmail, Comments: Comments } = req.data;
        // Mapping status to text
        const statusMapping = {
            "Rejected": "Rejected",
            "trigDemand": "Trigger Demand",
            "Notif": "Pending Approval"
        };
        const templateMapping = {
            "Rejected": "rejectionWorkflowNotification",
            "trigDemand": "workflowCompletion",
            "Notif": "workflowNotification"
        };
        const subjectMapping = {
            "Rejected": "Rejected ",
            "trigDemand": "Approval Complete ",
            "Notif": "CWA ACTION REQUIRED: "
        };

        const statusText = statusMapping[status] || "Unknown Status";
        const template = templateMapping[status] || "Unknown Template";
        const subjectPriefix = subjectMapping[status] || "CWA";


        // Fetching CWA data
        const [cwaData] = await SELECT.from("CWA_REQUEST.CWAHeader").where({ ID: requestGuid });
        const cwaItem = await SELECT.from("CWA_REQUEST.CWAItem").where({ Parent_ID: requestGuid });
        const subject = subjectPriefix + ApproverLevel + " Approval " + cwaData.CWANAME;
        if (status == "trigDemand") {
            ApproverEmail = cwaData.CREATEDBY;
        }
        var Propose_MS = 0, Current_MS = 0, CurrentMonthShipment = 0, BalanceMonth = 0,
            MonthTM1 = 0, BalanceMonth = 0, CurrentMonthShipment = 0, ApprovedWaiver = 0;

        for (var j = 0; j < cwaItem.length; j++) {
            Propose_MS = Propose_MS + parseFloat(cwaItem[j].PROPOSEDMS);
            Current_MS = Current_MS + parseFloat(cwaItem[j].CURRENTMS);
            CurrentMonthShipment = CurrentMonthShipment + parseFloat(cwaItem[j].CURRENTMONTHSHIPMENT);
            BalanceMonth = BalanceMonth + parseFloat(cwaItem[j].BALANCEMONTH);
            MonthTM1 = MonthTM1 + parseFloat(cwaItem[j].MONTHTM1);
            ApprovedWaiver = ApprovedWaiver + parseFloat(cwaItem[j].APPROVEDWAIVER);
        }
        let profitCentersArray = cwaItem.map(item => item.PROFITCENTERS);
        let profitCentersString = profitCentersArray.join(',');
        // Fetch data from the database
        const cwaApproverHistory = await SELECT.from("CWA_REQUEST.CWAWFHistory").where({ Parent_ID: requestGuid });
        const cwaApprover = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: requestGuid });

        // Initialize variables for approvers, statuses, and comments
        let approver1 = "", status1 = "", comment1 = "";
        let approver2 = "", status2 = "", comment2 = "";
        let approver3 = "", status3 = "", comment3 = "";

        // Iterate over cwaApprover to set the approvers
        cwaApprover.forEach(entry => {
            switch (entry.APPROVERLEVEL) {
                case "WCM":
                    approver1 = entry.APPROVERNAME || "";
                    status1 = entry.STATUS || "Pending Approval";
                    comment1 = entry.COMMENTS || "No Comments";
                    break;
                case "BUM":
                    approver2 = entry.APPROVERNAME || "";
                    status2 = entry.STATUS || "Pending Approval";
                    comment2 = entry.COMMENTS || "No Comments";
                    break;
                case "SPM":
                    approver3 = entry.APPROVERNAME || "";
                    status3 = entry.STATUS || "Pending Approval";
                    comment3 = entry.COMMENTS || "No Comments";
                    break;
                default:
                    break;
            }
        });

        // Iterate over cwaApproverHistory to set statuses and comments
        cwaApproverHistory.forEach(entry => {
            switch (entry.APPROVERLEVEL) {
                case "WCM":
                    approver1 = entry.APPROVERNAME || approver1; // Keep existing value if not set
                    status1 = entry.STATUS || status1 || "Pending Approval";
                    comment1 = entry.COMMENTS || comment1 || "No Comments";
                    break;
                case "BUM":
                    approver2 = entry.APPROVERNAME || approver2; // Keep existing value if not set
                    status2 = entry.STATUS || status2 || "Pending Approval";
                    comment2 = entry.COMMENTS || comment2 || "No Comments";
                    break;
                case "SPM":
                    approver3 = entry.APPROVERNAME || approver3; // Keep existing value if not set
                    status3 = entry.STATUS || status3 || "Pending Approval";
                    comment3 = entry.COMMENTS || comment3 || "No Comments";
                    break;
                default:
                    break;
            }
        });
        // Fetching level data
        const level = await SELECT.from("CWA_REQUEST.EmailNotify").where({ Status: statusText, Type: "CWA" });
        let ccEmails = '';
        ccEmails = cwaData.CREATEDBY;
        let approverEmails = [];
        if (status === "Rejected") {

            if (ApproverLevel === "BUM") {
                // Get the email for WCM
                approverEmails = cwaApprover
                    .filter(approver => approver.APPROVERLEVEL === "WCM")
                    .map(approver => approver.APPROVEREMAIL);
            } else if (ApproverLevel === "SPM") {
                // Get emails for BUM and WCM
                approverEmails = cwaApprover
                    .filter(approver => approver.APPROVERLEVEL === "BUM" || approver.APPROVERLEVEL === "WCM")
                    .map(approver => approver.APPROVEREMAIL);
            }

            // Append approver emails to ccEmails
            if (approverEmails.length > 0) {
                ccEmails += `, ${approverEmails.join(', ')}`;
            }
        }

        if (level?.length) {
            // Split and trim email addresses
            const emailAddresses = level[0].EMAILNOTIFY.split(',').map(email => email.trim());

            // Create promises for each email address
            const promises = emailAddresses.map(email =>
                RolesUtil.getAllowedUsers(cwaData.REGION, cwaData.SITE, cwaData.CUSTOMER, null, 'CWA', email)
            );

            // Wait for all promises to resolve and extract emails
            const allUsers = (await Promise.all(promises)).flat();
            const newEmails = allUsers.map(user => user.Email).join(', ');

            // Append new emails to ccEmails, ensuring it doesn't overwrite
            if (ccEmails) {
                ccEmails += `, ${newEmails}`;
            } else {
                ccEmails = newEmails;
            }
        }

        const apiUrl = process.env.apiUrl;
        // var url = apiUrl + "#cwa-RequestCreate?CWAName=" + cwaData.CWANAME;
        var url = apiUrl + "#cwadashboard-manage?CWAName=" + cwaData.CWANAME;
        var inBoxUrl = apiUrl + "#WorkflowTask-DisplayMyInbox?sap-ui-app-id-hint=saas_approuter_com.sap.spa.inbox"
        // const subject = "CWA ACTION REQUIRED: " + ApproverLevel + " Approval " + cwaData.CWANAME;
        const from = process.env.FromEmail || "cwa_waiver_dev@jabil.com";
        const data = {
            approverName: ApproverName,
            cwaNumber: cwaData.CWANAME,
            customer: cwaData.CUSTOMER,
            site: cwaData.SITE,
            region: cwaData.REGION,
            segment: cwaData.SEGMENT,
            profitCenter: profitCentersString,
            CurrentMS: Current_MS ? Number(Current_MS).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
            ProposedMS: Propose_MS ? Number(Propose_MS).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
            ApprovedWaiver: ApprovedWaiver ? Number(ApprovedWaiver).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
            MPSAlignment: (100 * (MonthTM1 / (BalanceMonth + CurrentMonthShipment))).toFixed(2).toLocaleString(),
            MPSAlignment3MonthIncWaiver: (100 * ((MonthTM1 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment))).toFixed(2).toLocaleString(),
            Approver1: approver1,
            Status1: status1,
            comment1: comment1,
            Approver2: approver2,
            Status2: status2,
            comment2: comment2,
            Approver3: approver3,
            Status3: status3,
            comment3: comment3,
            comment: cwaData.COMMENT,
            approvalRejectLink: url,
            inBoxUrl: inBoxUrl,
            serviceNowLink: "https://jabilit.service-now.com/sp",
            level: ApproverLevel
        };
        //get Template
        // const templateName = template; // Template file name (without extension)
        // const template = await getTemplate(templateName);
        const responseMailStatus = await mailUtil.sendEmail(template, data, from, ApproverEmail, subject, ccEmails, req);
        if (responseMailStatus == "Success") {
            return { "CWARequestID": requestGuid, "MessageType": "S", "Message": "Success" }
        } else {
            return { "CWARequestID": requestGuid, "MessageType": "E", "Message": "Error" }
        }

    });


}

async function getEmailData(requestGuid, statusText, ApproverName, APPROVERLEVEL) {

    // Fetching CWA data
    const [cwaData] = await SELECT.from("CWA_REQUEST.CWAHeader").where({ ID: requestGuid });
    const cwaItem = await SELECT.from("CWA_REQUEST.CWAItem").where({ Parent_ID: requestGuid });
    var Propose_MS = 0, Current_MS = 0, CurrentMonthShipment = 0, BalanceMonth = 0,
        MonthTM1 = 0, BalanceMonth = 0, CurrentMonthShipment = 0, ApprovedWaiver = 0;

    for (var j = 0; j < cwaItem.length; j++) {
        Propose_MS = Propose_MS + parseFloat(cwaItem[j].PROPOSEDMS);
        Current_MS = Current_MS + parseFloat(cwaItem[j].CURRENTMS);
        CurrentMonthShipment = CurrentMonthShipment + parseFloat(cwaItem[j].CURRENTMONTHSHIPMENT);
        BalanceMonth = BalanceMonth + parseFloat(cwaItem[j].BALANCEMONTH);
        MonthTM1 = MonthTM1 + parseFloat(cwaItem[j].MONTHTM1);
        ApprovedWaiver = ApprovedWaiver + parseFloat(cwaItem[j].APPROVEDWAIVER);
    }
    let profitCentersArray = cwaItem.map(item => item.PROFITCENTERS);
    let profitCentersString = profitCentersArray.join(',');
    // Fetch data from the database
    const cwaApproverHistory = await SELECT.from("CWA_REQUEST.CWAWFHistory").where({ Parent_ID: requestGuid });
    const cwaApprover = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: requestGuid });

    // Initialize variables for approvers, statuses, and comments
    let approver1 = "", status1 = "", comment1 = "";
    let approver2 = "", status2 = "", comment2 = "";
    let approver3 = "", status3 = "", comment3 = "";

    // Iterate over cwaApprover to set the approvers
    cwaApprover.forEach(entry => {
        switch (entry.APPROVERLEVEL) {
            case "WCM":
                approver1 = entry.APPROVERNAME || "";
                status1 = entry.STATUS || "Pending Approval";
                comment1 = entry.COMMENTS || "No Comments";
                break;
            case "BUM":
                approver2 = entry.APPROVERNAME || "";
                status2 = entry.STATUS || "Pending Approval";
                comment2 = entry.COMMENTS || "No Comments";
                break;
            case "SPM":
                approver3 = entry.APPROVERNAME || "";
                status3 = entry.STATUS || "Pending Approval";
                comment3 = entry.COMMENTS || "No Comments";
                break;
            default:
                break;
        }
    });

    // Iterate over cwaApproverHistory to set statuses and comments
    cwaApproverHistory.forEach(entry => {
        switch (entry.APPROVERLEVEL) {
            case "WCM":
                approver1 = entry.APPROVERNAME || approver1; // Keep existing value if not set
                status1 = entry.STATUS || status1 || "Pending Approval";
                comment1 = entry.COMMENTS || comment1 || "No Comments";
                break;
            case "BUM":
                approver2 = entry.APPROVERNAME || approver2; // Keep existing value if not set
                status2 = entry.STATUS || status2 || "Pending Approval";
                comment2 = entry.COMMENTS || comment2 || "No Comments";
                break;
            case "SPM":
                approver3 = entry.APPROVERNAME || approver3; // Keep existing value if not set
                status3 = entry.STATUS || status3 || "Pending Approval";
                comment3 = entry.COMMENTS || comment3 || "No Comments";
                break;
            default:
                break;
        }
    });
    // Fetching level data
    const level = await SELECT.from("CWA_REQUEST.EmailNotify").where({ Status: statusText, Type: "CWA" });
    let ccEmails = '';
    ccEmails = cwaData.CREATEDBY;

    if (level?.length) {
        // Split and trim email addresses
        const emailAddresses = level[0].EMAILNOTIFY.split(',').map(email => email.trim());

        // Create promises for each email address
        const promises = emailAddresses.map(email =>
            RolesUtil.getAllowedUsers(cwaData.REGION, cwaData.SITE, cwaData.CUSTOMER, null, 'CWA', email)
        );

        // Wait for all promises to resolve and extract emails
        const allUsers = (await Promise.all(promises)).flat();
        const newEmails = allUsers.map(user => user.Email).join(', ');

        // Append new emails to ccEmails, ensuring it doesn't overwrite
        if (ccEmails) {
            ccEmails += `, ${newEmails}`;
        } else {
            ccEmails = newEmails;
        }
    }

    const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site?siteId=24a954a1-987b-464e-80ae-efd3687823c8";
    var url = apiUrl + "#cwadashboard-manage?CWAName=" + cwaData.CWANAME;
    var inBoxUrl = apiUrl + "#WorkflowTask-DisplayMyInbox?sap-ui-app-id-hint=saas_approuter_com.sap.spa.inbox"
    const subject = "CWA ACTION REQUIRED: " + APPROVERLEVEL + " Approval " + cwaData.CWANAME;
    const from = process.env.FromEmail || "cwa_waiver_dev@jabil.com";
    const data = {
        approverName: ApproverName,
        cwaNumber: cwaData.CWANAME,
        customer: cwaData.CUSTOMER,
        site: cwaData.SITE,
        region: cwaData.REGION,
        segment: cwaData.SEGMENT,
        profitCenter: profitCentersString,
        CurrentMS: Current_MS ? Number(Current_MS).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
        ProposedMS: Propose_MS ? Number(Propose_MS).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
        ApprovedWaiver: ApprovedWaiver ? Number(ApprovedWaiver).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0.00",
        MPSAlignment: (100 * (MonthTM1 / (BalanceMonth + CurrentMonthShipment))).toFixed(2).toLocaleString(),
        MPSAlignment3MonthIncWaiver: (100 * ((MonthTM1 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment))).toFixed(2).toLocaleString(),
        Approver1: approver1,
        Status1: status1,
        comment1: comment1,
        Approver2: approver2,
        Status2: status2,
        comment2: comment2,
        Approver3: approver3,
        Status3: status3,
        comment3: comment3,
        comment: cwaData.COMMENT,
        approvalRejectLink: url,
        inBoxUrl: inBoxUrl,
        serviceNowLink: "https://jabilit.service-now.com/sp"
    };
    const returnPayload = {
        data: data,
        subject: subject,
        from: from,
        ccEmails: ccEmails
    }
    return returnPayload;
}
async function getTemplate(templateName) {
    const templatePath = path.resolve(__dirname, './templates', `${templateName}.html`);
    return new Promise((resolve, reject) => {
        fs.readFile(templatePath, 'utf8', (err, data) => {
            if (err) return reject(err);
            resolve(data);
        });
    });
}
const createDMSFolder = async function (repoId) {
    const folderName = repoId;
    const url = process.env.dmsURL;//https://jabilcfdev.authentication.us10.hana.ondemand.com";
    // var url = sdmCredentials.uaa.url;
    // const clientid = "sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
    // const clientSecret = "HQJVceIL92Oo9dr8RHrK4L7oP2U=";
    const clientid = process.env.clientid;//"sb-8d98e1b1-f2d8-4410-a599-11d9d3a6db24!b22715|sdm-di-DocumentManagement-sdm_integration!b6332";
    const clientSecret = process.env.clientSecret;
    // var clientid = sdmCredentials.uaa.clientid;
    // var clientSecret = sdmCredentials.uaa.clientsecret;
    console.log("Client ID: " + clientid);
    console.log("Client Secret: " + clientSecret);
    console.log("URL: " + url);
    const repositoryId = "CWA_REQUEST_REPO";
    const connJwtToken = await fetchJwtToken(url, clientid, clientSecret);
    const eURL = "https://api-sdm-di.cfapps.us10.hana.ondemand.com";
    const folderId = await createFolder(eURL, connJwtToken, repositoryId, folderName);
    console.log("Folder ID Created: " + folderId);
    return { 'folderID': folderId };
}
const fetchJwtToken = async function (oauthUrl, oauthClient, oauthSecret) {
    // This is to get the oauth token , which is used to create the folder ID
    const tokenUrl = oauthUrl + '/oauth/token?grant_type=client_credentials&response_type=token'
    const config = {
        headers: {
            Authorization: "Basic " + Buffer.from(oauthClient + ':' + oauthSecret).toString("base64")
        }
    };
    let token = await axios.get(tokenUrl, config)
        .then(response => {
            return response.data.access_token;
        })
        .catch(error => {
            return error;
        });

    return token;

}

// This is to create a folder in the repository for every new book that is getting created.
// So basically we create a new folder for every book id and user can add their respective attachments in that folder.
const createFolder = async function (sdmUrl, jwtToken, repositoryId, forlderName) {
    const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root"
    const formData = new FormData();
    // formData.append("objectId", repositoryId);
    formData.append("cmisaction", "createFolder");
    formData.append("propertyId[0]", "cmis:name");
    formData.append("propertyValue[0]", forlderName);
    formData.append("propertyId[1]", "cmis:objectTypeId");
    formData.append("propertyValue[1]", "cmis:folder");
    formData.append("succinct", 'true');


    let headers = formData.getHeaders();
    headers["Authorization"] = "Bearer " + jwtToken;

    const config = {
        headers: headers
    };

    let folderID = await axios.post(folderCreateURL, formData, config)
        .then(response => {
            console.log(" axios create folder id Successfull ");
            console.log(response.data);
            return response.data.succinctProperties["cmis:objectId"];
        })
        .catch(error => {
            console.log("Error occurred while axios create folder id: ");
            console.log(error);
            return error;
        });

    return folderID;

}

const deleteFile = async function (sdmUrl, jwtToken, repositoryId, forlderName, docId) {
    const folderCreateURL = sdmUrl + "/browser/" + repositoryId + "/root/" + forlderName
    const formData = new FormData();
    // formData.append("objectId", repositoryId);
    formData.append("cmisaction", "delete");
    formData.append("objectId", docId);


    let headers = formData.getHeaders();
    headers["Authorization"] = "Bearer " + jwtToken;

    const config = {
        headers: headers
    };

    let response = await axios.post(folderCreateURL, formData, config)
        .then(response => {
            return response;
        })
        .catch(error => {
            return error;
        });

    return response;

}

function getUniqueUsers(originalArray) {
    const uniqueSet = new Set();
    const uniqueArray = [];

    originalArray.forEach(item => {
        const identifier = `${item.User}:${item.Email}`; // Create a unique identifier
        if (!uniqueSet.has(identifier)) {
            uniqueSet.add(identifier);
            uniqueArray.push(item);
        }
    });

    return uniqueArray;
}

async function get_verified_email(approverEmail, req) {
    const xsuaa = await cds.connect.to("xsuaa");
    const userFilterUrl = `/Users?filter=email eq '${approverEmail}'`;
    const response = await xsuaa.tx(req).get(userFilterUrl);

    // Check if the user already exists
    if (response.resources.length > 0) {
        // Loop through the resources to find the matching origin
        const userWithMatchingOrigin = response.resources.find(user =>
            user.origin.includes("okta")
        );

        if (userWithMatchingOrigin) {
            return userWithMatchingOrigin.emails[0].value;
            // return userWithMatchingOrigin.id; // Return the ID if found
        }
    }
}

async function sendEmail(cwaHeader, status, req) {
    if (status == '7') { //demand error
        var mailReceiverRoles = await SELECT.from("CWA_REQUEST.EmailNotify").where({ Status: "Demand Error" }).and({ Type: "CWA" }).columns('EmailNotify');
    } else {
        mailReceiverRoles = await SELECT.from("CWA_REQUEST.EmailNotify").where({ Status: "Closed" }).and({ Type: "CWA" }).columns('EmailNotify');
    }


    var mailReceivers = [];
    if (mailReceiverRoles.length !== 0)
        mailReceiverRoles = mailReceiverRoles[0].EmailNotify.split(",").map(s => s.trim());
    for (let index = 0; index < mailReceiverRoles.length; index++) {
        const element = mailReceiverRoles[index];
        switch (element) {
            case 'Global Admin':
                let receivers = await RolesUtil.getAllowedUsers(null, null, null, null, 'CWA', element);
                mailReceivers.push(...receivers);
                break;
            case 'Regional Admin':
                mailReceivers.push(...(await RolesUtil.getAllowedUsers(cwaHeader.Region, null, null, null, 'CWA', element)));
                break;
            case 'Site Admin':
                mailReceivers.push(...(await RolesUtil.getAllowedUsers(null, cwaHeader.Site, null, null, 'CWA', element)));
                break;
            default:
                let receivers1 = await RolesUtil.getAllowedUsers(null, null, null, null, 'CWA', element);
                mailReceivers.push(...receivers1);
                break;
        }
    }

    var from = process.env.FromEmail || "cwa_waiver_dev@jabil.com";
    var to = cwaHeader.createdBy;


    const apiUrl = process.env.apiUrl || "https://jabilcfdev.launchpad.cfapps.us10.hana.ondemand.com/site?siteId=24a954a1-987b-464e-80ae-efd3687823c8";
    if (status == '7') {
        var mailData = {
            "plannerEmail": cwaHeader.createdBy,
            "cwaName": cwaHeader.CWAName,
            "cwaDBUrl": apiUrl + "#cwadashboard-manage?CWAName=" + cwaHeader.CWAName
        };
        var subject = "Demand Error " + cwaHeader.CWAName;
        var responseMailStatus = await mailUtility.sendEmail("demandError", mailData, from, to, subject, getUniqueUsers(mailReceivers).map(user => user.Email).join(', '), req);
    } else {
        // Fetching CWA data
        const [cwaData] = await SELECT.from("CWA_REQUEST.CWAHeader").where({ ID: cwaHeader.ID });
        const cwaItem = await SELECT.from("CWA_REQUEST.CWAItem").where({ Parent_ID: cwaHeader.ID });
        var Propose_MS = 0, Current_MS = 0, CurrentMonthShipment = 0, BalanceMonth = 0,
            MonthTM1 = 0, BalanceMonth = 0, CurrentMonthShipment = 0, ApprovedWaiver = 0;

        for (var j = 0; j < cwaItem.length; j++) {
            Propose_MS = Propose_MS + parseFloat(cwaItem[j].PROPOSEDMS);
            Current_MS = Current_MS + parseFloat(cwaItem[j].CURRENTMS);
            CurrentMonthShipment = CurrentMonthShipment + parseFloat(cwaItem[j].CURRENTMONTHSHIPMENT);
            BalanceMonth = BalanceMonth + parseFloat(cwaItem[j].BALANCEMONTH);
            MonthTM1 = MonthTM1 + parseFloat(cwaItem[j].MONTHTM1);
            ApprovedWaiver = ApprovedWaiver + parseFloat(cwaItem[j].APPROVEDWAIVER);
        }
        let profitCentersArray = cwaItem.map(item => item.PROFITCENTERS);
        let profitCentersString = profitCentersArray.join(',');

        // Fetch data from the database
        const cwaApproverHistory = await SELECT.from("CWA_REQUEST.CWAWFHistory").where({ Parent_ID: cwaHeader.ID });
        const cwaApprover = await SELECT.from("CWA_REQUEST.CWAApprovers").where({ Parent_ID: cwaHeader.ID });

        // Initialize variables for approvers, statuses, and comments
        let approver1 = "", status1 = "", comment1 = "";
        let approver2 = "", status2 = "", comment2 = "";
        let approver3 = "", status3 = "", comment3 = "";

        // Iterate over cwaApprover to set the approvers
        cwaApprover.forEach(entry => {
            switch (entry.APPROVERLEVEL) {
                case "WCM":
                    approver1 = entry.APPROVERNAME || "";
                    status1 = entry.STATUS || "Pending Approval";
                    comment1 = entry.COMMENTS || "No Comments";
                    break;
                case "BUM":
                    approver2 = entry.APPROVERNAME || "";
                    status2 = entry.STATUS || "Pending Approval";
                    comment2 = entry.COMMENTS || "No Comments";
                    break;
                case "SPM":
                    approver3 = entry.APPROVERNAME || "";
                    status3 = entry.STATUS || "Pending Approval";
                    comment3 = entry.COMMENTS || "No Comments";
                    break;
                default:
                    break;
            }
        });

        // Iterate over cwaApproverHistory to set statuses and comments
        cwaApproverHistory.forEach(entry => {
            switch (entry.APPROVERLEVEL) {
                case "WCM":
                    approver1 = entry.APPROVERNAME || approver1; // Keep existing value if not set
                    status1 = entry.STATUS || status1 || "Pending Approval";
                    comment1 = entry.COMMENTS || comment1 || "No Comments";
                    break;
                case "BUM":
                    approver2 = entry.APPROVERNAME || approver2; // Keep existing value if not set
                    status2 = entry.STATUS || status2 || "Pending Approval";
                    comment2 = entry.COMMENTS || comment2 || "No Comments";
                    break;
                case "SPM":
                    approver3 = entry.APPROVERNAME || approver3; // Keep existing value if not set
                    status3 = entry.STATUS || status3 || "Pending Approval";
                    comment3 = entry.COMMENTS || comment3 || "No Comments";
                    break;
                default:
                    break;
            }
        });

        const mailData = {
            cwaNumber: cwaData.CWANAME,
            customer: cwaData.CUSTOMER,
            site: cwaData.SITE,
            region: cwaData.REGION,
            segment: cwaData.SEGMENT,
            division: cwaData.DIVISION,
            profitCenter: profitCentersString,
            CurrentMS: String(Current_MS),
            ProposedMS: String(Propose_MS),
            ApprovedWaiver: String(ApprovedWaiver),
            MPSAlignment: String((100 * (MonthTM1 / (BalanceMonth + CurrentMonthShipment))).toFixed(2)),
            MPSAlignment3MonthIncWaiver: String((100 * ((MonthTM1 + ApprovedWaiver) / (BalanceMonth + CurrentMonthShipment))).toFixed(2)),
            Approver1: approver1,
            Status1: status1,
            comment1: comment1,
            Approver2: approver2,
            Status2: status2,
            comment2: comment2,
            Approver3: approver3,
            Status3: status3,
            comment3: comment3,
            comment: cwaData.COMMENT,
            cwaDBUrl: apiUrl + "#cwadashboard-manage?CWAName=" + cwaData.CWANAME
        };

        //abhishek
        subject = "Closed " + cwaHeader.CWAName;
        responseMailStatus = await mailUtility.sendEmail("CWAClosed", mailData, from, to, subject, getUniqueUsers(mailReceivers).map(user => user.Email).join(', '), req);
    }

    console.log(responseMailStatus);
    if (responseMailStatus == "Success") {
        console.log("Email sending successful");
        return { "Success": true }
    } else {
        console.log("Email sending failed");
        return { "Success": false }
    }
}






