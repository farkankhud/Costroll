sap.ui.define(
  [
      "sap/ui/core/UIComponent",
      "sap/ui/Device",
      "com/jabil/workflowuimodule/model/models",
      "sap/m/MessageBox",
      "sap/ui/model/json/JSONModel",
      "sap/m/Dialog",
      "sap/m/Button",
      "sap/m/Label",
      "sap/m/library",
      "sap/m/MessageToast",
      "sap/m/Text",
      "sap/m/TextArea",
      "sap/ui/core/Element",
      "sap/m/ComboBox",
      "sap/ui/core/Item",
      
  ],
  function (UIComponent, Device, models, MessageBox, JSONModel, Dialog, Button, Label, mobileLibrary, MessageToast, Text, TextArea, Element,ComboBox,Item) {
      "use strict";
      var ButtonType = mobileLibrary.ButtonType;

      // shortcut for sap.m.DialogType
      var DialogType = mobileLibrary.DialogType;
      return UIComponent.extend(
          "com.jabil.workflowuimodule.Component",
          {
              metadata: {
                  manifest: "json",
              },

              /**
              * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
              * @public
              * @override
              */
              init: async function () {
                  // call the base component's init function
                  UIComponent.prototype.init.apply(this, arguments);

                  // enable routing
                  this.getRouter().initialize();

                  // set the device model
                  this.setModel(models.createDeviceModel(), "device");

                  this.setTaskModels();

                  var rejectionReason = await this.getRejectionReason();
                  var oModel = new JSONModel(rejectionReason); // Properly creating a JSON model
                  // this.setModel(oModel, "rejectionReasons");
                  sap.ui.getCore().setModel(oModel, "rejectionReasons1");

                  const rejectOutcomeId = "reject";
                  this.getInboxAPI().addAction(
                      {
                          action: rejectOutcomeId,
                          label: "Reject",
                          type: "reject",
                      },
                      function () {
                          const level = this.getModel("context").getProperty("/ApproverLevel");
                          
                          var selected = this.getModel("context").getProperty("/selectedRB");
                          if (level === "BUM" && (selected === null || selected === undefined)) {
                              MessageBox.error("Please choose Mandatory Action for Radio Buttons");
                              return;
                          }
                          if (selected == 0 || selected == 1) {
                              MessageBox.information("Cant be rejected as Trigger BU Waiver or Adjust TM1 is selected");
                              return;
                          }
                          this.onSubmitDialogPress(true, rejectOutcomeId);
                          // this.completeTask(false, rejectOutcomeId);
                      },
                      this
                  );
                  const approveOutcomeId = "approve";
                  this.getInboxAPI().addAction(
                      {
                          action: approveOutcomeId,
                          label: "Approve",
                          type: "accept",
                          id: "idTest"
                      },
                      function () {
                          const level = this.getModel("context").getProperty("/ApproverLevel");

                          var selected = this.getModel("context").getProperty("/selectedRB");
                          if (level === "BUM" && (selected === null || selected === undefined)) {
                              MessageBox.error("Please choose Mandatory Action for Radio Buttons");
                              return;
                          }
                          if (selected == 2) {
                              MessageBox.information("Cant be Approved as Adjust MPS is Selected");
                              return;
                          }
                          this.onSubmitDialogApprovedPress(true, approveOutcomeId);
                          // this.completeTask(true, approveOutcomeId);
                      },
                      this
                  );
              },
              onSubmitDialogPress: function (approvalStatus, outcomeId) {
                  if (!this.oSubmitDialog) {
                      this.oSubmitDialog = new Dialog({
                          type: DialogType.Message,
                          title: "Reject",
                          content: [
                              new Label({
                                  text: "Rejection Reason",
                                  labelFor: "rejectionReason"
                              }),
                              new ComboBox("rejectionReason", {
                                  width: "100%",
                                  items: {
                                      path: "rejectionReasons1>/",
                                      template: new Item({
                                          key: "{rejectionReasons1>Description}",
                                          text: "{rejectionReasons1>Description}"
                                      })
                                  },
                                  change: function () {
                                      this._updateSubmitButtonState();
                                  }.bind(this)
                              }),
                              new Label({
                                  text: "Do you want to Reject this #CWA Request?",
                                  labelFor: "submissionNote"
                              }),
                              new TextArea("submissionNote", {
                                  width: "100%",
                                  placeholder: "Add rejection note (optional)",
                                  liveChange: function (oEvent) {
                                      this._updateSubmitButtonState();
                                      // var sText = oEvent.getParameter("value");
                                      // this.oSubmitDialog.getBeginButton().setEnabled(sText.length > 0);
                                  }.bind(this)
                              })
                              
                          ],
                          beginButton: new Button({
                              type: ButtonType.Emphasized,
                              text: "Reject",
                              enabled: false,
                              press: function () {
                                  var sText = Element.getElementById("submissionNote").getValue();
                                  var sReason = Element.getElementById("rejectionReason").getSelectedKey()
                                  var reason = "Rejection Reason: " + sReason + "Comments: " + sText; 
                                  this.getModel("context").setProperty("/comment", reason);
                                  this.oSubmitDialog.close();
                                  this.onCloseRejectDialog();
                                  this.completeTask(approvalStatus, outcomeId);
                              }.bind(this)
                          }),
                          endButton: new Button({
                              text: "Cancel",
                              press: function () {
                                  this.oSubmitDialog.close();
                                  this.onCloseRejectDialog()
                              }.bind(this)
                          })
                      });
                  }

                  this.oSubmitDialog.open();
              },
              onSubmitDialogApprovedPress: function (approvalStatus, outcomeId) {
                  if (!this.oSubmitApproveDialog) {
                      this.oSubmitApproveDialog = new Dialog({
                          type: DialogType.Message,
                          title: "Approve",
                          content: [
                              new Label({
                                  text: "Do you want to Approve this #CWA Request?",
                                  labelFor: "submissionNoteApproved"
                              }),
                              new TextArea("submissionNoteApproved", {
                                  width: "100%",
                                  placeholder: "Add Approval note (optional)",
                                  liveChange: function (oEvent) {
                                      var sText = oEvent.getParameter("value");
                                      // this.oSubmitApproveDialog.getBeginButton().setEnabled(sText.length > 0);
                                  }.bind(this)
                              })
                          ],
                          beginButton: new Button({
                              type: ButtonType.Emphasized,
                              text: "Approve",
                              enabled: true,
                              press: function () {
                                  var sText = Element.getElementById("submissionNoteApproved").getValue();
                                  this.getModel("context").setProperty("/comment", sText);
                                  this.oSubmitApproveDialog.close();
                                  this.onCloseApprovedDialog();
                                  this.completeTask(approvalStatus, outcomeId);
                              }.bind(this)
                          }),
                          endButton: new Button({
                              text: "Cancel",
                              press: function () {
                                  this.oSubmitApproveDialog.close();
                                  this.onCloseApprovedDialog();
                              }.bind(this)
                          })
                      });
                  }

                  this.oSubmitApproveDialog.open();
                  //this.onCloseApprovedDialog();
              },
              _updateSubmitButtonState: function () {
                  var sText = sap.ui.getCore().byId("submissionNote").getValue();
                  var sReason = sap.ui.getCore().byId("rejectionReason").getSelectedKey();
                  var bIsEnabled = sReason.length > 0;
                  this.oSubmitDialog.getBeginButton().setEnabled(bIsEnabled);
              },
              onCloseApprovedDialog: function () {
                  this.oSubmitApproveDialog.destroy();
              },
              onCloseRejectDialog: function () {
                  this.oSubmitDialog.destroy();
              },
              setTaskModels: function () {
                  // set the task model
                  var startupParameters = this.getComponentData().startupParameters;
                  this.setModel(startupParameters.taskModel, "task");

                  // set the task context model
                  var taskContextModel = new sap.ui.model.json.JSONModel(
                      this._getTaskInstancesBaseURL() + "/context"
                  );
                  this.setModel(taskContextModel, "context");
                  const context = this.getModel("context").getData();
                  console.log(context);
                  //   this.getView().setModel(oModel, "CWACreateRequestModel");
              },
              getRequestDetails: function (reqId) {
                  return new Promise((resolve, reject) => {
                      var urlCap = $.sap.getModulePath("com.jabil.workflowuimodule") + "/v2/service/CWARequest/Dashboard?$filter=CWAName eq '" + reqId + "'&$expand=Status,CWAItems($expand=FileID,CWAAttachments($expand=FileID)),CWAApprovers,CWAWFHistory";

                      $.ajax({
                          url: urlCap,
                          type: 'GET',
                          contentType: 'application/json',
                          success: function (oData) {
                              console.log(oData);
                              resolve(oData.d.results);
                          },
                          error: function (oError) {
                              reject(oError);
                          }
                      });
                  });
              },
              getRejectionReason: function(reqId) {
                  return new Promise((resolve, reject) => {
                      var urlCap = $.sap.getModulePath("com.jabil.workflowuimodule") + "/v2/odata/v4/cwamaintenance/RejectionReason";
                      
                      $.ajax({
                          url: urlCap,
                          type: 'GET',
                          contentType: 'application/json',
                          success: function(oData) {
                            console.log(oData);
                              resolve(oData.d.results);
                          },
                          error: function(oError) {
                              reject(oError);
                          }
                      });
                  });
                },
              _getTaskInstancesBaseURL: function () {
                  return (
                      this._getWorkflowRuntimeBaseURL() +
                      "/task-instances/" +
                      this.getTaskInstanceID()
                  );
              },

              _getWorkflowRuntimeBaseURL: function () {
                  var ui5CloudService = this.getManifestEntry("/sap.cloud/service").replaceAll(".", "");
                  var ui5ApplicationName = this.getManifestEntry("/sap.app/id").replaceAll(".", "");
                  var appPath = `${ui5CloudService}.${ui5ApplicationName}`;
                  return `/${appPath}/api/public/workflow/rest/v1`

              },

              getTaskInstanceID: function () {
                  return this.getModel("task").getData().InstanceID;
              },

              getInboxAPI: function () {
                  var startupParameters = this.getComponentData().startupParameters;
                  return startupParameters.inboxAPI;
              },

              completeTask: function (approvalStatus, outcomeId) {
                  this.getModel("context").setProperty("/approved", approvalStatus);
                  this._patchTaskInstance(outcomeId);
              },

              _patchTaskInstance: function (outcomeId) {
                  const context = this.getModel("context").getData();
                  var data = {
                      status: "COMPLETED",
                      context: { ...context, comment: context.comment || '' },
                      decision: outcomeId
                  };

                  jQuery.ajax({
                      url: `${this._getTaskInstancesBaseURL()}`,
                      method: "PATCH",
                      contentType: "application/json",
                      async: true,
                      data: JSON.stringify(data),
                      headers: {
                          "X-CSRF-Token": this._fetchToken(),
                      },
                  }).done(() => {
                      this._refreshTaskList();
                  })
              },

              _fetchToken: function () {
                  var fetchedToken;

                  jQuery.ajax({
                      url: this._getWorkflowRuntimeBaseURL() + "/xsrf-token",
                      method: "GET",
                      async: false,
                      headers: {
                          "X-CSRF-Token": "Fetch",
                      },
                      success(result, xhr, data) {
                          fetchedToken = data.getResponseHeader("X-CSRF-Token");
                      },
                  });
                  return fetchedToken;
              },

              _refreshTaskList: function () {
                  this.getInboxAPI().updateTask("NA", this.getTaskInstanceID());
              },
          }
      );
  }
);
