sap.ui.define(
    [
      "sap/ui/core/mvc/Controller"
    ],
    function (BaseController) {
      "use strict";
  
      return BaseController.extend("com.jabil.workflowuimodule.controller.App", {
        onInit: async function () {
        },
        onSelectRB: function (oEvent) {
          var getSelected = oEvent.getParameters().selectedIndex;
          this.getView().getModel("context").setProperty("/selectedRB",getSelected);
          if(getSelected == 0) {
            var triggerTypeText = "BU Waiver Required";
          } else if(getSelected == 1 || getSelected == 2) {
            var triggerTypeText = "BU Waiver Not Required";
          } 
          this.getOwnerComponent().getModel("context").setProperty("/BUWaiverStatus", triggerTypeText)
        },
        formatMenuButtonText: function (sDocumentName, sDocumentType) {
          return sDocumentName + "." + sDocumentType;
      },
        onBeforeRendering:  function () {
          // this.loadData()
        },
        onAfterRendering:  function () {
          // this.loadData()
        },
        loadData: async function () {
          var contextData = this.getOwnerComponent().getModel("context").getData();
          const reqId = contextData.CWAGUID;
          console.log(reqId);
          if (reqId) {
            var requestData = await this.getApprovers(reqId);
            var approverData = contextData.CWAApprover;

            var oModel = new sap.ui.model.json.JSONModel(requestData); // Properly creating a JSON model
              this.getView().setModel(oModel, "CWACreateRequestModel");
          }
        },
        getIconSrc: async function (level, name) {
          var contextData = this.getOwnerComponent().getModel("context").getData();
          const reqId = contextData.CWAGUID;
          console.log(reqId);
          if (reqId) {
            var requestData = await this.getApprovers(reqId);
            var approverData = contextData.CWAApprover;
            var filteredApp = requestData.filter(function (approver) {
              return approver.ApproverLevel === level;
            });
            return filteredApp[0].ApproverName;

          }
          return "test";
          // return UploadSetwithTable.getIconForFileType(mediaType, thumbnailUrl);
      },

        getRequestDetails: function(reqId) {
          return new Promise((resolve, reject) => {
              var urlCap = $.sap.getModulePath("com.jabil.workflowuimodule") + "/v2/service/CWARequest/CWADashboardWorkflow?$filter=CWAName eq '" + reqId + "'&$expand=FileID,CWAAttachments,Status,CWAItems($expand=FileID,CWAAttachments($expand=FileID)),CWAApprovers,CWAWFHistory,ToBeCWACurrentApproval";
              
              $.ajax({
                  url: urlCap,
                  type: 'GET',
                  contentType: 'application/json',
                  success: function(oData) {
                    console.log(oData);
                      resolve(oData.d.results);
                  },
                  error: function(oError) {
                      reject(oError);
                  }
              });
          });
        },
        getRejectionReason: function(reqId) {
          return new Promise((resolve, reject) => {
              var urlCap = $.sap.getModulePath("com.jabil.workflowuimodule") + "/v2/odata/v4/cwamaintenance/RejectionReason";
              
              $.ajax({
                  url: urlCap,
                  type: 'GET',
                  contentType: 'application/json',
                  success: function(oData) {
                    console.log(oData);
                      resolve(oData.d.results);
                  },
                  error: function(oError) {
                      reject(oError);
                  }
              });
          });
        },
        getApprovers: function(reqId) {
          return new Promise((resolve, reject) => {
              var urlCap = $.sap.getModulePath("com.jabil.workflowuimodule") + "/v2/service/CWARequest/Approvers?$filter=Parent_ID eq " + reqId;
              
              $.ajax({
                  url: urlCap,
                  type: 'GET',
                  contentType: 'application/json',
                  success: function(oData) {
                    console.log(oData);
                      resolve(oData.d.results);
                  },
                  error: function(oError) {
                      reject(oError);
                  }
              });
          });
        },
        OnDownloadExcel:function (oEvent) {
          var iIndex = parseInt(oEvent.getParameters().item.getBindingContext("context").getPath().charAt(oEvent.getParameters().item.getBindingContext("context").getPath().lastIndexOf("/") + 1));
          var docId = this.getView().getModel("context").getProperty("/FileDocuments")[iIndex].DocID
          var oContextData = this.getView().getModel("context").getData();
          var urlCap = $.sap.getModulePath("com.jabil.workflowuimodule") + "/browser/CWA_REQUEST_REPO/root/" + oContextData.CWAGUID + "?objectId=" + docId;
          window.open(urlCap);
              
        },
        onOpeningFile: function (oEvent) {
          const docId = oEvent.getSource().getUrl();
          var oContextData = this.getView().getModel("context").getData();
          var urlCap = $.sap.getModulePath("com.jabil.workflowuimodule") + "/browser/CWA_REQUEST_REPO/root/" + oContextData.CWAGUID + "?objectId=" + docId;
          var win = window.open(urlCap, '_blank');
          win.focus();
  
        }
      });
    }
  );
  
  