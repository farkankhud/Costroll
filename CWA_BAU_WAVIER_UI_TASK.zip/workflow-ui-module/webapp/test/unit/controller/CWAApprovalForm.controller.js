/*global QUnit*/

sap.ui.define([
	"comjabil/workflow-ui-module/controller/CWAApprovalForm.controller"
], function (Controller) {
	"use strict";

	QUnit.module("CWAApprovalForm Controller");

	QUnit.test("I should test the CWAApprovalForm controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
