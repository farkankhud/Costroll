sap.ui.define([
	"comjabil/workflow-ui-module/test/unit/controller/CWAApprovalForm.controller"
], function () {
	"use strict";
});
